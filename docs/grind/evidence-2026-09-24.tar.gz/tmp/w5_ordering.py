#!/usr/bin/env python3
"""Deliverable 1 — hardcoded cc1-label ordering assessment.

For every rule referencing a hardcoded `.L<N>` (cc1's per-TU counter), decide
whether it is EXPOSED to label drift: a rule drifts only if a body being removed
by the campaign sits BEFORE the rule's owner in the SAME TU's cc1 emission order,
because cc1 numbers .L labels from one per-TU counter in source order.
"""
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from engine import inlineasm

ROOT = Path(__file__).resolve().parent.parent
MAP = json.load(open("tmp/resplit_map.json"))

# same boundary-correct pattern as the fixed HARD_L (erratum 1f8346c2)
HARD_L = re.compile(r'(?<!\{lbl)\.L\d+(?![0-9A-Za-z_])')
RULE = re.compile(r'^([A-Za-z_]\w*)\s*:')

owners = {}
for fname in ("regfix.txt", "asmfix.txt"):
    for i, raw in enumerate((ROOT / fname).read_text(encoding="utf-8").splitlines(), 1):
        s = raw.strip()
        if not s or s.startswith("#"):
            continue
        m = RULE.match(s)
        if m and HARD_L.search(s):
            owners.setdefault(m.group(1), []).append(
                (fname, i, sorted(set(HARD_L.findall(s)))))

# where does each function live, and what does the campaign remove from that TU?
loc, wave_of, targets_in = {}, {}, {}
for stem, t in MAP["tus"].items():
    wave_of[stem] = t.get("wave")
    targets_in[stem] = [f["func"] for f in t["funcs"]]

src_cache = {}
def src(stem):
    if stem not in src_cache:
        src_cache[stem] = (ROOT / f"src/{stem}.c").read_text(encoding="utf-8")
    return src_cache[stem]

def find_stem(func):
    for stem in MAP["tus"]:
        if inlineasm._func_body_span(src(stem), func) is not None:
            return stem
    return None

print("=== Deliverable 1: hardcoded cc1-label rules, ordering vs campaign removals ===\n")
for func, rules in sorted(owners.items()):
    stem = find_stem(func)
    if stem is None:
        print(f"{func}: no C definition in any campaign TU -> already asm-supplied; "
              f"rules listed below are not cc1-drift exposed")
        for fn, ln, labs in rules:
            print(f"    {fn}:{ln}  {labs}")
        print()
        continue
    text = src(stem)
    owner_pos = inlineasm._func_body_span(text, func)[0]
    removed_before, removed_after = [], []
    for tgt in targets_in.get(stem, []):
        sp = inlineasm._func_body_span(text, tgt)
        if sp is None:
            continue
        (removed_before if sp[0] < owner_pos else removed_after).append(tgt)
    exposed = bool(removed_before)
    print(f"{func}  (src/{stem}.c, wave {wave_of.get(stem)})  "
          f"{'*** EXPOSED ***' if exposed else 'SAFE'}")
    for fn, ln, labs in rules:
        print(f"    rule {fn}:{ln}  {labs}")
    print(f"    campaign removals BEFORE it in this TU: {removed_before or 'none'}")
    print(f"    campaign removals AFTER  it in this TU: {removed_after or 'none'}")
    if exposed:
        labels = inlineasm._extract_local_label_defs if False else None
        print(f"    -> MIGRATION NEEDED: rewrite the hardcoded labels as "
              f"{{lbl#N}} slots (function-local, drift-robust).")
    print()
