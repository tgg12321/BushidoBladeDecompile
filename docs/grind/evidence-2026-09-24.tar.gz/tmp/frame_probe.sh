#!/bin/bash
# frame_probe.sh <func> <stem> — print cc1's .frame line for one function (fast
# gradient: vars= IS get_frame_size), without running the full pipeline.
set -uo pipefail
cd "/mnt/c/Users/Trenton/Desktop/Bushido Blade 2 Decompile"
source .venv/bin/activate
FUNC="$1"; STEM="$2"
mipsel-linux-gnu-cpp -Iinclude -undef -Wall -lang-c -fno-builtin \
  -Dmips -D__GNUC__=2 -D__OPTIMIZE__ -D__mips__ -D__mips -Dpsx -D__psx__ -D__psx \
  -D_PSYQ -D__EXTENSIONS__ -D_MIPSEL -D_LANGUAGE_C -DLANGUAGE_C "src/$STEM.c" 2>/dev/null \
| tools/gcc-2.7.2/build/cc1 -O2 -G0 -funsigned-char -quiet -mcpu=3000 -mips1 \
    -mno-abicalls -fno-builtin -w -mel 2>/dev/null \
| awk -v f="$FUNC" '$0 ~ "\\.ent\t"f || $0 ~ "\\.ent "f {p=1} p && /\.frame/ {print; exit}'
