#!/usr/bin/env python3
"""Compare movovl link-map symbol addresses against the known-correct
symbol_addrs.movovl.txt (derived from the original binary) to locate the
points where the built image drifts."""
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MAP = ROOT / "movovl" / "build" / "movovl.map"
SYMS = ROOT / "movovl" / "symbol_addrs.movovl.txt"

want = {}
for line in SYMS.read_text().splitlines():
    m = re.match(r"^\s*(\w+)\s*=\s*(0x[0-9A-Fa-f]+)", line)
    if m:
        want[m.group(1)] = int(m.group(2), 16)

# map body: lines "                0x801d8800                SYMBOL"
got = {}
body = MAP.read_text().splitlines()
start = next(i for i, l in enumerate(body) if l.startswith("Linker script and memory map"))
sec_order = []
for line in body[start:]:
    m = re.match(r"^\s+(0x[0-9a-f]+)\s+([A-Za-z_][\w.]*)\s*$", line)
    if m:
        name = m.group(2)
        if name.endswith(".NON_MATCHING"):
            continue
        got.setdefault(name, int(m.group(1), 16))
    m2 = re.match(r"^ \.(text|rodata|data)\s+(0x[0-9a-f]+)\s+(0x[0-9a-f]+)\s+(\S+)", line)
    if m2:
        sec_order.append((int(m2.group(2), 16), int(m2.group(3), 16), m2.group(4), m2.group(1)))

common = [(want[k], got[k], k) for k in want if k in got]
common.sort()
print(f"{len(common)} symbols compared ({len(want)} wanted, {len(got)} in map)\n")
prev = 0
transitions = []
for w, g, k in common:
    d = g - w
    if d != prev:
        transitions.append((w, g, d, k))
        prev = d
print("delta transitions (vram_expected, vram_built, delta, symbol):")
for w, g, d, k in transitions:
    print(f"  0x{w:08X} -> 0x{g:08X}  delta={d:+d}  {k}")

print("\nsection placements (built) around each transition:")
for w, g, d, k in transitions:
    for i, (addr, size, obj, kind) in enumerate(sec_order):
        if addr <= g < addr + max(size, 1):
            prev_s = sec_order[i - 1] if i else None
            if prev_s:
                gap = addr - (prev_s[0] + prev_s[1])
                print(f"  {k}: in {obj} .{kind} @0x{addr:08X} size=0x{size:x}; "
                      f"prev {prev_s[2]} .{prev_s[3]} end=0x{prev_s[0]+prev_s[1]:08X} gap={gap}")
            break

print("\nall inter-section gaps > 0:")
for i in range(1, len(sec_order)):
    pa, ps, po, pk = sec_order[i - 1]
    a, s, o, kk = sec_order[i]
    if pa == 0:
        continue
    gap = a - (pa + ps)
    if gap:
        print(f"  gap={gap:+d} after {po} .{pk} (end 0x{pa+ps:08X}) before {o} .{kk} (0x{a:08X})")
