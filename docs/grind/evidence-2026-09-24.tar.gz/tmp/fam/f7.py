import re, os, json
BS = chr(92)
ROOT = "C:/Users/Trenton/Desktop/Bushido Blade 2 Decompile/tmp/sotn/src"
files = []
for d, _, fs in os.walk(ROOT):
    for f in fs:
        if f.endswith(('.c', '.h')):
            files.append(os.path.join(d, f).replace(BS, '/'))

store = re.compile(r'^\s*[A-Za-z_][\w\.\->\[\]]*\s*=\s*[^=].*;\s*$')
hits = []
for p in files:
    L = open(p, encoding='utf-8', errors='replace').read().split('\n')
    for i, l in enumerate(L):
        if not re.search(r'\}\s*else\s*\{\s*$', l):
            continue
        # walk back to find the 'if (' opening at same indent
        ind = len(l) - len(l.lstrip())
        # then-arm statements = lines between the if-open and this line
        k = i - 1
        then = []
        while k > 0 and not re.match(r'^\s{%d}(if|\}\s*else\s+if)\s*\(' % ind, L[k]):
            then.append(L[k]); k -= 1
            if i - k > 40:
                break
        then.reverse()
        # else-arm statements until closing brace at same indent
        els = []
        j = i + 1
        while j < len(L) and not re.match(r'^\s{%d}\}' % ind, L[j]):
            els.append(L[j]); j += 1
            if j - i > 40:
                break
        after = L[j + 1] if j + 1 < len(L) else ''
        ts = set(x.strip() for x in then if store.match(x))
        es = set(x.strip() for x in els if store.match(x))
        common = ts & es
        # only interesting if the common store is not the ONLY content
        for c in sorted(common):
            if len(c) < 6:
                continue
            hits.append([p.split('tmp/sotn/')[1], i + 1, c,
                         len(ts), len(es), after.strip()[:50]])

print(len(hits))
json.dump(hits, open("C:/Users/Trenton/Desktop/Bushido Blade 2 Decompile/tmp/fam/f7.json", 'w'), indent=1)
for h in hits[:80]:
    print('%s:%d  DUP-IN-BOTH-ARMS: %s   (then %d / else %d stores)' % (h[0], h[1], h[2], h[3], h[4]))
