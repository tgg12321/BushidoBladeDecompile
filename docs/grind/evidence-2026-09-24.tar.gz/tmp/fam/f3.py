import re, os, json
BS = chr(92)
ROOT = "C:/Users/Trenton/Desktop/Bushido Blade 2 Decompile/tmp/sotn/src"
files = []
for d, _, fs in os.walk(ROOT):
    for f in fs:
        if f.endswith(('.c', '.h')):
            files.append(os.path.join(d, f).replace(BS, '/'))

# split file into brace-balanced top-level function bodies (approximate)
callargs = re.compile(r'\b([A-Za-z_]\w{2,})\s*\(([^();]{4,400})\)')
# a "compound address expression": has & or [] or -> plus arithmetic, length >= 15
def is_compound_addr(a):
    a = a.strip()
    if len(a) < 15:
        return False
    if not re.search(r'[\[\]]|->|\.\w', a):
        return False
    if not re.search(r'[+\-*<>]', a):
        return False
    if a.count('"'):
        return False
    return True

hits = []
for p in files:
    txt = open(p, encoding='utf-8', errors='replace').read()
    lines = txt.split('\n')
    # crude function partition: lines starting at col 0 with '{' ending, to a col-0 '}'
    starts = [i for i, l in enumerate(lines) if re.match(r'^[A-Za-z_].*\)\s*\{\s*$', l)]
    ends = [i for i, l in enumerate(lines) if l.startswith('}')]
    for s in starts:
        e = next((x for x in ends if x > s), len(lines))
        body = lines[s:e]
        seen = {}
        for k, l in enumerate(body):
            for m in callargs.finditer(l):
                fn = m.group(1)
                if fn in ('if', 'for', 'while', 'switch', 'return', 'sizeof'):
                    continue
                # split args at top level commas
                depth = 0
                cur = ''
                args = []
                for ch in m.group(2):
                    if ch in '([':
                        depth += 1
                    elif ch in ')]':
                        depth -= 1
                    if ch == ',' and depth == 0:
                        args.append(cur); cur = ''
                    else:
                        cur += ch
                args.append(cur)
                for a in args:
                    a2 = re.sub(r'\s+', '', a)
                    if is_compound_addr(a):
                        seen.setdefault(a2, []).append((s + k + 1, fn, a.strip()))
        for a2, occ in seen.items():
            fns = set(o[1] for o in occ)
            if len(occ) >= 2:
                hits.append([p.split('tmp/sotn/')[1], [o[0] for o in occ],
                             sorted(fns), occ[0][2], lines[s].strip()[:70]])

print(len(hits))
json.dump(hits, open("C:/Users/Trenton/Desktop/Bushido Blade 2 Decompile/tmp/fam/f3.json", 'w'), indent=1)
for h in hits[:60]:
    print(h[0], h[1], h[2], '|', h[3][:70], '| in', h[4])
