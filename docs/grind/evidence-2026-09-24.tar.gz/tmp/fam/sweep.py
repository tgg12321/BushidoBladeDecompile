import re, os, sys, json
BASE = "C:/Users/Trenton/Desktop/Bushido Blade 2 Decompile/tmp/sotn"
ROOT = BASE + "/src"
BS = chr(92)
files = []
for d, _, fs in os.walk(ROOT):
    for f in fs:
        if f.endswith(('.c', '.h')):
            files.append(os.path.join(d, f).replace(BS, '/'))

def rel(p):
    return p.split('tmp/sotn/')[1]

out = {'F1': [], 'F2': [], 'F6': []}

hexc = re.compile(r'^\s*(\w+)\s*=\s*(0x[0-9A-Fa-f]{3,}|-?\d{3,})\s*;\s*$')
copy = re.compile(r'^\s*(\w+)\s*=\s*(\w+)\s*;\s*$')
inc = re.compile(r'^\s*(\w+(?:->\w+|\.\w+|\[\w+\])*)\s*(\+\+|--)\s*;\s*$')
pre = re.compile(r'^\s*(\+\+|--)\s*(\w+(?:->\w+|\.\w+)*)\s*;\s*$')

for p in files:
    try:
        L = open(p, encoding='utf-8', errors='replace').read().split('\n')
    except Exception:
        continue
    for i, line in enumerate(L):
        m = hexc.match(line)
        if m:
            for j in range(i + 1, min(i + 4, len(L))):
                m2 = copy.match(L[j])
                if m2 and m2.group(2) == m.group(1) and m2.group(1) != m.group(1):
                    out['F1'].append([rel(p), i + 1, line.strip() + '  ||  ' + L[j].strip()])
                    break
        a = inc.match(line)
        apre = pre.match(line) if not a else None
        if a or apre:
            av = a.group(1) if a else apre.group(2)
            ao = a.group(2) if a else apre.group(1)
            for j in range(i + 1, min(i + 3, len(L))):
                b = inc.match(L[j])
                bpre = pre.match(L[j]) if not b else None
                if not (b or bpre):
                    continue
                bv = b.group(1) if b else bpre.group(2)
                bo = b.group(2) if b else bpre.group(1)
                if av == bv and ao != bo:
                    out['F6'].append([rel(p), i + 1, line.strip() + '  ||  ' + L[j].strip()])
                break
    txt = '\n'.join(L)
    for sN, uN in (('s16', 'u16'), ('s8', 'u8'), ('short', 'unsigned short')):
        sset = set(re.findall(r'\(\s*' + re.escape(sN) + r'\s*\)\s*([A-Za-z_][\w\.\[\]]*(?:->\w+)*)', txt))
        uset = set(re.findall(r'\(\s*' + re.escape(uN) + r'\s*\)\s*([A-Za-z_][\w\.\[\]]*(?:->\w+)*)', txt))
        for v in sorted(sset & uset):
            out['F2'].append([rel(p), 0, 'CAST-DUAL (%s)%s AND (%s)%s' % (sN, v, uN, v)])
    ps = set(re.findall(r'\*\(\s*s16\s*\*\)\s*\(?([^;,\)]{2,40})', txt))
    pu = set(re.findall(r'\*\(\s*u16\s*\*\)\s*\(?([^;,\)]{2,40})', txt))
    for v in sorted(ps & pu):
        out['F2'].append([rel(p), 0, 'PTR-DUAL *(s16*)%s AND *(u16*)%s' % (v, v)])

print(json.dumps(dict((k, len(v)) for k, v in out.items())))
json.dump(out, open(BASE + "/../fam/hits.json", 'w'), indent=1)
