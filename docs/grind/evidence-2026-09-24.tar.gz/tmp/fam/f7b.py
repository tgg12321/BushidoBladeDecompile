import re, os, json
BS = chr(92)
ROOT = "C:/Users/Trenton/Desktop/Bushido Blade 2 Decompile/tmp/sotn/src"
files = []
for d, _, fs in os.walk(ROOT):
    for f in fs:
        if f.endswith(('.c', '.h')):
            files.append(os.path.join(d, f).replace(BS, '/'))

hits = []
for p in files:
    L = open(p, encoding='utf-8', errors='replace').read().split('\n')
    for i, l in enumerate(L):
        m = re.match(r'^(\s*)\}\s*else\s*\{\s*$', l)
        if not m:
            continue
        ind = len(m.group(1))
        k = i - 1
        then = []
        while k > 0:
            if re.match(r'^\s{%d}\S' % ind, L[k]):
                break
            then.append(L[k].strip()); k -= 1
            if i - k > 60:
                then = []; break
        then.reverse()
        els = []
        j = i + 1
        while j < len(L):
            if re.match(r'^\s{%d}\}' % ind, L[j]):
                break
            els.append(L[j].strip()); j += 1
            if j - i > 60:
                els = []; break
        then = [x for x in then if x and not x.startswith('//') and not x.startswith('#')]
        els = [x for x in els if x and not x.startswith('//') and not x.startswith('#')]
        if then and then == els:
            hits.append([p.split('tmp/sotn/')[1], i + 1, len(then), ' ;; '.join(then)[:120]])

print('IDENTICAL-ARM if/else count:', len(hits))
json.dump(hits, open("C:/Users/Trenton/Desktop/Bushido Blade 2 Decompile/tmp/fam/f7b.json", 'w'), indent=1)
for h in hits:
    print('%s:%d  (%d stmts)  %s' % (h[0], h[1], h[2], h[3]))
