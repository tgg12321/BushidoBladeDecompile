/* Can STOCK gcc-2.7.2 (transform present) reach `andi $x,$y,3 ; addiu $z,$x,4`?
   Target shape (gnd_disp_loop_ctrl, 0x800175C0):
       andi  $v0, $v0, 0x3
       addiu $s1, $v0, 0x4                                        */
extern int src(void);
extern void sink(int);
extern int gv;

/* v0: as written in src/ings.c today */
unsigned short v0(void) { int v = src(); v &= 3; return v + 4; }

/* v1: single expression */
unsigned short v1(void) { return (src() & 3) + 4; }

/* v2: second use of the masked value (defeat combine substitution) */
unsigned short v2(void) { int v = src(); v &= 3; sink(v); return v + 4; }

/* v3: masked value stored to a global first */
unsigned short v3(void) { int v = src(); v &= 3; gv = v; return v + 4; }

/* v4: mask via modulo */
unsigned short v4(void) { unsigned v = src(); v %= 4u; return v + 4; }

/* v5: signed char carrier */
unsigned short v5(void) { signed char v = src(); v &= 3; return v + 4; }

/* v6: unsigned short carrier for the masked value */
unsigned short v6(void) { unsigned short v = src(); v &= 3; return v + 4; }

/* v7: volatile carrier */
unsigned short v7(void) { volatile int v = src(); v &= 3; return v + 4; }

/* v8: the +4 comes from a variable, not a literal */
unsigned short v8(void) { int v = src(); int k = 4; v &= 3; return v + k; }

/* v9: mask value from a global (nonzero_bits unknown) */
unsigned short v9(void) { int v = src(); v &= gv; return v + 4; }

/* v10: add first, mask after -- different shape entirely */
unsigned short v10(void) { int v = src(); return ((v + 4) & 7); }

/* v11: two sets of the masked pseudo across a branch */
unsigned short v11(int c) { int v = src(); if (c) v &= 3; else v &= 3; return v + 4; }

/* v12: masked value is a loop bound used twice (target's actual role) */
int v12(void) { int i, v = src(); v &= 3; v += 4; for (i = 0; i < v; i++) sink(i); return v; }
