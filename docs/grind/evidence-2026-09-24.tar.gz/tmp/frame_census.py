#!/usr/bin/env python3
"""frame_census.py -- reconnaissance: for every ACTIVE engine/queue.json item,
compare cc1's native frame for the CURRENT source against the target's prologue
frame, and classify the delta. Writes tmp/frame_census.csv.

Method notes (see the CSV `notes` column):
  * our_frame comes from cc1's own `.frame` comment (vars/regs/args are
    get_frame_size / gp_reg_size / outgoing args), harvested one TU at a time so
    the whole tree costs ~31 cc1 runs rather than one per function.
  * cc1 runs BEFORE prologue_fix / frame_fix / regfix / asmfix, so its .frame is
    the honest native frame even for rule-carrying functions. It is NOT honest
    for functions whose SOURCE carries cheat-asm (register pins / __asm__) --
    those are flagged `srcheat` and their numbers should be re-measured after
    the pins come out.
  * target_frame is the `addiu $sp, $sp, -N` in asm/funcs/<func>.s (0 for leaves).
"""
import csv, glob, json, os, re, subprocess, sys

ROOT = os.getcwd()
WORK = "tmp/fcen"
CPP = ("mipsel-linux-gnu-cpp -Iinclude -undef -lang-c -fno-builtin -Dmips "
       "-D__GNUC__=2 -D__OPTIMIZE__ -D__mips__ -D__mips -Dpsx -D__psx__ -D__psx "
       "-D_PSYQ -D__EXTENSIONS__ -D_MIPSEL -D_LANGUAGE_C -DLANGUAGE_C ")
CC1 = ("../../tools/gcc-2.7.2/build/cc1 -O2 -G0 -funsigned-char -quiet -mcpu=3000 "
       "-mips1 -mno-abicalls -fno-builtin -w -mel -da base.c -o base.s")
USE_RE = re.compile(r"^\(insn \d+ \d+ \d+ \(use \(reg:\w+ (\d+)\)\)", re.M)

os.makedirs(WORK, exist_ok=True)

queue = json.load(open("engine/queue.json"))
ONLY_ACTIVE = "--all" not in sys.argv
active = [it for it in queue["items"]
          if it.get("status") == "active" or not ONLY_ACTIVE]
by_file = {}
for it in active:
    by_file.setdefault(it["file"], []).append(it)
print("active items: %d across %d files" % (len(active), len(by_file)), flush=True)


def target_frame(func):
    """(frame_bytes, n_saved_regs) from the target asm; (None, None) if absent."""
    p = "asm/funcs/%s.s" % func
    if not os.path.exists(p):
        return None, None
    txt = open(p, errors="ignore").read()
    m = re.search(r"addiu\s+\$sp,\s*\$sp,\s*-(0x[0-9A-Fa-f]+|\d+)", txt)
    fr = int(m.group(1), 0) if m else 0
    saves = len(re.findall(r"\bsw\s+\$(?:s[0-7]|ra|fp|gp),\s*0x[0-9A-Fa-f]+\(\$sp\)", txt))
    return fr, saves


def body_of(src_text, func):
    """Crude brace-matched C body for heuristics; '' if not found."""
    m = re.search(r"^[A-Za-z_].*\b%s\s*\([^;{]*\)\s*\{" % re.escape(func),
                  src_text, re.M)
    if not m:
        return ""
    i, depth = m.end() - 1, 0
    for j in range(i, min(len(src_text), i + 60000)):
        if src_text[j] == "{":
            depth += 1
        elif src_text[j] == "}":
            depth -= 1
            if depth == 0:
                return src_text[i:j + 1]
    return ""


rows = []
for fstem, items in sorted(by_file.items()):
    cpath = "src/%s.c" % fstem
    if not os.path.exists(cpath):
        for it in items:
            rows.append(dict(status=it.get("status",""), func=it["func"], file=fstem, distance=it["distance"],
                             rules=it["rules"], target_frame="", our_frame="",
                             delta="", cls="no-src", notes="src file missing"))
        continue
    for old in glob.glob(WORK + "/base.c.*"):
        os.remove(old)
    r = subprocess.run(CPP + cpath, shell=True, capture_output=True, text=True)
    open(WORK + "/base.c", "w").write(r.stdout)
    subprocess.run(CC1, shell=True, cwd=WORK, capture_output=True, text=True)
    asm = open(WORK + "/base.s").read() if os.path.exists(WORK + "/base.s") else ""
    frames, cur = {}, None
    for ln in asm.splitlines():
        m = re.match(r"\t\.ent\t(\S+)", ln)
        if m:
            cur = m.group(1); continue
        m = re.search(r"\.frame\t\$sp,(\d+),\$31\s+# vars= (\d+), regs= (\d+)/\d+, "
                      r"args= (\d+)", ln)
        if m and cur:
            frames[cur] = tuple(int(x) for x in m.groups()); cur = None
    comb = (open(WORK + "/base.c.combine").read()
            if os.path.exists(WORK + "/base.c.combine") else "")
    orphans = {}
    for seg in re.split(r"\n;; Function ", comb)[1:]:
        orphans[seg.split("\n", 1)[0].strip()] = len(USE_RE.findall(seg))
    src_text = open(cpath, errors="ignore").read()

    for it in items:
        fn = it["func"]
        tf, tsaves = target_frame(fn)
        got = frames.get(fn)
        note = []
        if got is None:
            rows.append(dict(status=it.get("status",""), func=fn, file=fstem, distance=it["distance"],
                             rules=it["rules"], target_frame=tf if tf is not None else "",
                             our_frame="", delta="", cls="no-cc1-frame",
                             notes="function absent from cc1 output (inlined/renamed/compile miss)"))
            continue
        ofr, ovars, oregs, oargs = got
        body = body_of(src_text, fn)
        stripped = re.sub(r"/\*.*?\*/|//[^\n]*|\s", "", body, flags=re.S)
        if len(stripped) <= 2:
            rows.append(dict(status=it.get("status",""), func=fn, file=fstem, distance=it["distance"],
                             rules=it["rules"],
                             target_frame=tf if tf is not None else "",
                             our_frame=ofr, delta="", cls="empty-c-body",
                             notes="C body is empty — whole body comes from an "
                                   "asmfix splice; frame comparison meaningless"))
            continue
        if re.search(r'asm\s*\(|__asm__|register\s+\w[\w \*]*\s+\w+\s*asm', body):
            note.append("srcheat")
        for am in re.finditer(r"\w+\s+(\w+)\s*\[\s*\d+\s*\]\s*;", body):
            nm = am.group(1)
            if len(re.findall(r"%s" % re.escape(nm), body)) <= 2:
                note.append("deadarr:%s" % nm)
        if orphans.get(fn):
            note.append("orphan=%d" % orphans[fn])
        if re.search(r"\b(while|for)\s*\(", body):
            note.append("loop")
        if re.search(r"if\s*\([^)]*[<>]", body):
            note.append("relguard")
        if re.search(r"\bs16\b|\bu16\b|\(s16\)|\(u16\)", body):
            note.append("hi16")
        note.append("vars=%d/regs=%d/args=%d" % (ovars, oregs, oargs))
        if tsaves is not None:
            note.append("tgt_saves=%d" % tsaves)
        if tf is None:
            cls, delta = "no-target-asm", ""
        else:
            delta = tf - ofr
            if delta == 0:
                cls = "equal"
            elif delta == 8:
                cls = "phantom-8"
            elif delta > 0 and delta % 8 == 0:
                cls = "phantom-%d" % delta
            elif delta > 0:
                cls = "delta-unaligned"
            else:
                cls = "ours-larger"
        rows.append(dict(status=it.get("status",""), func=fn, file=fstem, distance=it["distance"],
                         rules=it["rules"], target_frame=tf if tf is not None else "",
                         our_frame=ofr, delta=delta, cls=cls, notes=" ".join(note)))
    print("  %-16s %d items" % (fstem, len(items)), flush=True)

out = "tmp/frame_census.csv"
with open(out, "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=["status", "func", "file", "distance", "rules",
                                      "target_frame", "our_frame", "delta",
                                      "cls", "notes"])
    w.writeheader()
    for r_ in sorted(rows, key=lambda x: (x["cls"], x["distance"])):
        w.writerow(r_)
print("\nwrote %s (%d rows)" % (out, len(rows)))

from collections import Counter
for c, n in Counter(r_["cls"] for r_ in rows).most_common():
    print("  %-18s %d" % (c, n))
