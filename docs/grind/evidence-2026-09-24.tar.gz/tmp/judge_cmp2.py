import re,struct
tw=[];bw=[];bt=[]
for line in open('asm/funcs/_spu_gcSPU.s'):
    m=re.match(r'\s*/\* [0-9A-F]+ [0-9A-F]+ ([0-9A-F]{8}) \*/',line)
    if m: tw.append(struct.unpack('<I',bytes.fromhex(m.group(1)))[0])
for line in open('tmp/grind/_spu_gcSPU/s1/fn.gate.txt'):
    m=re.match(r'\s*[0-9a-f]+:\t([0-9a-f]{8}) \t(.*)',line)
    if m: bw.append(int(m.group(1),16)); bt.append(m.group(2).strip())
bad=[]
for i,(t,b) in enumerate(zip(tw,bw)):
    if t==b: continue
    op=t>>26
    if op==0 or (b>>26)!=op: bad.append((i,hex(t),hex(b),bt[i],'STRICT')); continue
    if op in (2,3): continue                      # j/jal target
    if op in (1,4,5,6,7):                          # branch: regs must match, disp masked
        if (t>>16)!=(b>>16): bad.append((i,hex(t),hex(b),bt[i],'BR-REG'))
        continue
    if (t>>16)==(b>>16): continue                  # imm-only diff (hi/lo reloc)
    bad.append((i,hex(t),hex(b),bt[i],'IMM-REG'))
print("counts",len(tw),len(bw),"bad",len(bad))
for x in bad[:20]: print(x)
