#!/usr/bin/env python3
"""Independent structural-signal scan over the ASM-STRUCTURAL authorize batch.

Read-only. Emits JSON on stdout. Signals are the ones the hand-coded-asm
recognition rule names that scan_hand_coded.py does NOT compute:
  - splat '/* handwritten instruction */' tags
  - GTE/cop2 opcode presence
  - trapping arithmetic (add/addi/sub/neg -- GCC 2.7.2 emits addu/addiu/subu)
  - unfilled `jr $ra` delay slot (nop in delay)
  - callee-save registers USED but never saved (ghost/custom ABI)
  - callee-save registers SAVED but never used (ghost saves)
  - leaf function (no jal/jalr) that still saves $ra
  - syscall / break / raw .word
"""
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
FUNCS = ROOT / "asm" / "funcs"

INSN = re.compile(r"^\s*/\*\s*([0-9A-Fa-f]+)\s+([0-9A-Fa-f]+)\s+([0-9A-Fa-f]{8})\s*\*/\s*(.*?)\s*$")
GTE = re.compile(r"^(mtc2|mfc2|ctc2|cfc2|cop2|lwc2|swc2|rtps|rtpt|nclip|avsz3|avsz4|mvmva|"
                 r"sqr|op|dcpl|dpcs|dpct|intpl|ncs|nct|ncds|ncdt|nccs|ncct|cdp|cc|gpf|gpl)\b")
TRAP = re.compile(r"^(add|addi|sub|neg)\s")
CALLEE = [f"$s{i}" for i in range(8)] + ["$fp", "$s8"]


def parse(path):
    rows = []
    for line in path.read_text(errors="replace").splitlines():
        m = INSN.match(line)
        if m:
            rows.append((m.group(2), m.group(4), "handwritten instruction" in line))
        elif "handwritten instruction" in line:
            rows.append(("?", line.strip(), True))
    return rows


def analyse(name):
    p = FUNCS / f"{name}.s"
    if not p.exists():
        return {"func": name, "error": "asm not found"}
    rows = parse(p)
    body = [(a, t) for a, t, _ in rows]
    hand = [(a, t) for a, t, h in rows if h]
    gte = [(a, t) for a, t in body if GTE.match(t)]
    trap = [(a, t) for a, t in body if TRAP.match(t)]
    words = [(a, t) for a, t in body if t.startswith(".word") or t.startswith("syscall") or t.startswith("break")]

    has_call = any(t.startswith("jal") for _, t in body)
    saved = set()
    restored = set()
    used = set()
    for _, t in body:
        m = re.match(r"^sw\s+(\$\w+),.*\(\$sp\)", t)
        if m:
            saved.add(m.group(1))
        m = re.match(r"^lw\s+(\$\w+),.*\(\$sp\)", t)
        if m:
            restored.add(m.group(1))
        for r in re.findall(r"\$\w+", t):
            used.add(r)

    callee_used = [r for r in CALLEE if r in used]
    callee_unsaved = [r for r in callee_used if r not in saved]
    callee_ghost = [r for r in saved if r in CALLEE and r not in used]

    # unfilled jr $ra delay slots
    unfilled = []
    for i, (a, t) in enumerate(body):
        if t.startswith("jr") and "$ra" in t and i + 1 < len(body):
            if body[i + 1][1].startswith("nop"):
                unfilled.append(a)

    return {
        "func": name,
        "insns": len(body),
        "handwritten_tags": len(hand),
        "handwritten_examples": hand[:5],
        "gte_ops": len(gte),
        "gte_examples": gte[:5],
        "trapping_ops": len(trap),
        "trapping_examples": trap[:5],
        "raw_word_syscall_break": len(words),
        "leaf": not has_call,
        "leaf_saves_ra": (not has_call) and "$ra" in saved,
        "callee_used": callee_used,
        "callee_used_unsaved": callee_unsaved,
        "callee_saved_unused": callee_ghost,
        "unfilled_jr_ra_delay": unfilled,
    }


if __name__ == "__main__":
    names = sys.argv[1:]
    out = [analyse(n) for n in names]
    json.dump(out, sys.stdout, indent=1)
