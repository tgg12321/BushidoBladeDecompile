#!/usr/bin/env python3
"""Emit the libscan wave's address restriction list.

Source of truth is the MANIFEST, not the census. The census's 16 src-only rows read
their current name from build/bb2.map so they can self-heal after a wave, which makes
a census-derived list depend on whether the map is fresher than the tree — the wrong
thing for a file that just says "consider these addresses". The manifest's renameable
classifications are stable regardless of build order; a row that turns out to need no
work is simply reported by the wave as "nothing to rename".
"""
import csv
import io
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MAN = os.path.join(ROOT, "docs", "naming", "libscan", "rename_manifest.csv")
CEN = os.path.join(ROOT, "docs", "naming", "function-names.csv")
OUT = os.path.join(ROOT, "docs", "naming", "libscan", "wave_addresses.txt")

RENAMEABLE = {"CONTRADICTED", "CONTRADICTED_ALIAS", "FILL"}
rows = [r for r in csv.DictReader(io.open(MAN, encoding="utf-8", errors="replace"))
        if r["proposed_name"] and r["classification"] in RENAMEABLE]

live = {}
if os.path.exists(CEN):
    for c in csv.DictReader(io.open(CEN, encoding="utf-8", errors="replace")):
        live[c["address"].upper()] = c

L = ["# The 2026-08-07 libscan naming wave — the address restriction passed to",
     "#   python3 tools/naming_wave.py --from-census \\",
     "#       --only-file docs/naming/libscan/wave_addresses.txt --apply",
     "#",
     "# Source: docs/naming/libscan/rename_manifest.csv, every row classified",
     "# CONTRADICTED / CONTRADICTED_ALIAS / FILL (i.e. carrying a proposal).",
     "# Excluded by construction: the 52 MODULE_LOCAL_STATIC, 10 AMBIGUOUS and 1",
     "# IN_SPAN_NO_SYMBOL rows (no proposal), the 2 CONFIRM rows (already correct),",
     "# and the 9 mid-function XDEFs (docs/naming/libscan/boundary_fixes.md).",
     "#",
     "# Regenerate with tmp/gen_wave_addrs.py. Once the wave has landed every row here",
     "# reads KEEP in the census and a re-run is a no-op — that is the wave landing.",
     "#",
     "# addr        current name -> Sony XDEF name"]
for r in sorted(rows, key=lambda r: r["addr"]):
    cur = live.get(r["addr"].upper(), {}).get("current_name") or r["current_name"]
    L.append("%-12s # %s -> %s" % (r["addr"], cur, r["proposed_name"]))

io.open(OUT, "w", encoding="utf-8", newline="\n").write("\n".join(L) + "\n")
print("wrote", OUT, len(rows), "addresses")
