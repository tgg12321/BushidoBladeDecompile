#!/usr/bin/env python3
"""Exactly how exposed is mk_leaf_newpos's .L631 rule?"""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from engine import inlineasm

MAP = json.load(open("tmp/resplit_map.json"))
STEM = "code6cac_b"
text = Path(f"src/{STEM}.c").read_text(encoding="utf-8")
targets = [f["func"] for f in MAP["tus"][STEM]["funcs"]]

pos = {}
for f in targets + ["func_80032854", "mk_leaf_newpos"]:
    sp = inlineasm._func_body_span(text, f)
    pos[f] = sp[0] if sp else None

anchor = pos["func_80032854"]
owner = pos["mk_leaf_newpos"]
print(f"src/{STEM}.c is wave {MAP['tus'][STEM]['wave']}, "
      f"{len(targets)} conversion targets\n")
print(f"func_80032854 (DEFINES .L631) at char {anchor} "
      f"{'-- IS a conversion target' if 'func_80032854' in targets else '-- not a target'}")
print(f"mk_leaf_newpos (REFERENCES .L631) at char {owner} "
      f"{'-- IS a conversion target' if 'mk_leaf_newpos' in targets else '-- not a target'}")

before_anchor = [f for f in targets if pos[f] is not None and pos[f] < anchor]
between = [f for f in targets if pos[f] is not None and anchor < pos[f] < owner]
print(f"\nconversion targets BEFORE func_80032854 (these shift .L631's number): "
      f"{len(before_anchor)}")
for f in before_anchor:
    print(f"    {f}")
print(f"\nconversion targets between the definer and the referencer: {between or 'none'}")
