#!/usr/bin/env python3
import re, os, subprocess, sys
os.chdir("/mnt/c/Users/Trenton/Desktop/Bushido Blade 2 Decompile")
T = "tmp/fx"
F = "-O2 -G0 -funsigned-char -quiet -mcpu=3000 -mips1 -mno-abicalls -fno-builtin -w -mel".split()
CPP = ("mipsel-linux-gnu-cpp -undef -lang-c -fno-builtin -Dmips -D__GNUC__=2 -D__OPTIMIZE__ "
       "-D__mips__ -D__mips -Dpsx -D__psx__ -D__psx -D_PSYQ -D_MIPSEL -D_LANGUAGE_C -DLANGUAGE_C").split()
src = sys.argv[1] if len(sys.argv) > 1 else "tmp/fx_sweep.c"
i = f"{T}/sweep.i"
open(i, "wb").write(subprocess.run(CPP + [src], capture_output=True).stdout)
for tag, cc in (("stock", "tmp/ab/cc1.mixed"),
                ("shipped", "tools/gcc-2.7.2/build/cc1"),
                ("cc1psx", None)):
    if cc:
        subprocess.run([cc] + F + [i, "-o", f"{T}/sweep.{tag}.s"], capture_output=True)
    else:
        r = subprocess.run(["tools/cc1psx_wrapper.sh", "-O2", "-G0", "-funsigned-char",
                            "-quiet", "-mcpu=3000", "-mips1", "-w"],
                           stdin=open(i, "rb"), capture_output=True)
        open(f"{T}/sweep.{tag}.s", "wb").write(r.stdout)

def funcs(p):
    out, cur = {}, None
    for l in open(p, errors='replace'):
        m = re.match(r'^(v\d+):\s*$', l)
        if m:
            cur = m.group(1); out[cur] = []; continue
        if cur is None: continue
        if re.match(r'^\s*\.(end|size)\b', l): cur = None; continue
        s = l.strip()
        if not s or s.startswith('.') or s.startswith('#') or s.endswith(':'): continue
        out[cur].append(s)
    return out

S = funcs(f"{T}/sweep.stock.s"); B = funcs(f"{T}/sweep.shipped.s"); P = funcs(f"{T}/sweep.cc1psx.s")
ORI = re.compile(r'^(or|ori)\b')
for k in sorted(S, key=lambda x: int(x[1:])):
    def mark(d):
        b = d.get(k)
        if b is None: return "?"
        return "ORI" if any(ORI.match(x) for x in b) else "add"
    print(f"{k:5} stock={mark(S):3} shipped={mark(B):3} cc1psx={mark(P):3}")
    print(f"       stock:   {' | '.join(S.get(k, []))}")
    if mark(S) != mark(B):
        print(f"       shipped: {' | '.join(B.get(k, []))}")
