import sys,re
body=open(sys.argv[1]).read()
p='src/text1b.c'
s=open(p,'rb').read().decode()
m=re.search(r'(?:INCLUDE_ASM\("asm/funcs", func_80074B18\);\n)|(?:void func_80074B18\([^)]*\) \{.*?\n\}\n)',s,re.S)
assert m, 'no func found'
s=s[:m.start()]+body+s[m.end():]
open(p,'wb').write(s.encode())
print('spliced',sys.argv[1])
