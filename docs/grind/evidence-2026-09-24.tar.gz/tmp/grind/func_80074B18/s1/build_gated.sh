#!/bin/bash
# Byte proof for func_80074B18 WITHOUT touching maspsx_label_nop_funcs.txt:
# reproduce the Makefile pipeline for text1b (non-GP, no expand-lb, no rodata
# align sed, NO_SR empty) with a SCRATCH copy of the label-nop list that adds
# func_80074B18. Output stays in tmp/.
set -e
cd "$(dirname "$0")/../../../.."
S=tmp/grind/func_80074B18/s1
cp maspsx_label_nop_funcs.txt $S/label_nop_scratch.txt
echo func_80074B18 >> $S/label_nop_scratch.txt
CC_FLAGS="-O2 -G0 -funsigned-char -quiet -mcpu=3000 -mips1 -mno-abicalls -fno-builtin -w -mel -msoft-float"
CPP_FLAGS="-Iinclude -undef -Wall -lang-c -fno-builtin"
CPP_DEFS=$(sed -n '43,44p' Makefile | tr -d '\\n' | sed 's/^CPP_DEFS *:= *//')
MASPSX_FLAGS="--expand-div --aspsx-version=2.34 --sdata-syms=sdata_syms.txt --sdata-funcs=sdata_funcs.txt --sdata-exclude=sdata_exclude.txt --expand-lb --expand-lb-funcs=expand_lb_funcs.txt --multu-funcs=multu_funcs.txt --expand-dest-funcs=expand_dest_funcs.txt --label-nop-funcs=$S/label_nop_scratch.txt --prefill-label-funcs=maspsx_prefill_label_funcs.txt"
AS_FLAGS="-Iinclude -march=r3000 -mtune=r3000 -no-pad-sections -O1 -G0"
echo "CPP_DEFS=$CPP_DEFS"
mipsel-linux-gnu-cpp $CPP_FLAGS $CPP_DEFS src/text1b.c \
  | tools/gcc-2.7.2/build/cc1 $CC_FLAGS \
  | python3 tools/prologue_fix.py \
  | python3 tools/maspsx/maspsx.py $MASPSX_FLAGS \
  | python3 tools/multu_pad.py --funcs multu_pad_funcs.txt \
  > $S/gated.s
mipsel-linux-gnu-as $AS_FLAGS -o $S/gated.o $S/gated.s
echo "== gated object built: $S/gated.o"
grep -n -A3 'lw\t\$7,16(\$sp)' $S/gated.s | grep -B1 -A2 'DEBUG\|^.*\.L[0-9]*:' | tail -8
