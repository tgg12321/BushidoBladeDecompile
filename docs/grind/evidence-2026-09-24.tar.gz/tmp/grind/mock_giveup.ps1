@{ result='progress'; floor=99; headline='this function is a wall, blocked, giving up'
   hypotheses=@(); evidence=@(); frontier=@(); artifacts=@(); ruling_question='' } |
   ConvertTo-Json -Depth 4 | Set-Content $env:GRIND_OUTCOME_PATH -Encoding utf8
