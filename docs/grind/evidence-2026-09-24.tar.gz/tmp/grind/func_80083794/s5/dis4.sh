#!/bin/bash
# Disassemble a ws4 permuter proposal through the real pipeline.
set -e
cd "/mnt/c/Users/Trenton/Desktop/Bushido Blade 2 Decompile"
W=tmp/grind/func_80083794/s5/ws4
for n in "$@"; do
  echo "=== $n"
  sed -n '/void func_80083794/,/^}/p' "$W/$n/source.c"
  bash "$W/compile.sh" "$W/$n/source.c" -o "/tmp/w4$n.o"
  mipsel-linux-gnu-objdump -d "/tmp/w4$n.o" \
    | awk '/>:/{p=1;next} p' \
    | sed 's/^[^\t]*\t[^\t]*\t//' | grep -v '^$' | cat -n
done
