"""s107 Ruling-D aggregate-merge probes for CD_sync.

Builds variants of memory/grind/CD_sync/candidate.c in which the three
per-word splat scalars at 0x800A1494/95/96 are replaced by a single
aggregate declaration (the CD_intr merge authorised by owner Ruling D,
2026-09-01).  The aggregate is declared ON the existing splat symbol name
D_800A1494 so that no splat symbol-config change is needed for the
MEASUREMENT (prong (c)/(d) conformance is a separate question, handled in
the session record).

usage: python3 mkprobe.py <variant>
"""
import pathlib, subprocess, sys

root = pathlib.Path(__file__).resolve().parents[4]
here = pathlib.Path(__file__).resolve().parent
MARK = 'INCLUDE_ASM("asm/funcs", CD_sync);'

cand = (root / 'memory/grind/CD_sync/candidate.c').read_text()
head = subprocess.check_output(
    ['git', 'show', 'HEAD:src/system.c'], cwd=root).decode('utf-8', 'replace')

DECL_A = 'extern u8 D_800A1494;\nextern u8 D_800A1495;\n'
AGG = ('typedef struct {\n    u8 sync;\n    u8 ready;\n    u8 c;\n} CD_intr;\n')


def body_members(volatile=True, keep_ptr=False):
    """candidate body with idx_1494 / idx_1495 replaced by aggregate members."""
    b = cand
    # drop the two pointer locals + their (FAKE) initialisers
    b = b.replace('  u8 *idx_1494;\n', '')
    b = b.replace('  u8 *idx_1495;\n', '')
    lines = [l for l in b.split('\n')
             if not l.startswith('  idx_1494 = ') and not l.startswith('  idx_1495 = ')]
    b = '\n'.join(lines)
    if keep_ptr:
        b = b.replace('  s32 v0;\n', '  s32 v0;\n  %sCD_intr *ip;\n'
                      % ('volatile ' if volatile else ''))
        b = b.replace('  tbl_125c = D_800A125C;',
                      '  tbl_125c = D_800A125C;\n  ip = &D_800A1494;')
        sync, ready = 'ip->sync', 'ip->ready'
    else:
        sync, ready = 'D_800A1494.sync', 'D_800A1494.ready'
    b = b.replace('t0 = idx_1494[0];', 't0 = %s;' % sync)
    b = b.replace('ix = idx_1494[1];', 'ix = %s;' % ready)
    b = b.replace('*idx_1495', ready)
    b = b.replace('*idx_1494 = 2;', '%s = 2;' % sync)
    b = b.replace('(*idx_1494)', sync)
    b = b.replace('*idx_1494', sync)
    assert 'idx_149' not in b, [l for l in b.split('\n') if 'idx_149' in l]
    return b


VARIANTS = {}
# P1 volatile aggregate, direct member access everywhere
VARIANTS['p1_vol_direct'] = (AGG + 'extern volatile CD_intr D_800A1494;\n',
                             body_members(True, False))
# P2 volatile aggregate reached through a base pointer (mirrors the target's
#    lbu 0/1($s1) base+offset addressing)
VARIANTS['p2_vol_ptr'] = (AGG + 'extern volatile CD_intr D_800A1494;\n',
                          body_members(True, True))
# P3 non-volatile aggregate, direct member access
VARIANTS['p3_novol_direct'] = (AGG + 'extern CD_intr D_800A1494;\n',
                               body_members(False, False))
# P4 non-volatile aggregate through a base pointer
VARIANTS['p4_novol_ptr'] = (AGG + 'extern CD_intr D_800A1494;\n',
                            body_members(False, True))

name = sys.argv[1]
decl, body = VARIANTS[name]
src = head
assert MARK in src
assert DECL_A in src
# first occurrence (the CD_sync block) becomes the aggregate declaration;
# the duplicate declaration further down (CD_ready block) is dropped.
src = src.replace(DECL_A, decl, 1)
src = src.replace(DECL_A, '', 1)
src = src.replace(MARK, body.rstrip('\n'))
(root / 'src/system.c').write_text(src, newline='\n')
(here / (name + '.c')).write_text(body, newline='\n')
print('wrote variant', name)
