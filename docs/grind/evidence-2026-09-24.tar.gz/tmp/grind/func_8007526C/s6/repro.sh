set -e
cd /mnt/c/Users/Trenton/Desktop/"Bushido Blade 2 Decompile"
source .venv/bin/activate
O=tmp/grind/func_8007526C/s6
CPPF="-Iinclude -undef -Wall -lang-c -fno-builtin -Dmips -D__GNUC__=2 -D__OPTIMIZE__ -D__mips__ -D__mips -Dpsx -D__psx__ -D__psx -D_PSYQ -D__EXTENSIONS__ -D_MIPSEL -D_LANGUAGE_C -DLANGUAGE_C"
CCF="-O2 -G0 -funsigned-char -quiet -mcpu=3000 -mips1 -mno-abicalls -fno-builtin -w -mel"
MB="--expand-div --aspsx-version=2.34 --sdata-syms=sdata_syms.txt --sdata-funcs=sdata_funcs.txt --sdata-exclude=sdata_exclude.txt --expand-lb --expand-lb-funcs=expand_lb_funcs.txt --multu-funcs=multu_funcs.txt --expand-dest-funcs=expand_dest_funcs.txt --prefill-label-funcs=maspsx_prefill_label_funcs.txt"
mipsel-linux-gnu-cpp $CPPF src/text1b.c > $O/text1b.i
cp maspsx_label_nop_funcs.txt $O/labelnop.txt
echo "func_8007526C" >> $O/labelnop.txt
build () { # $1 label-nop list, $2 tag
  tools/gcc-2.7.2/build/cc1 $CCF -quiet < $O/text1b.i 2>/dev/null > $O/$2.s || true
  cat $O/$2.s | python3 tools/prologue_fix.py \
    | python3 tools/maspsx/maspsx.py $MB --label-nop-funcs=$1 \
    | python3 tools/multu_pad.py --funcs multu_pad_funcs.txt \
    | mipsel-linux-gnu-as -Iinclude -march=r3000 -mtune=r3000 -no-pad-sections -O1 -G0 -o $O/$2.o
  mipsel-linux-gnu-objdump -d $O/$2.o > $O/$2.dis
  echo "built $2"
}
build maspsx_label_nop_funcs.txt base
build $O/labelnop.txt gated
