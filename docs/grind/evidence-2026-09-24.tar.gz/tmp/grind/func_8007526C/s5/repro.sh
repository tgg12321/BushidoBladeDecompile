set -e
cd /mnt/c/Users/Trenton/Desktop/"Bushido Blade 2 Decompile"
source .venv/bin/activate
O=tmp/grind/func_8007526C/s5
CPPF="-Iinclude -undef -Wall -lang-c -fno-builtin -Dmips -D__GNUC__=2 -D__OPTIMIZE__ -D__mips__ -D__mips -Dpsx -D__psx__ -D__psx -D_PSYQ -D__EXTENSIONS__ -D_MIPSEL -D_LANGUAGE_C -DLANGUAGE_C"
CCF="-O2 -G0 -funsigned-char -quiet -mcpu=3000 -mips1 -mno-abicalls -fno-builtin -w -mel"
MB="--expand-div --aspsx-version=2.34 --sdata-syms=sdata_syms.txt --sdata-funcs=sdata_funcs.txt --sdata-exclude=sdata_exclude.txt --expand-lb --expand-lb-funcs=expand_lb_funcs.txt --multu-funcs=multu_funcs.txt --expand-dest-funcs=expand_dest_funcs.txt --prefill-label-funcs=maspsx_prefill_label_funcs.txt"
mipsel-linux-gnu-cpp $CPPF src/text1b.c > $O/text1b.i
build () { # $1 extra cc flags, $2 label-nop list, $3 tag
  tools/gcc-2.7.2/build/cc1 $CCF $1 -quiet < $O/text1b.i 2>/dev/null > $O/$3.s || true
  cat $O/$3.s | python3 tools/prologue_fix.py \
    | python3 tools/maspsx/maspsx.py $MB --label-nop-funcs=$2 \
    | python3 tools/multu_pad.py --funcs multu_pad_funcs.txt \
    | mipsel-linux-gnu-as -Iinclude -march=r3000 -mtune=r3000 -no-pad-sections -O1 -G0 -o $O/$3.o
  mipsel-linux-gnu-objdump -d $O/$3.o > $O/$3.dis
  echo "built $3"
}
cp maspsx_label_nop_funcs.txt $O/labelnop.txt
echo "func_8007526C" >> $O/labelnop.txt
build ""             maspsx_label_nop_funcs.txt hard
build "-msoft-float" maspsx_label_nop_funcs.txt soft
build "-msoft-float" $O/labelnop.txt             softnop
