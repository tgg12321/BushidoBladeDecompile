import re,difflib
O='tmp/grind/func_8007526C/s5/'
def load(p):
    return [l.rstrip('\n') for l in open(p)]
a=load(O+'hard.s'); b=load(O+'soft.s')
def owner(lines):
    cur=None; own=[]
    for l in lines:
        m=re.match(r'\s*\.ent\s+(\S+)',l)
        if m: cur=m.group(1)
        own.append(cur)
        if re.match(r'\s*\.end',l): cur=None
    return own
oa=owner(a); ob=owner(b)
sm=difflib.SequenceMatcher(None,a,b,autojunk=False)
funcs={}
nlines=0
for tag,i1,i2,j1,j2 in sm.get_opcodes():
    if tag=='equal': continue
    nlines+=(i2-i1)+(j2-j1)
    for i in range(i1,i2): funcs.setdefault(oa[i] or '<toplevel>',0); funcs[oa[i] or '<toplevel>']+=1
    for j in range(j1,j2): funcs.setdefault(ob[j] or '<toplevel>',0); funcs[ob[j] or '<toplevel>']+=1
print("total diff lines:",nlines)
for k,v in sorted(funcs.items(),key=lambda x:-x[1]): print(f"  {k}: {v}")
