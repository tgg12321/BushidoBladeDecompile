import re,sys
O='tmp/grind/func_8007526C/s5/'
def getfunc(dis,name):
    out=[];on=False
    for l in open(dis):
        m=re.match(r'^[0-9a-f]+ <(.+)>:',l)
        if m: on=(m.group(1)==name); continue
        if on:
            m2=re.match(r'^\s*[0-9a-f]+:\s+([0-9a-f]{8})\s+(.*)$',l)
            if m2: out.append((m2.group(1),m2.group(2).strip()))
            elif not l.strip(): on=False
    return out
def swap(h): return h[6:8]+h[4:6]+h[2:4]+h[0:2]
tg=[]
for l in open('asm/funcs/func_8007526C.s'):
    m=re.search(r'/\* \w+ \w+ (\w{8}) \*/\s+(.*)$',l)
    if m: tg.append((swap(m.group(1)).lower(),m.group(2).strip()))
def MASK(w,t):
    return '________' if re.match(r'^(b|j)',t) else w
for tag in ('hard','soft','softnop'):
    b=getfunc(O+tag+'.dis','func_8007526C')
    n=max(len(tg),len(b)); d=[]
    for i in range(n):
        a=tg[i] if i<len(tg) else ('--------','')
        c=b[i] if i<len(b) else ('--------','')
        if MASK(*a)!=MASK(*c): d.append((i,a,c))
    print(f"== {tag}: target_insns={len(tg)} build_insns={len(b)} masked_diffs={len(d)}")
    for i,a,c in d[:12]: print("  ",i,"T",a,"B",c)
