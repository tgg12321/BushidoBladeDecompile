#!/usr/bin/env python3
"""s11 — score the false-clobber occupancy form with the honest sandbox.

clobA (s11/occ.sh) reproduces the target's ENTIRE instruction stream except the
delay slot at ZERO instruction cost (17 emitted insns, `lw $8,0($4)` ...
`ctc2 $15,$7`, `j $31`) by adding a clobber list naming $2,$3,$5,$6,$7 to the
real fused ctc2 asm. The template writes none of those registers, so the clobber
list is a false statement about the asm made solely to steer reload — the
register-pin cheat in a new spelling. This script measures what the honest
cheat-invisible sandbox makes of it (is the construct stripped, i.e. score-inert
as policy intends, or does it move the honest floor?).

Run from WSL. Splices each body over src/text1b.c:10969-10994 and ALWAYS
restores the file.
"""
import json, pathlib, subprocess

ROOT = pathlib.Path(__file__).resolve().parents[4]
SRC = ROOT / "src" / "text1b.c"
START, END = 10969, 10994

FUSED = '''void func_80052B00(s32 *matrix) {
    s32 t0,t1,t2,t3,t4,t5,t6,t7;
    t0=matrix[0]; t1=matrix[1]; t2=matrix[2]; t3=matrix[3];
    t4=matrix[4]; t5=matrix[5]; t6=matrix[6]; t7=matrix[7];
    __asm__ volatile (
        "ctc2 %0, $0\\n\\tctc2 %1, $1\\n\\tctc2 %2, $2\\n\\tctc2 %3, $3\\n\\t"
        "ctc2 %4, $4\\n\\tctc2 %5, $5\\n\\tctc2 %6, $6\\n\\tctc2 %7, $7"
        :: "r"(t0),"r"(t1),"r"(t2),"r"(t3),"r"(t4),"r"(t5),"r"(t6),"r"(t7));
}'''

CLOB = FUSED.replace(
    '"r"(t6),"r"(t7));',
    '"r"(t6),"r"(t7)\n        : "$2","$3","$5","$6","$7");')

FORMS = {"baseline_head": None, "fused8_banked": FUSED, "clobA_false_clobber": CLOB}

orig = SRC.read_bytes()
lines = orig.decode("utf-8", "surrogateescape").split("\n")
assert lines[START - 1].startswith("void func_80052B00"), lines[START - 1][:60]
assert lines[END - 1] == "}", repr(lines[END - 1])


def sandbox():
    p = subprocess.run(
        ["python3", "-m", "engine.cli", "sandbox", "func_80052B00", "--disable", "all"],
        cwd=ROOT, capture_output=True, text=True)
    out = (p.stdout + p.stderr).strip()
    keep = [l for l in out.splitlines()
            if any(k in l for k in ("score", "insns", "rules", "error", "Error"))]
    return keep[-6:] or out[-300:]


results = {}
try:
    for name, body in FORMS.items():
        if body is not None:
            SRC.write_bytes("\n".join(lines[:START - 1] + body.split("\n") + lines[END:]).encode())
        else:
            SRC.write_bytes(orig)
        results[name] = sandbox()
        print(name, results[name], flush=True)
finally:
    SRC.write_bytes(orig)
    print("restored:", SRC.read_bytes() == orig)

(pathlib.Path(__file__).parent / "score_results.json").write_text(json.dumps(results, indent=2))
