#!/bin/bash
# grind session 11 (escalation/disposition) — func_80052B00.
#
# THE ONE OPEN FRONTIER ITEM inherited from s10: "is there a LEGAL C construct
# that makes a value live ACROSS the fused asm without emitting an instruction?"
# s10 measured occupancy to be the entire register residual (H26) and measured
# the only free channel to be the jr-ra delay slot (H25, capacity 1 of 5 needed).
#
# This script probes the ONE occupancy channel that no session 1-10 form ever
# used: GCC asm operand/clobber machinery on the REAL (non-empty) fused ctc2
# template — a clobber list naming the five registers, and dead "=r" outputs.
# Neither emits an instruction, so if reload honours them the register residual
# closes at zero instruction cost.
#
# MECHANISM PROBES, NOT proposed forms. Nothing here is applied to src/.
set -e
cd "$(dirname "$0")/../../../.."
ROOT=$(pwd); S="$ROOT/tmp/grind/func_80052B00/s11"; CC1="${CC1:-$ROOT/tools/gcc-2.7.2/cc1}"
mkdir -p "$S/dumps"; cd "$S/dumps"

run() {
  local n=$1
  rm -f $n.c.* $n.s
  "$CC1" -O2 -G0 -funsigned-char -quiet -mcpu=3000 -mips1 -mno-abicalls -fno-builtin -w -da $n.c -o $n.s
  echo "##### $n"
  grep -h "Spilling" $n.c.greg | head -2 || echo "  (no spill line)"
  grep -h "got .* delays" $n.c.dbr | head -2 || true
  sed -n "/^$n:/,/\.end/p" $n.s | grep -E "^[[:space:]]+[a-z]" | grep -v "^[[:space:]]*\.set" > $n.body.txt || true
  echo "  emitted insns: $(wc -l < $n.body.txt)"
  cat $n.body.txt
  echo
}

# --- base: the banked honest floor-17 fused-8 body ---------------------------
cat > baseA.c <<'EOF'
typedef signed int s32;
void baseA(s32 *matrix) {
    s32 t0,t1,t2,t3,t4,t5,t6,t7;
    t0=matrix[0]; t1=matrix[1]; t2=matrix[2]; t3=matrix[3];
    t4=matrix[4]; t5=matrix[5]; t6=matrix[6]; t7=matrix[7];
    __asm__ volatile (
        "ctc2 %0, $0\n\tctc2 %1, $1\n\tctc2 %2, $2\n\tctc2 %3, $3\n\t"
        "ctc2 %4, $4\n\tctc2 %5, $5\n\tctc2 %6, $6\n\tctc2 %7, $7"
        :: "r"(t0),"r"(t1),"r"(t2),"r"(t3),"r"(t4),"r"(t5),"r"(t6),"r"(t7));
}
EOF
run baseA

# --- clobA: same asm + clobber list naming $2,$3,$5,$6,$7 --------------------
cat > clobA.c <<'EOF'
typedef signed int s32;
void clobA(s32 *matrix) {
    s32 t0,t1,t2,t3,t4,t5,t6,t7;
    t0=matrix[0]; t1=matrix[1]; t2=matrix[2]; t3=matrix[3];
    t4=matrix[4]; t5=matrix[5]; t6=matrix[6]; t7=matrix[7];
    __asm__ volatile (
        "ctc2 %0, $0\n\tctc2 %1, $1\n\tctc2 %2, $2\n\tctc2 %3, $3\n\t"
        "ctc2 %4, $4\n\tctc2 %5, $5\n\tctc2 %6, $6\n\tctc2 %7, $7"
        :: "r"(t0),"r"(t1),"r"(t2),"r"(t3),"r"(t4),"r"(t5),"r"(t6),"r"(t7)
        : "$2","$3","$5","$6","$7");
}
EOF
run clobA

# --- outB: same asm + five DEAD "=r" outputs (no instruction writes them) ----
cat > outB.c <<'EOF'
typedef signed int s32;
void outB(s32 *matrix) {
    s32 t0,t1,t2,t3,t4,t5,t6,t7;
    s32 d0,d1,d2,d3,d4;
    t0=matrix[0]; t1=matrix[1]; t2=matrix[2]; t3=matrix[3];
    t4=matrix[4]; t5=matrix[5]; t6=matrix[6]; t7=matrix[7];
    __asm__ volatile (
        "ctc2 %5, $0\n\tctc2 %6, $1\n\tctc2 %7, $2\n\tctc2 %8, $3\n\t"
        "ctc2 %9, $4\n\tctc2 %10, $5\n\tctc2 %11, $6\n\tctc2 %12, $7"
        : "=r"(d0),"=r"(d1),"=r"(d2),"=r"(d3),"=r"(d4)
        : "r"(t0),"r"(t1),"r"(t2),"r"(t3),"r"(t4),"r"(t5),"r"(t6),"r"(t7));
}
EOF
run outB

# --- liveC: a ninth value derived from the SAME loads, live across the asm,
#            consumed by nothing emitted (legal-C control for the "free live
#            value" question: does a dead-after-asm live range occupy at all?) -
cat > liveC.c <<'EOF'
typedef signed int s32;
void liveC(s32 *matrix) {
    s32 t0,t1,t2,t3,t4,t5,t6,t7;
    s32 k0,k1,k2,k3,k4;
    t0=matrix[0]; t1=matrix[1]; t2=matrix[2]; t3=matrix[3];
    t4=matrix[4]; t5=matrix[5]; t6=matrix[6]; t7=matrix[7];
    k0=t0; k1=t1; k2=t2; k3=t3; k4=t4;
    __asm__ volatile (
        "ctc2 %0, $0\n\tctc2 %1, $1\n\tctc2 %2, $2\n\tctc2 %3, $3\n\t"
        "ctc2 %4, $4\n\tctc2 %5, $5\n\tctc2 %6, $6\n\tctc2 %7, $7"
        :: "r"(t0),"r"(t1),"r"(t2),"r"(t3),"r"(t4),"r"(t5),"r"(t6),"r"(t7));
    __asm__ volatile ("" :: "r"(k0),"r"(k1),"r"(k2),"r"(k3),"r"(k4));
}
EOF
run liveC
