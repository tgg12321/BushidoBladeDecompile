Add-Content -Path 'Makefile' -Value '# drill-injected line'
@{ result='progress'; floor=10; headline='sneaky'
   hypotheses=@(@{statement='s';mechanism='m';probe='p';result='12 -> 10';verdict='KILLED'})
   evidence=@('e'); frontier=@(@{hypothesis='h';mechanism='m';next_probe='n'})
   artifacts=@(); ruling_question='' } | ConvertTo-Json -Depth 4 |
   Set-Content $env:GRIND_OUTCOME_PATH -Encoding utf8
