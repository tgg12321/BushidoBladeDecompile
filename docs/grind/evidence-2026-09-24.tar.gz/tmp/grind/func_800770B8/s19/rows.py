import re, subprocess, sys
OBJ=sys.argv[1] if len(sys.argv)>1 else "tmp/sandbox/func_800770B8/text1b.o"
TGT="asm/funcs/func_800770B8.s"; FUNC="func_800770B8"
NAMES="zero at v0 v1 a0 a1 a2 a3 t0 t1 t2 t3 t4 t5 t6 t7 s0 s1 s2 s3 s4 s5 s6 s7 t8 t9 k0 k1 gp sp fp ra".split()
n2s={i:NAMES[i] for i in range(32)}
def norm_ours(txt):
    txt=re.sub(r"\$(\d+)", lambda m:"$"+n2s[int(m.group(1))], txt)
    txt=txt.replace("$fp","$s8")
    return txt
out=subprocess.run(["mipsel-linux-gnu-objdump","-d","-Mreg-names=numeric",OBJ],capture_output=True,text=True).stdout
ours=[];cur=None
for line in out.splitlines():
    if line.endswith(">:") and "<" in line: cur=line.split("<")[1].rstrip(">:"); continue
    if cur!=FUNC: continue
    p=line.split("\t")
    if len(p)>=3: ours.append(norm_ours((p[2].strip()+" "+(p[3].strip() if len(p)>3 else "")).strip()))
tgt=[]
pat=re.compile(r"/\* \w+ \w+ (\w{8}) \*/\s+(\S+)\s*(.*)")
for line in open(TGT):
    m=pat.search(line)
    if m: tgt.append((m.group(2)+" "+m.group(3)).strip())
def key(s):
    # opcode + register operands only (drop immediates/targets/symbols)
    s=s.replace(","," ").replace("("," ").replace(")"," ")
    toks=s.split()
    op=toks[0]
    regs=[t for t in toks[1:] if t.startswith("$")]
    return (op,tuple(regs))
lo=int(sys.argv[2]) if len(sys.argv)>2 else 0
hi=int(sys.argv[3]) if len(sys.argv)>3 else 10**9
nd=0
for i in range(max(len(ours),len(tgt))):
    o=ours[i] if i<len(ours) else "---"; t=tgt[i] if i<len(tgt) else "---"
    if key(o)!=key(t):
        nd+=1
        if lo<=i<=hi: print(f"{i:3d} {o:<38} | {t}")
print("TOTAL differing rows:",nd,"  ours",len(ours),"tgt",len(tgt))
