import os, itertools
D = 'tmp/grind/func_800770B8/s20/v'
os.makedirs(D, exist_ok=True)
BASES = {
 'F': 'memory/grind/func_800770B8/candidate.c',
 'C': 'tmp/grind/func_800770B8/s12/perm/Q12.c',
}
def body(p):
    t = open(p, encoding='utf-8', newline='').read()
    i = t.index('\ns32 func_800770B8(s32 arg0') + 1
    return t[i:].rstrip() + '\n'

# --- slack spellings (each -1 insn on the F base, per s13/s18fx) ---
FOR3 = """        for (a2 = 0; a2 < 0xA; a2 = (s16)(a2 + 1)) {
"""
DO3_HEAD = """        a2 = 0;
        do {
"""
def slack_dowhile(t):
    assert FOR3 in t
    t = t.replace(FOR3, DO3_HEAD, 1)
    old = """            }
        }
        t0 = (s16)(t0 + 1);"""
    new = """            }
            a2 = (s16)(a2 + 1);
        } while (a2 < 0xA);
        t0 = (s16)(t0 + 1);"""
    assert old in t
    return t.replace(old, new, 1)

def slack_gate1(t):
    # s18fx: block-local reload of D_800A36A0 feeding both inner cursors
    t = t.replace("""        u8 *base = D_800A36A0;
        u8 *ptr;""", """        u8 *base = D_800A36A0;
        u8 *ptr;
        u8 *b2;""", 1)
    t = t.replace("""        a2 = 0;
""", """        a2 = 0;
        b2 = D_800A36A0;
""", 1)
    n = t.count('D_800A36A0 + (t0 * 10)') + t.count('(t0 * 10) + (s32)D_800A36A0')
    assert n == 2, n
    t = t.replace('(s16 *)(D_800A36A0 + (t0 * 10) + 0x6A)', '(s16 *)(b2 + (t0 * 10) + 0x6A)')
    t = t.replace('(s16 *)(D_800A36A0 + (t0 * 10) + 0x7E)', '(s16 *)(b2 + (t0 * 10) + 0x7E)')
    t = t.replace('(s16 *)((t0 * 10) + (s32)D_800A36A0 + 0x6A)', '(s16 *)((t0 * 10) + (s32)b2 + 0x6A)')
    t = t.replace('(s16 *)((t0 * 10) + (s32)D_800A36A0 + 0x7E)', '(s16 *)((t0 * 10) + (s32)b2 + 0x7E)')
    assert 'b2 + (t0 * 10)' in t or '(s32)b2' in t
    return t

def slack_walk(t):
    old = """                p_6a[a2] = -1;
                p_7e[a2] = 0;"""
    new = """                *p_6a++ = -1;
                *p_7e++ = 0;"""
    assert old in t
    return t.replace(old, new, 1)

SLACK = {'0': lambda t: t, 'D': slack_dowhile, 'G': slack_gate1,
         'E': lambda t: slack_gate1(slack_dowhile(t)),
         'P': slack_walk,
         'Q': lambda t: slack_walk(slack_dowhile(t))}

# --- label devices (s17) ---
CALLBLK = """        s32 *prev = p_old;
        p_old = (s32 *)func_8006E49C(r, D_800A35D8);
        D_800A36A0 = (u8 *)p_old;
        *(s32 *)((u8 *)p_old + 4) = (s32)prev;
        *(s32 *)(D_800A36A0 + 0x30) = 0;
        *(s16 *)(D_800A36A0 + 0x34) = 0;"""
C1BLK = """        s32 *prev = p_old;
        s32 *pn = (s32 *)func_8006E49C(r, D_800A35D8);
        p_old = pn;
        D_800A36A0 = (u8 *)p_old;
        if (r != 0) {
            *(s32 *)((u8 *)p_old + 4) = (s32)prev;
        } else {
            *(s32 *)((u8 *)p_old + 4) = (s32)prev;
        }
        *(s32 *)((u8 *)pn + 0x30) = 0;
        *(s16 *)((u8 *)pn + 0x34) = 0;"""
B1BLK = """        s32 *prev = p_old;
        s32 *pn = (s32 *)func_8006E49C(r, D_800A35D8);
        p_old = pn;
        D_800A36A0 = (u8 *)p_old;
        *(s32 *)((u8 *)p_old + 4) = (s32)prev;
        if (r != 0) {
            *(s32 *)((u8 *)pn + 0x30) = 0;
            *(s16 *)((u8 *)pn + 0x34) = 0;
        }"""
TAIL = """        u8 *p = D_800A36A0;
        *(s32 *)(p + 0x20) = 0;
        *(s32 *)(p + 0x1C) = 0;
        if ((s16)sp[0] < (s16)sp[1]) {
            *(s8 *)(p + 0x64) = (s8)((s16)sp[0] - 3);
        } else {
            *(s8 *)(p + 0x64) = (s8)((s16)sp[1] - 3);
        }"""
TAIL2 = """        p_old = (s32 *)D_800A36A0;
        *(s32 *)((u8 *)p_old + 0x20) = 0;
        *(s32 *)((u8 *)p_old + 0x1C) = 0;
        if ((s16)sp[0] < (s16)sp[1]) {
            *(s8 *)((u8 *)p_old + 0x64) = (s8)((s16)sp[0] - 3);
        } else {
            *(s8 *)((u8 *)p_old + 0x64) = (s8)((s16)sp[1] - 3);
        }"""
def dev(blk):
    def f(t):
        assert CALLBLK in t and TAIL in t
        return t.replace(CALLBLK, blk, 1).replace(TAIL, TAIL2, 1)
    return f
DEV = {'0': lambda t: t, 'c': dev(C1BLK), 'b': dev(B1BLK)}

man = []
for bk, bp in BASES.items():
    base = body(bp)
    for sk, sf in SLACK.items():
        for dk, df in DEV.items():
            t = df(sf(base))
            name = f'{bk}{sk}{dk}'
            open(f'{D}/{name}.c', 'w', encoding='utf-8', newline='').write(t)
            man.append(f'{name}\tbase={bk} slack={sk} device={dk}')
open(f'{D}/manifest.tsv', 'w', encoding='utf-8', newline='').write('\n'.join(man) + '\n')
print(len(man), 'variants')
