import sys, difflib
sys.path.insert(0, "/mnt/c/Users/Trenton/Desktop/Bushido Blade 2 Decompile")
from engine.score import normalized_insns
ref = sys.argv[1] if len(sys.argv) > 1 else "build/src/system.o"
sb = "tmp/sandbox/saEft00Add/system.o"
a = normalized_insns(ref, "saEft00Add")
b = normalized_insns(sb, "saEft00Add")
print(f"ref={len(a)} build={len(b)}")
for i, (x, y) in enumerate(zip(a, b)):
    if x != y:
        for j in range(max(0, i - 2), min(len(a), i + 3)):
            m = "==" if a[j] == (b[j] if j < len(b) else None) else "<<"
            print(f"{j:3d} {m} ref: {a[j]:40s} bld: {b[j] if j < len(b) else '-'}")
        print("---")
