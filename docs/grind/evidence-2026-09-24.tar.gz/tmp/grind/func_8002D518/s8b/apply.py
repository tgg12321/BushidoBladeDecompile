import sys, io
src = "src/code6cac_b.c"
var = sys.argv[1]
lines = io.open(src, newline='').read().split("\n")
# locate function start/end
start = next(i for i,l in enumerate(lines) if l.startswith("s32 func_8002D518("))
# find helper block marker if previously injected
hs = next((i for i,l in enumerate(lines) if l.startswith("/* BB2GRIND-HELPER */")), None)
if hs is not None:
    he = next(i for i,l in enumerate(lines) if l.startswith("/* BB2GRIND-HELPER-END */"))
    del lines[hs:he+1]
    start = next(i for i,l in enumerate(lines) if l.startswith("s32 func_8002D518("))
end = next(i for i,l in enumerate(lines) if i>start and l == "}")
body = io.open(var, newline='').read().rstrip("\n").split("\n")
lines[start:end+1] = body
io.open(src, "w", newline='').write("\n".join(lines))
print("replaced lines", start+1, end+1, "with", len(body))
