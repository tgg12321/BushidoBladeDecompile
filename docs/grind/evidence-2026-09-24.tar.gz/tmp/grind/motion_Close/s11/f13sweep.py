#!/usr/bin/env python3
"""Session 11 (structural) — frontier F13: GUARD / MATERIALISATION-SHAPE surface
on the session-9 GOTO chassis.

Why this is not a re-measurement of a dead axis.  Sessions 2 and 3 swept guard
shape (early return, hoisted guard local, &&-chain, block-local declarations,
declaration-with-initialiser, count-assigned-first, decrement-before-call) and
concluded "the guard shape is inert / costly".  Every one of those measurements
was taken on the do-while-LOOP chassis, i.e. inside the LOOP-NOTE regime where
flow.c weights every reference in the function by loop depth and the two
allocnos are separated by a ~10% priority margin (p 10/8 = 37500 vs count
8/7 = 34285).  Session 9 replaced the chassis with a `goto` loop, which emits no
NOTE_INSN_LOOP_BEG/END at all, so every reference is now counted RAW and the
margin collapsed to 1.4% (p 5/8 = 12500 vs count 5/7 = 14285).  A one-reference
or one-insn lever that was worthless at a 10% margin can be decisive at 1.4%,
so the guard-shape conclusions do NOT transfer and must be re-measured in the
raw regime.  That is the same transfer error FR3 exists to prevent.

Success criteria, in order of value:
  1. score < 13  (would reopen a residual bucket — not expected under H1/F5/F7)
  2. score 13 at do-while(0) wrap depth <= 1  (frontier FR2 / F4b)
  3. a measured KILL of the whole surface, with the allocno table showing why

All cells: p declared first, goto-tail walk, wrap depths 0/1/2 applied to the
first statement of the guard body (which is p's initialiser except where the
variant has none — see V5/V6, where the wrap lands on the following statement
and the cell doubles as a wrap-PLACEMENT probe).

M1 is MEASUREMENT ONLY: a `p = p;` self-assign is a sanctioned-family construct
only under the dead-store FAKE carve-out's prerequisites and must never be
proposed off the back of this sweep; it is here to learn whether flow.c counts a
self-assign as a reference at all (the [[duplicated-statement-into-arms]] rule
says dead stores are deleted BEFORE flow counts, which this cell tests directly
on this function).
"""
import json
import os
import re
import subprocess
import sys

SRC = "src/ings2.c"
OUT = "tmp/grind/motion_Close/s11"
START = "extern s32 D_800A2668;"
END = "\n/* kengo:HIGH"

CPP = ("mipsel-linux-gnu-cpp -Iinclude -undef -Wall -lang-c -fno-builtin "
       "-Dmips -D__GNUC__=2 -D__OPTIMIZE__ -D__mips__ -D__mips -Dpsx -D__psx__ -D__psx "
       "-D_PSYQ -D__EXTENSIONS__ -D_MIPSEL -D_LANGUAGE_C -DLANGUAGE_C")
CC1 = ("tools/gcc-2.7.2/cc1 -O2 -G0 -funsigned-char -quiet -mcpu=3000 -mips1 "
       "-mno-abicalls -fno-builtin -w -mel")

DECLS = ("extern s32 D_800A2668;\n"
         "extern void (*D_8008D070)(void);\n"
         "extern s32 D_00000000;\n")

SIB = """
void func_80083794(void) {
    register void (**p)(void) asm("s0");
    register s32 count asm("s1");

    if (D_800A2668 == 0) {
        D_800A2668 = 1;
        p = &D_8008D070;
        count = (s32)&D_00000000;
        if (count != 0) {
            do {
                register void (*f)(void) asm("t0") = *p;
                p++;
                __asm__ volatile("jalr %0" :: "r"(f) : "ra", "memory");
                __asm__ volatile("addiu $17, $17, -1" : "=r"(count) : "0"(count));
            } while (count != 0);
        }
    }
}
"""


def walk(dec_first=False, f_outer=False):
    """The goto-tail walk, optionally with count-- before the call."""
    inner = ("void (*f)(void) = *p;" if not f_outer else "f = *p;")
    if dec_first:
        stmts = "%s\n                p++;\n                count--;\n                f();" % inner
    else:
        stmts = "%s\n                p++;\n                f();\n                count--;" % inner
    return """if (count != 0) {
        again:
            {
                %s
            }
            if (count != 0) {
                goto again;
            }
        }""" % stmts


def wrap(stmt, depth):
    for _ in range(depth):
        stmt = "do { %s } while (0);" % stmt
    return stmt


PINIT = "p = &D_8008D070;"
CINIT = "count = (s32)&D_00000000;"


def V0_control(d):
    return """
void motion_Close(void) {
    s32 count;
    void (**p)(void);

    if (D_800A2668 != 0) {
        %s
        %s
        %s
    }
}
""" % (wrap(PINIT, d), CINIT, walk())


def V1_early_return(d):
    return """
void motion_Close(void) {
    s32 count;
    void (**p)(void);

    if (D_800A2668 == 0) {
        return;
    }
    %s
    %s
    %s
}
""" % (wrap(PINIT, d), CINIT, walk())


def V2_guard_local(d):
    return """
void motion_Close(void) {
    s32 g;
    s32 count;
    void (**p)(void);

    g = D_800A2668;
    if (g != 0) {
        %s
        %s
        %s
    }
}
""" % (wrap(PINIT, d), CINIT, walk())


def V3_countfirst_assign(d):
    return """
void motion_Close(void) {
    s32 count;
    void (**p)(void);

    if (D_800A2668 != 0) {
        %s
        %s
        %s
    }
}
""" % (CINIT, wrap(PINIT, d), walk())


def V4_blocklocal_decls(d):
    return """
void motion_Close(void) {
    if (D_800A2668 != 0) {
        s32 count;
        void (**p)(void);

        %s
        %s
        %s
    }
}
""" % (wrap(PINIT, d), CINIT, walk())


def V5_declinit(d):
    """No init statements in the guard body — the wrap lands on the walk."""
    return """
void motion_Close(void) {
    void (**p)(void) = &D_8008D070;
    s32 count = (s32)&D_00000000;

    if (D_800A2668 != 0) {
        %s
    }
}
""" % wrap(walk(), d)


def V6_f_outer(d):
    return """
void motion_Close(void) {
    s32 count;
    void (**p)(void);
    void (*f)(void);

    if (D_800A2668 != 0) {
        %s
        %s
        %s
    }
}
""" % (wrap(PINIT, d), CINIT, walk(f_outer=True))


def V7_dec_before_call(d):
    return """
void motion_Close(void) {
    s32 count;
    void (**p)(void);

    if (D_800A2668 != 0) {
        %s
        %s
        %s
    }
}
""" % (wrap(PINIT, d), CINIT, walk(dec_first=True))


def V8_guard_inside(d):
    """The D_800A2668 guard tested AFTER p is materialised (materialisation
    hoisted above the guard) — moves p's birth earlier without moving count's."""
    return """
void motion_Close(void) {
    s32 count;
    void (**p)(void);

    %s
    if (D_800A2668 != 0) {
        %s
        %s
    }
}
""" % (wrap(PINIT, d), CINIT, walk())


def M1_self_assign(d):
    """MEASUREMENT ONLY — never propose off this cell."""
    return """
void motion_Close(void) {
    s32 count;
    void (**p)(void);

    if (D_800A2668 != 0) {
        %s
        p = p;
        %s
        %s
    }
}
""" % (wrap(PINIT, d), CINIT, walk())


VARIANTS = [
    ("V0_control", V0_control),
    ("V1_early_return", V1_early_return),
    ("V2_guard_local", V2_guard_local),
    ("V3_countfirst_assign", V3_countfirst_assign),
    ("V4_blocklocal_decls", V4_blocklocal_decls),
    ("V5_declinit", V5_declinit),
    ("V6_f_outer", V6_f_outer),
    ("V7_dec_before_call", V7_dec_before_call),
    ("V8_guard_inside", V8_guard_inside),
    ("M1_self_assign", M1_self_assign),
]


def patch(region):
    i = ORIG.index(START)
    j = ORIG.index(END, i)
    with open(SRC, "w", newline="\n") as fh:
        fh.write(ORIG[:i] + DECLS + SIB + region + ORIG[j:])


def sandbox():
    r = subprocess.run(
        [sys.executable, "-m", "engine.cli", "sandbox", "motion_Close", "--disable", "all"],
        capture_output=True, text=True)
    m = re.search(r"\{.*\}", r.stdout, re.S)
    if not m:
        return {"error": (r.stdout[-300:] + r.stderr[-300:]).replace("\n", " ")}
    return json.loads(m.group(0))


def allocdbg(name):
    i_path = f"{OUT}/probe.i"
    with open(i_path, "w") as fh:
        subprocess.run(CPP.split() + [SRC], stdout=fh, stderr=subprocess.DEVNULL)
    env = dict(os.environ, BB2_ALLOC_DEBUG="1")
    r = subprocess.run(CC1.split() + [i_path, "-o", f"{OUT}/f13_{name}.s"],
                       capture_output=True, text=True, env=env)
    return [re.sub(r"^\s*ALLOCDBG func=\S+ ", "", l)
            for l in r.stderr.splitlines()
            if "func=motion_Close" in l and "ord=" in l]


with open(SRC) as fh:
    ORIG = fh.read()

res = {}
try:
    for vname, gen in VARIANTS:
        for depth in (0, 1, 2):
            name = "%s_d%d" % (vname, depth)
            patch(gen(depth))
            s = sandbox()
            res[name] = s.get("score")
            print(f"=== {name}  score={s.get('score')} insns={s.get('build_insns')} "
                  f"{str(s.get('error',''))[:160]}", flush=True)
            for row in allocdbg(name):
                print("      " + row, flush=True)
finally:
    with open(SRC, "w", newline="\n") as fh:
        fh.write(ORIG)

print("\n=== SUMMARY ===")
for k, v in sorted(res.items(), key=lambda kv: (kv[1] is None, kv[1])):
    print(f"{k:26s} score={v}")
