.set noat
.set noreorder
.text
.align 2
.globl motion_Close
motion_Close:
    lui     $t0, %hi(D_800A2668)
    lw      $t0, %lo(D_800A2668)($t0)
    addiu   $sp, $sp, -16
    sw      $s0, 4($sp)
    sw      $s1, 8($sp)
    sw      $ra, 12($sp)
    beqz    $t0, .Lend
    nop
    lui     $s0, %hi(D_8008D070)
    addiu   $s0, $s0, %lo(D_8008D070)
    lui     $s1, %hi(D_00000000)
    addiu   $s1, $s1, %lo(D_00000000)
    beqz    $s1, .Lend
    nop
.Lloop:
    lw      $t0, 0($s0)
    addiu   $s0, $s0, 4
    jalr    $t0
    addiu   $s1, $s1, -1
    bnez    $s1, .Lloop
    nop
.Lend:
    lw      $ra, 12($sp)
    lw      $s1, 8($sp)
    lw      $s0, 4($sp)
    addiu   $sp, $sp, 16
    jr      $ra
    nop
