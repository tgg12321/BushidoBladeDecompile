import re, glob, json, os
inc=set()
for f in glob.glob('src/*.c'):
    t=open(f,errors='ignore').read()
    for m in re.finditer(r'INCLUDE_ASM\("asm/funcs",\s*(\w+)\)', t): inc.add(m.group(1))
    for m in re.finditer(r'glabel (\w+)', t): inc.add(m.group(1))
canon=set()
for line in open('inline_asm_canonical.txt',errors='ignore'):
    line=line.split('#')[0].strip()
    if line: canon.add(line.split()[0].strip(':'))
allf={os.path.basename(p)[:-2] for p in glob.glob('asm/funcs/*.s')}
pureC=allf-inc-canon
d=json.load(open('tmp/grind/motion_Close/s14/prov_census.json'))
asc=[n for n,_ in d['asc']]
am=[n for n in asc if n in pureC]
print("pure-C matched fns:",len(pureC))
print("ascending-save + PURE-C-matched:",len(am))
print("  sample:",am[:30])
c=json.load(open('tmp/grind/motion_Close/s14/cfoas_census.json'))
print("cfoas<16 fns:",[r[0] for r in c['sub']])
