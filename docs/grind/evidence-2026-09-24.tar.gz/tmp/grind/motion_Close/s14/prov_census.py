import re, glob, os, json
INSN = re.compile(r'^\s*/\*\s*\S+\s+(\S+)\s+\S+\s*\*/\s+(\S+)\s+(.*)$')
SW = re.compile(r'^sw$')
CALL = re.compile(r'^(jal|jalr)$')
COND = re.compile(r'^(beq|bne|beqz|bnez|blez|bgtz|bltz|bgez)$')
save_asc=[]; save_desc=[]; other=[]
nopstat=[]
for f in sorted(glob.glob('asm/funcs/*.s')):
    name=os.path.basename(f)[:-2]
    ins=[]
    for line in open(f, errors='ignore'):
        m=INSN.match(line)
        if m: ins.append((m.group(2), m.group(3).strip(), m.group(1)))
    if not ins: continue
    if not any(CALL.match(o) for o,_,_ in ins): continue
    # save block: leading run of sw $sX/$ra,off($sp)
    saves=[]
    for o,a,_ in ins[:12]:
        m=re.match(r'\$(s[0-7]|ra|fp|gp|s8),\s*(0x[0-9A-Fa-f]+|\d+)\(\$sp\)', a)
        if o=='sw' and m: saves.append(int(m.group(2),0))
    if len(saves)>=2:
        if saves==sorted(saves): save_asc.append((name,saves))
        elif saves==sorted(saves,reverse=True): save_desc.append((name,saves))
        else: other.append((name,saves))
    # unfilled conditional-branch delay slots
    tot=0; nops=0
    for i,(o,a,_) in enumerate(ins[:-1]):
        if COND.match(o):
            tot+=1
            if ins[i+1][0]=='nop': nops+=1
    if tot: nopstat.append((name, nops, tot))
print("call-making fns with >=2 leading sp-saves:", len(save_asc)+len(save_desc)+len(other))
print("  ASCENDING save order:", len(save_asc), [n for n,_ in save_asc][:20])
print("  DESCENDING save order:", len(save_desc))
print("  mixed:", len(other), [n for n,_ in other][:10])
allnop=[(n,a,b) for n,a,b in nopstat if a==b and b>=2]
print("call-making fns where EVERY conditional branch (>=2) has an unfilled nop slot:", len(allnop))
print("   ", allnop[:30])
mc=[x for x in nopstat if x[0] in ('motion_Close','func_80083794')]
print("motion pair nop stats:", mc)
tot=sum(b for _,_,b in nopstat); nn=sum(a for _,a,_ in nopstat)
print("binary-wide conditional-branch delay slots: %d, unfilled: %d (%.1f%%)"%(tot,nn,100.0*nn/tot))
json.dump({"asc":save_asc,"mixed":other,"allnop":allnop}, open('tmp/grind/motion_Close/s14/prov_census.json','w'), indent=1)
