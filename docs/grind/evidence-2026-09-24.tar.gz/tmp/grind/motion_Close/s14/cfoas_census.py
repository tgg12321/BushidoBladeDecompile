import re, glob, os, json
SAVED = re.compile(r'\bsw\s+\$(s[0-7]|ra|fp|gp|s8),\s*(0x[0-9A-Fa-f]+|\d+)\(\$sp\)')
FRAME = re.compile(r'\baddiu\s+\$sp,\s*\$sp,\s*-(0x[0-9A-Fa-f]+|\d+)\b')
CALL  = re.compile(r'^\s*/\*[^*]*\*/\s+(jal|jalr)\b', re.M)
rows=[]
for f in sorted(glob.glob('asm/funcs/*.s')):
    txt=open(f, errors='ignore').read()
    if not CALL.search(txt): continue
    fr=FRAME.search(txt)
    if not fr: continue
    frame=int(fr.group(1),0)
    offs=[int(m.group(2),0) for m in SAVED.finditer(txt)]
    if not offs: continue
    name=os.path.basename(f)[:-2]
    addr=re.search(r'([0-9A-F]{8})\s+[0-9A-F]{8}\s*\*/', txt)
    rows.append((name, frame, min(offs), len(offs), sorted(offs)))
sub=[r for r in rows if r[2] < 16]
print("call-making functions with saves+frame:", len(rows))
print("with a callee-save/ra stored below offset 16 (=> outgoing-arg area < 16):", len(sub))
for r in sub: print("   ", r)
json.dump({"total":len(rows),"sub":sub}, open('tmp/grind/motion_Close/s14/cfoas_census.json','w'), indent=1)
