# motion_Close — instruction-level residual table at the honest floor of 13 (session 7)

Chassis: `memory/grind/motion_Close/candidate.c` applied to `src/ings2.c`.
Measured this session: `sandbox motion_Close --disable all` →
`score 13, target_insns 26, build_insns 25`.

Streams taken from `tmp/grind/motion_Close/s5b/wsA/_tgt_mine.txt` (target, 26
insns + relocation records) and `_base.txt` (honest build, 25 insns), which the
session-4 setup verified byte-identical against
`objdump -dr build/src/ings2.o` for the target region.

| # | TARGET | BUILD | differs? | bucket / mechanism |
|---|--------|-------|----------|--------------------|
| 1 | `lui $t0, %hi(D_800A2668)` | `lui $v0, %hi(...)` | YES | temp register — **F5** (killed s5b) |
| 2 | `lw $t0, %lo(D_800A2668)` | `lw $v0, %lo(...)` | YES | temp register — **F5** |
| 3 | `addiu $sp,$sp,-16` | `addiu $sp,$sp,-32` | YES | frame size — **H1** (killed s1) |
| 4 | `sw $s0,4($sp)` | `sw $ra,24($sp)` | YES | save order + offsets — **F7a** (order, killed s6) + **H1** (offsets) |
| 5 | `sw $s1,8($sp)` | `sw $s1,20($sp)` | YES | save offsets — **H1** |
| 6 | `sw $ra,12($sp)` | `sw $s0,16($sp)` (in the beqz delay slot) | YES | save order — **F7a**; slot fill — **F7b** (killed s6) |
| 7 | `beq $t0,$zero,+13` | `beq $v0,$zero,+13` | YES | temp register — **F5** |
| 8 | `nop` (empty delay slot) | — (build has no insn here; `sw $s0` was pulled in) | YES | empty delay slot — **F7b** |
| 9 | `lui $s0,%hi(D_8008D070)` | same | no | — |
| 10 | `addiu $s0,%lo(D_8008D070)` | same | no | — |
| 11 | `lui $s1,%hi(D_00000000)` | same | no | — |
| 12 | `addiu $s1,%lo(D_00000000)` | same | no | — |
| 13 | `beq $s1,$zero,+7` | same | no | — |
| 14 | `nop` | same | no | — |
| 15 | `lw $t0,0($s0)` | `lw $v0,0($s0)` | YES | temp register — **F5** |
| 16 | `addiu $s0,$s0,4` | same | no | — |
| 17 | `jalr $t0` | `jalr $v0` | YES | temp register — **F5** |
| 18 | `addiu $s1,$s1,-1` | same | no | — |
| 19 | `bne $s1,$zero,-5` | same | no | — |
| 20 | `nop` | same | no | — |
| 21 | `lw $ra,12($sp)` | `lw $ra,24($sp)` | YES | epilogue offset — **H1** |
| 22 | `lw $s1,8($sp)` | `lw $s1,20($sp)` | YES | epilogue offset — **H1** |
| 23 | `lw $s0,4($sp)` | `lw $s0,16($sp)` | YES | epilogue offset — **H1** |
| 24 | `addiu $sp,$sp,16` | `addiu $sp,$sp,32` | YES | frame size — **H1** |
| 25 | `jr $ra` | same | no | — |
| 26 | `nop` | same | no | — |

**13 differing positions, and the measured score is 13.** The attribution is
therefore exhaustive — there is no unexplained instruction anywhere in the
function.

Bucket totals:
* **F5** (the guard/call temp is `$v0` where the target uses `$t0`) — 5 positions
  (1, 2, 7, 15, 17). KILLED s5b: `local-alloc.c:2249-2262` and
  `global.c:1057-1062/1203-1209` scan hard registers in ascending numeric order
  because the MIPS backend defines no `REG_ALLOC_ORDER`, so `$v0` (hard reg 2) is
  taken whenever free; reaching `$t0` (hard reg 8) needs regs 2-7 all excluded,
  i.e. six simultaneously live call-clobbered values that the target's byte
  stream does not contain.
* **H1** (frame size + save/restore offsets) — 6 positions (3, 5, 21, 22, 23, 24)
  plus the offset half of 4. KILLED s1 by census, and KILLED s7 at the backend
  level — see `f9probe.sh` / `f9probe2.sh` in this directory.
* **F7a/F7b** (ascending save order, and the empty `beqz` delay slot) — positions
  4 (order half), 6 and 8. KILLED s6 with corpus measurements (2 instances of the
  save shape in 1788 functions, both this cheat-carrying crt0 pair; 0 compiled-C
  counterexamples for the empty slot).

Every one of the 13 points is attributed to a mechanism that has been killed with
a measurement, not to an unexplored search direction.

Caveat on alignment: the build is one instruction shorter than the target
(position 8), so the table above uses the natural semantic alignment rather than
a strict positional zip. Under that alignment the differing-position count is
exactly the engine's reported score of 13.
