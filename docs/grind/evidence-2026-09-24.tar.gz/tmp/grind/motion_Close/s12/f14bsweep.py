#!/usr/bin/env python3
"""Session 12 (structural) - F14 follow-up: can the IN-WALK wrap's reference
lift be had WITHOUT the 26th instruction it costs?

f14sweep.py established: a do-while(0) placed inside the walk lifts p by
1 (read) / 2 (bump) / 3 (read+bump) weighted references per level, so p wins
$s0 at ONE wrap level instead of two - but every in-walk cell emits 26
instructions instead of 25 and scores 15 (or 21 when the roles are not won).
The stream diff says why: with the bump wrapped, `addu $16,$16,4` is scheduled
INTO the jal delay slot instead of ahead of the call, which leaves the
`lw $2,0($16)` feeding `jal $31,$2` back-to-back, and maspsx inserts a
load-delay nop between them.  The target (like the depth-2 control) has
`addu $16,$16,4` BETWEEN the lw and the jal and `addu $17,$17,-1` in the jal
delay slot.

So the question this sweep answers: is the schedule change a fixed
consequence of the loop note landing inside the walk, or is it an artefact of
WHICH statement the note isolates?  If some in-walk placement keeps the
target's loop schedule while still lifting p, floor 13 becomes reachable at
wrap depth 1 (frontier FR2).

X6 is the isolating diagnostic: an EMPTY do-while(0) between the bump and the
call adds no reference to either allocno, so if it alone produces the 26th
instruction the fence is the note, not the wrapped statement.
"""
import json
import os
import re
import subprocess
import sys

SRC = "src/ings2.c"
OUT = "tmp/grind/motion_Close/s12"
START = "extern s32 D_800A2668;"
END = "\n/* kengo:HIGH"

CPP = ("mipsel-linux-gnu-cpp -Iinclude -undef -Wall -lang-c -fno-builtin "
       "-Dmips -D__GNUC__=2 -D__OPTIMIZE__ -D__mips__ -D__mips -Dpsx -D__psx__ -D__psx "
       "-D_PSYQ -D__EXTENSIONS__ -D_MIPSEL -D_LANGUAGE_C -DLANGUAGE_C")
CC1 = ("tools/gcc-2.7.2/cc1 -O2 -G0 -funsigned-char -quiet -mcpu=3000 -mips1 "
       "-mno-abicalls -fno-builtin -w -mel")

DECLS = ("extern s32 D_800A2668;\n"
         "extern void (*D_8008D070)(void);\n"
         "extern s32 D_00000000;\n")

SIB = """
void func_80083794(void) {
    register void (**p)(void) asm("s0");
    register s32 count asm("s1");

    if (D_800A2668 == 0) {
        D_800A2668 = 1;
        p = &D_8008D070;
        count = (s32)&D_00000000;
        if (count != 0) {
            do {
                register void (*f)(void) asm("t0") = *p;
                p++;
                __asm__ volatile("jalr %0" :: "r"(f) : "ra", "memory");
                __asm__ volatile("addiu $17, $17, -1" : "=r"(count) : "0"(count));
            } while (count != 0);
        }
    }
}
"""

PINIT = "p = &D_8008D070;"
CINIT = "count = (s32)&D_00000000;"


def wrap(stmt, depth):
    for _ in range(depth):
        stmt = "do { %s } while (0);" % stmt
    return stmt


def build(inner, decls="    s32 count;\n    void (**p)(void);"):
    return """
void motion_Close(void) {
%s
    if (D_800A2668 != 0) {
        %s
        %s
        if (count != 0) {
        again:
            {
                %s
            }
            if (count != 0) {
                goto again;
            }
        }
    }
}
""" % (decls, PINIT, CINIT, inner)


DF = "    s32 count;\n    void (**p)(void);\n    void (*f)(void);"


def X0_control(d):
    """f14 W1: wrap the bump only, call then decrement (scores 15 at d>=1)."""
    return build("void (*f)(void) = *p;\n                %s\n                f();"
                 "\n                count--;" % wrap("p++;", d))


def X1_dec_before_call(d):
    """Bump wrapped, decrement moved ahead of the call (s11 V7 is free at 13),
    to give the scheduler a second candidate for the jal delay slot."""
    return build("void (*f)(void) = *p;\n                %s\n                count--;"
                 "\n                f();" % wrap("p++;", d))


def X2_bump_and_call(d):
    """The note encloses the bump AND the call, so it cannot fence between
    them."""
    return build("%s\n                count--;"
                 % wrap("f = *p; p++; f();", d), decls=DF)


def X3_read_and_bump_dec_first(d):
    """Read+bump pair wrapped (3 refs/level) with the decrement ahead of the
    call."""
    return build("%s\n                count--;\n                f();"
                 % wrap("f = *p; p++;", d), decls=DF)


def X4_bump_after_call(d):
    """Bump wrapped and moved AFTER the call (f is already loaded)."""
    return build("void (*f)(void) = *p;\n                f();\n                %s"
                 "\n                count--;" % wrap("p++;", d))


def X6_empty_note(d):
    """DIAGNOSTIC: an EMPTY wrap between the bump and the call - zero extra
    references for either allocno.  Isolates note-as-fence from
    statement-in-note."""
    return build("void (*f)(void) = *p;\n                p++;\n                %s"
                 "\n                f();\n                count--;" % wrap("", d))


def X7_outer_plus_bump(d):
    """One level on p's initialiser AND one level on the bump (depth d each) -
    the cheapest split that reaches 6 weighted refs at d=1."""
    return """
void motion_Close(void) {
    s32 count;
    void (**p)(void);

    if (D_800A2668 != 0) {
        %s
        %s
        if (count != 0) {
        again:
            {
                void (*f)(void) = *p;
                %s
                count--;
                f();
            }
            if (count != 0) {
                goto again;
            }
        }
    }
}
""" % (wrap(PINIT, d), CINIT, wrap("p++;", d))


VARIANTS = [
    ("X0_control", X0_control),
    ("X1_dec_before_call", X1_dec_before_call),
    ("X2_bump_and_call", X2_bump_and_call),
    ("X3_pair_dec_first", X3_read_and_bump_dec_first),
    ("X4_bump_after_call", X4_bump_after_call),
    ("X6_empty_note", X6_empty_note),
    ("X7_outer_plus_bump", X7_outer_plus_bump),
]


def patch(region):
    i = ORIG.index(START)
    j = ORIG.index(END, i)
    with open(SRC, "w", newline="\n") as fh:
        fh.write(ORIG[:i] + DECLS + SIB + region + ORIG[j:])


def sandbox():
    r = subprocess.run(
        [sys.executable, "-m", "engine.cli", "sandbox", "motion_Close", "--disable", "all"],
        capture_output=True, text=True)
    m = re.search(r"\{.*\}", r.stdout, re.S)
    if not m:
        return {"error": (r.stdout[-300:] + r.stderr[-300:]).replace("\n", " ")}
    return json.loads(m.group(0))


def allocdbg(name):
    i_path = f"{OUT}/probe.i"
    with open(i_path, "w") as fh:
        subprocess.run(CPP.split() + [SRC], stdout=fh, stderr=subprocess.DEVNULL)
    env = dict(os.environ, BB2_ALLOC_DEBUG="1")
    r = subprocess.run(CC1.split() + [i_path, "-o", f"{OUT}/f14b_{name}.s"],
                       capture_output=True, text=True, env=env)
    return [re.sub(r"^\s*ALLOCDBG func=\S+ ", "", l)
            for l in r.stderr.splitlines()
            if "func=motion_Close" in l and "ord=" in l]


with open(SRC) as fh:
    ORIG = fh.read()

res = {}
try:
    for vname, gen in VARIANTS:
        for depth in (1, 2):
            name = "%s_d%d" % (vname, depth)
            patch(gen(depth))
            s = sandbox()
            res[name] = (s.get("score"), s.get("build_insns"))
            print(f"=== {name}  score={s.get('score')} insns={s.get('build_insns')} "
                  f"{str(s.get('error',''))[:160]}", flush=True)
            for row in allocdbg(name):
                print("      " + row, flush=True)
finally:
    with open(SRC, "w", newline="\n") as fh:
        fh.write(ORIG)

print("\n=== SUMMARY ===")
for k, v in sorted(res.items(), key=lambda kv: (kv[1][0] is None, kv[1])):
    print(f"{k:26s} score={v[0]} insns={v[1]}")
