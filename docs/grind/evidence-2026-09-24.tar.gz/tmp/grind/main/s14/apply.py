#!/usr/bin/env python3
"""s14 standing procedure: reapply memory/grind/main/candidate.c to src/ings.c.
Edits (per candidate.c header):
  1. func_80016A8C signature -> (u8 *arg0, u8 *arg1, s32 arg2)
  2. func_80016E60 signature -> (u8 *arg0, s32 arg1)
  3+4. Replace the whole `void main(void)` function body with candidate lines 44..end.
Preserves LF (binary read/write)."""
import sys

SRC = "src/ings.c"
CAND = "memory/grind/main/candidate.c"

src = open(SRC, "rb").read().decode("utf-8").split("\n")
cand = open(CAND, "rb").read().decode("utf-8").split("\n")

# candidate body: from the 'void main(void) {' line to the final '}'
mstart = next(i for i, l in enumerate(cand) if l.startswith("void main(void)"))
body = cand[mstart:]
while body and body[-1] == "":
    body.pop()

# 1+2: signatures
for i, l in enumerate(src):
    if l == "void func_80016A8C(u8 *arg0) {":
        src[i] = "void func_80016A8C(u8 *arg0, u8 *arg1, s32 arg2) {"
    elif l == "void func_80016E60(u8 *arg0) {":
        src[i] = "void func_80016E60(u8 *arg0, s32 arg1) {"

# 3+4: replace main
s = next(i for i, l in enumerate(src) if l.startswith("void main(void)"))
e = s
while src[e] != "}":
    e += 1
out = src[:s] + body + src[e + 1:]

open(SRC, "wb").write("\n".join(out).encode("utf-8"))
print(f"applied: main lines {s+1}..{e+1} replaced with {len(body)} candidate lines")
