	.file	1 "src/ings.c"

 # GNU C 2.7.2 [AL 1.1, MM 40] GNU MIPS/ELF compiled by GNU C

 # Cc1 defaults:
 # -mgas

 # Cc1 arguments (-G value = 0, Cpu = 3000, ISA = 1):
 # -O2 -G0 -funsigned-char -quiet -mcpu=3000 -mips1 -mno-abicalls -fno-builtin
 # -w -mel -o

	.version	"01.01"
gcc2_compiled.:
 #APP
	.include "include/labels.inc"

	.set noreorder
.set noat
glabel func_800164AC
    .word 0x8008C49C
    .word 0x8008C5B4
    .word 0x8008C750
    .word 0x8008C8A0
    .word 0x8008C930
    .word 0x8008C94C
    .word 0x8008C4C0
    .word 0x8008C4D8
    .word 0x8008C504
    .word 0x8008C518
    .word 0x8008C928
    .word 0x8008C560
    .word 0x8008C590
    .word 0x00000000
    .word 0x8008C95C
    .word 0x8008C5D8
    .word 0x8008C658
    .word 0x8008C680
    .word 0x8008C6DC
.set reorder
.set at

	.set noreorder
.set noat
glabel func_800164F8
    .word 0x2402270F
    .word 0x0001000D
    .word 0x2442FFFF
    .word 0x0441FFFD
    .word 0x00000000
    .word 0x03E00008
    .word 0x00000000
.set reorder
.set at

 #NO_APP
	.text
	.align	2
	.globl	file_LoadAll
	.type	 file_LoadAll,@function
	.ent	file_LoadAll
file_LoadAll:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, extra= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	sw	$19,28($sp)
	move	$19,$5
	addu	$4,$4,4
	move	$5,$0
	move	$6,$0
	sw	$31,36($sp)
	sw	$20,32($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80083698
	sw	$16,16($sp)
	.set	macro
	.set	reorder

	move	$18,$2
	li	$2,-1			# 0xffffffff
	.set	noreorder
	.set	nomacro
	bne	$18,$2,.L2
	move	$4,$18
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L10
	li	$2,-2			# 0xfffffffe
	.set	macro
	.set	reorder

.L11:
	.set	noreorder
	.set	nomacro
	jal	close
	move	$4,$18
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L10
	li	$2,-1			# 0xffffffff
	.set	macro
	.set	reorder

.L2:
	move	$5,$0
	.set	noreorder
	.set	nomacro
	jal	func_800836C8
	li	$6,0x00000002		# 2
	.set	macro
	.set	reorder

	move	$20,$2
	move	$17,$20
	move	$4,$18
	move	$5,$0
	.set	noreorder
	.set	nomacro
	jal	func_800836C8
	move	$6,$0
	.set	macro
	.set	reorder

	blez	$20,.L3
.L4:
	slt	$2,$17,16385
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L7
	li	$16,0x00004000		# 16384
	.set	macro
	.set	reorder

	move	$16,$17
.L7:
	move	$4,$18
	move	$5,$19
	.set	noreorder
	.set	nomacro
	jal	bios_FileRead
	move	$6,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	bne	$2,$16,.L11
	subu	$17,$17,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	bgtz	$17,.L4
	addu	$19,$19,$16
	.set	macro
	.set	reorder

.L3:
	.set	noreorder
	.set	nomacro
	jal	func_800836B8
	move	$4,$18
	.set	macro
	.set	reorder

	move	$2,$20
.L10:
	lw	$31,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,40
	j	$31
	.end	file_LoadAll
.Lfe1:
	.size	 file_LoadAll,.Lfe1-file_LoadAll
	.align	2
	.globl	file_LoadSectors
	.type	 file_LoadSectors,@function
	.ent	file_LoadSectors
file_LoadSectors:
	.frame	$sp,48,$31		# vars= 8, regs= 6/0, args= 16, extra= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,48
	sw	$18,32($sp)
	move	$18,$5
	sw	$16,24($sp)
	move	$16,$6
	sw	$19,36($sp)
	move	$19,$7
	addu	$4,$4,4
	move	$5,$0
	move	$6,$0
	sw	$31,44($sp)
	sw	$20,40($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80083698
	sw	$17,28($sp)
	.set	macro
	.set	reorder

	move	$17,$2
	li	$2,-1			# 0xffffffff
	.set	noreorder
	.set	nomacro
	bne	$17,$2,.L13
	move	$4,$17
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L20
	li	$2,-2			# 0xfffffffe
	.set	macro
	.set	reorder

.L21:
	.set	noreorder
	.set	nomacro
	jal	close
	move	$4,$17
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L20
	li	$2,-1			# 0xffffffff
	.set	macro
	.set	reorder

.L13:
	sll	$5,$16,11
	.set	noreorder
	.set	nomacro
	jal	func_800836C8
	move	$6,$0
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	blez	$19,.L14
	move	$16,$0
	.set	macro
	.set	reorder

	li	$20,0x00000800		# 2048
.L15:
	move	$4,$17
	move	$5,$18
	.set	noreorder
	.set	nomacro
	jal	bios_FileRead
	li	$6,0x00000800		# 2048
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	bne	$2,$20,.L21
	addu	$16,$16,1
	.set	macro
	.set	reorder

	slt	$2,$16,$19
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L15
	addu	$18,$18,2048
	.set	macro
	.set	reorder

.L14:
	.set	noreorder
	.set	nomacro
	jal	func_800836B8
	move	$4,$17
	.set	macro
	.set	reorder

	sll	$2,$19,11
.L20:
	lw	$31,44($sp)
	lw	$20,40($sp)
	lw	$19,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,48
	j	$31
	.end	file_LoadSectors
.Lfe2:
	.size	 file_LoadSectors,.Lfe2-file_LoadSectors
	.align	2
	.globl	disp_CalcFov
	.type	 disp_CalcFov,@function
	.ent	disp_CalcFov
disp_CalcFov:
	.frame	$sp,8,$31		# vars= 8, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	li	$2,-1240793088			# 0xb60b0000
	ori	$2,$2,0x60b7
	sll	$4,$4,12
	mult	$4,$2
	subu	$sp,$sp,8
	mfhi	$5
	#nop
	#nop
	addu	$3,$5,$4
	sra	$3,$3,8
	sra	$4,$4,31
	subu	$3,$3,$4
	srl	$2,$3,31
	addu	$3,$3,$2
	sra	$3,$3,1
	addu	$2,$3,1024
	andi	$2,$2,0x0fff
	sll	$2,$2,1
	andi	$3,$3,0x0fff
	sll	$3,$3,1
	lh	$4,Judge($2)
	lh	$3,Judge($3)
	sll	$2,$4,2
	addu	$2,$2,$4
	sll	$2,$2,6
	div	$2,$2,$3
	addu	$sp,$sp,8
	j	$31
	.end	disp_CalcFov
.Lfe3:
	.size	 disp_CalcFov,.Lfe3-disp_CalcFov
	.align	2
	.globl	disp_SetFramebufferMode
	.type	 disp_SetFramebufferMode,@function
	.ent	disp_SetFramebufferMode
disp_SetFramebufferMode:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	move	$9,$0
	la	$3,g_disp_fb_base
	move	$8,$0
.L24:
	sb	$4,g_disp_fb_flag($8)
	sb	$5,25($3)
	sb	$6,26($3)
	sb	$7,27($3)
	addu	$3,$3,16528
	addu	$9,$9,1
	slt	$2,$9,2
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L24
	addu	$8,$8,16528
	.set	macro
	.set	reorder

	j	$31
	.end	disp_SetFramebufferMode
.Lfe4:
	.size	 disp_SetFramebufferMode,.Lfe4-disp_SetFramebufferMode
	.align	2
	.globl	file_GetFlag0
	.type	 file_GetFlag0,@function
	.ent	file_GetFlag0
file_GetFlag0:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lbu	$2,g_file_flags
	.set	noreorder
	.set	nomacro
	j	$31
	andi	$2,$2,0x0001
	.set	macro
	.set	reorder

	.end	file_GetFlag0
.Lfe5:
	.size	 file_GetFlag0,.Lfe5-file_GetFlag0
	.align	2
	.globl	file_GetFlag1
	.type	 file_GetFlag1,@function
	.ent	file_GetFlag1
file_GetFlag1:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lbu	$2,g_file_flags
	#nop
	srl	$2,$2,1
	.set	noreorder
	.set	nomacro
	j	$31
	andi	$2,$2,0x0001
	.set	macro
	.set	reorder

	.end	file_GetFlag1
.Lfe6:
	.size	 file_GetFlag1,.Lfe6-file_GetFlag1
	.align	2
	.globl	file_GetFlag2
	.type	 file_GetFlag2,@function
	.ent	file_GetFlag2
file_GetFlag2:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lbu	$2,g_file_flags
	#nop
	srl	$2,$2,2
	.set	noreorder
	.set	nomacro
	j	$31
	andi	$2,$2,0x0001
	.set	macro
	.set	reorder

	.end	file_GetFlag2
.Lfe7:
	.size	 file_GetFlag2,.Lfe7-file_GetFlag2
	.align	2
	.globl	func_800167EC
	.type	 func_800167EC,@function
	.ent	func_800167EC
func_800167EC:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	move	$4,$0
	li	$5,0x00010000		# 65536
	ori	$5,$5,0xa5e0
	la	$2,g_file_disc_size
	move	$3,$2
	li	$2,0x00007007		# 28679
	sw	$31,16($sp)
	sh	$0,g_file_vram_timer
	sb	$0,g_file_flags
	sw	$2,0($3)
	sb	$0,g_file_disc_type
.L33:
	sb	$0,8($3)
	sb	$0,9($3)
	sw	$5,12($3)
	addu	$4,$4,1
	slt	$2,$4,3
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L33
	addu	$3,$3,8
	.set	macro
	.set	reorder

	li	$2,0x00006978		# 27000
	sw	$2,D_80106A5C
	jal	func_8001945C
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_800167EC
.Lfe8:
	.size	 func_800167EC,.Lfe8-func_800167EC
	.align	2
	.globl	gpu_EnableDisplay
	.type	 gpu_EnableDisplay,@function
	.ent	gpu_EnableDisplay
gpu_EnableDisplay:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	ResetGraph
	li	$4,0x00000001		# 1
	.set	macro
	.set	reorder

	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	gpu_EnableDisplay
.Lfe9:
	.size	 gpu_EnableDisplay,.Lfe9-gpu_EnableDisplay
	.align	2
	.globl	gpu_InitDisplay
	.type	 gpu_InitDisplay,@function
	.ent	gpu_InitDisplay
gpu_InitDisplay:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	SetDispMask
	move	$4,$0
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	ResetGraph
	li	$4,0x00000001		# 1
	.set	macro
	.set	reorder

	la	$4,g_disp_gp_base
	move	$5,$0
	move	$6,$0
	.set	noreorder
	.set	nomacro
	jal	ClearImage
	move	$7,$0
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	gpu_InitDisplay
.Lfe10:
	.size	 gpu_InitDisplay,.Lfe10-gpu_InitDisplay
	.align	2
	.globl	gpu_DisableDisplay
	.type	 gpu_DisableDisplay,@function
	.ent	gpu_DisableDisplay
gpu_DisableDisplay:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	SetDispMask
	li	$4,0x00000001		# 1
	.set	macro
	.set	reorder

	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	gpu_DisableDisplay
.Lfe11:
	.size	 gpu_DisableDisplay,.Lfe11-gpu_DisableDisplay
	.align	2
	.globl	sys_StubEmpty
	.type	 sys_StubEmpty,@function
	.ent	sys_StubEmpty
sys_StubEmpty:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	sys_StubEmpty
.Lfe12:
	.size	 sys_StubEmpty,.Lfe12-sys_StubEmpty
	.align	2
	.globl	sys_InitSound
	.type	 sys_InitSound,@function
	.ent	sys_InitSound
sys_InitSound:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	jal	snd_PlaySystemSe
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	sys_InitSound
.Lfe13:
	.size	 sys_InitSound,.Lfe13-sys_InitSound
	.align	2
	.globl	disp_Init
	.type	 disp_Init,@function
	.ent	disp_Init
disp_Init:
	.frame	$sp,40,$31		# vars= 0, regs= 3/0, args= 24, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	move	$4,$0
	sw	$31,32($sp)
	sw	$17,28($sp)
	.set	noreorder
	.set	nomacro
	jal	ResetGraph
	sw	$16,24($sp)
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	SetGraphDebug
	move	$4,$0
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	SetDispMask
	move	$4,$0
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	InitGeom
	li	$16,0x000000f0		# 240
	.set	macro
	.set	reorder

	li	$4,0x00000140		# 320
	.set	noreorder
	.set	nomacro
	jal	SetGeomOffset
	li	$5,0x00000078		# 120
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	disp_CalcFov
	li	$4,0x0000002d		# 45
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	SetGeomScreen
	move	$4,$2
	.set	macro
	.set	reorder

	la	$17,g_disp_fb_base
	move	$4,$17
	move	$5,$0
	move	$6,$0
	li	$7,0x00000280		# 640
	.set	noreorder
	.set	nomacro
	jal	SetDefDrawEnv
	sw	$16,16($sp)
	.set	macro
	.set	reorder

	addu	$4,$17,16528
	move	$5,$0
	li	$6,0x000000f0		# 240
	li	$7,0x00000280		# 640
	.set	noreorder
	.set	nomacro
	jal	SetDefDrawEnv
	sw	$16,16($sp)
	.set	macro
	.set	reorder

	addu	$4,$17,92
	move	$5,$0
	li	$6,0x000000f0		# 240
	li	$7,0x00000280		# 640
	.set	noreorder
	.set	nomacro
	jal	SetDefDispEnv
	sw	$16,16($sp)
	.set	macro
	.set	reorder

	addu	$4,$17,16620
	move	$5,$0
	move	$6,$0
	li	$7,0x00000280		# 640
	.set	noreorder
	.set	nomacro
	jal	SetDefDispEnv
	sw	$16,16($sp)
	.set	macro
	.set	reorder

	li	$4,0x00000001		# 1
	move	$5,$0
	move	$6,$0
	.set	noreorder
	.set	nomacro
	jal	disp_SetFramebufferMode
	move	$7,$0
	.set	macro
	.set	reorder

	la	$4,g_disp_gp_base
	move	$5,$0
	move	$6,$0
	.set	noreorder
	.set	nomacro
	jal	ClearImage
	move	$7,$0
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	lw	$31,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,40
	j	$31
	.end	disp_Init
.Lfe14:
	.size	 disp_Init,.Lfe14-disp_Init
	.align	2
	.globl	sys_Init
	.type	 sys_Init,@function
	.ent	sys_Init
sys_Init:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	jal	ResetCallback
	la	$4,g_pad_data
	li	$5,0x00000008		# 8
	addu	$6,$4,36
	.set	noreorder
	.set	nomacro
	jal	InitPAD
	li	$7,0x00000008		# 8
	.set	macro
	.set	reorder

	jal	StartPAD
	.set	noreorder
	.set	nomacro
	jal	ChangeClearPAD
	move	$4,$0
	.set	macro
	.set	reorder

	jal	disp_Init
	li	$2,0x000000ff		# 255
	sb	$2,g_disp_enable
	sb	$0,g_disp_fade
	jal	func_80035FE0
	jal	func_800375EC
	jal	sys_InitSound
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	sys_Init
.Lfe15:
	.size	 sys_Init,.Lfe15-sys_Init
	.align	2
	.globl	func_80016A8C
	.type	 func_80016A8C,@function
	.ent	func_80016A8C
func_80016A8C:
	.frame	$sp,56,$31		# vars= 16, regs= 3/0, args= 24, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,56
	sw	$17,44($sp)
	move	$17,$4
	sw	$31,48($sp)
	sw	$16,40($sp)
	la	$5,D_800A30D4
	lwl	$2,3($5)
	lwr	$2,0($5)
	lwl	$3,7($5)
	lwr	$3,4($5)
	swl	$2,27($sp)
	swr	$2,24($sp)
	swl	$3,31($sp)
	swr	$3,28($sp)
	.set	noreorder
	.set	nomacro
	jal	SetDispMask
	move	$4,$0
	.set	macro
	.set	reorder

	li	$2,0x000000f0		# 240
	la	$16,D_800FB524
	move	$4,$16
	move	$5,$0
	move	$6,$0
	li	$7,0x00000140		# 320
	.set	noreorder
	.set	nomacro
	jal	SetDefDispEnv
	sw	$2,16($sp)
	.set	macro
	.set	reorder

	jal	game_FrameLoop
	li	$4,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	jal	func_80036EA8
	li	$5,0x00000061		# 97
	.set	macro
	.set	reorder

	move	$4,$2
	.set	noreorder
	.set	nomacro
	jal	replay_camera_Init
	move	$5,$17
	.set	macro
	.set	reorder

	jal	game_FrameLoop
	.set	noreorder
	.set	nomacro
	jal	PutDispEnv
	move	$4,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	addu	$4,$sp,24
	.set	noreorder
	.set	nomacro
	jal	LoadImage
	addu	$5,$17,20
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	SetDispMask
	li	$4,0x00000001		# 1
	.set	macro
	.set	reorder

	move	$16,$0
	slt	$2,$16,121
.L54:
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L47
	addu	$5,$17,40
	.set	macro
	.set	reorder

	lh	$3,28($sp)
	lh	$2,30($sp)
	#nop
	mult	$3,$2
	mflo	$8
	#nop
	#nop
	.set	noreorder
	.set	nomacro
	blez	$8,.L49
	move	$6,$0
	.set	macro
	.set	reorder

.L51:
	lhu	$3,0($5)
	#nop
	andi	$4,$3,0x001f
	sra	$4,$4,1
	andi	$3,$3,0xffff
	srl	$2,$3,1
	andi	$2,$2,0x01e0
	addu	$4,$4,$2
	srl	$3,$3,1
	andi	$3,$3,0x3c00
	addu	$4,$4,$3
	sh	$4,0($5)
	lh	$3,28($sp)
	lh	$2,30($sp)
	#nop
	mult	$3,$2
	addu	$6,$6,1
	mflo	$8
	#nop
	#nop
	slt	$2,$6,$8
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L51
	addu	$5,$5,2
	.set	macro
	.set	reorder

.L49:
	addu	$4,$sp,24
	.set	noreorder
	.set	nomacro
	jal	LoadImage
	addu	$5,$17,20
	.set	macro
	.set	reorder

.L47:
	.set	noreorder
	.set	nomacro
	jal	DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	VSync
	move	$4,$0
	.set	macro
	.set	reorder

	addu	$16,$16,1
	slt	$2,$16,150
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L54
	slt	$2,$16,121
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	SetDispMask
	move	$4,$0
	.set	macro
	.set	reorder

	li	$2,0x000000f0		# 240
	sw	$2,16($sp)
	la	$4,D_800FB524
	move	$5,$0
	move	$6,$0
	.set	noreorder
	.set	nomacro
	jal	SetDefDispEnv
	li	$7,0x00000280		# 640
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	SetDispMask
	li	$4,0x00000001		# 1
	.set	macro
	.set	reorder

	lw	$31,48($sp)
	lw	$17,44($sp)
	lw	$16,40($sp)
	addu	$sp,$sp,56
	j	$31
	.end	func_80016A8C
.Lfe16:
	.size	 func_80016A8C,.Lfe16-func_80016A8C
	.align	2
	.globl	sys_Panic
	.type	 sys_Panic,@function
	.ent	sys_Panic
sys_Panic:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	la	$4,g_str_overflow
	jal	printf
.L58:
	jal	func_800164F8
	j	.L58
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	sys_Panic
.Lfe17:
	.size	 sys_Panic,.Lfe17-sys_Panic
	.align	2
	.globl	file_ResetDmaFlag
	.type	 file_ResetDmaFlag,@function
	.ent	file_ResetDmaFlag
file_ResetDmaFlag:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	sb	$0,g_file_dma_flag
	j	$31
	.end	file_ResetDmaFlag
.Lfe18:
	.size	 file_ResetDmaFlag,.Lfe18-file_ResetDmaFlag
	.align	2
	.globl	file_LoadOverlay
	.type	 file_LoadOverlay,@function
	.ent	file_LoadOverlay
file_LoadOverlay:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	lbu	$2,g_file_dma_flag
	subu	$sp,$sp,24
	sw	$31,20($sp)
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L61
	sw	$16,16($sp)
	.set	macro
	.set	reorder

	li	$4,-2145583104			# 0x801d0000
	ori	$4,$4,0x8800
	li	$5,-2146435072			# 0x80100000
	.set	noreorder
	.set	nomacro
	jal	func_80060CB8
	ori	$5,$5,0xe800
	.set	macro
	.set	reorder

	la	$4,g_str_eff_init
	li	$5,-2146435072			# 0x80100000
	ori	$5,$5,0xe800
	move	$16,$2
	.set	noreorder
	.set	nomacro
	jal	printf
	move	$6,$16
	.set	macro
	.set	reorder

	li	$2,0x0000a000		# 40960
	slt	$2,$2,$16
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L64
	li	$2,0x00000001		# 1
	.set	macro
	.set	reorder

	jal	sys_Panic
	li	$2,0x00000001		# 1
.L64:
	sb	$2,g_file_dma_flag
.L61:
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	file_LoadOverlay
.Lfe19:
	.size	 file_LoadOverlay,.Lfe19-file_LoadOverlay
	.align	2
	.globl	file_LoadSoundData
	.type	 file_LoadSoundData,@function
	.ent	file_LoadSoundData
file_LoadSoundData:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,20($sp)
	.set	noreorder
	.set	nomacro
	jal	func_8005B43C
	sw	$16,16($sp)
	.set	macro
	.set	reorder

	li	$4,-2145583104			# 0x801d0000
	.set	noreorder
	.set	nomacro
	jal	func_8005B7C4
	ori	$4,$4,0x8800
	.set	macro
	.set	reorder

	move	$16,$2
	slt	$2,$16,3329
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L67
	li	$4,-2146435072			# 0x80100000
	.set	macro
	.set	reorder

	jal	sys_Panic
	li	$4,-2146435072			# 0x80100000
.L67:
	ori	$4,$4,0xdb00
	li	$5,-2145583104			# 0x801d0000
	ori	$5,$5,0x8800
	.set	noreorder
	.set	nomacro
	jal	memcpy
	move	$6,$16
	.set	macro
	.set	reorder

	li	$4,-851968			# 0xfff30000
	ori	$4,$4,0x5300
	.set	noreorder
	.set	nomacro
	jal	func_8005C4C0
	move	$5,$0
	.set	macro
	.set	reorder

	jal	func_8005C614
	li	$2,0x00000001		# 1
	sb	$2,D_800A3906
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	file_LoadSoundData
.Lfe20:
	.size	 file_LoadSoundData,.Lfe20-file_LoadSoundData
	.align	2
	.globl	sys_GameInit
	.type	 sys_GameInit,@function
	.ent	sys_GameInit
sys_GameInit:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	li	$5,-2146435072			# 0x80100000
	la	$4,g_str_limit
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	printf
	ori	$5,$5,0xdb00
	.set	macro
	.set	reorder

	jal	func_800167EC
	jal	func_80020D70
	li	$4,-2145583104			# 0x801d0000
	ori	$4,$4,0x8800
	li	$3,-2145517568			# 0x801e0000
	ori	$3,$3,0xbc00
	li	$2,0x00010000		# 65536
	ori	$2,$2,0x3400
	sw	$4,D_800A3770
	sw	$3,D_800A3774
	sw	$2,D_800A3798
	sb	$0,g_file_dma_flag
	sb	$0,D_800A3906
	jal	file_LoadSoundData
	jal	func_80019534
	jal	func_8003D2C4
	jal	func_8001C444
	sb	$0,D_800A36F9
	sb	$0,D_800A3690
	sb	$0,D_800A3744
	sb	$0,D_800A3745
	sb	$0,D_800A3746
	jal	game_Init
	li	$2,0x00000002		# 2
	sb	$2,D_800A36F1
	sh	$0,D_800A38C6
	sb	$0,D_800A36B0
	sb	$0,D_800A3928
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	sys_GameInit
.Lfe21:
	.size	 sys_GameInit,.Lfe21-sys_GameInit
	.align	2
	.globl	gpu_SetDrawMode
	.type	 gpu_SetDrawMode,@function
	.ent	gpu_SetDrawMode
gpu_SetDrawMode:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	gpu_SetDrawMode
.Lfe22:
	.size	 gpu_SetDrawMode,.Lfe22-gpu_SetDrawMode
	.align	2
	.globl	func_80016E60
	.type	 func_80016E60,@function
	.ent	func_80016E60
func_80016E60:
	.frame	$sp,56,$31		# vars= 8, regs= 7/0, args= 16, extra= 0
	.mask	0x803f0000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,56
	sw	$17,28($sp)
	move	$17,$0
	sw	$18,32($sp)
	move	$18,$0
	sw	$21,44($sp)
	move	$21,$4
	lh	$3,D_800A38DC
	li	$2,0x00000002		# 2
	sw	$31,48($sp)
	sw	$20,40($sp)
	sw	$19,36($sp)
	.set	noreorder
	.set	nomacro
	bne	$3,$2,.L71
	sw	$16,24($sp)
	.set	macro
	.set	reorder

	lbu	$2,D_800A389A
	#nop
	sltu	$18,$2,1
.L71:
	.set	noreorder
	.set	nomacro
	beq	$18,$0,.L72
	li	$19,0x00000003		# 3
	.set	macro
	.set	reorder

	li	$19,0x00000006		# 6
.L72:
	li	$4,0x00000003		# 3
	li	$5,0x0000007f		# 127
	li	$2,0x00000001		# 1
	sb	$2,D_800A36B0
	.set	noreorder
	.set	nomacro
	jal	func_8005C650
	li	$6,0x0000007f		# 127
	.set	macro
	.set	reorder

	lw	$2,D_800A36AC
	#nop
	andi	$2,$2,0x0001
	sll	$2,$2,2
	lw	$20,D_800A3770($2)
	li	$5,0x00000001		# 1
.L98:
	lw	$3,D_800A36AC
	addu	$4,$sp,16
	andi	$3,$3,0x0001
	sll	$2,$3,2
	addu	$4,$4,$2
	addu	$2,$2,$3
	sll	$2,$2,2
	subu	$2,$2,$3
	sll	$2,$2,2
	addu	$2,$2,$3
	sll	$2,$2,9
	addu	$2,$20,$2
	sw	$2,D_800A38B4
	sll	$2,$3,7
	addu	$2,$2,$3
	sll	$2,$2,3
	addu	$2,$2,$3
	sll	$2,$2,4
	la	$3,D_800F7438
	sw	$4,D_800A374C
	.set	noreorder
	.set	nomacro
	jal	ClearOTagR
	addu	$16,$2,$3
	.set	macro
	.set	reorder

	jal	func_80019568
	.set	noreorder
	.set	nomacro
	beq	$18,$0,.L76
	move	$7,$0
	.set	macro
	.set	reorder

	li	$4,0x00000002		# 2
	lbu	$5,D_800A3788
	lw	$6,D_800A38B4
	sll	$5,$5,16
	.set	noreorder
	.set	nomacro
	j	.L96
	or	$5,$17,$5
	.set	macro
	.set	reorder

.L76:
	move	$4,$18
	move	$5,$17
	lw	$6,D_800A38B4
.L96:
	jal	func_8005C8A8
	jal	func_80036940
	jal	func_8005C6D0
	.set	noreorder
	.set	nomacro
	jal	DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	VSync
	li	$4,0x00000002		# 2
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	PutDispEnv
	addu	$4,$16,92
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	PutDrawEnv
	move	$4,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	DrawOTag
	addu	$4,$21,16524
	.set	macro
	.set	reorder

	lw	$4,D_800A374C
	jal	DrawOTag
	li	$3,0x00100000		# 1048576
	ori	$3,$3,0x0010
	lw	$2,D_800A36AC
	lw	$4,D_80102794
	addu	$2,$2,1
	and	$3,$4,$3
	sw	$2,D_800A36AC
	.set	noreorder
	.set	nomacro
	bne	$3,$0,.L94
	li	$2,0x00400000		# 4194304
	.set	macro
	.set	reorder

	ori	$2,$2,0x0040
	and	$2,$4,$2
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L95
	li	$2,0x10000000		# 268435456
	.set	macro
	.set	reorder

	ori	$2,$2,0x1000
	and	$2,$4,$2
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L80
	li	$5,0x0000007f		# 127
	.set	macro
	.set	reorder

	move	$4,$0
	.set	noreorder
	.set	nomacro
	jal	func_8005C650
	li	$6,0x0000007f		# 127
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	bne	$17,$0,.L81
	addu	$5,$17,-1
	.set	macro
	.set	reorder

	addu	$5,$19,-1
.L81:
	.set	noreorder
	.set	nomacro
	j	.L82
	move	$17,$5
	.set	macro
	.set	reorder

.L80:
	li	$2,0x40000000		# 1073741824
	ori	$2,$2,0x4000
	and	$2,$4,$2
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L82
	move	$4,$0
	.set	macro
	.set	reorder

	li	$5,0x0000007f		# 127
	.set	noreorder
	.set	nomacro
	jal	func_8005C650
	li	$6,0x0000007f		# 127
	.set	macro
	.set	reorder

	addu	$2,$19,-1
	.set	noreorder
	.set	nomacro
	beq	$17,$2,.L84
	move	$3,$0
	.set	macro
	.set	reorder

	addu	$3,$17,1
.L84:
	move	$17,$3
.L82:
	.set	noreorder
	.set	nomacro
	beq	$18,$0,.L98
	li	$5,0x00000001		# 1
	.set	macro
	.set	reorder

	slt	$2,$17,3
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L98
	li	$2,-2147483648			# 0x80000000
	.set	macro
	.set	reorder

	lw	$3,D_80102794
	ori	$2,$2,0x8000
	and	$2,$3,$2
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L86
	move	$4,$0
	.set	macro
	.set	reorder

	li	$5,0x0000007f		# 127
	.set	noreorder
	.set	nomacro
	jal	func_8005C650
	li	$6,0x0000007f		# 127
	.set	macro
	.set	reorder

	addu	$2,$17,-3
	li	$3,0x00000001		# 1
	lbu	$4,D_800A3788
 #APP
	sllv $3, $3, $2
 #NO_APP
	#nop
	or	$4,$4,$3
	sb	$4,D_800A3788
	.set	noreorder
	.set	nomacro
	j	.L98
	li	$5,0x00000001		# 1
	.set	macro
	.set	reorder

.L86:
	li	$2,0x20000000		# 536870912
	ori	$2,$2,0x2000
	and	$2,$3,$2
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L98
	li	$5,0x00000001		# 1
	.set	macro
	.set	reorder

	move	$4,$0
	li	$5,0x0000007f		# 127
	.set	noreorder
	.set	nomacro
	jal	func_8005C650
	li	$6,0x0000007f		# 127
	.set	macro
	.set	reorder

	addu	$2,$17,-3
	li	$3,0x00000001		# 1
 #APP
	sllv $3, $3, $2
 #NO_APP
	lbu	$2,D_800A3788
	nor	$3,$0,$3
	and	$2,$2,$3
	sb	$2,D_800A3788
	.set	noreorder
	.set	nomacro
	j	.L98
	li	$5,0x00000001		# 1
	.set	macro
	.set	reorder

.L74:
	.set	noreorder
	.set	nomacro
	beq	$17,$0,.L90
	li	$2,0x00000001		# 1
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	bne	$17,$2,.L91
	li	$2,0x00000002		# 2
	.set	macro
	.set	reorder

	li	$2,0x00000001		# 1
	sb	$2,D_800A31DA
	.set	noreorder
	.set	nomacro
	j	.L99
	li	$2,0x00000008		# 8
	.set	macro
	.set	reorder

.L95:
	li	$4,0x00000001		# 1
	li	$5,0x0000007f		# 127
	.set	noreorder
	.set	nomacro
	jal	func_8005C650
	li	$6,0x0000007f		# 127
	.set	macro
	.set	reorder

	j	.L74
.L94:
	li	$4,0x00000001		# 1
	li	$5,0x0000007f		# 127
	.set	noreorder
	.set	nomacro
	jal	func_8005C650
	li	$6,0x0000007f		# 127
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L74
	move	$17,$0
	.set	macro
	.set	reorder

.L91:
	.set	noreorder
	.set	nomacro
	bne	$17,$2,.L90
	li	$2,0x00000008		# 8
	.set	macro
	.set	reorder

.L99:
	sh	$2,D_800A3834
	jal	func_800372C0
.L90:
	.set	noreorder
	.set	nomacro
	jal	DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	li	$4,-234881024			# 0xf2000000
	.set	noreorder
	.set	nomacro
	jal	ResetRCnt
	ori	$4,$4,0x0001
	.set	macro
	.set	reorder

	li	$2,0x00000001		# 1
	sb	$2,D_800A36B0
	lw	$31,48($sp)
	lw	$21,44($sp)
	lw	$20,40($sp)
	lw	$19,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,56
	j	$31
	.end	func_80016E60
.Lfe23:
	.size	 func_80016E60,.Lfe23-func_80016E60
	.align	2
	.globl	rng_SetSeed
	.type	 rng_SetSeed,@function
	.ent	rng_SetSeed
rng_SetSeed:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	sw	$4,g_file_heap_base
	j	$31
	.end	rng_SetSeed
.Lfe24:
	.size	 rng_SetSeed,.Lfe24-rng_SetSeed
	.align	2
	.globl	rng_Next
	.type	 rng_Next,@function
	.ent	rng_Next
rng_Next:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$3,g_file_heap_base
	#nop
	sll	$2,$3,1
	addu	$2,$2,$3
	sll	$2,$2,2
	subu	$2,$2,$3
	sll	$2,$2,2
	subu	$2,$2,$3
	sll	$2,$2,4
	subu	$2,$2,$3
	sll	$2,$2,3
	addu	$2,$2,$3
	addu	$2,$2,32681
	sra	$3,$3,16
	xor	$3,$3,$2
	sw	$3,g_file_heap_base
	.set	noreorder
	.set	nomacro
	j	$31
	andi	$2,$3,0x7fff
	.set	macro
	.set	reorder

	.end	rng_Next
.Lfe25:
	.size	 rng_Next,.Lfe25-rng_Next
	.align	2
	.globl	main
	.type	 main,@function
	.ent	main
main:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, extra= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	sw	$31,36($sp)
	sw	$20,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80083794
	sw	$16,16($sp)
	.set	macro
	.set	reorder

	li	$4,-2145452032			# 0x801f0000
	.set	noreorder
	.set	nomacro
	jal	SetSp
	ori	$4,$4,0xff00
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	SetMem
	li	$4,0x00000002		# 2
	.set	macro
	.set	reorder

	jal	sys_Init
	jal	sys_GameInit
	.set	noreorder
	.set	nomacro
	jal	SetDispMask
	li	$4,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$4,-2146369536			# 0x80110000
	ori	$4,$4,0x8800
	move	$5,$18
	.set	noreorder
	.set	nomacro
	jal	func_80016A8C
	move	$6,$17
	.set	macro
	.set	reorder

	la	$20,D_800A3770
	li	$2,0x0000000f		# 15
	sh	$2,D_800A3834
	sb	$0,D_800A390D
	sw	$0,D_800A36AC
	li	$5,0x00001008		# 4104
.L128:
	lw	$2,D_800A36AC
	la	$3,D_800F7438
	andi	$17,$2,0x0001
	sll	$2,$17,7
	addu	$2,$2,$17
	sll	$2,$2,3
	addu	$2,$2,$17
	sll	$2,$2,4
	addu	$18,$2,$3
	addu	$16,$18,112
	.set	noreorder
	.set	nomacro
	jal	ClearOTagR
	move	$4,$16
	.set	macro
	.set	reorder

	sll	$2,$17,2
	addu	$2,$2,$20
	lw	$2,0($2)
	sw	$16,D_800A374C
	sw	$2,D_800A38B4
	.set	noreorder
	.set	nomacro
	jal	func_80060E04
	move	$4,$17
	.set	macro
	.set	reorder

	jal	func_8003D2F4
	.set	noreorder
	.set	nomacro
	jal	func_80019568
	move	$4,$19
	.set	macro
	.set	reorder

	jal	func_80036940
	jal	func_8005C6D0
	lbu	$2,D_800A3928
	#nop
	beq	$2,$0,.L104
	jal	func_800372C0
	li	$2,0x000000ff		# 255
	sb	$2,D_800A3768
	li	$2,0x00000008		# 8
	sb	$0,D_800A3928
	sb	$0,D_800A31DA
	sh	$2,D_800A3834
.L104:
	lh	$2,D_800A3834
	#nop
	sll	$2,$2,2
	lw	$2,D_8008D090($2)
	#nop
	jal	$31,$2
	jal	func_8003D330
	li	$4,-234881024			# 0xf2000000
.L126:
	.set	noreorder
	.set	nomacro
	jal	GetRCnt
	ori	$4,$4,0x0001
	.set	macro
	.set	reorder

	lbu	$3,D_800A36F1
	#nop
	addu	$3,$3,-1
	sll	$3,$3,8
	addu	$3,$3,128
	slt	$2,$2,$3
	beq	$2,$0,.L106
	jal	rand
	.set	noreorder
	.set	nomacro
	j	.L126
	li	$4,-234881024			# 0xf2000000
	.set	macro
	.set	reorder

.L106:
	.set	noreorder
	.set	nomacro
	jal	VSync
	li	$4,0x00000001		# 1
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	VSync
	move	$4,$0
	.set	macro
	.set	reorder

	li	$4,-234881024			# 0xf2000000
	.set	noreorder
	.set	nomacro
	jal	ResetRCnt
	ori	$4,$4,0x0001
	.set	macro
	.set	reorder

	lbu	$19,D_800A390D
	#nop
	.set	noreorder
	.set	nomacro
	bne	$19,$0,.L127
	li	$4,-131072			# 0xfffe0000
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	PutDispEnv
	addu	$4,$18,92
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	PutDrawEnv
	move	$4,$18
	.set	macro
	.set	reorder

	li	$4,-131072			# 0xfffe0000
.L127:
	ori	$4,$4,0xcc00
	sll	$2,$17,2
	lw	$3,D_800A38B4
	addu	$2,$2,$20
	addu	$3,$3,$4
	lw	$4,0($2)
	lw	$2,D_800A30DC
	subu	$4,$4,$3
	slt	$2,$4,$2
	beq	$2,$0,.L111
	sw	$4,D_800A30DC
.L111:
	bgez	$4,.L112
	la	$4,D_80010034
	jal	printf
.L115:
	jal	func_800164F8
	j	.L115
.L112:
	lbu	$2,D_800A390D
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L117
	addu	$2,$2,-1
	.set	macro
	.set	reorder

	sb	$2,D_800A390D
	j	.L118
.L117:
	.set	noreorder
	.set	nomacro
	jal	DrawOTag
	addu	$4,$18,16524
	.set	macro
	.set	reorder

	lw	$2,D_800A36AC
	#nop
	addu	$2,$2,1
	sw	$2,D_800A36AC
.L118:
	lh	$3,D_800A3834
	li	$2,0x00000001		# 1
	.set	noreorder
	.set	nomacro
	bne	$3,$2,.L128
	li	$5,0x00001008		# 4104
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	bne	$19,$0,.L128
	li	$3,0x08000000		# 134217728
	.set	macro
	.set	reorder

	lw	$2,D_80102794
	ori	$3,$3,0x0800
	and	$2,$2,$3
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L122
	li	$2,0x00000002		# 2
	.set	macro
	.set	reorder

	lh	$3,D_800A38DC
	#nop
	bne	$3,$2,.L128
	lbu	$2,D_800A3713
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L128
	addu	$2,$2,-1
	.set	macro
	.set	reorder

	sb	$2,D_800A3713
	andi	$2,$2,0x00ff
	bne	$2,$0,.L128
.L122:
	move	$4,$18
	.set	noreorder
	.set	nomacro
	jal	func_80016E60
	move	$5,$17
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L128
	li	$5,0x00001008		# 4104
	.set	macro
	.set	reorder

	lw	$31,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,40
	j	$31
	.end	main
.Lfe26:
	.size	 main,.Lfe26-main
	.align	2
	.globl	func_800174F4
	.type	 func_800174F4,@function
	.ent	func_800174F4
func_800174F4:
	.frame	$sp,152,$31		# vars= 112, regs= 4/0, args= 24, extra= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,152
	sw	$18,144($sp)
	la	$18,D_800F33D8
	lbu	$3,g_disp_enable
	li	$2,0x000000ff		# 255
	sw	$31,148($sp)
	sw	$17,140($sp)
	.set	noreorder
	.set	nomacro
	beq	$3,$2,.L129
	sw	$16,136($sp)
	.set	macro
	.set	reorder

	addu	$16,$sp,32
	move	$4,$16
	move	$5,$0
	li	$17,0x000000f0		# 240
	lw	$6,D_800A36AC
	li	$7,0x00000280		# 640
	sw	$17,16($sp)
	andi	$6,$6,0x0001
	subu	$6,$0,$6
	.set	noreorder
	.set	nomacro
	jal	SetDefDrawEnv
	andi	$6,$6,0x00f0
	.set	macro
	.set	reorder

	move	$4,$16
	.set	noreorder
	.set	nomacro
	jal	PutDrawEnv
	sb	$0,56($sp)
	.set	macro
	.set	reorder

	addu	$4,$sp,24
	sw	$4,D_800A374C
	.set	noreorder
	.set	nomacro
	jal	ClearOTagR
	li	$5,0x00000002		# 2
	.set	macro
	.set	reorder

	lbu	$3,g_disp_enable
	li	$2,0x0000000a		# 10
	.set	noreorder
	.set	nomacro
	beq	$3,$2,.L140
	slt	$2,$3,11
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L150
	slt	$2,$3,3
	.set	macro
	.set	reorder

	li	$2,0x00000014		# 20
	beq	$3,$2,.L141
	j	.L131
.L150:
	beq	$2,$0,.L131
	beq	$3,$0,.L131
	.set	noreorder
	.set	nomacro
	jal	func_8005D46C
	move	$4,$18
	.set	macro
	.set	reorder

	lbu	$3,g_disp_fade
	#nop
	.set	noreorder
	.set	nomacro
	beq	$3,$0,.L134
	move	$18,$2
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	rand
	move	$16,$0
	.set	macro
	.set	reorder

	andi	$2,$2,0x0003
	addu	$17,$2,4
	beq	$17,$0,.L131
	move	$4,$18
.L152:
	lbu	$5,g_disp_enable
	.set	noreorder
	.set	nomacro
	jal	func_8005D554
	addu	$16,$16,1
	.set	macro
	.set	reorder

	move	$18,$2
	slt	$2,$16,$17
	beq	$2,$0,.L131
	.set	noreorder
	.set	nomacro
	j	.L152
	move	$4,$18
	.set	macro
	.set	reorder

.L134:
	jal	rand
	andi	$2,$2,0x0007
	bne	$2,$0,.L131
	lbu	$5,g_disp_enable
	.set	noreorder
	.set	nomacro
	jal	func_8005D554
	move	$4,$18
	.set	macro
	.set	reorder

	j	.L131
.L140:
	lw	$4,D_800A3784
	move	$5,$18
	.set	noreorder
	.set	nomacro
	jal	func_8005E54C
	move	$6,$0
	.set	macro
	.set	reorder

	j	.L131
.L141:
	lbu	$6,D_800A38F8
	lbu	$5,D_800A37A0
	andi	$4,$6,0x00ff
	sltu	$2,$5,$4
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L131
	addu	$3,$5,1
	.set	macro
	.set	reorder

	div	$3,$17,$3
	lw	$2,D_800A37C0
	#nop
	addu	$2,$2,1
	sw	$2,D_800A37C0
	slt	$3,$3,$2
	beq	$3,$0,.L131
	.set	noreorder
	.set	nomacro
	bne	$4,$5,.L144
	addu	$2,$6,1
	.set	macro
	.set	reorder

	addu	$2,$6,1
	sb	$2,D_800A38F8
	j	.L131
.L144:
	sb	$2,D_800A38F8
	andi	$2,$2,0x00ff
	sw	$0,D_800A37C0
	lbu	$17,D_800A37A8($4)
	bne	$2,$5,.L146
	ori	$17,$17,0x8000
.L146:
	move	$4,$17
	move	$5,$18
	.set	noreorder
	.set	nomacro
	jal	func_80060414
	move	$6,$0
	.set	macro
	.set	reorder

.L131:
	lw	$4,D_800A374C
	.set	noreorder
	.set	nomacro
	jal	DrawOTag
	addu	$4,$4,4
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

.L129:
	lw	$31,148($sp)
	lw	$18,144($sp)
	lw	$17,140($sp)
	lw	$16,136($sp)
	addu	$sp,$sp,152
	j	$31
	.end	func_800174F4
.Lfe27:
	.size	 func_800174F4,.Lfe27-func_800174F4
	.align	2
	.globl	obj_ClearAll
	.type	 obj_ClearAll,@function
	.ent	obj_ClearAll
obj_ClearAll:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	li	$2,0x0000016c		# 364
.L157:
	sw	$0,g_file_data_buf($2)
	addu	$2,$2,-52
	bgez	$2,.L157
	j	$31
	.end	obj_ClearAll
.Lfe28:
	.size	 obj_ClearAll,.Lfe28-obj_ClearAll
	.align	2
	.globl	obj_CalcOffset
	.type	 obj_CalcOffset,@function
	.ent	obj_CalcOffset
obj_CalcOffset:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	sll	$4,$4,6
	sll	$2,$5,4
	.set	noreorder
	.set	nomacro
	j	$31
	addu	$2,$4,$2
	.set	macro
	.set	reorder

	.end	obj_CalcOffset
.Lfe29:
	.size	 obj_CalcOffset,.Lfe29-obj_CalcOffset
	.align	2
	.globl	math_Distance3D
	.type	 math_Distance3D,@function
	.ent	math_Distance3D
math_Distance3D:
	.frame	$sp,56,$31		# vars= 32, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,56
	sw	$31,48($sp)
	lw	$2,0($4)
	lw	$3,0($5)
	#nop
	subu	$2,$2,$3
	sra	$2,$2,2
	sw	$2,16($sp)
	lw	$2,4($4)
	lw	$3,4($5)
	#nop
	subu	$2,$2,$3
	sra	$2,$2,2
	sw	$2,20($sp)
	lw	$2,8($4)
	addu	$4,$sp,16
	lw	$3,8($5)
	addu	$5,$sp,32
	subu	$2,$2,$3
	sra	$2,$2,2
	.set	noreorder
	.set	nomacro
	jal	Square12
	sw	$2,24($sp)
	.set	macro
	.set	reorder

	lw	$4,32($sp)
	lw	$2,36($sp)
	lw	$3,40($sp)
	addu	$4,$4,$2
	.set	noreorder
	.set	nomacro
	jal	SquareRoot12
	addu	$4,$4,$3
	.set	macro
	.set	reorder

	.set	noreorder
	lw	$31,48($sp)
	sll	$2,$2,2
	j	$31
	addu	$sp,$sp,56
	.set	reorder
	.end	math_Distance3D
.Lfe30:
	.size	 math_Distance3D,.Lfe30-math_Distance3D
	.align	2
	.globl	math_Distance3D_16
	.type	 math_Distance3D_16,@function
	.ent	math_Distance3D_16
math_Distance3D_16:
	.frame	$sp,56,$31		# vars= 32, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,56
	sw	$31,48($sp)
	lw	$2,0($4)
	lw	$3,0($5)
	#nop
	subu	$2,$2,$3
	sra	$2,$2,4
	sw	$2,16($sp)
	lw	$2,4($4)
	lw	$3,4($5)
	#nop
	subu	$2,$2,$3
	sra	$2,$2,4
	sw	$2,20($sp)
	lw	$2,8($4)
	addu	$4,$sp,16
	lw	$3,8($5)
	addu	$5,$sp,32
	subu	$2,$2,$3
	sra	$2,$2,4
	.set	noreorder
	.set	nomacro
	jal	Square12
	sw	$2,24($sp)
	.set	macro
	.set	reorder

	lw	$4,32($sp)
	lw	$2,36($sp)
	lw	$3,40($sp)
	addu	$4,$4,$2
	.set	noreorder
	.set	nomacro
	jal	SquareRoot12
	addu	$4,$4,$3
	.set	macro
	.set	reorder

	.set	noreorder
	lw	$31,48($sp)
	sll	$2,$2,4
	j	$31
	addu	$sp,$sp,56
	.set	reorder
	.end	math_Distance3D_16
.Lfe31:
	.size	 math_Distance3D_16,.Lfe31-math_Distance3D_16
	.align	2
	.globl	func_80017848
	.type	 func_80017848,@function
	.ent	func_80017848
func_80017848:
	.frame	$sp,48,$31		# vars= 0, regs= 7/0, args= 16, extra= 0
	.mask	0x803f0000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,48
	sw	$18,24($sp)
	move	$18,$4
	sw	$21,36($sp)
	move	$21,$5
	sw	$20,32($sp)
	move	$20,$6
	sw	$19,28($sp)
	move	$19,$7
	sw	$31,40($sp)
	sw	$17,20($sp)
	.set	noreorder
	.set	nomacro
	beq	$20,$19,.L180
	sw	$16,16($sp)
	.set	macro
	.set	reorder

	lw	$5,12($18)
	sll	$2,$20,6
	addu	$2,$5,$2
	lw	$2,24($2)
	#nop
	.set	noreorder
	.set	nomacro
	bltz	$2,.L164
	sll	$2,$19,6
	.set	macro
	.set	reorder

	addu	$2,$5,$2
	lw	$2,24($2)
	#nop
	.set	noreorder
	.set	nomacro
	bltz	$2,.L182
	sll	$16,$20,6
	.set	macro
	.set	reorder

.L180:
	.set	noreorder
	.set	nomacro
	j	.L178
	move	$2,$0
	.set	macro
	.set	reorder

.L164:
	sll	$16,$20,6
.L182:
	addu	$16,$5,$16
	lw	$2,28($16)
	#nop
	blez	$2,.L166
	move	$3,$0
	addu	$2,$3,$16
.L183:
	lbu	$2,36($2)
	lw	$4,16($18)
	sll	$2,$2,4
	addu	$2,$4,$2
	lhu	$2,4($2)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$19,.L180
	addu	$3,$3,1
	.set	macro
	.set	reorder

	lw	$2,28($16)
	#nop
	slt	$2,$3,$2
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L183
	addu	$2,$3,$16
	.set	macro
	.set	reorder

.L166:
	lw	$2,32($16)
	#nop
	.set	noreorder
	.set	nomacro
	blez	$2,.L172
	move	$3,$0
	.set	macro
	.set	reorder

	addu	$2,$3,$16
.L184:
	lbu	$2,44($2)
	lw	$4,16($18)
	sll	$2,$2,4
	addu	$2,$4,$2
	lh	$2,6($2)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$19,.L180
	addu	$3,$3,1
	.set	macro
	.set	reorder

	lw	$2,32($16)
	#nop
	slt	$2,$3,$2
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L184
	addu	$2,$3,$16
	.set	macro
	.set	reorder

.L172:
	sll	$16,$20,6
	addu	$16,$5,$16
	sll	$17,$19,6
	addu	$17,$5,$17
	move	$4,$16
	.set	noreorder
	.set	nomacro
	jal	math_Distance3D
	move	$5,$17
	.set	macro
	.set	reorder

	sll	$20,$20,16
	or	$20,$20,$19
	lh	$3,6($18)
	lw	$4,16($18)
	sll	$3,$3,4
	addu	$4,$4,$3
	sll	$3,$2,1
	addu	$3,$3,$2
	sw	$2,0($4)
	sw	$3,8($4)
	sw	$21,12($4)
	sw	$20,4($4)
	lw	$3,28($16)
	#nop
	addu	$2,$3,1
	sw	$2,28($16)
	lhu	$2,6($18)
	addu	$16,$3,$16
	sb	$2,36($16)
	lw	$3,32($17)
	#nop
	addu	$2,$3,1
	sw	$2,32($17)
	lhu	$2,6($18)
	addu	$17,$3,$17
	sb	$2,44($17)
	lhu	$3,6($18)
	li	$2,0x00000001		# 1
	addu	$3,$3,1
	sh	$3,6($18)
.L178:
	lw	$31,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,48
	j	$31
	.end	func_80017848
.Lfe32:
	.size	 func_80017848,.Lfe32-func_80017848
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80017A44.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_80017D84
	.type	 func_80017D84,@function
	.ent	func_80017D84
func_80017D84:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	move	$8,$4
	la	$7,g_file_data_buf
	sw	$16,16($sp)
	move	$16,$0
	sw	$31,20($sp)
.L189:
	lw	$2,0($7)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L195
	li	$2,0x00000008		# 8
	.set	macro
	.set	reorder

	addu	$16,$16,1
	slt	$2,$16,8
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L189
	addu	$7,$7,52
	.set	macro
	.set	reorder

	li	$2,0x00000008		# 8
.L195:
	.set	noreorder
	.set	nomacro
	beq	$16,$2,.L194
	li	$2,-1			# 0xffffffff
	.set	macro
	.set	reorder

	lbu	$2,D_800A30E8
	#nop
	slt	$2,$2,$16
	beq	$2,$0,.L193
	sb	$16,D_800A30E8
.L193:
	lhu	$2,0($8)
	#nop
	sh	$2,4($7)
	lw	$2,4($8)
	#nop
	sw	$2,0($7)
	lw	$2,12($8)
	#nop
	lw	$3,0($2)
	lw	$4,4($2)
	lw	$5,8($2)
	lw	$6,12($2)
	sw	$3,20($7)
	sw	$4,24($7)
	sw	$5,28($7)
	sw	$6,32($7)
	lw	$3,16($2)
	lw	$4,20($2)
	lw	$5,24($2)
	lw	$6,28($2)
	sw	$3,36($7)
	sw	$4,40($7)
	sw	$5,44($7)
	sw	$6,48($7)
 #APP
 #NO_APP
	lh	$2,2($8)
	move	$4,$8
	sw	$2,8($7)
 #APP
 #NO_APP
	#.set	volatile
	lw	$3,16($8)
	#.set	novolatile
	lh	$2,4($7)
 #APP
	move $5, $7
 sh $0, 6($7)
 #NO_APP
	#nop
	sll	$2,$2,6
	sw	$3,12($7)
	addu	$3,$3,$2
	.set	noreorder
	.set	nomacro
	jal	func_80017A44
	sw	$3,16($7)
	.set	macro
	.set	reorder

	move	$2,$16
.L194:
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80017D84
.Lfe33:
	.size	 func_80017D84,.Lfe33-func_80017D84
	.align	2
	.globl	obj_Clear
	.type	 obj_Clear,@function
	.ent	obj_Clear
obj_Clear:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	sll	$2,$4,1
	addu	$2,$2,$4
	sll	$2,$2,2
	addu	$2,$2,$4
	sll	$2,$2,2
	sw	$0,g_file_data_buf($2)
	j	$31
	.end	obj_Clear
.Lfe34:
	.size	 obj_Clear,.Lfe34-obj_Clear
	.align	2
	.globl	obj_UpdatePosition
	.type	 obj_UpdatePosition,@function
	.ent	obj_UpdatePosition
obj_UpdatePosition:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	sll	$2,$4,1
	addu	$2,$2,$4
	sll	$2,$2,2
	addu	$2,$2,$4
	sll	$2,$2,2
	la	$3,g_file_data_buf
	addu	$2,$2,$3
	lw	$3,12($2)
	lh	$4,4($2)
	addu	$3,$3,$5
	sll	$4,$4,6
	sw	$3,12($2)
	addu	$3,$3,$4
	.set	noreorder
	.set	nomacro
	j	$31
	sw	$3,16($2)
	.set	macro
	.set	reorder

	.end	obj_UpdatePosition
.Lfe35:
	.size	 obj_UpdatePosition,.Lfe35-obj_UpdatePosition
	.align	2
	.globl	obj_AddValue
	.type	 obj_AddValue,@function
	.ent	obj_AddValue
obj_AddValue:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	sll	$2,$4,1
	addu	$2,$2,$4
	sll	$2,$2,2
	addu	$2,$2,$4
	sll	$2,$2,2
	la	$3,g_file_data_buf
	addu	$2,$2,$3
	lw	$3,0($2)
	#nop
	addu	$3,$3,$5
	.set	noreorder
	.set	nomacro
	j	$31
	sw	$3,0($2)
	.set	macro
	.set	reorder

	.end	obj_AddValue
.Lfe36:
	.size	 obj_AddValue,.Lfe36-obj_AddValue
	.align	2
	.globl	scratchpad_Save
	.type	 scratchpad_Save,@function
	.ent	scratchpad_Save
scratchpad_Save:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	li	$5,0x1f800000		# 528482304
	la	$4,D_800F5370
	move	$3,$0
.L203:
	#.set	volatile
	lw	$2,0($5)
	#.set	novolatile
	addu	$5,$5,4
	addu	$3,$3,1
	sw	$2,0($4)
	sltu	$2,$3,248
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L203
	addu	$4,$4,4
	.set	macro
	.set	reorder

	j	$31
	.end	scratchpad_Save
.Lfe37:
	.size	 scratchpad_Save,.Lfe37-scratchpad_Save
	.align	2
	.globl	scratchpad_Restore
	.type	 scratchpad_Restore,@function
	.ent	scratchpad_Restore
scratchpad_Restore:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	la	$5,D_800F5370
	li	$4,0x1f800000		# 528482304
	move	$3,$0
.L209:
	lw	$2,0($5)
	addu	$5,$5,4
	addu	$3,$3,1
	#.set	volatile
	sw	$2,0($4)
	#.set	novolatile
	sltu	$2,$3,248
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L209
	addu	$4,$4,4
	.set	macro
	.set	reorder

	j	$31
	.end	scratchpad_Restore
.Lfe38:
	.size	 scratchpad_Restore,.Lfe38-scratchpad_Restore
	.align	2
	.globl	sys_StubEmpty2
	.type	 sys_StubEmpty2,@function
	.ent	sys_StubEmpty2
sys_StubEmpty2:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	sys_StubEmpty2
.Lfe39:
	.size	 sys_StubEmpty2,.Lfe39-sys_StubEmpty2
	.align	2
	.globl	sys_StubEmpty3
	.type	 sys_StubEmpty3,@function
	.ent	sys_StubEmpty3
sys_StubEmpty3:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	sys_StubEmpty3
.Lfe40:
	.size	 sys_StubEmpty3,.Lfe40-sys_StubEmpty3
	.ident	"GCC: (GNU) 2.7.2"
