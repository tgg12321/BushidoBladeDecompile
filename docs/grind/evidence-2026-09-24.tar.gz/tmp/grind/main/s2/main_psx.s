main:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, extra= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	sw	$31,36($sp)
	sw	$20,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	.set	noreorder
	.set	nomacro
	jal	__main
	sw	$16,16($sp)
	.set	macro
	.set	reorder

	jal	func_80083794
	li	$4,-2145452032			# 0x801f0000
	.set	noreorder
	.set	nomacro
	jal	SetSp
	ori	$4,$4,0xff00
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	SetMem
	li	$4,0x00000002		# 2
	.set	macro
	.set	reorder

	jal	sys_Init
	jal	sys_GameInit
	.set	noreorder
	.set	nomacro
	jal	SetDispMask
	li	$4,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$4,-2146369536			# 0x80110000
	ori	$4,$4,0x8800
	move	$5,$18
	.set	noreorder
	.set	nomacro
	jal	func_80016A8C
	move	$6,$17
	.set	macro
	.set	reorder

	la	$20,D_800A3770
	li	$2,0x0000000f		# 15
	sh	$2,D_800A3834
	sb	$0,D_800A390D
	sw	$0,D_800A36AC
$L102:
	lw	$2,D_800A36AC
	li	$5,0x00001008		# 4104
	la	$3,D_800F7438
	andi	$17,$2,0x0001
	sll	$2,$17,7
	addu	$2,$2,$17
	sll	$2,$2,3
	addu	$2,$2,$17
	sll	$2,$2,4
	addu	$18,$2,$3
	addu	$16,$18,112
	.set	noreorder
	.set	nomacro
	jal	ClearOTagR
	move	$4,$16
	.set	macro
	.set	reorder

	sll	$2,$17,2
	addu	$2,$2,$20
	lw	$2,0($2)
	sw	$16,D_800A374C
	sw	$2,D_800A38B4
	.set	noreorder
	.set	nomacro
	jal	func_80060E04
	move	$4,$17
	.set	macro
	.set	reorder

	jal	func_8003D2F4
	.set	noreorder
	.set	nomacro
	jal	func_80019568
	move	$4,$19
	.set	macro
	.set	reorder

	jal	func_80036940
	jal	func_8005C6D0
	lbu	$2,D_800A3928
	#nop
	beq	$2,$0,$L103
	jal	func_800372C0
	li	$2,0x000000ff		# 255
	sb	$2,D_800A3768
	li	$2,0x00000008		# 8
	sb	$0,D_800A3928
	sb	$0,D_800A31DA
	sh	$2,D_800A3834
$L103:
	lh	$2,D_800A3834
	#nop
	sll	$2,$2,2
	lw	$2,D_8008D090($2)
	#nop
	jal	$31,$2
	jal	func_8003D330
	li	$4,-234881024			# 0xf2000000
$L125:
	.set	noreorder
	.set	nomacro
	jal	GetRCnt
	ori	$4,$4,0x0001
	.set	macro
	.set	reorder

	lbu	$3,D_800A36F1
	#nop
	addu	$3,$3,-1
	sll	$3,$3,8
	addu	$3,$3,128
	slt	$2,$2,$3
	beq	$2,$0,$L105
	jal	rand
	.set	noreorder
	.set	nomacro
	j	$L125
	li	$4,-234881024			# 0xf2000000
	.set	macro
	.set	reorder

$L105:
	.set	noreorder
	.set	nomacro
	jal	VSync
	li	$4,0x00000001		# 1
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	VSync
	move	$4,$0
	.set	macro
	.set	reorder

	li	$4,-234881024			# 0xf2000000
	.set	noreorder
	.set	nomacro
	jal	ResetRCnt
	ori	$4,$4,0x0001
	.set	macro
	.set	reorder

	lbu	$19,D_800A390D
	#nop
	.set	noreorder
	.set	nomacro
	bne	$19,$0,$L126
	li	$5,-131072			# 0xfffe0000
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	PutDispEnv
	addu	$4,$18,92
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	PutDrawEnv
	move	$4,$18
	.set	macro
	.set	reorder

	li	$5,-131072			# 0xfffe0000
$L126:
	sll	$2,$17,2
	addu	$2,$2,$20
	lw	$3,D_800A38B4
	lw	$4,0($2)
	lw	$2,D_800A30DC
	ori	$5,$5,0xcc00
	addu	$3,$3,$5
	subu	$4,$4,$3
	slt	$2,$4,$2
	beq	$2,$0,$L110
	sw	$4,D_800A30DC
$L110:
	bgez	$4,$L111
	la	$4,D_80010034
	jal	printf
$L114:
	jal	func_800164F8
	j	$L114
$L111:
	lbu	$2,D_800A390D
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L116
	addu	$2,$2,-1
	.set	macro
	.set	reorder

	sb	$2,D_800A390D
	j	$L117
$L116:
	.set	noreorder
	.set	nomacro
	jal	DrawOTag
	addu	$4,$18,16524
	.set	macro
	.set	reorder

	lw	$2,D_800A36AC
	#nop
	addu	$2,$2,1
	sw	$2,D_800A36AC
$L117:
	lh	$3,D_800A3834
	li	$2,0x00000001		# 1
	bne	$3,$2,$L102
	.set	noreorder
	.set	nomacro
	bne	$19,$0,$L102
	li	$3,0x08000000		# 134217728
	.set	macro
	.set	reorder

	lw	$2,D_80102794
	ori	$3,$3,0x0800
	and	$2,$2,$3
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L121
	li	$2,0x00000002		# 2
	.set	macro
	.set	reorder

	lh	$3,D_800A38DC
	#nop
	bne	$3,$2,$L102
	lbu	$2,D_800A3713
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L102
	addu	$2,$2,-1
	.set	macro
	.set	reorder

	sb	$2,D_800A3713
	andi	$2,$2,0x00ff
	bne	$2,$0,$L102
$L121:
	move	$4,$18
	.set	noreorder
	.set	nomacro
	jal	func_80016E60
	move	$5,$17
	.set	macro
	.set	reorder

	j	$L102
	lw	$31,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,40
	j	$31
	.end	main
