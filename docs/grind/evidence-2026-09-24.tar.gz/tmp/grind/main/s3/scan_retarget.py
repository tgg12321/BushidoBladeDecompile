#!/usr/bin/env python3
"""Corpus scan for the ASPSX-retarget signature found on main (grind s3).

Signature (see memory/grind/main/evidence.md s3): a loop head with TWO labels
4 bytes apart (one insn between), where branches whose delay slot ASPSX could
fill were retargeted to the LATER label (past the fill source insn), while
branches left with a nop delay slot still target the EARLIER label (executing
the insn). Under our cc1's reorg, the redundancy thread-skip retargets the
unfilled branches too, producing a 2-branch-target byte diff that only label
regfix rules can patch. Each corpus hit = another function in the same class,
strengthening the owner-level disposition packet.

Detection per asm/funcs/*.s:
  - label pair (L1, L2) with addr(L2) == addr(L1) + 4, both branch-targeted
  - >=1 branch -> L1 whose delay slot is `nop` (unfilled, on the early label)
  - >=1 branch -> L2 whose delay slot is NOT nop (filled, retargeted past)
"""
import re, sys, glob, os

LABEL_RE = re.compile(r'^\s*(\.L\w+):')
INSN_RE = re.compile(r'^\s*/\* ([0-9A-Fa-f]+) ([0-9A-Fa-f]+) [0-9A-Fa-f]+ \*/\s+(\S+)\s*(.*)')
BRANCH_MNEMONICS = {'b','beq','bne','beqz','bnez','blez','bgtz','bltz','bgez','j',
                    'beql','bnel','bltzal','bgezal'}

def scan_file(path):
    # ordered stream of ('label', name) / ('insn', addr, mnem, ops)
    items = []
    for line in open(path, encoding='utf-8', errors='replace'):
        m = LABEL_RE.match(line)
        if m:
            items.append(('label', m.group(1)))
            continue
        m = INSN_RE.match(line)
        if m:
            items.append(('insn', int(m.group(2), 16), m.group(3), m.group(4)))
    # label -> addr of next insn
    label_addr = {}
    for i, it in enumerate(items):
        if it[0] == 'label':
            for j in range(i + 1, len(items)):
                if items[j][0] == 'insn':
                    label_addr[it[1]] = items[j][1]
                    break
    # branches: (target_label, delay_mnem)
    branches = []
    insn_seq = [it for it in items if it[0] == 'insn']
    for k, it in enumerate(insn_seq):
        mnem, ops = it[2], it[3]
        if mnem in BRANCH_MNEMONICS:
            tm = re.search(r'(\.L\w+)\s*$', ops)
            if not tm:
                continue
            delay = insn_seq[k + 1][2] if k + 1 < len(insn_seq) else '?'
            branches.append((tm.group(1), delay))
    # adjacent label pairs, both targeted
    targets = {}
    for lbl, delay in branches:
        targets.setdefault(lbl, []).append(delay)
    hits = []
    labels_sorted = sorted(label_addr.items(), key=lambda kv: kv[1])
    for a in range(len(labels_sorted) - 1):
        l1, a1 = labels_sorted[a]
        l2, a2 = labels_sorted[a + 1]
        if a2 - a1 != 4:
            continue
        if l1 not in targets or l2 not in targets:
            continue
        unfilled_l1 = [d for d in targets[l1] if d == 'nop']
        filled_l2 = [d for d in targets[l2] if d != 'nop']
        if unfilled_l1 and filled_l2:
            hits.append((l1, l2, len(targets[l1]), len(unfilled_l1),
                         len(targets[l2]), len(filled_l2)))
    return hits

def main():
    root = os.path.dirname(os.path.abspath(__file__))
    repo = os.path.abspath(os.path.join(root, '..', '..', '..', '..'))
    n_hit = 0
    files = sorted(glob.glob(os.path.join(repo, 'asm', 'funcs', '*.s')))
    print(f'scanning {len(files)} files')
    for path in files:
        try:
            hits = scan_file(path)
        except Exception as e:
            print(f'ERR {os.path.basename(path)}: {e}')
            continue
        for (l1, l2, t1, u1, t2, f2) in hits:
            n_hit += 1
            print(f'HIT {os.path.basename(path)}: {l1}(+0)<-{t1} br ({u1} nop-delay) | '
                  f'{l2}(+4)<-{t2} br ({f2} filled)')
    print(f'total signature hits: {n_hit}')

if __name__ == '__main__':
    main()
