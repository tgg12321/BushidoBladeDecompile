#!/usr/bin/env python3
"""s17 probe harness: splice each s14/variants/*.c body into src/code6cac_b.c,
score with the HONEST sandbox (`sandbox func_80034F88 --disable all`), census
the sandbox object (lbu / sb / lui), restore src/ afterwards.

    python3 .../s14/probe.py [name.c ...]      (no args = all variants)
"""
import json
import pathlib
import re
import subprocess
import sys

HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parents[3]
SRC = ROOT / "src" / "code6cac_b.c"
VARDIR = HERE / "variants"
START = "void func_80034F88(void) {"
END_MARK = "void func_8003504C(void) {"


def splice(body, text):
    i = text.index(START)
    j = text.index(END_MARK, i)
    return text[:i] + body.rstrip() + "\n" + text[j:]


def sandbox():
    r = subprocess.run(["python3", "-m", "engine.cli", "sandbox", "func_80034F88",
                        "--disable", "all"], cwd=ROOT, capture_output=True, text=True)
    m = re.search(r'"score":\s*(-?\d+)', r.stdout)
    n = re.search(r'"build_insns":\s*(\d+)', r.stdout)
    return (int(m.group(1)) if m else None, int(n.group(1)) if n else None,
            "" if m else (r.stdout[-300:] + r.stderr[-300:]))


def census():
    obj = ROOT / "tmp" / "sandbox" / "func_80034F88" / "code6cac_b.o"
    if not obj.exists():
        return {}
    r = subprocess.run(["mipsel-linux-gnu-objdump", "-d", str(obj)],
                       cwd=ROOT, capture_output=True, text=True)
    return {k: len(re.findall(r"\t" + k + r"\t", r.stdout))
            for k in ("lbu", "sb", "lui")}


def main():
    orig = SRC.read_text()
    names = sys.argv[1:] or sorted(p.name for p in VARDIR.glob("*.c"))
    out = []
    try:
        for name in names:
            SRC.write_text(splice((VARDIR / name).read_text(), orig), newline="\n")
            s, n, err = sandbox()
            out.append({"v": name, "score": s, "insns": n, **census(), "err": err[:200]})
            print(json.dumps(out[-1]), flush=True)
    finally:
        SRC.write_text(orig, newline="\n")
    (HERE / "results.json").write_text(json.dumps(out, indent=1), newline="\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
