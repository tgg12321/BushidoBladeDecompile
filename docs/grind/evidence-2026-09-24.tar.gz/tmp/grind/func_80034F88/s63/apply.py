import sys, pathlib, subprocess
root = pathlib.Path(".")
body = pathlib.Path(sys.argv[1]).read_text().rstrip("\n") + "\n"
subprocess.run(["git","checkout","--","include/code6cac.h","src/code6cac.c","src/code6cac_b.c"],check=True)

h = root/"include/code6cac.h"
t = h.read_text()
t = t.replace("extern u8 D_80106A70;\nextern u8 D_80106A71;\nextern u8 D_80106A72;\n",
              "extern u8 D_80106A70[3];\n")
assert "D_80106A70[3]" in t
h.write_bytes(t.encode())

c = root/"src/code6cac.c"
t = c.read_text()
t = t.replace("    D_80106A70 = 0x11;\n    D_80106A71 = 0x44;\n    D_80106A72 = 0x88;\n",
              "    D_80106A70[0] = 0x11;\n    D_80106A70[1] = 0x44;\n    D_80106A70[2] = 0x88;\n")
t = t.replace("return (D_80106A70 & 0xF) | ((D_80106A71 & 0xF) << 4) | ((D_80106A72 & 0xF) << 8);",
              "return (D_80106A70[0] & 0xF) | ((D_80106A70[1] & 0xF) << 4) | ((D_80106A70[2] & 0xF) << 8);")
assert "D_80106A71" not in t
c.write_bytes(t.encode())

b = root/"src/code6cac_b.c"
t = b.read_text()
t = t.replace('INCLUDE_ASM("asm/funcs", func_80034F88);\n', body)
assert 'INCLUDE_ASM("asm/funcs", func_80034F88)' not in t
b.write_bytes(t.encode())
print("applied", sys.argv[1])
