#!/usr/bin/env python3
"""s22 gate-2 census: does SOTN master exhibit MULTIPLE simultaneously-live C
handles on ONE global (two locals both initialised from the same &SYM inside a
single function), as a load-bearing / match-required construct?

Run against the local sotn-decomp master checkout. Prints, per hit:
    file:line  function  symbol  handles
plus any nearby fake/match annotation on the handle lines.
"""
import re
import sys
from pathlib import Path

ROOT = Path(sys.argv[1] if len(sys.argv) > 1 else r"C:\Users\Trenton\Desktop\sotn-decomp")
SRC = ROOT / "src"

# start of a top-level function definition (col 0, has '(' and ends with '{')
FUNC_RE = re.compile(r"^[A-Za-z_][\w \t\*]*\**\s*([A-Za-z_]\w*)\s*\([^;]*\)\s*\{\s*$")
# `foo = &g_Bar;` / `Type *foo = &g_Bar;` / `&g_Bar[3]` / `&g_Bar.x`
ADDR_RE = re.compile(r"\b([A-Za-z_]\w*)\s*=\s*&\s*([A-Za-z_]\w*)\b")

hits = 0
files = 0
for path in sorted(SRC.rglob("*.c")):
    files += 1
    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        continue
    fname = "<file-scope>"
    fstart = 0
    # per function: symbol -> {handle: [lineno,...]}
    table = {}

    def flush():
        global hits
        for sym, handles in table.items():
            if len(handles) >= 2:
                hits += 1
                locs = ", ".join(
                    f"{h}@{','.join(str(n) for n in ns)}" for h, ns in handles.items()
                )
                print(
                    f"{path.relative_to(ROOT).as_posix()}:{fstart}  {fname}  "
                    f"&{sym}  ->  {locs}"
                )
                for h, ns in handles.items():
                    for n in ns:
                        txt = lines[n - 1].strip()
                        print(f"      {n}: {txt}")

    for i, line in enumerate(lines, 1):
        m = FUNC_RE.match(line)
        if m:
            flush()
            table = {}
            fname = m.group(1)
            fstart = i
            continue
        for handle, sym in ADDR_RE.findall(line):
            table.setdefault(sym, {}).setdefault(handle, []).append(i)
    flush()

print(f"\n--- scanned {files} .c files under {SRC}; functions with 2+ distinct "
      f"C handles on one &SYMBOL: {hits}")
