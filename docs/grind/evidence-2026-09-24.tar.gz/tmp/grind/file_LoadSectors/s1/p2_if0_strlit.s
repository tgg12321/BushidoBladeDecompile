	.file	1 "tmp/grind/file_LoadSectors/s1/p2_if0_strlit.c"

 # GNU C 2.7.2 [AL 1.1, MM 40] GNU MIPS/ELF compiled by GNU C

 # Cc1 defaults:
 # -mgas

 # Cc1 arguments (-G value = 0, Cpu = 3000, ISA = 1):
 # -O2 -G0 -funsigned-char -quiet -mcpu=3000 -mips1 -mno-abicalls -fno-builtin
 # -w -o

	.version	"01.01"
gcc2_compiled.:
.section	.rodata
	.align	2
.LC0:
	.string	"file_LoadSectors: open error %d %d %d\n"
	.text
	.align	2
	.globl	file_LoadSectors
	.type	 file_LoadSectors,@function
	.ent	file_LoadSectors
file_LoadSectors:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, extra= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	sw	$18,24($sp)
	move	$18,$5
	sw	$16,16($sp)
	move	$16,$6
	sw	$19,28($sp)
	move	$19,$7
	addu	$4,$4,4
	move	$5,$0
	move	$6,$0
	sw	$31,36($sp)
	sw	$20,32($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80083698
	sw	$17,20($sp)
	.set	macro
	.set	reorder

	move	$17,$2
	li	$2,-1			# 0xffffffff
	.set	noreorder
	.set	nomacro
	bne	$17,$2,.L3
	move	$4,$17
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L10
	li	$2,-2			# 0xfffffffe
	.set	macro
	.set	reorder

.L11:
	.set	noreorder
	.set	nomacro
	jal	bios_FileClose_B
	move	$4,$17
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L10
	li	$2,-1			# 0xffffffff
	.set	macro
	.set	reorder

.L3:
	sll	$5,$16,11
	.set	noreorder
	.set	nomacro
	jal	ang_hosei
	move	$6,$0
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	blez	$19,.L4
	move	$16,$0
	.set	macro
	.set	reorder

	li	$20,0x00000800		# 2048
.L5:
	move	$4,$17
	move	$5,$18
	.set	noreorder
	.set	nomacro
	jal	bios_FileRead
	li	$6,0x00000800		# 2048
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	bne	$2,$20,.L11
	addu	$16,$16,1
	.set	macro
	.set	reorder

	slt	$2,$16,$19
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L5
	addu	$18,$18,2048
	.set	macro
	.set	reorder

.L4:
	.set	noreorder
	.set	nomacro
	jal	md_gview_init
	move	$4,$17
	.set	macro
	.set	reorder

	sll	$2,$19,11
.L10:
	lw	$31,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,40
	j	$31
	.end	file_LoadSectors
.Lfe1:
	.size	 file_LoadSectors,.Lfe1-file_LoadSectors
	.ident	"GCC: (GNU) 2.7.2"
