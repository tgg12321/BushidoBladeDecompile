#!/bin/bash
# eval.sh <chassis.c> <label>
# 1) instrumented-cc1 ALLOCDBG allocno priority table for the standalone chassis
# 2) assemble via the exact build pipeline and objdump-diff against the s4 rig's target.o
set -e
cd "/mnt/c/Users/Trenton/Desktop/Bushido Blade 2 Decompile"
SRC="$1"; L="${2:-x}"
OUT=tmp/grind/func_80078654/s5/$L
mkdir -p "$OUT"

# --- allocno table (instrumented cc1, NOT build/cc1) ---
BB2_ALLOC_DEBUG=1 tools/gcc-2.7.2/cc1 -O2 -G0 -funsigned-char -quiet -mcpu=3000 \
  -mips1 -mno-abicalls -fno-builtin -w -mel "$SRC" -o "$OUT/chassis.s" 2> "$OUT/alloc.log" || true
echo "--- ALLOCDBG ($L) ---"
grep -E 'ord=|seed_used' "$OUT/alloc.log" | head -30

# --- bytes ---
cat "$SRC" | tools/gcc-2.7.2/build/cc1 -O2 -G0 -funsigned-char -quiet -mcpu=3000 -mips1 -mno-abicalls -fno-builtin -w -mel \
  | python3 tools/prologue_fix.py \
  | python3 tools/maspsx/maspsx.py --expand-div --aspsx-version=2.34 --sdata-syms=sdata_syms.txt --sdata-funcs=sdata_funcs.txt --sdata-exclude=sdata_exclude.txt --expand-lb --expand-lb-funcs=expand_lb_funcs.txt --multu-funcs=multu_funcs.txt --expand-dest-funcs=expand_dest_funcs.txt --label-nop-funcs=maspsx_label_nop_funcs.txt \
  | python3 tools/multu_pad.py --funcs multu_pad_funcs.txt \
  | mipsel-linux-gnu-as -Iinclude -march=r3000 -mtune=r3000 -no-pad-sections -O1 -G0 -o "$OUT/chassis.o"

f() {
  mipsel-linux-gnu-objdump -d "$1" | awk '/<func_80078654>:/{p=1;next} /^[0-9a-f]+ </{p=0} p' \
    | sed 's/^[^\t]*\t[^\t]*\t//' | sed 's/0x[0-9a-f]*//g' | grep -v '^$'
}
f "$OUT/chassis.o" > "$OUT/mine.txt"
f tmp/grind/func_80078654/s4/ws/target.o > "$OUT/tgt.txt"
echo "--- insns: mine=$(wc -l < "$OUT/mine.txt") target=$(wc -l < "$OUT/tgt.txt")  difflines=$(diff "$OUT/mine.txt" "$OUT/tgt.txt" | grep -c '^[<>]') ---"
diff "$OUT/mine.txt" "$OUT/tgt.txt" | head -30
