#!/usr/bin/env python3
"""s9: where does the freshly built EXE differ from the original?  Prints every
differing 4-byte word grouped into contiguous runs, with the KSEG0 address."""
import sys
A = open("/mnt/c/Users/Trenton/Desktop/Bushido Blade 2 Decompile/build/bb2.exe", "rb").read()
B = open("/mnt/c/Users/Trenton/Desktop/Bushido Blade 2 Decompile/disc/SLUS_006.63", "rb").read()
print("sizes", len(A), len(B))
runs, cur = [], None
n = min(len(A), len(B))
for off in range(0, n - 3, 4):
    if A[off:off + 4] != B[off:off + 4]:
        if cur and cur[1] == off:
            cur[1] = off + 4
        else:
            cur = [off, off + 4]
            runs.append(cur)
for s, e in runs:
    print("file 0x%X..0x%X  vaddr 0x%08X  (%d words)" %
          (s, e, 0x80010000 + s - 0x800, (e - s) // 4))
    for off in range(s, e, 4):
        print("    0x%08X  built=%s  orig=%s" %
              (0x80010000 + off - 0x800,
               A[off:off + 4][::-1].hex().upper(),
               B[off:off + 4][::-1].hex().upper()))
print("total differing words:", sum((e - s) // 4 for s, e in runs))
