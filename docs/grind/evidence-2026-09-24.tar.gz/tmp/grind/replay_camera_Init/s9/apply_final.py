#!/usr/bin/env python3
"""s9 (second run): apply the full two-file matching patch for replay_camera_Init.

  1. include/code6cac.h        extern s16 D_80101E62;  -> extern s16 D_80101E62[];
  2. src/code6cac_b2_post.c:45 extern volatile s32 D_80101E70; -> extern s32 D_80101E70;
  3. src/code6cac_b2_post.c    every scalar D_80101E62 use -> D_80101E62[0]
                               every &D_80101E62          -> D_80101E62
  4. src/code6cac_b2_post.c    replay_camera_Init body <- memory/.../candidate.c

Usage:  python3 apply_final.py            (apply)
        python3 apply_final.py --revert   (git checkout the two files)
"""
import os, re, subprocess, sys

ROOT = "/mnt/c/Users/Trenton/Desktop/Bushido Blade 2 Decompile"
HDR = os.path.join(ROOT, "include/code6cac.h")
SRC = os.path.join(ROOT, "src/code6cac_b2_post.c")
CAND = os.path.join(ROOT, "memory/grind/replay_camera_Init/candidate.c")

if "--revert" in sys.argv:
    subprocess.check_call(["git", "checkout", "--", "include/code6cac.h",
                           "src/code6cac_b2_post.c"], cwd=ROOT)
    print("reverted")
    sys.exit(0)

# --- header -----------------------------------------------------------------
h = open(HDR).read()
assert "extern s16 D_80101E62;" in h, "header decl not found"
h = h.replace("extern s16 D_80101E62;", "extern s16 D_80101E62[];")
open(HDR, "w", newline="").write(h)

# --- src --------------------------------------------------------------------
s = open(SRC).read()
assert "extern volatile s32 D_80101E70;" in s, "volatile decl not found"
s = s.replace("extern volatile s32 D_80101E70;", "extern s32 D_80101E70;")

# body swap
start = s.index("s32 replay_camera_Init(s32 a0, s32 a1) {")
end = s.index("\n}\n", start) + len("\n}\n")
cand = open(CAND).read()
bstart = cand.index("s32 replay_camera_Init(s32 a0, s32 a1) {")
body = cand[bstart:]
assert body.rstrip().endswith("}")
s = s[:start] + body.rstrip("\n") + "\n" + s[end:]

# D_80101E62 array rewrite (placeholder protects the &-form)
s = s.replace("&D_80101E62", "\x00E62PTR\x00")
s = re.sub(r"\bD_80101E62\b(?!\s*\[)", "D_80101E62[0]", s)
s = s.replace("\x00E62PTR\x00", "D_80101E62")
open(SRC, "w", newline="").write(s)

print("applied")
for i, line in enumerate(open(SRC), 1):
    if "D_80101E62" in line or "D_80101E70" in line:
        print("  %4d  %s" % (i, line.rstrip()))
