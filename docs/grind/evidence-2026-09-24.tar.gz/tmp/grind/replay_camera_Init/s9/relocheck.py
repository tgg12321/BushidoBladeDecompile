#!/usr/bin/env python3
"""s9: resolve the sandbox object's relocations by hand and compare the FINAL
32-bit encodings, word for word, against the target bytes in
asm/funcs/replay_camera_Init.s.

The engine sandbox compares SYMBOLIC operands, so `%lo(SpecialCam)+4` reads as
different from `%lo(D_8008EC38)` even though both relocate to the same value.
This script answers the only question that matters: after relocation, are the
39 words identical?
"""
import re, subprocess, sys

ROOT = "/mnt/c/Users/Trenton/Desktop/Bushido Blade 2 Decompile"
OBJ = ROOT + "/tmp/sandbox/replay_camera_Init/code6cac_b2_post.o"
TGT = ROOT + "/asm/funcs/replay_camera_Init.s"

SYMS = {"SpecialCam": 0x8008EC34}


def symval(name):
    if name in SYMS:
        return SYMS[name]
    m = re.match(r"D_([0-9A-Fa-f]{8})$", name)
    if m:
        return int(m.group(1), 16)
    raise KeyError(name)


def target_words():
    out = []
    for ln in open(TGT):
        m = re.search(r"/\*\s+\w+\s+\w+\s+([0-9A-Fa-f]{8})\s+\*/", ln)
        if m:
            b = m.group(1)
            # stored little-endian byte string
            out.append(int(b[6:8] + b[4:6] + b[2:4] + b[0:2], 16))
    return out


def our_words():
    txt = subprocess.run(["mipsel-linux-gnu-objdump", "-dr", OBJ],
                         capture_output=True, text=True).stdout
    seg = txt.split("<replay_camera_Init>:")[1]
    words, relocs = [], {}
    for ln in seg.splitlines():
        m = re.match(r"\s*([0-9a-f]+):\s+([0-9a-f]{8})\s", ln)
        r = re.match(r"\s*([0-9a-f]+):\s+(R_MIPS_\S+)\s+(\S+)", ln)
        if m:
            words.append([int(m.group(1), 16), int(m.group(2), 16)])
        elif r:
            relocs.setdefault(int(r.group(1), 16), []).append(
                (r.group(2), r.group(3)))
        elif ln.strip().endswith(">:") and words:
            break
    base = words[0][0]
    # AHL pairing: HI16 uses the following LO16's in-field addend
    lo_addend = {}
    idxs = [w[0] for w in words]
    for i, (off, w) in enumerate(words):
        for kind, sym in relocs.get(off, []):
            if kind == "R_MIPS_LO16":
                lo_addend[off] = w & 0xFFFF
    pend_hi = []
    out = []
    for off, w in words:
        rl = relocs.get(off, [])
        nw = w
        for kind, sym in rl:
            if kind == "R_MIPS_LO16":
                S = symval(sym) + (w & 0xFFFF)
                nw = (w & 0xFFFF0000) | (S & 0xFFFF)
            elif kind == "R_MIPS_HI16":
                pend_hi.append((off, sym))
        if rl and rl[0][0] == "R_MIPS_LO16":
            # resolve any pending HI16 with this AHL
            ahl = w & 0xFFFF
            for hoff, hsym in pend_hi:
                S = symval(hsym) + ahl
                hi = ((S - ((S & 0xFFFF) ^ 0x8000) + 0x8000) >> 16) & 0xFFFF
                for k, ent in enumerate(out):
                    if ent[0] == hoff:
                        out[k] = (hoff, (ent[1] & 0xFFFF0000) | hi)
            pend_hi = []
        out.append((off, nw))
    return [w for _, w in out]


ours, tgt = our_words(), target_words()
print("ours=%d target=%d" % (len(ours), len(tgt)))
bad = 0
for i in range(max(len(ours), len(tgt))):
    o = ours[i] if i < len(ours) else None
    t = tgt[i] if i < len(tgt) else None
    if o != t:
        bad += 1
        print("  [%2d] ours=%s target=%s" %
              (i, "%08X" % o if o is not None else "--",
               "%08X" % t if t is not None else "--"))
print("DIFFERING WORDS:", bad)
