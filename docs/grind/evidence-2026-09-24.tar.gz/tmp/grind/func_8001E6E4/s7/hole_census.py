#!/usr/bin/env python3
"""s7 probe H-F5: find OTHER functions in the binary whose frame has an
ALLOCATED-BUT-NEVER-TOUCHED leading vars region -- the same shape as
func_8001E6E4's sp+0x10..0x17 phantom slot -- and report which of them are
already reconstructed in src/*.c, so their C shows what construct produced it.

For each asm/funcs/*.s:
  * frame size N from the prologue `addiu $sp, $sp, -N`
  * every sp-relative load/store offset actually touched
  * whether the function contains a `jal` (=> outgoing args area >= 16 bytes,
    so offsets 0..15 are the args area, not vars)
  * the callee-save block is detected as the top run of sw $s?/$ra/$fp offsets
A "hole" = a >=8-byte gap starting at 0x10 (first vars byte for a non-leaf)
before the lowest touched vars offset, with the save block accounted for.
"""
import os
import re
import subprocess

ASM = "asm/funcs"
prol_re = re.compile(r"addiu\s+\$sp,\s*\$sp,\s*-(0x[0-9A-Fa-f]+|\d+)")
mem_re = re.compile(r"\b(sw|sh|sb|swl|swr|lw|lh|lhu|lb|lbu|lwl|lwr)\s+\$(\w+),\s*(-?(?:0x)?[0-9A-Fa-f]+)?\(\$sp\)")
addiu_sp_re = re.compile(r"addiu\s+\$(\w+),\s*\$sp,\s*(0x[0-9A-Fa-f]+|\d+)")
SAVE_REGS = {"s0", "s1", "s2", "s3", "s4", "s5", "s6", "s7", "ra", "fp", "s8"}


def num(s):
    if s is None:
        return 0
    s = s.strip()
    neg = s.startswith("-")
    if neg:
        s = s[1:]
    v = int(s, 16) if s.lower().startswith("0x") else int(s)
    return -v if neg else v


rows = []
for fn in sorted(os.listdir(ASM)):
    if not fn.endswith(".s"):
        continue
    txt = open(os.path.join(ASM, fn), errors="replace").read()
    m = prol_re.search(txt)
    if not m:
        continue
    frame = num(m.group(1))
    if frame < 0x20:
        continue
    has_jal = "jal " in txt or "jal\t" in txt
    if not has_jal:
        continue
    touched = set()
    saves = set()
    for mm in mem_re.finditer(txt):
        op, reg, off = mm.group(1), mm.group(2), mm.group(3)
        o = num(off)
        if reg in SAVE_REGS and op in ("sw", "lw"):
            saves.add(o)
        touched.add(o)
    for mm in addiu_sp_re.finditer(txt):
        touched.add(num(mm.group(2)))  # address-taken record base counts as touched
    # vars region: [0x10, frame - savesize)
    save_lo = min(saves) if saves else frame
    vars_touched = sorted(o for o in touched if 0x10 <= o < save_lo)
    if not vars_touched:
        continue
    lo = vars_touched[0]
    hole = lo - 0x10
    if hole >= 8:
        rows.append((hole, fn[:-2], frame, hex(lo), hex(save_lo)))

rows.sort(reverse=True)
print(f"{len(rows)} non-leaf functions with a >=8-byte untouched leading vars hole\n")
print(f"{'hole':>5} {'func':<20} {'frame':>6} {'lowest':>8} {'saves@':>8}  in-src?")
for hole, fn, frame, lo, save_lo in rows:
    try:
        hit = subprocess.run(["grep", "-rl", fn, "src/"], capture_output=True, text=True).stdout.split()
    except Exception:
        hit = []
    print(f"{hole:>5} {fn:<20} {frame:>6} {lo:>8} {save_lo:>8}  {','.join(h.split('/')[-1] for h in hit)}")
