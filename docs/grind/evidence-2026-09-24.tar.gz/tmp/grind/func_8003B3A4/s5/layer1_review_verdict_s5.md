# Layer-1 cheat-reviewer verdict — func_8003B3A4 — s5 (2026-07-14, post owner ruling 13:45)

Decision: **PASS**

Summary: Store-only pointer alias at src/code6cac_c_ab.c:466-478 independently verified
against the tree — all pointer-alias-fake-exception prerequisites hold, owner ruling on
prerequisite-1 is on record and not being re-litigated, and prerequisite 4 (the only open
item) is satisfied.

Verification detail (reviewer's own record):
1. Lever exhaustion real: 8 rejected-form files in memory/grind/func_8003B3A4/rejected/;
   scores cross-checked in tmp/grind/func_8003B3A4/s2/variantA/B/C/D_*.txt: 6/6/8/6.
2. Mechanism verified against asm/funcs/func_8003B3A4.s: lui/addiu $v1 (lines 24-25)
   BEFORE beqz; sb $v0,0($v1) at .L8003B414 (line 33). Siblings func_8003B484/func_8003B4DC
   write D_8010277D directly (in-file control) — checks out.
3. Annotation committed at HEAD (src/code6cac_c_ab.c:467-471, commit 9e7d10f2).
4. Shape minimal + clean: store-only, block-scoped, ordinary C; rest of function clean —
   no pins, no __asm__, no volatile coercion, no dead stores, no alias renames.
5. Sandbox: tmp/grind/func_8003B3A4/s5/sandbox_prereq4_s5.json — score 0, 56/56,
   rules_dropped 0, disable all, measured s5.
6. Zero regfix/asmfix rules for the function or its address range.
