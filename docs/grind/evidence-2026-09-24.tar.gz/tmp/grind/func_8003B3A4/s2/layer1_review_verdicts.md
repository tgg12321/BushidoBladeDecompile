# Layer-1 cheat-reviewer verdicts — func_8003B3A4 (2026-07-13 review-gate session)

## Invocation 1 — FAIL
Grounds: (a) first-reach temporal taint — the alias was the sole form ever written at its
2026-03-26 introduction (commits 5a4dba61/3817ca7a, msg "Used register asm() hints and
pointer-based store patterns"); prereq 1 of pointer-alias-fake-exception reads "If the alias
was the first reach, FAIL", and the 2026-07-13 exhaustion record is post-hoc (produced after
the fable-blitz audit flagged the construct). (b) claimed "the ruling never addresses the
temporal sequencing question at all".

## Re-invocation with new fact (docs/grind/decisions.md 2026-07-13 22:51 ruling text)
Ground (b) shown factually wrong: ruling point (1) concedes the flag was correct at the time
("first-reach or un-annotated use of an exception is a cheat"); point (4) rules the complaint
"cured, not disguised"; operative clause directs "keep the annotated alias and proceed to
layer-1/2 cheat-reviewer and candidate-ready".

## Invocation 2 — NEEDS_USER (final)
Reviewer withdrew ground (b) but holds the Judge's "retroactive exhaustion cures first-reach"
doctrine is a novel interpretive gloss absent from the frozen rule text, authored by an
in-pipeline instrument to rescue the pipeline's own prior product — a genuine policy gap only
the human owner can close. Prerequisites (a) exhaustion artifacts real, (b) mechanism named,
(c) /* FAKE */ annotation present at src/code6cac_c_ab.c:467-471, (d) shape is the minimal
ordinary-C store-only alias — all verified INTACT against the tree by the reviewer.

Precise question for the owner (verbatim from the verdict's next_action):
"Does documented lever-exhaustion performed AFTER a construct was already flagged as an
unsanctioned first-reach cheat (same construct, re-measured and re-annotated post-audit)
satisfy the fake-exception family's first-reach prerequisite, or does the original 2026-03-26
introduction permanently taint this occurrence regardless of later measurement?"

Disposition: NO self-resolved NEEDS_USER (review-discipline-before-commit hard rule #1) —
session ends as ruling-request; layer-2 not run (it gates on layer-1 clearance + owner answer).
