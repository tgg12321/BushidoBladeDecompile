"""UNFOCUSED depth-2 sweep of global.c's modelled inputs (plain control).

s15 ran depth 1 and found exactly 3 reaching atoms (2 routes), both foreclosed.
This asks the next question the frontier names: does a PAIR of modelled
perturbations reach target's 103->$t1 where no single atom does, and is the pair
free of the two foreclosed atoms (own $t1 preference; the 97<->103 edge)?
"""
import json, sys, itertools
sys.path.insert(0, "tools/ra_solver")
from simulate import Sim

MODEL = sys.argv[1] if len(sys.argv) > 1 else "tmp/grind/func_8002EA24/s15/plain.model.json"
GOAL_P = int(sys.argv[2]) if len(sys.argv) > 2 else 103
GOAL_R = int(sys.argv[3]) if len(sys.argv) > 3 else 9

M = json.load(open(MODEL))
S = Sim(M)
order, base = S.simulate()
allp = sorted(set(S.pseudos) | {int(k) for k in M["conflicts"]})
print("model", MODEL, "pseudos", allp)
print("baseline", {p: base.get(p) for p in order})

atoms = []   # (desc, pseudo, override-dict-for-that-pseudo)
for p in allp:
    f = S.flow.get(p, {})
    nr, ll = f.get("nrefs_flow", 1), f.get("livelen_flow", 1)
    for d in range(-nr + 1, 25):
        if d:
            atoms.append((f"p{p}:refs{nr}->{nr+d}", p, {"nrefs": nr + d}))
    for d in (-16, -12, -8, -6, -4, -2, -1, 1, 2, 4, 6, 8, 12, 16, 24, 32):
        if ll + d >= 1:
            atoms.append((f"p{p}:livelen{ll}->{ll+d}", p, {"livelen": ll + d}))
    cc = f.get("calls_crossed", 0)
    atoms.append((f"p{p}:calls->{0 if cc else 1}", p, {"calls": 0 if cc else 1}))
    for q in allp:
        if q != p and q not in S.conf.get(p, set()):
            atoms.append((f"conf{p}<->{q}", p, {"conf_add": [q]}))
    for r in range(2, 26):
        cur = sorted(S.prefs.get(p, set()))
        if [r] != cur:
            atoms.append((f"p{p}:prefs{cur}->[{r}]", p, {"prefs": [r]}))
print("atom count", len(atoms))

def run(ovs):
    try:
        _, got = S.simulate(overrides=ovs)
    except Exception:
        return None
    return got

def merge(a, b):
    da, pa, oa = a
    db, pb, ob = b
    ov = {}
    for p, o in ((pa, oa), (pb, ob)):
        cur = ov.setdefault(p, {})
        for k, v in o.items():
            if k in cur:
                if k == "conf_add":
                    cur[k] = sorted(set(cur[k]) | set(v))
                else:
                    return None          # two atoms fighting over one scalar input
            else:
                cur[k] = v
    return ov

d1 = []
for a in atoms:
    got = run({a[1]: a[2]})
    if got and got.get(GOAL_P) == GOAL_R:
        d1.append(a[0])
print("depth-1 reaching:", len(d1))
for d in d1:
    print("   ", d)
d1set = set(d1)

hits = []
n = 0
for a, b in itertools.combinations(atoms, 2):
    if a[0] in d1set or b[0] in d1set:
        continue
    ov = merge(a, b)
    if ov is None:
        continue
    n += 1
    got = run(ov)
    if got and got.get(GOAL_P) == GOAL_R:
        coll = {p: (base.get(p), got.get(p)) for p in order
                if p != GOAL_P and got.get(p) != base.get(p)}
        hits.append((a[0], b[0], coll))
print(f"pairs evaluated: {n}")
print(f"depth-2 reaching pairs (neither atom reaching alone): {len(hits)}")
clean = [h for h in hits if not h[2]]
print(f"  CLEAN: {len(clean)}")
for h in clean[:200]:
    print("    ", h[0], "+", h[1])
print(f"  with collateral: {len(hits)-len(clean)}")
for h in hits[:60]:
    if h[2]:
        print("    ", h[0], "+", h[1], h[2])
