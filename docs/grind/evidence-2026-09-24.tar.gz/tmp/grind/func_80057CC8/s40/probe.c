typedef unsigned char u8;
typedef short s16;
typedef int s32;
extern s32 ratan2(s32, s32);

/* A: two source-level reads of *(s16**)(a0+4), an extern call BETWEEN them. */
s32 pA(u8 *a0, s32 i, s32 j) {
    s32 r = ratan2((*(s16 **)(a0 + 4))[i], 0);
    return r + (*(s16 **)(a0 + 4))[j];
}

/* B: the SAME two source-level reads, NO call between them. */
s32 pB(u8 *a0, s32 i, s32 j) {
    s32 r = (*(s16 **)(a0 + 4))[i];
    return r + (*(s16 **)(a0 + 4))[j];
}

/* C: one read cached in a local, call between the two uses. */
s32 pC(u8 *a0, s32 i, s32 j) {
    s16 *t = *(s16 **)(a0 + 4);
    s32 r = ratan2(t[i], 0);
    return r + t[j];
}

/* D: two source-level reads, call between, but the pointed-to slot is const-
   qualified so the MEM carries RTX_UNCHANGING_P and the call cannot kill it. */
s32 pD(u8 *a0, s32 i, s32 j) {
    s32 r = ratan2((*(s16 *const *)(a0 + 4))[i], 0);
    return r + (*(s16 *const *)(a0 + 4))[j];
}
