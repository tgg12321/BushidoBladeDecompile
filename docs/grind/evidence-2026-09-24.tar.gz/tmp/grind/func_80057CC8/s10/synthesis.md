# s10 SYNTHESIS — func_80057CC8

Session modality: synthesis. Job: merge the s1–s9 ledger, name the strongest
merged attack, and reset the frontier. No new sandbox measurements this
session — the analytical output IS the artifact.

## The proven core (immovable facts from s1–s9)

1. **Floor is 3** on candidate.c (offset+table reassociation of both p adds,
   s3 pin removed). 3-insn gap localizes to p1's addu dest: ours `addu v1,v0,a2`
   vs target `addu v0,v0,a2` (cascades to two lh base regs).
2. **Pseudo 86 = DECL_RTL(p) [s7 CONFIRMED, /v-marked in every dump].**
   Both p1 (insn 89) and p2 (insn 124) SET the SAME pseudo 86.
3. **86's copy-pref = {3} [s6/s7 CONFIRMED].** Origin: pseudo 129 (shifted
   next_idx, v1 by local-alloc) propagates via expand_preferences from insn
   124's addsi3. p1 operands (112 v0, 88 a2) do NOT propagate; p2's other
   operand (130 a0) does NOT propagate. Only 129→86 does.
4. **86 conflicts with v0 [s6 CONFIRMED].** sched1 hoists insn 115
   (`and $v0, $v0, 0xFFF` finalizing ang_prev) from (114,117) to (145,147),
   extending v0 live across insn 124.
5. **s7 EXPLICIT COROLLARY:** any pure-C form that keeps `p` as ONE C
   variable cannot reach target's p1=v0 allocation — 86 will always land in
   v1 because {3} is a positive pref and v0 is conflict-blocked. Two levers
   are needed (kill the hoist AND kill the {3} pref), and BOTH the hoist and
   the pref trace to properties of a single-pseudo `p`.

## The binding constraint (Judge + user rulings)

Every source-level spelling that creates TWO C-locals for the p1/p2 pointers
is closed: 17 rejected forms in `rejected/`, spanning block-scope aliases,
function-scope aliases, permuter-found long/s16* holders, ternary direct-
bind, split-init-off-accumulation, inline-both-call-sites, and split
lh px0/px1 locals. The Judge's binding sentence for this session is
"under any spelling (semantic naming, numeric suffix, block-scope, function-
scope, or FAKE-annotated)". The user's 2026-06-22 rejection of split-init
via layer-2 review made this explicit.

## The impossibility surface

Combining points 5 and the Judge constraint:

- ONE C-variable `p` ⇒ ONE RTL pseudo 86 ⇒ p1 dest cannot be v0.
- TWO C-variables ⇒ closed by Judge + rejected bank.

There is a THIRD path the Judge NAMED for this session (see next section),
but the two axes the Judge suggested were both measured dead in s8:
- inline-both-call-sites: score 0 but cheat-class (char-for-char address-expr
  duplication of a 30+ char expression, 4× per call). Rejected.
- p2 PLUS operand swap: score 3→9 regression.

## What remains (the true frontier — reset)

The s1–s9 ledger names three unmeasured/unresolvable axes. Ranked by
plausibility given the s6/s7 forensics:

### F1 — Duplicated-statement-into-arms (STRUCTURAL modality) [PRIMARY]

Concrete probe: duplicate the assignment `p = (s16*)((((s32)(prev_idx<<16)>>16)<<2) + (s32)table);`
INSIDE BOTH arms of `if ((s16)prev_idx < 0) { prev_idx = arg0[3] - 1; }` —
i.e., the ELSE-arm gets `else { p = <expr>; }` explicitly with the same
statement, and the THEN-arm appends the same assignment. This is a
SOTN-sanctioned form per [[duplicated-statement-into-arms]]: cross-jump
find_cross_jump re-merges byte-identical arms, so the emitted bytes are
neutral, but the SOURCE-level duplication bumps pseudo 86's reg_n_refs
count — which enters global.c's allocno-priority calculation.

**Why this is DIFFERENT from the closed axes:** it uses ONE `p` (not two
locals), the duplication is a genuine SOTN policy carve-out (not a
cheat-by-any-spelling), the source-level statement duplication is human-
readable (not an unmotivated holder), and its mechanism is a REFS-COUNT
adjustment on the SAME pseudo — orthogonal to lifetime shaping.

**Why it might still fail:** reg_n_refs affects allocno PRIORITY, but the
copy-pref {3} on pseudo 86 is a POSITIVE preference — priority reordering
doesn't remove it. If 86 gets allocated FIRST (before 129), 129 has not yet
placed in v1, so the expand_preferences propagation may or may not have been
computed differently (expand_preferences precedes actual allocation, so the
pref set is built from static SET-operand analysis, not from realized
placements — so reg_n_refs bump likely does NOT alter 86's pref set at all).

**Prerequisite for closure:** cross-jump MUST merge the two arms byte-
identically. If it doesn't, the +1 insn kills byte-neutrality and the SOTN
sanction prerequisite fails.

**Required review chain if it lands at 0:** layer-1 cheat-reviewer, then
layer-2 fresh cheat-reviewer per [[duplicated-statement-into-arms]] policy
compliance. Must carry the mandatory FAKE annotation and cite s1–s9 as
exhaustion evidence.

### F2 — Header-type correction on arg0 (REDERIVE modality) [SECONDARY]

Per [[header-type-correction-from-use-sites]]: if arg0 is actually a
pointer to a game-state struct (not `u8*`), grepping ALL callers may reveal
a consistent struct layout with fields at offsets 2 (u8), 3 (u8), and 4
(s16**). If so, rewriting the function via struct-member access changes
coercion casts, may alter combine's shape for `(s16*)((offset)+(table))`,
and could produce different RTL.

**Speculative — requires evidence.** If the caller sweep shows arg0 is
genuinely per-byte-offset used everywhere, this axis dies. First step is
the grep, not the rewrite.

### F3 — Kengo (PS2 successor) transplant (REDERIVE modality) [TERTIARY]

Marionation engine reuse per AGENTS.md. [[slog-kengo-dead-end]] found no
match for func_80023F08 / func_80058580 but did NOT probe func_80057CC8.
This is angle-interpolation over an arena-point table — a plausibly-shared
routine. Requires Kengo source accessibility, which is unproven.

## Ranked kill-order for the next 1–3 sessions

- **s11 (structural):** attempt F1. Draft duplicated-arms form, objdump-
  verify byte-neutrality vs candidate.c AT THE CANDIDATE FLOOR (not target),
  sandbox. If floor drops AND arms merge identical bytes, invoke layer-1
  review. If floor doesn't drop OR arms don't merge, KILL F1.
- **s12 (rederive):** grep callers of func_80057CC8. If consistent struct
  emerges, prototype F2. If not, KILL F2 by measurement.
- **s13 (rederive):** Kengo corpus availability check. If accessible, grep
  for angle-interp signatures. If not accessible, KILL F3 as unfindable.

If all three of F1/F2/F3 KILLED with measurements, the function has
exhausted the sanctioned pure-C axes and OWNER-ESCALATION becomes the
correct next step (not this session — owner-gated requires a pre-filed
entry in docs/grind/decisions.md).

## Nothing to save that isn't already saved

- candidate.c unchanged (floor 3 baseline; no new measurement this session).
- No new rejected forms this session (synthesis-only; no drafts sandboxed).
- Rejected bank of 17 forms already documents every closed spelling.
