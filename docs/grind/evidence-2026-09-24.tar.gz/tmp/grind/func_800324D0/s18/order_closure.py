#!/usr/bin/env python3
"""s18 SOLVER — COMPLETE closure over the allocation-ORDER channel.

Every previously banked priority argument is quantitative ("the walker needs a
4.84x priority lift, which a 68-insn shape cannot supply").  That leaves the
door formally open: a reader can always ask "but what if some spelling DID
reorder the allocnos?".  This closes the question categorically instead of
quantitatively by enumerating ALL 8! = 40320 permutations of the allocation
order and replaying the exact find_reg forward model (Sim.simulate(order=...))
on each, with everything else held at the measured model.

If no permutation reaches the target disposition, then ordering -- and hence
priority, and hence nrefs / live length / birth order, the entire
source-controllable side of global.c pass 0 -- cannot produce target's
allocation at all, and the remaining channels (conflicts, prefs,
regs_used_so_far) are already closed by s15/s16.
"""
import itertools, json, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(ROOT / "tools/ra_solver"))
from simulate import Sim

M = json.loads((ROOT / "tmp/grind/func_800324D0/s18/model_candidate.json").read_text())
GOAL = {73: 3, 75: 6, 85: 6}
BASE = {72: 4, 74: 2, 76: 5, 86: 8, 91: 7}      # target keeps these seats
s = Sim(M)
order0 = list(M["order"])
tot = full = partial = walker = 0
hits, walker_rows = [], []
for perm in itertools.permutations(order0):
    _, a = s.simulate(order=list(perm))
    tot += 1
    if a.get(73) == 3:
        walker += 1
        if len(walker_rows) < 5:
            walker_rows.append({"order": list(perm),
                                "alloc": {str(k): v for k, v in sorted(a.items())}})
    if all(a.get(k) == v for k, v in GOAL.items()):
        partial += 1
        if all(a.get(k) == v for k, v in BASE.items()):
            full += 1
            if len(hits) < 10:
                hits.append({"order": list(perm),
                             "alloc": {str(k): v for k, v in sorted(a.items())}})
print(f"orders replayed                         : {tot}")
print(f"orders seating the walker (73) in $v1   : {walker}")
print(f"orders reaching the 3-seat goal 73/75/85: {partial}")
print(f"orders reaching the FULL target (8/8)   : {full}")
print("sample walker-in-$v1 allocations:")
for r in walker_rows:
    print("  ", r["order"], r["alloc"])
print("full-target orders:", hits if hits else "(none)")
(Path(__file__).parent / "order_closure.json").write_text(json.dumps(
    {"orders": tot, "walker_v1": walker, "goal3": partial, "full": full,
     "walker_samples": walker_rows, "full_hits": hits}, indent=1))
