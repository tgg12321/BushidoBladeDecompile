import sys, pathlib

NL = chr(10)
mode = sys.argv[1]
p = pathlib.Path("src/code6cac_b.c")
txt = p.read_text()
start = txt.index("void func_800324D0(")
end = txt.index('INCLUDE_ASM("asm/funcs", func_800325E0);')
cand = pathlib.Path("memory/grind/func_800324D0/candidate.c").read_text()
body = cand[cand.index("void func_800324D0("):]
if mode == "candidate":
    new = body.rstrip() + NL
elif mode == "migration":
    new = ('INCLUDE_ASM("asm/funcs", func_800324D0);' + NL +
           'INCLUDE_RODATA("asm/rodata", jtbl_800105A0);' + NL)
else:
    raise SystemExit("bad mode")
open(p, "w", newline="").write(txt[:start] + new + txt[end:])
print("applied", mode)
