# s18 measurements — func_80041688 (2026-08-20, escalation modality)

Both runs via `& tools/wteng.ps1 main sandbox func_80041688 --disable all` on the
current main chassis (src/text1a_post.c).

1. Committed rule-era baseline:
   score=8, target_insns=82, build_insns=82, rules_dropped=3, cheat_asm_stripped=2
   (the two stripped constructs are the rule-era `volatile s32 sp10[8];` + `(void)sp10;`).

2. memory/grind/func_80041688/candidate.c form applied over the function
   (pre_pad[8] first-declared !FAKE pad, staged loop1 guard, no (void) shim):
   score=6, target_insns=82, build_insns=82, rules_dropped=3, cheat_asm_stripped=1
   (the one stripped construct is `pre_pad` itself — no _SANCTIONED_UNWRITTEN_PADS
   row exists for func_80041688, so the engine strips it before scoring; the
   residual 6 is exactly the six frame immediates: addiu sp,-0x18 vs -0x38 and the
   ra/s0 save+restore offsets 0x14/0x10 vs 0x34/0x30).

src/text1a_post.c was restored to the committed baseline after the measurement
(`git checkout -- src/text1a_post.c`); regfix.txt:212-214 would corrupt the
already-correct [b,r,g] lbu stream if the candidate form were left in place.
