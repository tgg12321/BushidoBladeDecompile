	.file	1 "src/text1b.c"

 # GNU C 2.7.2.SN.1 [AL 1.1, MM 40] Sony Playstation compiled by GNU C

 # Cc1 defaults:
 # -mgas -msoft-float

 # Cc1 arguments (-G value = 0, Cpu = 3000, ISA = 1):
 # -quiet -O2 -G0 -funsigned-char -mcpu=3000 -mips1 -w -o

gcc2_compiled.:
__gnu_compiled_c:
 #APP
	.include "include/macro.inc"

 #NO_APP
	.text
	.align	2
	.globl	func_80047ED0
	.ent	func_80047ED0
func_80047ED0:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$2,g_snd_volume
	#nop
	addu	$2,$2,$4
	sw	$2,g_snd_volume
	j	$31
	.end	func_80047ED0
	.align	2
	.globl	AddTbpOfst_80047EE8
	.ent	AddTbpOfst_80047EE8
AddTbpOfst_80047EE8:
	.frame	$sp,72,$31		# vars= 32, regs= 4/0, args= 24, extra= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,72
	sw	$16,56($sp)
	move	$16,$4
	sw	$31,68($sp)
	sw	$18,64($sp)
	sw	$17,60($sp)
 #APP
	move $18, $16
 #NO_APP
	sll	$5,$5,16
	sra	$5,$5,14
	addu	$16,$16,$5
	lw	$2,0($16)
	#nop
	srl	$2,$2,2
	sll	$2,$2,2
	addu	$16,$18,$2
	lw	$17,0($16)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$17,$0,$L3
	addu	$16,$16,4
	.set	macro
	.set	reorder

	addu	$17,$17,-1
$L4:
	lw	$4,0($16)
	addu	$16,$16,4
	lhu	$5,0($16)
	addu	$16,$16,2
	lhu	$6,0($16)
	addu	$16,$16,2
	lhu	$7,0($16)
	addu	$16,$16,2
	lhu	$2,0($16)
	addu	$16,$16,2
	sll	$2,$2,16
	sra	$2,$2,16
	srl	$4,$4,2
	sll	$4,$4,2
	sll	$5,$5,16
	sll	$6,$6,16
	sll	$7,$7,16
	addu	$4,$18,$4
	sra	$5,$5,16
	sra	$6,$6,16
	sra	$7,$7,16
	.set	noreorder
	.set	nomacro
	jal	efc_buki_draw_zanzou
	sw	$2,16($sp)
	.set	macro
	.set	reorder

	move	$2,$17
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L4
	addu	$17,$17,-1
	.set	macro
	.set	reorder

$L3:
	lw	$31,68($sp)
	lw	$18,64($sp)
	lw	$17,60($sp)
	lw	$16,56($sp)
	addu	$sp,$sp,72
	j	$31
	.end	AddTbpOfst_80047EE8
	.align	2
	.globl	InitHiraRmd_80047FBC
	.ent	InitHiraRmd_80047FBC
InitHiraRmd_80047FBC:
	.frame	$sp,80,$31		# vars= 32, regs= 6/0, args= 24, extra= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,80
	sw	$16,56($sp)
	move	$16,$4
	sw	$20,72($sp)
	move	$20,$16
	sll	$5,$5,16
	sra	$5,$5,14
	addu	$16,$16,$5
	sw	$31,76($sp)
	sw	$19,68($sp)
	sw	$18,64($sp)
	sw	$17,60($sp)
	lw	$2,0($16)
	#nop
	srl	$2,$2,2
	sll	$2,$2,2
	addu	$16,$20,$2
	lw	$17,0($16)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$17,$0,$L9
	addu	$16,$16,4
	.set	macro
	.set	reorder

	addu	$17,$17,-1
	sll	$2,$6,16
	sra	$19,$2,16
	sll	$2,$7,16
	sra	$18,$2,16
$L10:
	lw	$4,0($16)
	addu	$16,$16,4
	lhu	$5,0($16)
	addu	$16,$16,2
	lhu	$6,0($16)
	addu	$16,$16,2
	lhu	$7,0($16)
	addu	$16,$16,2
	lhu	$2,0($16)
	addu	$16,$16,2
	sll	$2,$2,16
	sra	$2,$2,16
	addu	$2,$2,$18
	srl	$4,$4,2
	sll	$4,$4,2
	sll	$5,$5,16
	sra	$5,$5,16
	sll	$6,$6,16
	sra	$6,$6,16
	sll	$7,$7,16
	sra	$7,$7,16
	addu	$4,$20,$4
	addu	$5,$5,$19
	addu	$6,$6,$18
	addu	$7,$7,$19
	.set	noreorder
	.set	nomacro
	jal	efc_buki_draw_zanzou
	sw	$2,16($sp)
	.set	macro
	.set	reorder

	move	$2,$17
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L10
	addu	$17,$17,-1
	.set	macro
	.set	reorder

$L9:
	lw	$31,76($sp)
	lw	$20,72($sp)
	lw	$19,68($sp)
	lw	$18,64($sp)
	lw	$17,60($sp)
	lw	$16,56($sp)
	addu	$sp,$sp,80
	j	$31
	.end	InitHiraRmd_80047FBC
	.align	2
	.globl	InitHiraRmd_800480C0
	.ent	InitHiraRmd_800480C0
InitHiraRmd_800480C0:
	.frame	$sp,56,$31		# vars= 0, regs= 8/0, args= 24, extra= 0
	.mask	0x807f0000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,56
	sll	$5,$5,16
	sra	$5,$5,14
	sw	$16,24($sp)
	addu	$16,$4,$5
	sw	$31,52($sp)
	sw	$22,48($sp)
	sw	$21,44($sp)
	sw	$20,40($sp)
	sw	$19,36($sp)
	sw	$18,32($sp)
	sw	$17,28($sp)
	lw	$2,0($16)
	lw	$20,72($sp)
	srl	$2,$2,2
	sll	$2,$2,2
	addu	$16,$4,$2
	lw	$17,0($16)
	lw	$19,76($sp)
	move	$18,$4
	.set	noreorder
	.set	nomacro
	beq	$17,$0,$L15
	addu	$16,$16,4
	.set	macro
	.set	reorder

	addu	$17,$17,-1
	sll	$22,$6,16
	sra	$22,$22,16
	sll	$21,$7,16
	sra	$21,$21,16
	sll	$20,$20,16
	sra	$20,$20,16
	sll	$19,$19,16
	sra	$19,$19,16
$L16:
	lw	$4,0($16)
	addu	$16,$16,4
	lhu	$5,0($16)
	addu	$16,$16,2
	lhu	$6,0($16)
	addu	$16,$16,2
	lhu	$7,0($16)
	addu	$16,$16,2
	lhu	$2,0($16)
	addu	$16,$16,2
	sll	$2,$2,16
	sra	$2,$2,16
	addu	$2,$2,$19
	srl	$4,$4,2
	sll	$4,$4,2
	sll	$5,$5,16
	sra	$5,$5,16
	sll	$6,$6,16
	sra	$6,$6,16
	sll	$7,$7,16
	sra	$7,$7,16
	addu	$4,$18,$4
	addu	$5,$5,$22
	addu	$6,$6,$21
	addu	$7,$7,$20
	.set	noreorder
	.set	nomacro
	jal	efc_buki_draw_zanzou
	sw	$2,16($sp)
	.set	macro
	.set	reorder

	move	$2,$17
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L16
	addu	$17,$17,-1
	.set	macro
	.set	reorder

$L15:
	lw	$31,52($sp)
	lw	$22,48($sp)
	lw	$21,44($sp)
	lw	$20,40($sp)
	lw	$19,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,56
	j	$31
	.end	InitHiraRmd_800480C0
	.align	2
	.globl	func_800481E8
	.ent	func_800481E8
func_800481E8:
	.frame	$sp,40,$31		# vars= 0, regs= 4/0, args= 24, extra= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	sw	$31,36($sp)
	sw	$18,32($sp)
	sw	$17,28($sp)
	sw	$16,24($sp)
 #APP
	move $16, $4
 #NO_APP
	move	$18,$16
	sll	$5,$5,16
	sra	$5,$5,14
	addu	$16,$18,$5
	lw	$2,0($16)
	#nop
	srl	$2,$2,2
	sll	$2,$2,2
	addu	$16,$18,$2
	lw	$17,0($16)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$17,$0,$L21
	addu	$16,$16,4
	.set	macro
	.set	reorder

	addu	$17,$17,-1
$L22:
	lw	$2,0($16)
	addu	$16,$16,4
	lhu	$5,0($16)
	addu	$16,$16,2
	lhu	$6,0($16)
	addu	$16,$16,2
	lhu	$3,0($16)
	addu	$16,$16,2
	lhu	$8,0($16)
	srl	$2,$2,2
	sll	$2,$2,2
	addu	$4,$18,$2
	sll	$3,$3,16
	sra	$7,$3,16
	slt	$2,$7,640
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L25
	addu	$16,$16,2
	.set	macro
	.set	reorder

	addu	$8,$8,1
$L25:
	sll	$2,$8,16
	sra	$2,$2,16
	sw	$2,16($sp)
	sll	$5,$5,16
	sll	$6,$6,16
	sra	$5,$5,16
	.set	noreorder
	.set	nomacro
	jal	efc_buki_draw_zanzou
	sra	$6,$6,16
	.set	macro
	.set	reorder

	move	$2,$17
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L22
	addu	$17,$17,-1
	.set	macro
	.set	reorder

$L21:
	lw	$31,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,40
	j	$31
	.end	func_800481E8
	.align	2
	.globl	efc_buki_draw_zanzou
	.ent	efc_buki_draw_zanzou
efc_buki_draw_zanzou:
	.frame	$sp,1072,$31		# vars= 1032, regs= 5/0, args= 16, extra= 0
	.mask	0x800f0000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,1072
	move	$8,$4
	sw	$31,1064($sp)
	sw	$19,1060($sp)
	sw	$18,1056($sp)
	sw	$17,1052($sp)
	sw	$16,1048($sp)
	lbu	$3,0($8)
	addu	$8,$8,4
	lhu	$19,1088($sp)
	li	$2,0x00000010		# 16
	.set	noreorder
	.set	nomacro
	bne	$3,$2,$L27
	move	$18,$7
	.set	macro
	.set	reorder

	lw	$2,0($8)
	#nop
	andi	$17,$2,0x0008
	.set	noreorder
	.set	nomacro
	beq	$17,$0,$L29
	addu	$8,$8,4
	.set	macro
	.set	reorder

	move	$16,$8
	lw	$2,0($16)
	#nop
	srl	$2,$2,2
	sll	$2,$2,2
	addu	$8,$16,$2
	addu	$16,$16,4
$L29:
	addu	$8,$8,8
	sh	$5,16($sp)
	sh	$6,18($sp)
	lw	$3,0($8)
	addu	$4,$sp,16
	addu	$5,$8,4
	srl	$2,$3,16
	sh	$2,22($sp)
	.set	noreorder
	.set	nomacro
	jal	gpu_LoadImage
	sh	$3,20($sp)
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	beq	$17,$0,$L27
	addu	$16,$16,4
	.set	macro
	.set	reorder

	sh	$18,16($sp)
	sh	$19,18($sp)
	lw	$3,0($16)
	addu	$16,$16,4
	srl	$2,$3,16
	sh	$2,22($sp)
	.set	noreorder
	.set	nomacro
	jal	func_800486FC
	sh	$3,20($sp)
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L31
	move	$4,$16
	.set	macro
	.set	reorder

	lh	$5,20($sp)
	addu	$16,$sp,24
	.set	noreorder
	.set	nomacro
	jal	func_8004876C
	move	$6,$16
	.set	macro
	.set	reorder

	addu	$4,$sp,16
	.set	noreorder
	.set	nomacro
	jal	gpu_LoadImage
	move	$5,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	gpu_DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	j	$L27
$L31:
	addu	$4,$sp,16
	.set	noreorder
	.set	nomacro
	jal	gpu_LoadImage
	move	$5,$16
	.set	macro
	.set	reorder

$L27:
	lw	$31,1064($sp)
	lw	$19,1060($sp)
	lw	$18,1056($sp)
	lw	$17,1052($sp)
	lw	$16,1048($sp)
	addu	$sp,$sp,1072
	j	$31
	.end	efc_buki_draw_zanzou
	.align	2
	.globl	func_800483DC
	.ent	func_800483DC
func_800483DC:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, extra= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	sw	$16,16($sp)
	move	$16,$4
	sll	$5,$5,16
	sra	$5,$5,14
	addu	$5,$5,$16
	sw	$31,36($sp)
	sw	$20,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	lw	$2,0($5)
	move	$20,$16
	addu	$16,$16,$2
	lw	$17,0($16)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$17,$0,$L33
	addu	$16,$16,4
	.set	macro
	.set	reorder

	addu	$17,$17,-1
	sll	$2,$6,16
	sra	$19,$2,16
	sll	$2,$7,16
	sra	$18,$2,16
$L34:
	lw	$4,0($16)
	addu	$16,$16,8
	lhu	$5,0($16)
	addu	$16,$16,2
	lhu	$6,0($16)
	addu	$16,$16,2
	sll	$5,$5,16
	sra	$5,$5,16
	sll	$6,$6,16
	sra	$6,$6,16
	addu	$4,$20,$4
	addu	$5,$5,$19
	.set	noreorder
	.set	nomacro
	jal	func_800484A0
	addu	$6,$6,$18
	.set	macro
	.set	reorder

	move	$2,$17
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L34
	addu	$17,$17,-1
	.set	macro
	.set	reorder

$L33:
	lw	$31,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,40
	j	$31
	.end	func_800483DC
	.align	2
	.globl	func_800484A0
	.ent	func_800484A0
func_800484A0:
	.frame	$sp,1056,$31		# vars= 1032, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,1056
	sw	$16,1048($sp)
	move	$16,$4
	sw	$31,1052($sp)
	lbu	$3,0($16)
	li	$2,0x00000010		# 16
	.set	noreorder
	.set	nomacro
	bne	$3,$2,$L38
	addu	$16,$16,4
	.set	macro
	.set	reorder

	lw	$2,0($16)
	#nop
	andi	$2,$2,0x0008
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L38
	addu	$16,$16,4
	.set	macro
	.set	reorder

	addu	$16,$16,8
	sh	$5,16($sp)
	sh	$6,18($sp)
	lw	$3,0($16)
	addu	$16,$16,4
	srl	$2,$3,16
	sh	$2,22($sp)
	.set	noreorder
	.set	nomacro
	jal	func_800486FC
	sh	$3,20($sp)
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L41
	move	$4,$16
	.set	macro
	.set	reorder

	lh	$5,20($sp)
	addu	$16,$sp,24
	.set	noreorder
	.set	nomacro
	jal	func_8004876C
	move	$6,$16
	.set	macro
	.set	reorder

$L41:
	addu	$4,$sp,16
	.set	noreorder
	.set	nomacro
	jal	gpu_LoadImage
	move	$5,$16
	.set	macro
	.set	reorder

$L38:
	lw	$31,1052($sp)
	lw	$16,1048($sp)
	addu	$sp,$sp,1056
	j	$31
	.end	func_800484A0
	.align	2
	.globl	func_80048530
	.ent	func_80048530
func_80048530:
	.frame	$sp,32,$31		# vars= 0, regs= 2/0, args= 24, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	move	$8,$4
	sll	$5,$5,2
	addu	$5,$5,$8
	sw	$31,28($sp)
	sw	$16,24($sp)
	lw	$2,0($5)
	move	$9,$8
	addu	$8,$8,$2
	lw	$16,0($8)
	move	$5,$7
	sltu	$2,$6,$16
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L43
	addu	$8,$8,4
	.set	macro
	.set	reorder

	sll	$2,$6,1
	addu	$2,$2,$6
	sll	$2,$2,2
	addu	$8,$8,$2
	lw	$4,0($8)
	addu	$8,$8,4
	lhu	$6,0($8)
	addu	$8,$8,2
	lhu	$7,0($8)
	addu	$8,$8,2
	lhu	$2,2($8)
	lh	$3,0($8)
	sll	$2,$2,16
	sra	$2,$2,16
	sll	$6,$6,16
	sll	$7,$7,16
	addu	$4,$4,$9
	sra	$6,$6,16
	sra	$7,$7,16
	sw	$3,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_800485EC
	sw	$2,20($sp)
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	$L44
	move	$2,$16
	.set	macro
	.set	reorder

$L43:
	li	$2,-1			# 0xffffffff
$L44:
	lw	$31,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,32
	j	$31
	.end	func_80048530
	.align	2
	.globl	func_800485EC
	.ent	func_800485EC
func_800485EC:
	.frame	$sp,40,$31		# vars= 0, regs= 5/0, args= 16, extra= 0
	.mask	0x800f0000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	sw	$17,20($sp)
	move	$17,$4
	sw	$31,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$16,16($sp)
	lbu	$8,0($17)
	lw	$4,56($sp)
	lw	$9,60($sp)
	move	$16,$5
	move	$18,$6
	li	$2,0x00000010		# 16
	.set	noreorder
	.set	nomacro
	bne	$8,$2,$L45
	move	$19,$7
	.set	macro
	.set	reorder

	addu	$17,$17,4
	lw	$2,0($17)
	addu	$17,$17,4
	andi	$3,$2,0x0007
	andi	$2,$2,0x0008
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L47
	sh	$3,0($5)
	.set	macro
	.set	reorder

	move	$8,$17
	lw	$2,0($8)
	sh	$4,10($16)
	lh	$4,10($16)
	sh	$9,12($16)
	lh	$5,12($16)
	srl	$2,$2,2
	sll	$2,$2,2
	addu	$17,$8,$2
	addu	$8,$8,8
	lhu	$2,2($8)
	#nop
	sh	$2,16($16)
	lw	$3,0($8)
	addu	$2,$8,4
	sw	$2,28($16)
	.set	noreorder
	.set	nomacro
	jal	gpu_CalcClut
	sh	$3,14($16)
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	$L48
	sh	$2,20($16)
	.set	macro
	.set	reorder

$L47:
	sh	$0,20($16)
$L48:
	addu	$8,$17,8
 #APP
 #NO_APP
	lh	$4,0($16)
	sh	$18,2($16)
	sh	$19,4($16)
	lhu	$2,2($8)
	lh	$6,2($16)
	lh	$7,4($16)
	move	$5,$0
	sh	$2,8($16)
	lw	$3,0($8)
	addu	$2,$8,4
	andi	$6,$6,0xffc0
	andi	$7,$7,0xff00
	sw	$2,24($16)
	.set	noreorder
	.set	nomacro
	jal	gpu_CalcTPage
	sh	$3,6($16)
	.set	macro
	.set	reorder

	sh	$2,18($16)
$L45:
	lw	$31,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,40
	j	$31
	.end	func_800485EC
	.align	2
	.globl	func_800486FC
	.ent	func_800486FC
func_800486FC:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	jal	file_GetFlag0
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L50
	li	$2,0x00000001		# 1
	.set	macro
	.set	reorder

	sh	$2,g_color_mode
	j	$L51
$L50:
	sh	$0,g_color_mode
$L51:
	lh	$2,g_color_mode
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_800486FC
	.align	2
	.globl	func_80048744
	.ent	func_80048744
func_80048744:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	beq	$4,$0,$L53
	li	$2,0x00000001		# 1
	.set	macro
	.set	reorder

	sh	$2,g_color_mode
	j	$L54
$L53:
	sh	$0,g_color_mode
$L54:
	j	$31
	.end	func_80048744
	.align	2
	.globl	func_8004876C
	.ent	func_8004876C
func_8004876C:
	.frame	$sp,8,$31		# vars= 8, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	subu	$sp,$sp,8
	move	$9,$4
	.set	noreorder
	.set	nomacro
	beq	$5,$0,$L56
	addu	$8,$5,-1
	.set	macro
	.set	reorder

	li	$11,-32768			# 0xffff8000
	li	$10,-1			# 0xffffffff
$L57:
	lhu	$5,0($9)
	addu	$9,$9,2
	addu	$8,$8,-1
	andi	$3,$5,0x001f
	sll	$2,$3,1
	addu	$2,$2,$3
	sll	$2,$2,6
	addu	$2,$2,$3
	sll	$3,$2,3
	subu	$7,$3,$2
	sll	$4,$5,16
	sra	$3,$4,26
	andi	$3,$3,0x001f
	sra	$4,$4,10
	andi	$4,$4,0xf800
 #APP
 #NO_APP
	sll	$2,$3,1
	addu	$2,$2,$3
	sll	$2,$2,2
	subu	$2,$2,$3
	sll	$2,$2,3
	subu	$2,$2,$3
	sll	$2,$2,3
	addu	$2,$7,$2
	addu	$2,$2,$4
	sra	$7,$2,12
	andi	$7,$7,0x001f
	and	$5,$5,$11
	sll	$2,$7,10
	addu	$5,$5,$2
	sll	$2,$7,5
	addu	$5,$5,$2
	addu	$5,$5,$7
	sh	$5,0($6)
	.set	noreorder
	.set	nomacro
	bne	$8,$10,$L57
	addu	$6,$6,2
	.set	macro
	.set	reorder

$L56:
	addu	$sp,$sp,8
	j	$31
	.end	func_8004876C
	.align	2
	.globl	func_8004881C
	.ent	func_8004881C
func_8004881C:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	sll	$2,$4,1
	addu	$2,$2,$4
	sll	$2,$2,6
	addu	$2,$2,$4
	sll	$3,$2,3
	subu	$4,$3,$2
	sll	$2,$5,11
	sll	$3,$6,1
	addu	$3,$3,$6
	sll	$3,$3,2
	subu	$3,$3,$6
	sll	$3,$3,3
	subu	$3,$3,$6
	sll	$3,$3,3
	addu	$2,$4,$2
	addu	$2,$2,$3
	.set	noreorder
	.set	nomacro
	j	$31
	sra	$2,$2,12
	.set	macro
	.set	reorder

	.end	func_8004881C
	.align	2
	.globl	saTan4FireDisp_80048864
	.ent	saTan4FireDisp_80048864
saTan4FireDisp_80048864:
	.frame	$sp,1096,$31		# vars= 1040, regs= 10/0, args= 16, extra= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,1096
	sw	$22,1080($sp)
	lw	$22,1112($sp)
	sw	$21,1076($sp)
	lw	$21,1116($sp)
	sw	$20,1072($sp)
	lw	$20,1120($sp)
	sw	$23,1084($sp)
	lw	$23,1124($sp)
	sw	$fp,1088($sp)
	lw	$fp,1128($sp)
	sw	$18,1064($sp)
	move	$18,$4
	sw	$16,1056($sp)
	move	$16,$5
	sw	$17,1060($sp)
	move	$17,$6
	sw	$19,1068($sp)
	move	$19,$7
	sw	$31,1092($sp)
	.set	noreorder
	.set	nomacro
	jal	gpu_DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	addu	$4,$sp,1040
	addu	$5,$sp,16
	li	$2,0x00000001		# 1
	sh	$16,1040($sp)
	sh	$17,1042($sp)
	sh	$19,1044($sp)
	.set	noreorder
	.set	nomacro
	jal	gpu_StoreImage
	sh	$2,1046($sp)
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	gpu_DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	addu	$11,$sp,16
	addu	$12,$sp,528
	.set	noreorder
	.set	nomacro
	blez	$19,$L63
	move	$10,$0
	.set	macro
	.set	reorder

$L64:
	lhu	$7,0($11)
	#nop
	andi	$3,$7,0xffff
	.set	noreorder
	.set	nomacro
	bne	$3,$0,$L67
	andi	$8,$7,0x001f
	.set	macro
	.set	reorder

	sh	$7,0($12)
	.set	noreorder
	.set	nomacro
	j	$L68
	addu	$11,$11,2
	.set	macro
	.set	reorder

$L67:
	addu	$11,$11,2
	sll	$4,$8,3
	srl	$2,$3,5
	andi	$9,$2,0x001f
	sll	$6,$9,3
	srl	$2,$3,10
	andi	$3,$2,0x001f
	sll	$5,$3,3
	.set	noreorder
	.set	nomacro
	beq	$18,$0,$L74
	andi	$7,$7,0x8000
	.set	macro
	.set	reorder

	li	$2,0x00000001		# 1
	.set	noreorder
	.set	nomacro
	beq	$18,$2,$L75
	sll	$2,$8,4
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	$L76
	andi	$4,$4,0x001f
	.set	macro
	.set	reorder

$L74:
	mult	$4,$22
	mflo	$8
	#nop
	#nop
	mult	$6,$21
	mflo	$2
	#nop
	#nop
	mult	$5,$20
	sra	$4,$8,15
	sra	$6,$2,15
	mflo	$3
	#nop
	.set	noreorder
	.set	nomacro
	j	$L73
	sra	$5,$3,15
	.set	macro
	.set	reorder

$L75:
	addu	$6,$2,$4
	sll	$2,$6,6
	addu	$6,$2,$4
	sll	$2,$6,3
	subu	$6,$2,$6
	sll	$2,$3,1
	addu	$2,$2,$3
	sll	$2,$2,2
	subu	$2,$2,$3
	sll	$2,$2,3
	subu	$2,$2,$3
	sll	$10,$2,6
	sll	$2,$9,14
	addu	$6,$6,$2
	addu	$6,$6,$10
	sra	$10,$6,15
	mult	$10,$22
	mflo	$3
	#nop
	#nop
	sra	$4,$3,12
	mult	$4,$21
	mflo	$3
	#nop
	#nop
	mult	$4,$20
	sra	$6,$3,12
	mflo	$2
	#nop
	#nop
	sra	$5,$2,12
$L76:
$L73:
	andi	$4,$4,0x001f
	andi	$6,$6,0x001f
	andi	$5,$5,0x001f
	or	$4,$7,$4
	sll	$6,$6,5
	or	$4,$4,$6
	sll	$5,$5,10
	or	$4,$4,$5
	sh	$4,0($12)
$L68:
	addu	$10,$10,1
	slt	$2,$10,$19
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L64
	addu	$12,$12,2
	.set	macro
	.set	reorder

$L63:
	addu	$4,$sp,1040
	addu	$5,$sp,528
	sh	$23,1040($sp)
	.set	noreorder
	.set	nomacro
	jal	gpu_LoadImage
	sh	$fp,1042($sp)
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	gpu_DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	lw	$31,1092($sp)
	lw	$fp,1088($sp)
	lw	$23,1084($sp)
	lw	$22,1080($sp)
	lw	$21,1076($sp)
	lw	$20,1072($sp)
	lw	$19,1068($sp)
	lw	$18,1064($sp)
	lw	$17,1060($sp)
	lw	$16,1056($sp)
	addu	$sp,$sp,1096
	j	$31
	.end	saTan4FireDisp_80048864
	.align	2
	.globl	func_80048A7C
	.ent	func_80048A7C
func_80048A7C:
	.frame	$sp,48,$31		# vars= 0, regs= 1/0, args= 40, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,48
	move	$8,$4
	move	$9,$5
	move	$10,$6
	lw	$2,64($sp)
	lw	$3,68($sp)
	move	$4,$0
	move	$5,$8
	move	$6,$9
	sw	$7,16($sp)
	move	$7,$10
	sw	$31,40($sp)
	sw	$8,28($sp)
	sw	$9,32($sp)
	sw	$2,20($sp)
	.set	noreorder
	.set	nomacro
	jal	saTan4FireDisp_80048864
	sw	$3,24($sp)
	.set	macro
	.set	reorder

	lw	$31,40($sp)
	addu	$sp,$sp,48
	j	$31
	.end	func_80048A7C
	.align	2
	.globl	mario_getMarioVoiceData_80048AD0
	.ent	mario_getMarioVoiceData_80048AD0
mario_getMarioVoiceData_80048AD0:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$16,16($sp)
	sw	$31,20($sp)
	.set	noreorder
	.set	nomacro
	jal	func_8004153C
	move	$16,$4
	.set	macro
	.set	reorder

	beq	$2,$0,$L88
	lh	$2,8($2)
	sw	$16,D_800A33E0
	lbu	$4,D_80099BCC($2)
	li	$2,0x000000ff		# 255
	bne	$4,$2,$L82
$L88:
	.set	noreorder
	.set	nomacro
	j	$L87
	move	$2,$0
	.set	macro
	.set	reorder

$L82:
	jal	snd_LoadBgm
	lw	$3,8($2)
	move	$4,$0
	li	$8,0x00000009		# 9
	li	$7,0x0000000f		# 15
	srl	$3,$3,2
	sll	$3,$3,2
	addu	$3,$2,$3
	subu	$6,$3,$2
	addu	$5,$3,10
	sw	$3,D_800A33E4
$L83:
	sh	$4,-8($5)
	sh	$8,-6($5)
	sb	$7,0($3)
	sb	$0,-9($5)
	sh	$16,0($5)
	addu	$5,$5,104
	addu	$4,$4,1
	slt	$2,$4,17
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L83
	addu	$3,$3,104
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	snd_PlayBgm
	addu	$4,$6,1768
	.set	macro
	.set	reorder

	li	$2,0x00000001		# 1
$L87:
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	mario_getMarioVoiceData_80048AD0
	.align	2
	.globl	saTan5GetTakeCutAnimType
	.ent	saTan5GetTakeCutAnimType
saTan5GetTakeCutAnimType:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$2,g_snd_play_count
	#nop
	addu	$2,$2,$4
	sw	$2,g_snd_play_count
	j	$31
	.end	saTan5GetTakeCutAnimType
	.align	2
	.globl	func_80048BA4
	.ent	func_80048BA4
func_80048BA4:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_80048BA4
	.align	2
	.globl	func_80048F58
	.ent	func_80048F58
func_80048F58:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	sw	$17,20($sp)
	move	$17,$4
	sw	$16,16($sp)
	move	$16,$5
	.set	noreorder
	.set	nomacro
	blez	$16,$L92
	sw	$31,24($sp)
	.set	macro
	.set	reorder

	jal	InitFadePanel
$L92:
	sll	$2,$16,2
	addu	$2,$2,$16
	sll	$2,$2,2
	subu	$2,$2,$16
	sll	$2,$2,2
	addu	$2,$2,$16
	sll	$2,$2,2
	la	$3,g_snd_ch_data
	addu	$2,$2,$3
	sw	$0,0($2)
	sll	$3,$17,3
	subu	$3,$3,$17
	sll	$3,$3,1
	la	$4,g_snd_se_bank
	addu	$3,$3,$4
	addu	$5,$2,292
	move	$4,$0
$L93:
	lhu	$2,0($3)
	addu	$3,$3,2
	addu	$4,$4,1
	sh	$2,0($5)
	slt	$2,$4,7
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L93
	addu	$5,$5,2
	.set	macro
	.set	reorder

	lw	$31,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,32
	j	$31
	.end	func_80048F58
	.align	2
	.globl	func_80048FFC
	.ent	func_80048FFC
func_80048FFC:
	.frame	$sp,144,$31		# vars= 88, regs= 10/0, args= 16, extra= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	sll	$2,$4,2
	addu	$2,$2,$4
	sll	$2,$2,2
	subu	$2,$2,$4
	sll	$2,$2,2
	addu	$2,$2,$4
	lw	$4,D_800A36AC
	subu	$sp,$sp,144
	sll	$2,$2,2
	la	$3,D_800EF848
	sw	$22,128($sp)
	addu	$22,$2,$3
	sw	$31,140($sp)
	sw	$fp,136($sp)
	sw	$23,132($sp)
	sw	$21,124($sp)
	sw	$20,120($sp)
	sw	$19,116($sp)
	sw	$18,112($sp)
	sw	$17,108($sp)
	sw	$16,104($sp)
	lw	$9,0($22)
	andi	$4,$4,0x0001
	sll	$2,$4,3
	addu	$2,$2,$4
	sw	$9,80($sp)
	lh	$6,292($22)
	sll	$2,$2,4
	addu	$3,$22,$2
	lhu	$2,292($22)
	addu	$10,$22,292
	li	$8,-64			# 0xffffffc0
	addu	$20,$3,4
	sw	$10,24($sp)
	lhu	$7,294($22)
	li	$4,-256			# 0xffffff00
	move	$5,$6
	and	$2,$2,$8
	sll	$2,$2,16
	sra	$2,$2,16
	.set	noreorder
	.set	nomacro
	bgez	$5,$L98
	sw	$2,32($sp)
	.set	macro
	.set	reorder

	addu	$5,$5,63
$L98:
	sra	$2,$5,6
	sll	$2,$2,6
	subu	$2,$6,$2
	sll	$2,$2,16
	sra	$2,$2,16
	sw	$2,40($sp)
	lh	$6,300($22)
	lhu	$2,300($22)
	lhu	$7,302($22)
	move	$5,$6
	and	$2,$2,$8
	sll	$2,$2,16
	sra	$2,$2,16
	sw	$2,48($sp)
	and	$2,$7,$4
	sll	$2,$2,16
	sra	$2,$2,16
	.set	noreorder
	.set	nomacro
	bgez	$6,$L100
	sw	$2,56($sp)
	.set	macro
	.set	reorder

	addu	$5,$6,63
$L100:
	sra	$2,$5,6
	sll	$2,$2,6
	subu	$2,$6,$2
	sll	$2,$2,16
	sra	$2,$2,16
	sw	$2,64($sp)
	sll	$2,$7,16
	sra	$5,$2,16
	.set	noreorder
	.set	nomacro
	bgez	$5,$L101
	move	$2,$5
	.set	macro
	.set	reorder

	addu	$2,$5,255
$L101:
	sra	$2,$2,8
	sll	$2,$2,8
	subu	$2,$5,$2
	sll	$2,$2,16
	sra	$2,$2,16
	sw	$2,72($sp)
	move	$23,$0
	li	$fp,-16777216			# 0xff000000
	la	$21,D_800A378C+16380
	li	$19,0x00ff0000		# 16711680
	ori	$19,$19,0xffff
	addu	$18,$3,28
$L102:
	lw	$9,32($sp)
	lw	$10,40($sp)
	#nop
	addu	$2,$9,$10
	lw	$9,48($sp)
	lw	$10,64($sp)
	#nop
	addu	$17,$9,$10
	lw	$9,56($sp)
	lw	$10,72($sp)
	#nop
	addu	$16,$9,$10
	lw	$9,80($sp)
	move	$4,$20
	addu	$5,$sp,16
	sh	$2,16($sp)
	move	$6,$17
	.set	noreorder
	.set	nomacro
	jal	initLoadImage
	addu	$7,$16,$9
	.set	macro
	.set	reorder

	lw	$10,80($sp)
	lw	$9,40($sp)
	sra	$10,$10,1
	sw	$10,80($sp)
	lw	$10,64($sp)
	sra	$9,$9,1
	sw	$9,40($sp)
	lw	$9,72($sp)
	sra	$10,$10,1
	sw	$10,64($sp)
	lw	$2,0($20)
	lw	$3,0($21)
	move	$4,$18
	addu	$5,$sp,16
	sra	$9,$9,1
	sw	$9,72($sp)
	and	$2,$2,$fp
	and	$3,$3,$19
	or	$2,$2,$3
	sw	$2,0($20)
	lw	$3,0($21)
	move	$6,$17
	move	$7,$16
	and	$2,$20,$19
	and	$3,$3,$fp
	or	$3,$3,$2
	.set	noreorder
	.set	nomacro
	jal	initLoadImage
	sw	$3,0($21)
	.set	macro
	.set	reorder

	lw	$3,0($18)
	lw	$4,0($21)
	addu	$23,$23,1
	addu	$20,$20,48
	and	$3,$3,$fp
	and	$2,$4,$19
	or	$3,$3,$2
	and	$2,$18,$19
	sw	$3,0($18)
	addu	$18,$18,48
	and	$4,$4,$fp
	or	$4,$4,$2
	slt	$2,$23,3
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L102
	sw	$4,0($21)
	.set	macro
	.set	reorder

	lw	$10,24($sp)
	lw	$3,0($22)
	lh	$4,12($10)
	lhu	$2,6($10)
	addu	$3,$3,$4
	sll	$2,$2,16
	sra	$4,$2,16
	slt	$2,$3,$4
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L106
	sw	$3,0($22)
	.set	macro
	.set	reorder

	rem	$2,$3,$4
	sw	$2,0($22)
$L106:
	lw	$31,140($sp)
	lw	$fp,136($sp)
	lw	$23,132($sp)
	lw	$22,128($sp)
	lw	$21,124($sp)
	lw	$20,120($sp)
	lw	$19,116($sp)
	lw	$18,112($sp)
	lw	$17,108($sp)
	lw	$16,104($sp)
	addu	$sp,$sp,144
	j	$31
	.end	func_80048FFC
	.align	2
	.globl	gnd_close_8004939C
	.ent	gnd_close_8004939C
gnd_close_8004939C:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	li	$4,-1			# 0xffffffff
	li	$3,0x00000039		# 57
	la	$2,D_800EF9F2
$L108:
	sh	$4,0($2)
	addu	$3,$3,-1
	.set	noreorder
	.set	nomacro
	bgez	$3,$L108
	addu	$2,$2,-2
	.set	macro
	.set	reorder

	li	$2,-2			# 0xfffffffe
	sh	$2,D_800EF9F4
	li	$2,-1			# 0xffffffff
	sh	$2,D_800A33EA
	sh	$2,D_800A33E8
	li	$2,-1			# 0xffffffff
	sw	$2,D_800A33EC
	j	$31
	.end	gnd_close_8004939C
	.align	2
	.globl	func_800493E4
	.ent	func_800493E4
func_800493E4:
	.frame	$sp,32,$31		# vars= 8, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	sw	$16,24($sp)
	move	$16,$4
	lw	$4,D_800A33EC
	sll	$2,$16,1
	li	$3,0x00000001		# 1
	sw	$31,28($sp)
	sh	$3,D_800EF980($2)
	li	$2,-1			# 0xffffffff
	.set	noreorder
	.set	nomacro
	bne	$4,$2,$L113
	slt	$2,$16,51
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L114
	li	$2,0x00000001		# 1
	.set	macro
	.set	reorder

	sw	$2,D_800A33EC
	.set	noreorder
	.set	nomacro
	j	$L124
	sll	$4,$16,1
	.set	macro
	.set	reorder

$L114:
	sw	$0,D_800A33EC
	.set	noreorder
	.set	nomacro
	j	$L124
	sll	$4,$16,1
	.set	macro
	.set	reorder

$L113:
	bne	$4,$0,$L117
	bne	$2,$0,$L117
	jal	InitFadePanel
$L117:
	lw	$3,D_800A33EC
	li	$2,0x00000001		# 1
	.set	noreorder
	.set	nomacro
	bne	$3,$2,$L124
	sll	$4,$16,1
	.set	macro
	.set	reorder

	slt	$2,$16,51
	beq	$2,$0,$L124
	jal	InitFadePanel
	sll	$4,$16,1
$L124:
	lbu	$3,D_80099CC8($4)
	li	$2,0x000000ff		# 255
	.set	noreorder
	.set	nomacro
	beq	$3,$2,$L119
	sll	$2,$3,1
	.set	macro
	.set	reorder

	li	$3,0x00000001		# 1
	sh	$3,D_800EF980($2)
	lbu	$2,D_80099CC9($4)
	#nop
	sll	$2,$2,1
	sh	$3,D_800EF980($2)
$L119:
	lw	$31,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,32
	j	$31
	.end	func_800493E4
	.align	2
	.globl	func_800494D4
	.ent	func_800494D4
func_800494D4:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	lw	$2,D_800A33EC
	subu	$sp,$sp,32
	sw	$17,20($sp)
	move	$17,$4
	sw	$16,16($sp)
	move	$16,$5
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L126
	sw	$31,24($sp)
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	$L127
	slt	$2,$16,16
	.set	macro
	.set	reorder

$L126:
	slt	$2,$16,8
$L127:
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L130
	sltu	$2,$17,2
	.set	macro
	.set	reorder

	jal	InitFadePanel
	sltu	$2,$17,2
$L130:
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L131
	sll	$2,$17,1
	.set	macro
	.set	reorder

	jal	InitFadePanel
	sll	$2,$17,1
$L131:
	sh	$16,D_800A33E8($2)
	lw	$31,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,32
	j	$31
	.end	func_800494D4
	.align	2
	.globl	func_8004954C
	.ent	func_8004954C
func_8004954C:
	.frame	$sp,8,$31		# vars= 8, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	subu	$sp,$sp,8
	move	$7,$0
	.set	noreorder
	.set	nomacro
	blez	$5,$L134
	move	$3,$0
	.set	macro
	.set	reorder

$L136:
	addu	$3,$3,$4
	addu	$7,$7,1
	slt	$2,$7,$5
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L136
	addu	$4,$4,-1
	.set	macro
	.set	reorder

$L134:
	subu	$2,$6,$5
	addu	$2,$3,$2
	addu	$sp,$sp,8
	j	$31
	.end	func_8004954C
	.align	2
	.globl	func_80049584
	.ent	func_80049584
func_80049584:
	.frame	$sp,40,$31		# vars= 8, regs= 4/0, args= 16, extra= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	sw	$18,32($sp)
	move	$18,$4
	sw	$17,28($sp)
	li	$17,0x00000001		# 1
	sw	$16,24($sp)
	move	$16,$0
	la	$5,D_80099C50
	la	$6,D_800EF980
	sw	$31,36($sp)
$L143:
	lh	$4,0($6)
	lh	$2,0($5)
	nor	$3,$0,$4
	srl	$3,$3,31
	nor	$2,$0,$2
	srl	$2,$2,31
	beq	$3,$2,$L146
	move	$17,$0
$L146:
	sh	$4,0($5)
	addu	$5,$5,2
	addu	$16,$16,1
	slt	$2,$16,58
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L143
	addu	$6,$6,2
	.set	macro
	.set	reorder

	move	$4,$0
	move	$16,$0
	la	$3,D_800EF980
$L148:
	lh	$2,0($3)
	#nop
	bltz	$2,$L151
	sh	$4,0($3)
	addu	$4,$4,1
$L151:
	addu	$16,$16,1
	slt	$2,$16,58
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L148
	addu	$3,$3,2
	.set	macro
	.set	reorder

	lw	$3,D_800A33EC
	#nop
	.set	noreorder
	.set	nomacro
	bne	$3,$0,$L153
	li	$4,0x00000008		# 8
	.set	macro
	.set	reorder

	li	$4,0x00000010		# 16
$L153:
	lh	$6,D_800A33E8
	li	$2,-1			# 0xffffffff
	bne	$6,$2,$L154
	lh	$5,D_800A33EA
	#nop
	bne	$5,$6,$L155
	.set	noreorder
	.set	nomacro
	bne	$3,$0,$L157
	li	$16,0x00000024		# 36
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	$L157
	li	$16,0x00000088		# 136
	.set	macro
	.set	reorder

$L155:
	.set	noreorder
	.set	nomacro
	j	$L158
	move	$6,$5
	.set	macro
	.set	reorder

$L154:
	lh	$3,D_800A33EA
	#nop
	.set	noreorder
	.set	nomacro
	beq	$3,$2,$L158
	move	$5,$6
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	beq	$6,$3,$L158
	slt	$2,$6,$3
	.set	macro
	.set	reorder

	beq	$2,$0,$L160
	.set	noreorder
	.set	nomacro
	j	$L158
	move	$6,$3
	.set	macro
	.set	reorder

$L160:
	move	$5,$3
$L158:
	jal	func_8004954C
	move	$16,$2
$L157:
	lw	$2,D_800A324C
	#nop
	beq	$2,$16,$L162
	sw	$16,D_800A324C
	move	$17,$0
$L162:
	bne	$17,$0,$L163
	jal	saTanMainDispGnd_80046020
	lw	$4,D_800A33EC
	move	$5,$16
	la	$6,D_800EF980
	.set	noreorder
	.set	nomacro
	jal	efc_rob_set_type_particle
	move	$7,$18
	.set	macro
	.set	reorder

	jal	func_8003E120
$L163:
	lw	$31,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,40
	j	$31
	.end	func_80049584
	.align	2
	.globl	func_80049710
	.ent	func_80049710
func_80049710:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_80049710
	.align	2
	.globl	func_80049718
	.ent	func_80049718
func_80049718:
	.frame	$sp,56,$31		# vars= 8, regs= 7/0, args= 16, extra= 0
	.mask	0x803f0000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,56
	sw	$21,44($sp)
	move	$21,$4
	sw	$20,40($sp)
	move	$20,$6
	sw	$17,28($sp)
	move	$17,$7
	sll	$3,$21,1
	la	$2,D_800EF980
	sw	$16,24($sp)
	addu	$16,$3,$2
	sw	$31,48($sp)
	sw	$19,36($sp)
	sw	$18,32($sp)
	lh	$2,0($16)
	#nop
	.set	noreorder
	.set	nomacro
	bgez	$2,$L167
	move	$19,$5
	.set	macro
	.set	reorder

	jal	InitFadePanel
$L167:
	lw	$18,D_800A38B4
	#nop
	sb	$0,0($18)
	sb	$0,1($18)
	lh	$2,0($16)
	li	$3,0x00000006		# 6
	move	$16,$0
	sh	$3,4($18)
	li	$3,0x00000004		# 4
	sh	$0,8($18)
	sw	$0,12($18)
	sh	$3,10($18)
	sll	$2,$2,1
	.set	noreorder
	.set	nomacro
	beq	$19,$0,$L172
	sh	$2,2($18)
	.set	macro
	.set	reorder

	li	$2,0x00000001		# 1
	bne	$19,$2,$L173
	lhu	$2,0($17)
	#nop
	sh	$2,16($18)
	lhu	$2,2($17)
	#nop
	sh	$2,18($18)
	lhu	$2,4($17)
	#nop
	sh	$2,20($18)
	lw	$2,g_anim_func_table
	addu	$4,$18,16
	.set	noreorder
	.set	nomacro
	jal	$31,$2
	addu	$5,$18,24
	.set	macro
	.set	reorder

	lw	$2,0($20)
	#nop
	sw	$2,44($18)
	lw	$2,4($20)
	#nop
	sw	$2,48($18)
	lw	$2,8($20)
	.set	noreorder
	.set	nomacro
	j	$L174
	sw	$2,52($18)
	.set	macro
	.set	reorder

$L173:
	andi	$19,$19,0x7fff
	.set	noreorder
	.set	nomacro
	jal	func_8004153C
	srl	$4,$19,1
	.set	macro
	.set	reorder

	andi	$3,$19,0x0001
	move	$17,$2
	sll	$16,$3,1
	addu	$16,$16,$3
	sll	$16,$16,2
	addu	$16,$16,$3
	sll	$16,$16,3
	addu	$16,$16,2020
	addu	$16,$17,$16
	lh	$3,18($17)
	lw	$2,76($16)
	#nop
	mult	$2,$3
	mflo	$8
	#nop
	#nop
	sra	$2,$8,12
	sw	$2,76($16)
	lh	$3,18($17)
	lw	$2,80($16)
	#nop
	mult	$2,$3
	mflo	$8
	#nop
	#nop
	sra	$2,$8,12
	sw	$2,80($16)
	lh	$3,18($17)
	lw	$2,84($16)
	#nop
	mult	$2,$3
	addu	$4,$17,68
	addu	$5,$16,56
	addu	$6,$18,24
	mflo	$8
	#nop
	#nop
	sra	$2,$8,12
	.set	noreorder
	.set	nomacro
	jal	func_8007E4DC
	sw	$2,84($16)
	.set	macro
	.set	reorder

	lw	$2,76($16)
	#nop
	sh	$2,16($sp)
	lw	$2,80($16)
	#nop
	sh	$2,18($sp)
	lw	$2,84($16)
	#nop
	sh	$2,20($sp)
	lw	$4,12($16)
	addu	$5,$sp,16
	addu	$6,$18,44
	.set	noreorder
	.set	nomacro
	jal	func_8007ED6C
	addu	$4,$4,24
	.set	macro
	.set	reorder

	lw	$3,12($16)
	lw	$2,44($18)
	lw	$3,44($3)
	#nop
	addu	$2,$2,$3
	sw	$2,44($18)
	lw	$3,12($16)
	lw	$2,48($18)
	lw	$3,48($3)
	#nop
	addu	$2,$2,$3
	sw	$2,48($18)
	lw	$3,12($16)
	lw	$2,52($18)
	lw	$3,52($3)
	ori	$19,$19,0x8000
	addu	$2,$2,$3
	sw	$2,52($18)
	lw	$2,24($18)
	lw	$3,28($18)
	lw	$4,32($18)
	lw	$5,36($18)
	sw	$2,24($16)
	sw	$3,28($16)
	sw	$4,32($16)
	sw	$5,36($16)
	lw	$2,40($18)
	lw	$3,44($18)
	lw	$4,48($18)
	lw	$5,52($18)
	sw	$2,40($16)
	sw	$3,44($16)
	sw	$4,48($16)
	sw	$5,52($16)
	lh	$16,6788($17)
$L174:
	lw	$2,D_800A3820
	#nop
	addu	$3,$2,4
	sw	$3,D_800A3820
	sw	$18,0($2)
	li	$2,0x00000001		# 1
	.set	noreorder
	.set	nomacro
	beq	$19,$2,$L175
	addu	$18,$18,104
	.set	macro
	.set	reorder

	sll	$2,$21,1
	lh	$3,D_800EF980($2)
	li	$2,0x00000003		# 3
	sb	$2,0($18)
	sb	$0,1($18)
	sw	$16,88($18)
	lw	$4,D_800A3820
	addu	$2,$18,-104
	sw	$2,12($18)
	li	$2,0x00000001		# 1
	sh	$2,6($18)
	li	$2,0x00000006		# 6
	sh	$2,4($18)
	sh	$0,8($18)
	sh	$0,10($18)
	sll	$3,$3,1
	addu	$3,$3,1
	addu	$2,$4,4
	sh	$3,2($18)
	sw	$2,D_800A3820
	sw	$18,0($4)
	addu	$18,$18,104
$L175:
	sw	$18,D_800A38B4
$L172:
	lw	$31,48($sp)
	lw	$21,44($sp)
	lw	$20,40($sp)
	lw	$19,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,56
	j	$31
	.end	func_80049718
	.align	2
	.globl	func_80049A2C
	.ent	func_80049A2C
func_80049A2C:
	.frame	$sp,48,$31		# vars= 8, regs= 5/0, args= 16, extra= 0
	.mask	0x800f0000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,48
	la	$2,D_80099CC8
	sll	$4,$4,1
	addu	$4,$4,$2
	addu	$4,$4,$6
	sw	$31,40($sp)
	sw	$19,36($sp)
	sw	$18,32($sp)
	sw	$17,28($sp)
	sw	$16,24($sp)
	lbu	$3,0($4)
	li	$2,0x000000ff		# 255
	.set	noreorder
	.set	nomacro
	beq	$3,$2,$L176
	move	$17,$5
	.set	macro
	.set	reorder

	la	$2,D_800EF980
	sll	$3,$3,1
	addu	$19,$3,$2
	lh	$2,0($19)
	#nop
	bgez	$2,$L178
	jal	InitFadePanel
$L178:
	.set	noreorder
	.set	nomacro
	jal	func_8004153C
	sra	$4,$17,1
	.set	macro
	.set	reorder

	lw	$16,D_800A38B4
	andi	$4,$17,0x0001
	sll	$3,$4,1
	addu	$3,$3,$4
	sll	$3,$3,2
	la	$4,D_80099D3C
	addu	$3,$3,$4
	sb	$0,0($16)
	sb	$0,1($16)
	lh	$5,0($19)
	li	$18,0x00000006		# 6
	li	$4,0x00000004		# 4
	move	$17,$2
	sh	$18,4($16)
	sh	$0,8($16)
	sh	$4,10($16)
	sll	$5,$5,1
	sh	$5,2($16)
	lh	$4,0($3)
	lh	$2,18($17)
	#nop
	mult	$4,$2
	addu	$3,$3,2
	mflo	$7
	#nop
	#nop
	sra	$2,$7,12
	sw	$2,76($16)
	lh	$4,0($3)
	lh	$2,18($17)
	#nop
	mult	$4,$2
	addu	$3,$3,2
	mflo	$7
	#nop
	#nop
	sra	$2,$7,12
	sw	$2,80($16)
	lh	$4,0($3)
	lh	$2,18($17)
	#nop
	mult	$4,$2
	addu	$3,$3,2
	mflo	$7
	#nop
	#nop
	sra	$2,$7,12
	sw	$2,84($16)
	lhu	$2,0($3)
	addu	$3,$3,2
	sh	$2,16($16)
	lhu	$2,0($3)
	#nop
	sh	$2,18($16)
	lhu	$3,2($3)
	move	$4,$16
	addu	$2,$17,1292
	sw	$2,12($16)
	sh	$0,6($16)
	.set	noreorder
	.set	nomacro
	jal	func_800417D0
	sh	$3,20($16)
	.set	macro
	.set	reorder

	lw	$3,D_800A3820
	#nop
	addu	$2,$3,4
	sw	$2,D_800A3820
	sw	$16,0($3)
	lh	$3,0($19)
	addu	$16,$16,104
	li	$2,0x00000003		# 3
	sb	$2,0($16)
	addu	$2,$16,-104
	sw	$2,12($16)
	li	$2,0x00000001		# 1
	sb	$0,1($16)
	sh	$0,8($16)
	sh	$2,6($16)
	sh	$0,10($16)
	sh	$18,4($16)
	sll	$3,$3,1
	addu	$3,$3,1
	sh	$3,2($16)
	lh	$2,6788($17)
	#nop
	sw	$2,88($16)
	lw	$3,D_800A3820
	#nop
	addu	$2,$3,4
	sw	$2,D_800A3820
	sw	$16,0($3)
	addu	$16,$16,104
	sw	$16,D_800A38B4
$L176:
	lw	$31,40($sp)
	lw	$19,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,48
	j	$31
	.end	func_80049A2C
	.align	2
	.globl	func_80049C24
	.ent	func_80049C24
func_80049C24:
	.frame	$sp,56,$31		# vars= 0, regs= 10/0, args= 16, extra= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,56
	move	$7,$4
	sw	$31,52($sp)
	sw	$fp,48($sp)
	sw	$23,44($sp)
	sw	$22,40($sp)
	sw	$21,36($sp)
	sw	$20,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	sw	$16,16($sp)
	lw	$3,0($7)
	lw	$6,8($7)
	sll	$2,$3,2
	addu	$2,$2,$7
	lw	$4,4($2)
	lw	$2,4($7)
	move	$19,$5
	slt	$3,$3,2
	addu	$23,$7,$4
	addu	$fp,$7,$2
	.set	noreorder
	.set	nomacro
	bne	$3,$0,$L181
	subu	$21,$6,$2
	.set	macro
	.set	reorder

	lw	$2,12($7)
	addu	$22,$7,$6
	.set	noreorder
	.set	nomacro
	j	$L182
	subu	$20,$2,$6
	.set	macro
	.set	reorder

$L181:
	move	$22,$0
	move	$20,$0
$L182:
	lh	$16,D_800A33E8
	lh	$18,D_800A33EA
	li	$2,-1			# 0xffffffff
	.set	noreorder
	.set	nomacro
	bne	$16,$2,$L183
	addu	$17,$19,12
	.set	macro
	.set	reorder

	bne	$18,$16,$L203
	.set	noreorder
	.set	nomacro
	j	$L186
	move	$16,$18
	.set	macro
	.set	reorder

$L183:
	bne	$18,$2,$L187
	.set	noreorder
	.set	nomacro
	j	$L186
	move	$16,$0
	.set	macro
	.set	reorder

$L187:
	bne	$16,$18,$L189
	move	$16,$0
$L203:
	.set	noreorder
	.set	nomacro
	j	$L186
	move	$18,$0
	.set	macro
	.set	reorder

$L189:
	slt	$2,$16,$18
	beq	$2,$0,$L191
	move	$16,$0
	.set	noreorder
	.set	nomacro
	j	$L186
	li	$18,0x00000001		# 1
	.set	macro
	.set	reorder

$L191:
	slt	$2,$18,$16
	beq	$2,$0,$L193
	.set	noreorder
	.set	nomacro
	j	$L203
	li	$16,0x00000001		# 1
	.set	macro
	.set	reorder

$L193:
	jal	InitFadePanel
$L186:
	nor	$2,$0,$16
	move	$3,$19
	addu	$19,$19,4
	.set	noreorder
	.set	nomacro
	bltz	$18,$L195
	srl	$2,$2,31
	.set	macro
	.set	reorder

	addu	$2,$2,1
$L195:
	.set	noreorder
	.set	nomacro
	bltz	$16,$L196
	sw	$2,0($3)
	.set	macro
	.set	reorder

	li	$2,0x00000002		# 2
	sw	$2,0($19)
	.set	noreorder
	.set	nomacro
	bne	$16,$0,$L197
	addu	$19,$19,4
	.set	macro
	.set	reorder

	move	$4,$fp
	move	$5,$17
	.set	noreorder
	.set	nomacro
	jal	func_800520B8
	move	$6,$21
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	$L198
	addu	$4,$17,$21
	.set	macro
	.set	reorder

$L197:
	move	$4,$22
	move	$5,$17
	.set	noreorder
	.set	nomacro
	jal	func_800520B8
	move	$6,$20
	.set	macro
	.set	reorder

	addu	$4,$17,$20
$L198:
	jal	saTan5TakeGetPos_80045230
	move	$4,$17
	li	$5,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	jal	tslGlobalMemFree_8005C2A8
	move	$6,$23
	.set	macro
	.set	reorder

	addu	$17,$17,$2
$L196:
	.set	noreorder
	.set	nomacro
	bltz	$18,$L199
	li	$2,0x00000005		# 5
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	bne	$18,$0,$L200
	sw	$2,0($19)
	.set	macro
	.set	reorder

	move	$4,$fp
	move	$5,$17
	.set	noreorder
	.set	nomacro
	jal	func_800520B8
	move	$6,$21
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	$L201
	addu	$4,$17,$21
	.set	macro
	.set	reorder

$L200:
	move	$4,$22
	move	$5,$17
	.set	noreorder
	.set	nomacro
	jal	func_800520B8
	move	$6,$20
	.set	macro
	.set	reorder

	addu	$4,$17,$20
$L201:
	jal	saTan5TakeGetPos_80045230
	move	$4,$17
	li	$5,0x00000005		# 5
	.set	noreorder
	.set	nomacro
	jal	tslGlobalMemFree_8005C2A8
	move	$6,$23
	.set	macro
	.set	reorder

	addu	$17,$17,$2
$L199:
	move	$2,$17
	lw	$31,52($sp)
	lw	$fp,48($sp)
	lw	$23,44($sp)
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,56
	j	$31
	.end	func_80049C24
	.align	2
	.globl	func_80049E1C
	.ent	func_80049E1C
func_80049E1C:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	li	$4,-1			# 0xffffffff
	li	$3,0x00000039		# 57
	la	$2,D_80099CC2
$L205:
	sh	$4,0($2)
	addu	$3,$3,-1
	.set	noreorder
	.set	nomacro
	bgez	$3,$L205
	addu	$2,$2,-2
	.set	macro
	.set	reorder

	li	$2,-1			# 0xffffffff
	sw	$2,D_800A324C
	j	$31
	.end	func_80049E1C
	.align	2
	.globl	func_80049E4C
	.ent	func_80049E4C
func_80049E4C:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	sw	$17,20($sp)
	la	$17,D_80101DF0
	li	$2,0x00000064		# 100
	sw	$31,24($sp)
	sw	$16,16($sp)
	sb	$2,0($17)
	li	$2,0x00000005		# 5
	sb	$0,D_80101DF1
	sh	$0,D_80101E00
	sh	$0,D_80101E02
	sh	$0,D_80101E04
	sw	$0,D_80101E3C
	sw	$0,D_80101E40
	sw	$0,D_80101E44
	sw	$0,D_80101DFC
	sh	$2,D_80101DF8
	.set	noreorder
	.set	nomacro
	jal	func_800418D0
	move	$4,$17
	.set	macro
	.set	reorder

	la	$16,D_800FF638
	li	$2,0x00000065		# 101
	sb	$2,0($16)
	li	$2,0x00000002		# 2
	sb	$0,D_800FF639
	sh	$0,D_800FF648
	sh	$0,D_800FF64A
	sh	$0,D_800FF64C
	sw	$0,D_800FF684
	sw	$0,D_800FF688
	sw	$0,D_800FF68C
	sw	$0,D_800FF644
	sh	$2,D_800FF640
	.set	noreorder
	.set	nomacro
	jal	func_800418D0
	move	$4,$16
	.set	macro
	.set	reorder

	sw	$17,D_800A3708
	sw	$16,D_800A370C
	lw	$31,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,32
	j	$31
	.end	func_80049E4C
	.align	2
	.globl	func_80049F4C
	.ent	func_80049F4C
func_80049F4C:
	.frame	$sp,80,$31		# vars= 48, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,80
	addu	$7,$sp,16
	la	$6,D_800153F0
	or	$2,$7,$6
	andi	$2,$2,0x0003
	sw	$31,72($sp)
	sw	$17,68($sp)
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L211
	sw	$16,64($sp)
	.set	macro
	.set	reorder

	addu	$8,$6,32
$L213:
	lwl	$2,3($6)
	lwr	$2,0($6)
	lwl	$3,7($6)
	lwr	$3,4($6)
	lwl	$4,11($6)
	lwr	$4,8($6)
	lwl	$5,15($6)
	lwr	$5,12($6)
	swl	$2,3($7)
	swr	$2,0($7)
	swl	$3,7($7)
	swr	$3,4($7)
	swl	$4,11($7)
	swr	$4,8($7)
	swl	$5,15($7)
	swr	$5,12($7)
	addu	$6,$6,16
	.set	noreorder
	.set	nomacro
	bne	$6,$8,$L213
	addu	$7,$7,16
	.set	macro
	.set	reorder

	j	$L212
$L211:
	addu	$8,$6,32
$L214:
	lw	$2,0($6)
	lw	$3,4($6)
	lw	$4,8($6)
	lw	$5,12($6)
	sw	$2,0($7)
	sw	$3,4($7)
	sw	$4,8($7)
	sw	$5,12($7)
	addu	$6,$6,16
	.set	noreorder
	.set	nomacro
	bne	$6,$8,$L214
	addu	$7,$7,16
	.set	macro
	.set	reorder

$L212:
	lwl	$2,3($6)
	lwr	$2,0($6)
	lwl	$3,7($6)
	lwr	$3,4($6)
	lwl	$4,11($6)
	lwr	$4,8($6)
	swl	$2,3($7)
	swr	$2,0($7)
	swl	$3,7($7)
	swr	$3,4($7)
	swl	$4,11($7)
	swr	$4,8($7)
	move	$17,$0
	la	$16,D_800F62E0
$L215:
	move	$4,$16
	.set	noreorder
	.set	nomacro
	jal	func_8004A09C
	addu	$5,$sp,16
	.set	macro
	.set	reorder

	addu	$17,$17,1
	slt	$2,$17,8
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L215
	addu	$16,$16,96
	.set	macro
	.set	reorder

	la	$4,D_800F6318
	jal	gte_SetColorMatrix
	lbu	$4,D_800F6338
	lbu	$5,D_800F6339
	lbu	$6,D_800F633A
	jal	gte_SetBackColor
	lw	$31,72($sp)
	lw	$17,68($sp)
	lw	$16,64($sp)
	addu	$sp,$sp,80
	j	$31
	.end	func_80049F4C
	.align	2
	.globl	func_8004A09C
	.ent	func_8004A09C
func_8004A09C:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	sw	$16,16($sp)
	move	$16,$5
	sw	$31,24($sp)
	sw	$17,20($sp)
	lhu	$2,0($16)
	move	$17,$4
	addu	$16,$16,2
	sh	$2,56($17)
	lhu	$2,0($16)
	addu	$16,$16,2
	sh	$2,62($17)
	lhu	$2,0($16)
	addu	$16,$16,2
	sh	$2,68($17)
	lhu	$2,0($16)
	addu	$16,$16,2
	sh	$2,58($17)
	lhu	$2,0($16)
	addu	$16,$16,2
	sh	$2,64($17)
	lhu	$2,0($16)
	addu	$16,$16,2
	sh	$2,70($17)
	lhu	$2,0($16)
	addu	$16,$16,2
	sh	$2,60($17)
	lhu	$2,0($16)
	addu	$16,$16,2
	sh	$2,66($17)
	lhu	$2,0($16)
	addu	$16,$16,2
	sh	$0,24($17)
	sh	$0,26($17)
	sh	$0,28($17)
	sh	$0,30($17)
	sh	$0,32($17)
	sh	$0,34($17)
	sh	$0,36($17)
	sh	$0,38($17)
	sh	$0,40($17)
	sh	$2,72($17)
	lhu	$2,0($16)
	addu	$16,$16,2
	sh	$2,0($17)
	lhu	$2,0($16)
	addu	$16,$16,2
	sh	$2,2($17)
	lhu	$2,0($16)
	addu	$16,$16,2
	sh	$2,4($17)
	lhu	$2,0($16)
	addu	$16,$16,2
	sh	$2,8($17)
	lhu	$2,0($16)
	addu	$16,$16,2
	sh	$2,10($17)
	lhu	$2,0($16)
	addu	$16,$16,2
	sh	$2,12($17)
	lhu	$2,0($16)
	addu	$16,$16,2
	sh	$2,16($17)
	lhu	$2,0($16)
	addu	$16,$16,2
	sh	$2,18($17)
	lhu	$2,0($16)
	addu	$16,$16,2
	.set	noreorder
	.set	nomacro
	jal	func_8004A1FC
	sh	$2,20($17)
	.set	macro
	.set	reorder

	lhu	$2,0($16)
	addu	$16,$16,2
	sb	$2,88($17)
	lhu	$2,0($16)
	addu	$16,$16,2
	sb	$2,89($17)
	lhu	$2,0($16)
	#nop
	sb	$2,90($17)
	lhu	$2,2($16)
	#nop
	sh	$2,92($17)
	lw	$31,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,32
	j	$31
	.end	func_8004A09C
	.align	2
	.globl	func_8004A1FC
	.ent	func_8004A1FC
func_8004A1FC:
	.frame	$sp,48,$31		# vars= 0, regs= 7/0, args= 16, extra= 0
	.mask	0x803f0000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,48
	sw	$20,32($sp)
	move	$20,$4
	sw	$21,36($sp)
	move	$21,$0
	sw	$31,40($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	sw	$16,16($sp)
	sll	$2,$21,16
$L227:
	sra	$18,$2,16
	sll	$2,$18,3
	addu	$19,$20,$2
	lh	$2,4($19)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L224
	sll	$2,$18,1
	.set	macro
	.set	reorder

	lh	$4,0($19)
	.set	noreorder
	.set	nomacro
	jal	math_Cos
	sll	$16,$18,1
	.set	macro
	.set	reorder

	lh	$4,2($19)
	.set	noreorder
	.set	nomacro
	jal	math_Sin
	move	$17,$2
	.set	macro
	.set	reorder

	sll	$17,$17,16
	sra	$17,$17,16
	mult	$2,$17
	lh	$3,92($20)
	mflo	$5
	#nop
	#nop
	sra	$2,$5,12
	mult	$2,$3
	addu	$16,$16,$18
	sll	$16,$16,1
	addu	$16,$20,$16
	mflo	$5
	#nop
	#nop
	subu	$2,$0,$5
	sra	$2,$2,12
	sh	$2,24($16)
	lh	$4,0($19)
	jal	math_Sin
	lh	$3,92($20)
	#nop
	mult	$2,$3
	mflo	$5
	#nop
	#nop
	sra	$2,$5,12
	sh	$2,26($16)
	lh	$4,2($19)
	jal	math_Cos
	mult	$2,$17
	lh	$3,92($20)
	mflo	$5
	#nop
	#nop
	sra	$2,$5,12
	mult	$2,$3
	mflo	$5
	#nop
	#nop
	subu	$2,$0,$5
	sra	$2,$2,12
	.set	noreorder
	.set	nomacro
	j	$L225
	sh	$2,28($16)
	.set	macro
	.set	reorder

$L224:
	addu	$2,$2,$18
	sll	$2,$2,1
	addu	$2,$20,$2
	sh	$0,24($2)
	sh	$0,26($2)
	sh	$0,28($2)
$L225:
	addu	$2,$21,1
	move	$21,$2
	sll	$2,$2,16
	sra	$2,$2,16
	slt	$2,$2,3
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L227
	sll	$2,$21,16
	.set	macro
	.set	reorder

	lw	$31,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,48
	j	$31
	.end	func_8004A1FC
 #APP
	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_8004A348
    addiu  $sp, $sp, -0x38
    sw     $ra, 52($sp)
    sw     $fp, 48($sp)
    sw     $s7, 44($sp)
    sw     $s6, 40($sp)
    sw     $s5, 36($sp)
    sw     $s4, 32($sp)
    sw     $s3, 28($sp)
    sw     $s2, 24($sp)
    sw     $s1, 20($sp)
    sw     $s0, 16($sp)
    lui    $v0, %hi(Judge)
    addiu  $v0, $v0, %lo(Judge)
    lhu    $t0, 0($a0)
    lhu    $t1, 2($a0)
    lhu    $t2, 4($a0)
    andi   $t0, $t0, 0xFFF
    andi   $t1, $t1, 0xFFF
    andi   $t2, $t2, 0xFFF
    add    $t0, $t0, $t0
    add    $t1, $t1, $t1
    add    $t2, $t2, $t2
    add    $t3, $v0, $t0
    add    $t4, $v0, $t1
    add    $t5, $v0, $t2
    lh     $s0, 0($t3)
    lh     $s1, 0($t4)
    lh     $s2, 0($t5)
    addi   $t0, $t0, 0x800
    addi   $t1, $t1, 0x800
    addi   $t2, $t2, 0x800
    andi   $t0, $t0, 0x1FFE
    andi   $t1, $t1, 0x1FFE
    andi   $t2, $t2, 0x1FFE
    add    $t0, $v0, $t0
    add    $t1, $v0, $t1
    add    $t2, $v0, $t2
    lh     $t5, 0($t2)
    lh     $s4, 0($t1)
    lh     $s3, 0($t0)
    mtc2   $t5, $8
    mtc2   $s0, $9
    mtc2   $s3, $10
    mtc2   $s4, $11
    mfc2   $s0, $9
    nop
    gpf    1
    mult   $s0, $s4
    neg    $t7, $s1
    sh     $t7, 12($a1)
    mfc2   $t6, $9
    mfc2   $t7, $10
    mfc2   $t8, $11
    mtc2   $s2, $8
    mtc2   $s0, $9
    mtc2   $s3, $10
    mtc2   $s4, $11
    sh     $t8, 0($a1)
    mflo   $t9
    gpf    1
    sra    $t9, $t9, 12
    mult   $s3, $s4
    mtc2   $s1, $8
    sh     $t9, 14($a1)
    mfc2   $t8, $9
    mfc2   $t9, $10
    mfc2   $a2, $11
    mfc2   $s1, $8
    mtc2   $t7, $25
    neg    $a3, $t6
    mtc2   $a3, $26
    mtc2   $t8, $27
    mtc2   $t7, $11
    mflo   $a3
    nop
    gpl    1
    sh     $a2, 6($a1)
    mult   $s1, $t6
    sra    $a3, $a3, 12
    sh     $a3, 16($a1)
    mfc2   $t6, $9
    mfc2   $t7, $10
    mfc2   $t8, $11
    sh     $t6, 8($a1)
    sh     $t7, 10($a1)
    mflo   $a2
    sh     $t8, 4($a1)
    sra    $a2, $a2, 12
    sub    $a2, $a2, $t9
    sh     $a2, 2($a1)
    lw     $ra, 52($sp)
    lw     $fp, 48($sp)
    lw     $s7, 44($sp)
    lw     $s6, 40($sp)
    lw     $s5, 36($sp)
    lw     $s4, 32($sp)
    lw     $s3, 28($sp)
    lw     $s2, 24($sp)
    lw     $s1, 20($sp)
    lw     $s0, 16($sp)
    jr     $ra
    addiu  $sp, $sp, 0x38
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_8004A4E0
    addiu   $sp,$sp,-0x38
    sw   $ra,52($sp)
    sw   $fp,48($sp)
    sw   $s7,44($sp)
    sw   $s6,40($sp)
    sw   $s5,36($sp)
    sw   $s4,32($sp)
    sw   $s3,28($sp)
    sw   $s2,24($sp)
    sw   $s1,20($sp)
    sw   $s0,16($sp)
    lui   $v0,%hi(D_800A3820)
    lw   $v0,%lo(D_800A3820)($v0)
    lui   $s7,%hi(D_80102C00)
    addiu   $s7,$s7,%lo(D_80102C00)
    beq   $v0,$s7,.L8004A5D0
    lui   $s1,0x1F80
    addu   $s5,$zero,$zero
    lui   $fp,%hi(D_800FF610)
    addiu   $fp,$fp,%lo(D_800FF610)
    lw   $s4,28($s1)
.L8004A534:
    lw   $s2,0($s7)
    addu   $s6,$fp,$zero
    lbu   $t0,0($s2)
    nop
    sll   $t0,$t0,2
    lui   $at,%hi(jtbl_8001541C)
    addu   $at,$at,$t0
    lw   $t0,%lo(jtbl_8001541C)($at)
    nop
    jr   $t0
    addiu   $s7,$s7,0x4
.L8004A560:
    lh   $t0,4($s2)
    lh   $t1,2($s2)
    sll   $t0,$t0,2
    lui   $t2,%hi(D_80103608)
    addiu   $t2,$t2,%lo(D_80103608)
    addu   $t0,$t0,$t2
    lw   $t0,0($t0)
    sll   $t1,$t1,2
    addu   $t0,$t0,$t1
    lw   $s0,0($t0)
    nop
.L8004A58C:
    lw   $a1,0($s0)
    nop
    andi   $a0,$a1,0xFFFF
    srl   $a1,$a1,16
    beqz   $a0,.L8004A5D0
    addi   $s0,$s0,0x4
    sll   $a1,$a1,2
    lui   $at,%hi(jtbl_8001545C)
    addu   $at,$at,$a1
    lw   $a1,%lo(jtbl_8001545C)($at)
    nop
    jr   $a1
    nop
.L8004A5C0:
    lhu   $t0,0($s0)
    addiu   $s0,$s0,0x2
    bnez   $t0,.L8004A58C
    nop
    .global .L8004A5D0
.L8004A5D0:
    lui   $v0,%hi(D_800A3820)
    lw   $v0,%lo(D_800A3820)($v0)
    nop
    bne   $s7,$v0,.L8004A534
    nop
    lw   $ra,52($sp)
    lw   $fp,48($sp)
    lw   $s7,44($sp)
    lw   $s6,40($sp)
    lw   $s5,36($sp)
    lw   $s4,32($sp)
    lw   $s3,28($sp)
    lw   $s2,24($sp)
    lw   $s1,20($sp)
    lw   $s0,16($sp)
    jr   $ra
    addiu   $sp,$sp,0x38
    .global .L8004A614
.L8004A614:
    addiu   $t0,$zero,0x3
    subu   $t0,$t0,$s5
    lui   $at,0x1F80
    sw   $t0,8($at)
    addiu   $a1,$s1,0x20
    addiu   $a2,$s1,0x2B4
    jal   func_8004A76C
    nop
    jal   calc_loc_mat_fw_8004A940
    nop
    j   .L8004A5C0
    nop
    .global .L8004A644
.L8004A644:
    addiu   $t0,$zero,0x3
    subu   $t0,$t0,$s5
    lui   $at,0x1F80
    sw   $t0,8($at)
    addiu   $a1,$s1,0x20
    addiu   $a2,$s1,0x2B4
    jal   func_8004A808
    nop
    lbu   $t1,1($s2)
    lui   $s4,%hi(D_80095328)
    addiu   $s4,$s4,%lo(D_80095328)
    andi   $t1,$t1,0x1
    beqz   $t1,.L8004A680
    nop
    addi   $s4,$s4,0xB0
.L8004A680:
    jal   calc_loc_mat_fw_8004A940
    nop
    lw   $s4,28($s1)
    j   .L8004A5C0
    nop
    .global .L8004A694
.L8004A694:
    addiu   $t0,$zero,0x3
    subu   $t0,$t0,$s5
    lui   $at,0x1F80
    sw   $t0,8($at)
    addiu   $a1,$s1,0x20
    addiu   $a2,$s1,0x2B4
    lui   $t0,0x50
    lui   $t1,0x3C
    ctc2   $t0,$24
    ctc2   $t1,$25
    jal   func_8004A76C
    nop
    lui   $t0,0x140
    lui   $t1,0x78
    ctc2   $t0,$24
    ctc2   $t1,$25
    lui   $s4,%hi(D_80095508)
    addiu   $s4,$s4,%lo(D_80095508)
    jal   calc_loc_mat_fw_8004A940
    nop
    lw   $s4,28($s1)
    j   .L8004A5C0
    nop
    .global .L8004A6F0
.L8004A6F0:
    addiu   $t0,$zero,0x3
    subu   $t0,$t0,$s5
    lui   $at,0x1F80
    sw   $t0,8($at)
    addiu   $a1,$s1,0x20
    addiu   $a2,$s1,0x2B4
    jal   func_8004A938
    nop
    lui   $s4,%hi(D_80095328)
    addiu   $s4,$s4,%lo(D_80095328)
    nop
    jal   calc_loc_mat_fw_8004A940
    nop
    lw   $s4,28($s1)
    j   .L8004A5C0
    nop
    .global .L8004A730
.L8004A730:
    addiu   $t0,$zero,0x3
    subu   $t0,$t0,$s5
    lui   $at,0x1F80
    sw   $t0,8($at)
    addiu   $a1,$s1,0x20
    addiu   $a2,$s1,0x2B4
    jal   func_8004A808
    nop
    lui   $s4,%hi(D_80095488)
    addiu   $s4,$s4,%lo(D_80095488)
    jal   calc_loc_mat_fw_8004A940
    nop
    lw   $s4,28($s1)
    j   .L8004A5C0
    nop
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_8004A76C
    addiu  $a0, $a0, -1
    lwc2   $0, 0($s0)
    lwc2   $1, 4($s0)
    lwc2   $2, 8($s0)
    lwc2   $3, 12($s0)
    lwc2   $4, 16($s0)
    lwc2   $5, 20($s0)
    nop
    nop
    .word 0x4A280030
    j      .L8004A7B0_a76c
    addiu  $s0, $s0, 24
.L8004A79C_a76c:
    .word 0x4A280030
    addiu  $a2, $a2, 6
    sh     $t0, -6($a2)
    sh     $t1, -4($a2)
    sh     $t2, -2($a2)
.L8004A7B0_a76c:
    swc2   $12, 0($a1)
    swc2   $13, 4($a1)
    swc2   $14, 8($a1)
    mfc2   $t0, $17
    mfc2   $t1, $18
    mfc2   $t2, $19
    addiu  $a1, $a1, 12
    beqz   $a0, .L8004A7F4_a76c
    addiu  $a0, $a0, -1
    lwc2   $0, 0($s0)
    lwc2   $1, 4($s0)
    lwc2   $2, 8($s0)
    lwc2   $3, 12($s0)
    lwc2   $4, 16($s0)
    lwc2   $5, 20($s0)
    j      .L8004A79C_a76c
    addiu  $s0, $s0, 24
.L8004A7F4_a76c:
    sh     $t0, 0($a2)
    sh     $t1, 2($a2)
    sh     $t2, 4($a2)
    jr     $ra
    nop
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_8004A808
    addiu  $a0, $a0, -3
    lhu    $t6, 0($s0)
    lhu    $t7, 2($s0)
    lhu    $t8, 4($s0)
    sll    $t7, $t7, 16
    or     $t6, $t6, $t7
    mtc2   $t6, $0
    mtc2   $t8, $1
    lhu    $t6, 6($s0)
    lhu    $t7, 8($s0)
    lhu    $t8, 10($s0)
    sll    $t7, $t7, 16
    or     $t6, $t6, $t7
    mtc2   $t6, $2
    mtc2   $t8, $3
    lhu    $t6, 12($s0)
    lhu    $t7, 14($s0)
    lhu    $t8, 16($s0)
    sll    $t7, $t7, 16
    or     $t6, $t6, $t7
    mtc2   $t6, $4
    mtc2   $t8, $5
    nop
    nop
    rtpt
    j      .L8004A888
    addiu  $s0, $s0, 18
.L8004A874:
    rtpt
    addiu  $a2, $a2, 6
    sh     $t0, -6($a2)
    sh     $t1, -4($a2)
    sh     $t2, -2($a2)
.L8004A888:
    swc2   $12, 0($a1)
    swc2   $13, 4($a1)
    swc2   $14, 8($a1)
    mfc2   $t0, $17
    mfc2   $t1, $18
    mfc2   $t2, $19
    addiu  $a1, $a1, 12
    blez   $a0, .L8004A90C
    nop
    addiu  $a0, $a0, -3
    lhu    $t6, 0($s0)
    lhu    $t7, 2($s0)
    lhu    $t8, 4($s0)
    sll    $t7, $t7, 16
    or     $t6, $t6, $t7
    mtc2   $t6, $0
    mtc2   $t8, $1
    lhu    $t6, 6($s0)
    lhu    $t7, 8($s0)
    lhu    $t8, 10($s0)
    sll    $t7, $t7, 16
    or     $t6, $t6, $t7
    mtc2   $t6, $2
    mtc2   $t8, $3
    lhu    $t6, 12($s0)
    lhu    $t7, 14($s0)
    lhu    $t8, 16($s0)
    sll    $t7, $t7, 16
    or     $t6, $t6, $t7
    mtc2   $t6, $4
    mtc2   $t8, $5
    j      .L8004A874
    addiu  $s0, $s0, 18
.L8004A90C:
    sh     $t0, 0($a2)
    sh     $t1, 2($a2)
    sh     $t2, 4($a2)
    add    $a0, $a0, $a0
    add    $t0, $a0, $a0
    add    $a0, $t0, $a0
    add    $s0, $s0, $a0
    andi   $t0, $s0, 3
    add    $s0, $s0, $t0
    jr     $ra
    nop
.set	reorder
.set	at
.set reorder
.set at

 #NO_APP
	.align	2
	.globl	func_8004A938
	.ent	func_8004A938
func_8004A938:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_8004A938
 #APP
	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel calc_loc_mat_fw_8004A940
    sw  $ra,4($s1)
    lhu  $a0,0($s0)
    addiu  $s0,$s0,2
    beqz  $a0,.L8004A980
.L8004A950:
    lhu  $t0,0($s0)
    addiu  $s0,$s0,2
    sll  $t0,$t0,2
    addu  $t0,$t0,$s4
    lw  $t0,0($t0)
    nop
    jalr  $t0
    nop
    lhu  $a0,0($s0)
    addiu  $s0,$s0,2
    bnez  $a0,.L8004A950
    nop
.L8004A980:
    lw  $ra,4($s1)
    nop
    jr  $ra
    nop
jlabel .L8004A990
    lui  $v0,%hi(D_800A3708)
    lw  $v0,%lo(D_800A3708)($v0)
    lw  $t0,44($s2)
    lw  $t1,48($s2)
    lw  $t2,52($s2)
    lw  $t3,44($v0)
    lw  $t4,48($v0)
    lw  $t5,52($v0)
    subu  $t0,$t0,$t3
    subu  $t1,$t1,$t4
    subu  $t2,$t2,$t5
    slt  $t6,$t0,$zero
    neg  $t6,$t6
    xor  $t3,$t0,$t6
    sub  $t3,$t3,$t6
    slt  $t6,$t1,$zero
    neg  $t6,$t6
    xor  $t4,$t1,$t6
    sub  $t4,$t4,$t6
    slt  $t6,$t2,$zero
    neg  $t6,$t6
    xor  $t5,$t2,$t6
    sub  $t5,$t5,$t6
    or  $t3,$t3,$t4
    or  $t3,$t3,$t5
    addiu  $s5,$zero,2
    slti  $t4,$t3,18944
    ori  $at,$zero,42240
    slt  $t5,$t3,$at
    sub  $s5,$s5,$t4
    sub  $s5,$s5,$t5
    nop
    srav  $t0,$t0,$s5
    sh  $t0,32($s1)
    srav  $t1,$t1,$s5
    sh  $t1,34($s1)
    srav  $t2,$t2,$s5
    sh  $t2,36($s1)
    lh  $t0,10($s2)
    lui  $t2,%hi(D_800F62E0)
    addiu  $t2,$t2,%lo(D_800F62E0)
    sll  $t1,$t0,1
    add  $t1,$t1,$t0
    sll  $t1,$t1,5
    addu  $s3,$t1,$t2
    addiu  $a0,$s3,24
    addiu  $a1,$s2,24
    jal  func_80052930
    addiu  $a2,$s1,72
    lw  $t0,72($s1)
    lw  $t1,76($s1)
    lw  $t2,80($s1)
    lw  $t3,84($s1)
    lw  $t4,88($s1)
    ctc2  $t0,$8
    ctc2  $t1,$9
    ctc2  $t2,$10
    ctc2  $t3,$11
    ctc2  $t4,$12
    lw  $t0,56($s3)
    lw  $t1,60($s3)
    lw  $t2,64($s3)
    lw  $t3,68($s3)
    lw  $t4,72($s3)
    ctc2  $t0,$16
    ctc2  $t1,$17
    ctc2  $t2,$18
    ctc2  $t3,$19
    ctc2  $t4,$20
    addu  $a0,$s6,$zero
    addiu  $a1,$s2,24
    jal  func_80052930
    addiu  $a2,$s1,40
    lw  $t0,0($s6)
    lw  $t1,4($s6)
    lw  $t2,8($s6)
    lw  $t3,12($s6)
    lw  $t4,16($s6)
    ctc2  $t0,$0
    ctc2  $t1,$1
    ctc2  $t2,$2
    ctc2  $t3,$3
    ctc2  $t4,$4
    ctc2  $zero,$5
    ctc2  $zero,$6
    ctc2  $zero,$7
    lwc2  $0,32($s1)
    lwc2  $1,36($s1)
    lw  $a0,88($s3)
    addiu  $t1,$zero,4080
    mvmva  1,0,0,0,0
    srl  $a1,$a0,4
    srl  $a2,$a0,12
    sll  $a0,$a0,4
    and  $a0,$a0,$t1
    and  $a1,$a1,$t1
    and  $a2,$a2,$t1
    ctc2  $a0,$13
    ctc2  $a1,$14
    ctc2  $a2,$15
    mfc2  $t0,$9
    mfc2  $t1,$10
    mfc2  $t2,$11
    sra  $t1,$t1,1
    ctc2  $t0,$5
    ctc2  $t1,$6
    ctc2  $t2,$7
    lh  $t0,40($s1)
    lh  $t1,42($s1)
    lh  $t2,44($s1)
    lh  $t3,46($s1)
    lh  $t4,48($s1)
    lh  $t5,50($s1)
    lh  $t6,52($s1)
    lh  $t7,54($s1)
    lh  $t8,56($s1)
    srav  $t0,$t0,$s5
    srav  $t1,$t1,$s5
    srav  $t2,$t2,$s5
    addi  $s5,$s5,1
    srav  $t3,$t3,$s5
    srav  $t4,$t4,$s5
    srav  $t5,$t5,$s5
    addi  $s5,$s5,-1
    srav  $t6,$t6,$s5
    srav  $t7,$t7,$s5
    srav  $t8,$t8,$s5
    andi  $t0,$t0,65535
    sll  $t1,$t1,16
    andi  $t2,$t2,65535
    sll  $t3,$t3,16
    andi  $t4,$t4,65535
    sll  $t5,$t5,16
    andi  $t6,$t6,65535
    sll  $t7,$t7,16
    or  $t0,$t0,$t1
    or  $t2,$t2,$t3
    or  $t4,$t4,$t5
    or  $t6,$t6,$t7
    ctc2  $t0,$0
    ctc2  $t2,$1
    ctc2  $t4,$2
    ctc2  $t6,$3
    ctc2  $t8,$4
    j  .L8004A560
    nop
jlabel .L8004ABD8
    lui  $v0,%hi(D_800A3708)
    lw  $v0,%lo(D_800A3708)($v0)
    lw  $t0,44($s2)
    lw  $t1,48($s2)
    lw  $t2,52($s2)
    lw  $t3,44($v0)
    lw  $t4,48($v0)
    lw  $t5,52($v0)
    subu  $t0,$t0,$t3
    subu  $t1,$t1,$t4
    subu  $t2,$t2,$t5
    slt  $t6,$t0,$zero
    neg  $t6,$t6
    xor  $t3,$t0,$t6
    sub  $t3,$t3,$t6
    slt  $t6,$t1,$zero
    neg  $t6,$t6
    xor  $t4,$t1,$t6
    sub  $t4,$t4,$t6
    slt  $t6,$t2,$zero
    neg  $t6,$t6
    xor  $t5,$t2,$t6
    sub  $t5,$t5,$t6
    or  $t3,$t3,$t4
    or  $t3,$t3,$t5
    addiu  $s5,$zero,3
    slti  $t4,$t3,11520
    slti  $t5,$t3,23168
    ori  $at,$zero,46340
    slt  $t6,$t3,$at
    sub  $s5,$s5,$t6
    sub  $s5,$s5,$t5
    sub  $s5,$s5,$t4
    addiu  $s5,$zero,2
    srav  $t0,$t0,$s5
    sh  $t0,32($s1)
    srav  $t1,$t1,$s5
    sh  $t1,34($s1)
    srav  $t2,$t2,$s5
    sh  $t2,36($s1)
    lw  $t0,0($s6)
    lw  $t1,4($s6)
    lw  $t2,8($s6)
    lw  $t3,12($s6)
    lw  $t4,16($s6)
    ctc2  $t0,$0
    ctc2  $t1,$1
    ctc2  $t2,$2
    ctc2  $t3,$3
    ctc2  $t4,$4
    ctc2  $zero,$5
    ctc2  $zero,$6
    ctc2  $zero,$7
    lwc2  $0,32($s1)
    lwc2  $1,36($s1)
    lh  $t0,10($s2)
    nop
    mvmva  1,0,0,0,0
    sll  $t1,$t0,1
    add  $t1,$t1,$t0
    sll  $t1,$t1,5
    lui  $t0,%hi(D_800F62E0)
    addiu  $t0,$t0,%lo(D_800F62E0)
    addu  $s3,$t1,$t0
    mfc2  $t0,$9
    mfc2  $t1,$10
    mfc2  $t2,$11
    sra  $t1,$t1,1
    ctc2  $t0,$5
    ctc2  $t1,$6
    ctc2  $t2,$7
    lw  $t0,24($s3)
    lw  $t1,28($s3)
    lw  $t2,32($s3)
    lw  $t3,36($s3)
    lw  $t4,40($s3)
    ctc2  $t0,$8
    ctc2  $t1,$9
    ctc2  $t2,$10
    ctc2  $t3,$11
    ctc2  $t4,$12
    lw  $t0,56($s3)
    lw  $t1,60($s3)
    lw  $t2,64($s3)
    lw  $t3,68($s3)
    lw  $t4,72($s3)
    ctc2  $t0,$16
    ctc2  $t1,$17
    ctc2  $t2,$18
    ctc2  $t3,$19
    ctc2  $t4,$20
    lw  $a0,88($s3)
    addiu  $t1,$zero,4080
    srl  $a1,$a0,4
    srl  $a2,$a0,12
    sll  $a0,$a0,4
    and  $a0,$a0,$t1
    and  $a1,$a1,$t1
    and  $a2,$a2,$t1
    ctc2  $a0,$13
    ctc2  $a1,$14
    ctc2  $a2,$15
    lh  $t0,0($s6)
    lh  $t1,2($s6)
    lh  $t2,4($s6)
    lh  $t3,6($s6)
    lh  $t4,8($s6)
    lh  $t5,10($s6)
    lh  $t6,12($s6)
    lh  $t7,14($s6)
    lh  $t8,16($s6)
    srav  $t0,$t0,$s5
    srav  $t1,$t1,$s5
    srav  $t2,$t2,$s5
    addi  $s5,$s5,1
    srav  $t3,$t3,$s5
    srav  $t4,$t4,$s5
    srav  $t5,$t5,$s5
    addi  $s5,$s5,-1
    srav  $t6,$t6,$s5
    srav  $t7,$t7,$s5
    srav  $t8,$t8,$s5
    andi  $t0,$t0,65535
    sll  $t1,$t1,16
    andi  $t2,$t2,65535
    sll  $t3,$t3,16
    andi  $t4,$t4,65535
    sll  $t5,$t5,16
    andi  $t6,$t6,65535
    sll  $t7,$t7,16
    or  $t0,$t0,$t1
    or  $t2,$t2,$t3
    or  $t4,$t4,$t5
    or  $t6,$t6,$t7
    ctc2  $t0,$0
    ctc2  $t2,$1
    ctc2  $t4,$2
    ctc2  $t6,$3
    ctc2  $t8,$4
    j  .L8004A560
    nop
jlabel .L8004AE0C
    lw  $a0,12($s2)
    addiu  $a1,$s1,40
    lw  $a2,88($s2)
    jal  camera_Transform
    addiu  $a0,$a0,24
    lui  $v0,%hi(D_800A3708)
    lw  $v0,%lo(D_800A3708)($v0)
    lw  $t0,60($s1)
    lw  $t1,64($s1)
    lw  $t2,68($s1)
    lw  $t3,44($v0)
    lw  $t4,48($v0)
    lw  $t5,52($v0)
    subu  $t0,$t0,$t3
    subu  $t1,$t1,$t4
    subu  $t2,$t2,$t5
    sra  $t0,$t0,2
    sra  $t1,$t1,2
    sra  $t2,$t2,2
    sh  $t0,32($s1)
    sh  $t1,34($s1)
    sh  $t2,36($s1)
    lw  $t0,0($s6)
    lw  $t1,4($s6)
    lw  $t2,8($s6)
    lw  $t3,12($s6)
    lw  $t4,16($s6)
    ctc2  $t0,$0
    ctc2  $t1,$1
    ctc2  $t2,$2
    ctc2  $t3,$3
    ctc2  $t4,$4
    ctc2  $zero,$5
    ctc2  $zero,$6
    ctc2  $zero,$7
    lw  $t0,32($s1)
    lw  $t1,36($s1)
    mtc2  $t0,$0
    mtc2  $t1,$1
    nop
    nop
    mvmva  1,0,0,0,0
    nop
    nop
    swc2  $9,20($s6)
    swc2  $10,24($s6)
    swc2  $11,28($s6)
    addu  $a0,$s6,$zero
    jal  calc_fc_frame_8007EC5C
    addiu  $a1,$s1,40
    lw  $t0,20($s6)
    lw  $t1,24($s6)
    lw  $t2,28($s6)
    sra  $t1,$t1,1
    ctc2  $t0,$5
    ctc2  $t1,$6
    ctc2  $t2,$7
    lh  $t0,40($s1)
    lh  $t1,42($s1)
    lh  $t2,44($s1)
    lh  $t3,46($s1)
    lh  $t4,48($s1)
    lh  $t5,50($s1)
    lh  $t6,52($s1)
    lh  $t7,54($s1)
    lh  $t8,56($s1)
    sra  $t0,$t0,2
    sra  $t1,$t1,2
    sra  $t2,$t2,2
    sra  $t3,$t3,3
    sra  $t4,$t4,3
    sra  $t5,$t5,3
    sra  $t6,$t6,2
    sra  $t7,$t7,2
    sra  $t8,$t8,2
    andi  $t0,$t0,65535
    sll  $t1,$t1,16
    andi  $t2,$t2,65535
    sll  $t3,$t3,16
    andi  $t4,$t4,65535
    sll  $t5,$t5,16
    andi  $t6,$t6,65535
    sll  $t7,$t7,16
    or  $t0,$t0,$t1
    or  $t2,$t2,$t3
    or  $t4,$t4,$t5
    or  $t6,$t6,$t7
    ctc2  $t0,$0
    ctc2  $t2,$1
    ctc2  $t4,$2
    ctc2  $t6,$3
    ctc2  $t8,$4
    j  .L8004A560
    addiu  $s5,$zero,2
jlabel .L8004AF84
    lui  $v0,%hi(D_800A3708)
    lw  $v0,%lo(D_800A3708)($v0)
    lw  $t0,44($s2)
    lw  $t1,48($s2)
    lw  $t2,52($s2)
    lw  $t3,44($v0)
    lw  $t4,48($v0)
    lw  $t5,52($v0)
    subu  $t0,$t0,$t3
    subu  $t1,$t1,$t4
    subu  $t2,$t2,$t5
    slt  $t6,$t0,$zero
    neg  $t6,$t6
    xor  $t3,$t0,$t6
    sub  $t3,$t3,$t6
    slt  $t6,$t1,$zero
    neg  $t6,$t6
    xor  $t4,$t1,$t6
    sub  $t4,$t4,$t6
    slt  $t6,$t2,$zero
    neg  $t6,$t6
    xor  $t5,$t2,$t6
    sub  $t5,$t5,$t6
    or  $t3,$t3,$t4
    or  $t3,$t3,$t5
    addiu  $s5,$zero,2
    slti  $t4,$t3,23040
    ori  $at,$zero,46336
    slt  $t5,$t3,$at
    sub  $s5,$s5,$t4
    sub  $s5,$s5,$t5
    nop
    lh  $t0,10($s2)
    nop
    sll  $t1,$t0,1
    add  $t1,$t1,$t0
    sll  $t1,$t1,5
    lui  $t0,%hi(D_800F62E0)
    addiu  $t0,$t0,%lo(D_800F62E0)
    addu  $s3,$t1,$t0
    lw  $t0,56($s3)
    lw  $t1,60($s3)
    lw  $t2,64($s3)
    lw  $t3,68($s3)
    lw  $t4,72($s3)
    ctc2  $t0,$16
    ctc2  $t1,$17
    ctc2  $t2,$18
    ctc2  $t3,$19
    ctc2  $t4,$20
    lw  $a0,88($s3)
    addiu  $t1,$zero,4080
    srl  $a1,$a0,4
    srl  $a2,$a0,12
    sll  $a0,$a0,4
    and  $a0,$a0,$t1
    and  $a1,$a1,$t1
    and  $a2,$a2,$t1
    ctc2  $a0,$13
    ctc2  $a1,$14
    ctc2  $a2,$15
    lui  $at,8064
    sw  $s5,8($at)
    nop
    lh  $t0,4($s2)
    lh  $t1,2($s2)
    sll  $t0,$t0,2
    lui  $t2,%hi(D_80103608)
    addiu  $t2,$t2,%lo(D_80103608)
    addu  $t0,$t0,$t2
    lw  $t0,0($t0)
    sll  $t1,$t1,2
    addu  $t0,$t0,$t1
    lw  $a1,0($t0)
    lw  $a0,88($s2)
    lh  $a2,10($s2)
    jal  func_800430E4
    addu  $a3,$s2,$zero
    addu  $s0,$v0,$zero
    j  .L8004A5D0
    nop
jlabel .L8004B0C8
    addu  $a0,$s7,$zero
    addu  $a1,$s2,$zero
    jal  func_8004C404
    addu  $a2,$s6,$zero
    addu  $s7,$v0,$zero
    j  .L8004A5D0
    nop
jlabel .L8004B0E4
    lui  $v0,%hi(D_800A3708)
    lw  $v0,%lo(D_800A3708)($v0)
    lw  $t0,44($s2)
    lw  $t1,48($s2)
    lw  $t2,52($s2)
    lw  $t3,44($v0)
    lw  $t4,48($v0)
    lw  $t5,52($v0)
    subu  $t0,$t0,$t3
    subu  $t1,$t1,$t4
    subu  $t2,$t2,$t5
    slt  $t6,$t0,$zero
    neg  $t6,$t6
    xor  $t3,$t0,$t6
    sub  $t3,$t3,$t6
    slt  $t6,$t1,$zero
    neg  $t6,$t6
    xor  $t4,$t1,$t6
    sub  $t4,$t4,$t6
    slt  $t6,$t2,$zero
    neg  $t6,$t6
    xor  $t5,$t2,$t6
    sub  $t5,$t5,$t6
    or  $t3,$t3,$t4
    or  $t3,$t3,$t5
    addiu  $s5,$zero,2
    slti  $t4,$t3,18944
    ori  $at,$zero,42240
    slt  $t5,$t3,$at
    sub  $s5,$s5,$t4
    sub  $s5,$s5,$t5
    nop
    lh  $t0,10($s2)
    lui  $t2,%hi(D_800F62E0)
    addiu  $t2,$t2,%lo(D_800F62E0)
    sll  $t1,$t0,1
    add  $t1,$t1,$t0
    sll  $t1,$t1,5
    addu  $s3,$t1,$t2
    addiu  $a0,$s3,24
    addiu  $a1,$s2,24
    jal  func_80052930
    addiu  $a2,$s1,72
    lw  $t0,72($s1)
    lw  $t1,76($s1)
    lw  $t2,80($s1)
    lw  $t3,84($s1)
    lw  $t4,88($s1)
    ctc2  $t0,$8
    ctc2  $t1,$9
    ctc2  $t2,$10
    ctc2  $t3,$11
    ctc2  $t4,$12
    lw  $t0,56($s3)
    lw  $t1,60($s3)
    lw  $t2,64($s3)
    lw  $t3,68($s3)
    lw  $t4,72($s3)
    ctc2  $t0,$16
    ctc2  $t1,$17
    ctc2  $t2,$18
    ctc2  $t3,$19
    ctc2  $t4,$20
    lw  $a0,88($s3)
    addiu  $t1,$zero,4080
    srl  $a1,$a0,4
    srl  $a2,$a0,12
    sll  $a0,$a0,4
    and  $a0,$a0,$t1
    and  $a1,$a1,$t1
    and  $a2,$a2,$t1
    ctc2  $a0,$13
    ctc2  $a1,$14
    ctc2  $a2,$15
    lhu  $t2,4($s6)
    lh  $t3,6($s6)
    lh  $t4,8($s6)
    lh  $t5,10($s6)
    sra  $t3,$t3,1
    sra  $t4,$t4,1
    sra  $t5,$t5,1
    lw  $t0,0($s6)
    sll  $t3,$t3,16
    andi  $t4,$t4,65535
    sll  $t5,$t5,16
    or  $t2,$t2,$t3
    or  $t4,$t4,$t5
    lw  $t6,12($s6)
    lw  $t8,16($s6)
    ctc2  $t0,$0
    ctc2  $t2,$1
    ctc2  $t4,$2
    ctc2  $t6,$3
    ctc2  $t8,$4
    ctc2  $zero,$5
    ctc2  $zero,$6
    ctc2  $zero,$7
    addu  $a1,$s5,$zero
    jal  func_8004DA74
    addu  $a0,$s2,$zero
    j  .L8004A5D0
    nop
jlabel .L8004B27C
    lui  $v0,%hi(D_800FF558)
    addiu  $v0,$v0,%lo(D_800FF558)
    lw  $t0,44($s2)
    lw  $t1,48($s2)
    lw  $t2,52($s2)
    lw  $t3,20($v0)
    lw  $t4,24($v0)
    lw  $t5,28($v0)
    subu  $t0,$t0,$t3
    subu  $t1,$t1,$t4
    subu  $t2,$t2,$t5
    slt  $t6,$t0,$zero
    neg  $t6,$t6
    xor  $t3,$t0,$t6
    sub  $t3,$t3,$t6
    slt  $t6,$t1,$zero
    neg  $t6,$t6
    xor  $t4,$t1,$t6
    sub  $t4,$t4,$t6
    slt  $t6,$t2,$zero
    neg  $t6,$t6
    xor  $t5,$t2,$t6
    sub  $t5,$t5,$t6
    or  $t3,$t3,$t4
    or  $t3,$t3,$t5
    addiu  $s5,$zero,2
    slti  $t4,$t3,18944
    ori  $at,$zero,42240
    slt  $t5,$t3,$at
    sub  $s5,$s5,$t4
    sub  $s5,$s5,$t5
    nop
    addiu  $s5,$zero,1
    srav  $t0,$t0,$s5
    sh  $t0,32($s1)
    srav  $t1,$t1,$s5
    sh  $t1,34($s1)
    srav  $t2,$t2,$s5
    sh  $t2,36($s1)
    lh  $t0,10($s2)
    lui  $t2,%hi(D_800F62E0)
    addiu  $t2,$t2,%lo(D_800F62E0)
    sll  $t1,$t0,1
    add  $t1,$t1,$t0
    sll  $t1,$t1,5
    addu  $s3,$t1,$t2
    addiu  $a0,$s3,24
    addiu  $a1,$s2,24
    jal  func_80052930
    addiu  $a2,$s1,72
    lw  $t0,72($s1)
    lw  $t1,76($s1)
    lw  $t2,80($s1)
    lw  $t3,84($s1)
    lw  $t4,88($s1)
    ctc2  $t0,$8
    ctc2  $t1,$9
    ctc2  $t2,$10
    ctc2  $t3,$11
    ctc2  $t4,$12
    lw  $t0,56($s3)
    lw  $t1,60($s3)
    lw  $t2,64($s3)
    lw  $t3,68($s3)
    lw  $t4,72($s3)
    ctc2  $t0,$16
    ctc2  $t1,$17
    ctc2  $t2,$18
    ctc2  $t3,$19
    ctc2  $t4,$20
    lui  $a0,%hi(D_800FF558)
    addiu  $a0,$a0,%lo(D_800FF558)
    addiu  $a1,$s2,24
    jal  func_80052930
    addiu  $a2,$s1,40
    lui  $v0,%hi(D_800FF558)
    addiu  $v0,$v0,%lo(D_800FF558)
    nop
    lw  $t0,0($v0)
    lw  $t1,4($v0)
    lw  $t2,8($v0)
    lw  $t3,12($v0)
    lw  $t4,16($v0)
    ctc2  $t0,$0
    ctc2  $t1,$1
    ctc2  $t2,$2
    ctc2  $t3,$3
    ctc2  $t4,$4
    ctc2  $zero,$5
    ctc2  $zero,$6
    ctc2  $zero,$7
    lwc2  $0,32($s1)
    lwc2  $1,36($s1)
    lw  $a0,88($s3)
    addiu  $t1,$zero,4080
    mvmva  1,0,0,0,0
    srl  $a1,$a0,4
    srl  $a2,$a0,12
    sll  $a0,$a0,4
    and  $a0,$a0,$t1
    and  $a1,$a1,$t1
    and  $a2,$a2,$t1
    ctc2  $a0,$13
    ctc2  $a1,$14
    ctc2  $a2,$15
    mfc2  $t0,$9
    mfc2  $t1,$10
    mfc2  $t2,$11
    sra  $t1,$t1,1
    ctc2  $t0,$5
    ctc2  $t1,$6
    ctc2  $t2,$7
    lh  $t0,40($s1)
    lh  $t1,42($s1)
    lh  $t2,44($s1)
    lh  $t3,46($s1)
    lh  $t4,48($s1)
    lh  $t5,50($s1)
    lh  $t6,52($s1)
    lh  $t7,54($s1)
    lh  $t8,56($s1)
    srav  $t0,$t0,$s5
    srav  $t1,$t1,$s5
    srav  $t2,$t2,$s5
    addi  $s5,$s5,1
    srav  $t3,$t3,$s5
    srav  $t4,$t4,$s5
    srav  $t5,$t5,$s5
    addi  $s5,$s5,-1
    srav  $t6,$t6,$s5
    srav  $t7,$t7,$s5
    srav  $t8,$t8,$s5
    andi  $t0,$t0,65535
    sll  $t1,$t1,16
    andi  $t2,$t2,65535
    sll  $t3,$t3,16
    andi  $t4,$t4,65535
    sll  $t5,$t5,16
    andi  $t6,$t6,65535
    sll  $t7,$t7,16
    or  $t0,$t0,$t1
    or  $t2,$t2,$t3
    or  $t4,$t4,$t5
    or  $t6,$t6,$t7
    ctc2  $t0,$0
    ctc2  $t2,$1
    ctc2  $t4,$2
    ctc2  $t6,$3
    ctc2  $t8,$4
    j  .L8004A560
    nop
jlabel .L8004B4D8
    lui  $v0,%hi(D_800A3708)
    lw  $v0,%lo(D_800A3708)($v0)
    lw  $t0,44($s2)
    lw  $t1,48($s2)
    lw  $t2,52($s2)
    lw  $t3,44($v0)
    lw  $t4,48($v0)
    lw  $t5,52($v0)
    subu  $t0,$t0,$t3
    subu  $t1,$t1,$t4
    subu  $t2,$t2,$t5
    lui  $s5,%hi(g_game_p2_ctrl)
    lh  $s5,%lo(g_game_p2_ctrl)($s5)
    nop
    srav  $t0,$t0,$s5
    sh  $t0,32($s1)
    srav  $t1,$t1,$s5
    sh  $t1,34($s1)
    srav  $t2,$t2,$s5
    sh  $t2,36($s1)
    lw  $t0,0($s6)
    lw  $t1,4($s6)
    lw  $t2,8($s6)
    lw  $t3,12($s6)
    lw  $t4,16($s6)
    ctc2  $t0,$0
    ctc2  $t1,$1
    ctc2  $t2,$2
    ctc2  $t3,$3
    ctc2  $t4,$4
    ctc2  $zero,$5
    ctc2  $zero,$6
    ctc2  $zero,$7
    lwc2  $0,32($s1)
    lwc2  $1,36($s1)
    lh  $t0,10($s2)
    nop
    mvmva  1,0,0,0,0
    sll  $t1,$t0,1
    add  $t1,$t1,$t0
    sll  $t1,$t1,5
    lui  $t2,%hi(D_800F62E0)
    addiu  $t2,$t2,%lo(D_800F62E0)
    addu  $s3,$t1,$t2
    mfc2  $t0,$9
    mfc2  $t1,$10
    mfc2  $t2,$11
    sra  $t1,$t1,1
    ctc2  $t0,$5
    ctc2  $t1,$6
    ctc2  $t2,$7
    lw  $t0,24($s3)
    lw  $t1,28($s3)
    lw  $t2,32($s3)
    lw  $t3,36($s3)
    lw  $t4,40($s3)
    ctc2  $t0,$8
    ctc2  $t1,$9
    ctc2  $t2,$10
    ctc2  $t3,$11
    ctc2  $t4,$12
    lw  $t0,56($s3)
    lw  $t1,60($s3)
    lw  $t2,64($s3)
    lw  $t3,68($s3)
    lw  $t4,72($s3)
    ctc2  $t0,$16
    ctc2  $t1,$17
    ctc2  $t2,$18
    ctc2  $t3,$19
    ctc2  $t4,$20
    lw  $a0,88($s3)
    addiu  $t1,$zero,4080
    srl  $a1,$a0,4
    srl  $a2,$a0,12
    sll  $a0,$a0,4
    and  $a0,$a0,$t1
    and  $a1,$a1,$t1
    and  $a2,$a2,$t1
    ctc2  $a0,$13
    ctc2  $a1,$14
    ctc2  $a2,$15
    lh  $t0,0($s6)
    lh  $t1,2($s6)
    lh  $t2,4($s6)
    lh  $t3,6($s6)
    lh  $t4,8($s6)
    lh  $t5,10($s6)
    lh  $t6,12($s6)
    lh  $t7,14($s6)
    lh  $t8,16($s6)
    srav  $t0,$t0,$s5
    srav  $t1,$t1,$s5
    srav  $t2,$t2,$s5
    addi  $s5,$s5,1
    srav  $t3,$t3,$s5
    srav  $t4,$t4,$s5
    srav  $t5,$t5,$s5
    addi  $s5,$s5,-1
    srav  $t6,$t6,$s5
    srav  $t7,$t7,$s5
    srav  $t8,$t8,$s5
    sh  $t0,40($s1)
    sh  $t1,42($s1)
    sh  $t2,44($s1)
    sh  $t3,46($s1)
    sh  $t4,48($s1)
    sh  $t5,50($s1)
    sh  $t6,52($s1)
    sh  $t7,54($s1)
    sh  $t8,56($s1)
    lw  $t0,40($s1)
    lw  $t1,44($s1)
    lw  $t2,48($s1)
    lw  $t3,52($s1)
    lw  $t4,56($s1)
    ctc2  $t0,$0
    ctc2  $t1,$1
    ctc2  $t2,$2
    ctc2  $t3,$3
    ctc2  $t4,$4
    lui  $a1,%hi(g_game_timer)
    lw  $a1,%lo(g_game_timer)($a1)
    nop
    sw  $a1,448($s1)
    jal  func_80047BE0
    addu  $a0,$s2,$zero
    j  .L8004A5D0
    nop
    j  .L8004A560
    nop
    lui  $t0,8064
    sw  $ra,488($t0)
    sw  $fp,492($t0)
    sw  $s7,496($t0)
    sw  $s6,500($t0)
    sw  $s5,504($t0)
    sw  $s4,508($t0)
    sw  $s3,512($t0)
    sw  $s2,516($t0)
    sw  $s1,520($t0)
    sw  $s0,524($t0)
    addu  $s7,$t0,$zero
    sh  $a3,480($s7)
    sw  $a1,472($s7)
    addu  $s0,$a2,$zero
    lw  $s2,12($s7)
    lui  $s4,%hi(D_800A38B4)
    lw  $s4,%lo(D_800A38B4)($s4)
    addi  $s5,$s7,32
    addi  $s6,$s7,272
    addi  $s3,$s7,528
    lui  $fp,255
    ori  $fp,$fp,65535
    addi  $a0,$a0,-1
.L8004B744:
    lb  $t1,481($s7)
    lw  $t0,0($s0)
    andi  $t1,$t1,1
    sll  $t1,$t1,25
    or  $t0,$t0,$t1
    mtc2  $t0,$6
    lw  $v0,12($s0)
    sw  $a0,468($s7)
    sll  $t4,$v0,2
    andi  $t4,$t4,1020
    addu  $t0,$t4,$s5
    lw  $t0,0($t0)
    srl  $t5,$v0,6
    andi  $t5,$t5,1020
    addu  $t1,$t5,$s5
    lw  $t1,0($t1)
    srl  $t6,$v0,14
    andi  $t6,$t6,1020
    addu  $t2,$t6,$s5
    lw  $t2,0($t2)
    mtc2  $t0,$12
    mtc2  $t1,$13
    mtc2  $t2,$14
    and  $v1,$t0,$t1
    and  $v1,$v1,$t2
    nop
    nclip
    bltz  $v1,.L8004BB18
    nop
    andi  $v1,$v1,32768
    mfc2  $v0,$24
    bnez  $v1,.L8004BB18
    nop
    bgez  $v0,.L8004BB18
    neg  $v1,$v0
    sra  $a0,$t0,16
    addi  $a0,$a0,-240
    sra  $a1,$t1,16
    addi  $a1,$a1,-240
    or  $a0,$a0,$a1
    sra  $a1,$t2,16
    addi  $a1,$a1,-240
    or  $a0,$a0,$a1
    andi  $a0,$a0,32768
    beqz  $a0,.L8004BB18
    nop
    srl  $t4,$t4,1
    add  $a0,$t4,$s6
    lh  $a0,0($a0)
    srl  $t5,$t5,1
    add  $a1,$t5,$s6
    lh  $a1,0($a1)
    srl  $t6,$t6,1
    add  $a2,$t6,$s6
    lh  $a2,0($a2)
    slt  $v0,$a0,$a1
    beqz  $v0,.L8004B834
    slt  $v0,$a0,$a2
    addu  $a0,$a1,$zero
    slt  $v0,$a0,$a2
.L8004B834:
    beqz  $v0,.L8004B840
    nop
    addu  $a0,$a2,$zero
.L8004B840:
    addu  $v0,$a0,$zero
    addu  $a3,$v0,$zero
    lh  $t8,454($s7)
    lw  $a2,24($s7)
    lw  $a1,16($s7)
    srlv  $v0,$v0,$t8
    srl  $t8,$v0,11
    andi  $v0,$v0,2047
    addi  $v0,$v0,-4096
    srav  $v0,$v0,$t8
    andi  $v0,$v0,4095
    slt  $at,$a1,$v0
    bnez  $at,.L8004BB18
    nop
    slt  $at,$v0,$a2
    bnez  $at,.L8004BB18
    nop
    lwc2  $0,16($s0)
    lwc2  $1,20($s0)
    lh  $a0,4($s0)
    lh  $a1,0($s0)
    sh  $a0,460($s7)
    sh  $a1,462($s7)
    ncs
    slti  $a0,$v1,512
    slti  $v1,$v1,768
    add  $v1,$a0,$v1
    lw  $a1,448($s7)
    nop
    andi  $a1,$a1,3
    beqz  $a1,.L8004B900
    addu  $a0,$zero,$zero
    addi  $a2,$a1,-2
    beqz  $a2,.L8004B904
    nop
    lb  $a0,480($s7)
    nop
    addi  $a0,$a0,-2
    neg  $a0,$a0
    addi  $a2,$a1,-1
    beqz  $a2,.L8004B900
    nop
    lb  $a0,480($s7)
    nop
    slt  $a1,$a0,$v1
    neg  $a1,$a1
    sub  $a0,$v1,$a0
    and  $a0,$a0,$a1
.L8004B900:
    addu  $v1,$a0,$zero
.L8004B904:
    lhu  $a0,6($s0)
    lhu  $a1,8($s0)
    lhu  $a2,10($s0)
    beqz  $v1,.L8004B93C
    addiu  $t8,$zero,255
    srlv  $t8,$t8,$v1
    sll  $t9,$t8,8
    or  $t8,$t8,$t9
    srlv  $a0,$a0,$v1
    and  $a0,$a0,$t8
    srlv  $a1,$a1,$v1
    and  $a1,$a1,$t8
    srlv  $a2,$a2,$v1
    and  $a2,$a2,$t8
.L8004B93C:
    sh  $a0,482($s7)
    sh  $a1,484($s7)
    sh  $a2,486($s7)
    lbu  $t8,2($s0)
    lb  $a3,480($s7)
    srl  $t8,$t8,1
    andi  $t8,$t8,3
    beqz  $t8,.L8004B96C
    addi  $t8,$t8,-1
    sub  $a3,$a3,$t8
    bgtz  $a3,.L8004B9E8
    nop
.L8004B96C:
    lh  $t4,460($s7)
    lh  $t5,462($s7)
    sw  $t0,8($s4)
    sw  $t1,16($s4)
    sw  $t2,24($s4)
    sll  $t4,$t4,16
    sll  $t5,$t5,16
    lhu  $t0,482($s7)
    lhu  $t1,484($s7)
    lhu  $t2,486($s7)
    or  $t0,$t0,$t4
    or  $t1,$t1,$t5
    sw  $t0,12($s4)
    sw  $t1,20($s4)
    sh  $t2,28($s4)
    swc2  $22,4($s4)
    sll  $v0,$v0,2
    addu  $v0,$v0,$s2
    lw  $t1,0($v0)
    and  $t0,$s4,$fp
    sw  $t0,0($v0)
    lui  $t2,1792
    or  $t1,$t1,$t2
    sw  $t1,0($s4)
    lw  $a0,468($s7)
    addi  $s0,$s0,24
    addi  $s4,$s4,32
    bnez  $a0,.L8004B744
    addi  $a0,$a0,-1
    j  .L8004BB28
    nop
.L8004B9E8:
    lw  $a0,448($s7)
    nop
    andi  $a0,$a0,4
    beqz  $a0,.L8004BA48
    nop
    addu  $a0,$a3,$zero
    lw  $a1,0($s0)
    nop
    lui  $at,255
    ori  $at,$at,65535
    or  $a1,$a1,$at
    beqz  $a0,.L8004BA3C
    nop
    addiu  $at,$zero,-256
    and  $a1,$a1,$at
    addi  $a0,$a0,-1
    beqz  $a0,.L8004BA3C
    nop
    lui  $at,65535
    ori  $at,$at,16384
    and  $a1,$a1,$at
.L8004BA3C:
    mtc2  $a1,$22
    nop
    nop
.L8004BA48:
    sll  $v0,$v0,2
    addu  $v0,$v0,$s2
    lw  $s1,0($v0)
    sw  $v0,476($s7)
    lui  $t0,1792
    or  $s1,$s1,$t0
    lw  $a1,472($s7)
    swc2  $22,464($s7)
    add  $t0,$t4,$t4
    add  $t4,$t4,$t0
    add  $t4,$t4,$a1
    lh  $t0,0($t4)
    lh  $t1,2($t4)
    lh  $t2,4($t4)
    lh  $t3,482($s7)
    sh  $t0,8($s3)
    sh  $t1,10($s3)
    sh  $t2,12($s3)
    sh  $t3,14($s3)
    add  $t0,$t5,$t5
    add  $t5,$t5,$t0
    add  $t5,$t5,$a1
    lh  $t0,0($t5)
    lh  $t1,2($t5)
    lh  $t2,4($t5)
    lh  $t3,484($s7)
    sh  $t0,16($s3)
    sh  $t1,18($s3)
    sh  $t2,20($s3)
    sh  $t3,22($s3)
    add  $t0,$t6,$t6
    add  $t6,$t6,$t0
    add  $t6,$t6,$a1
    lh  $t0,0($t6)
    lh  $t1,2($t6)
    lh  $t2,4($t6)
    lh  $t3,486($s7)
    sh  $t0,24($s3)
    sh  $t1,26($s3)
    sh  $t2,28($s3)
    sh  $t3,30($s3)
    jal  func_8004BB68
    addu  $a0,$a3,$zero
    lw  $t0,476($s7)
    and  $t1,$s1,$fp
    sw  $t1,0($t0)
    lw  $a0,468($s7)
    addi  $s0,$s0,24
    bnez  $a0,.L8004B744
    addi  $a0,$a0,-1
    j  .L8004BB28
    nop
.L8004BB18:
    lw  $a0,468($s7)
    addi  $s0,$s0,24
    bnez  $a0,.L8004B744
    addi  $a0,$a0,-1
.L8004BB28:
    lui  $at,%hi(D_800A38B4)
    sw  $s4,%lo(D_800A38B4)($at)
    addu  $v0,$s0,$zero
    addu  $t0,$s7,$zero
    lw  $ra,488($t0)
    lw  $fp,492($t0)
    lw  $s7,496($t0)
    lw  $s6,500($t0)
    lw  $s5,504($t0)
    lw  $s4,508($t0)
    lw  $s3,512($t0)
    lw  $s2,516($t0)
    lw  $s1,520($t0)
    lw  $s0,524($t0)
    jr  $ra
    nop
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_8004BB68
    bnez   $a0,.L8004BBF0
    nop
    lwc2   $0,8($s3)
    lwc2   $1,12($s3)
    lwc2   $2,16($s3)
    lwc2   $3,20($s3)
    lwc2   $4,24($s3)
    lwc2   $5,28($s3)
    nop
    nop
    rtpt
    lhu   $t4,460($s7)
    lhu   $t5,462($s7)
    lhu   $t0,14($s3)
    lhu   $t1,22($s3)
    lhu   $t2,30($s3)
    sll   $t4,$t4,16
    sll   $t5,$t5,16
    or   $t0,$t0,$t4
    or   $t1,$t1,$t5
    sw   $t0,12($s4)
    sw   $t1,20($s4)
    sh   $t2,28($s4)
    swc2   $12,8($s4)
    swc2   $13,16($s4)
    swc2   $14,24($s4)
    lw   $t0,464($s7)
    sw   $s1,0($s4)
    sw   $t0,4($s4)
    lui   $t1,0x700
    and   $s1,$s4,$fp
    or   $s1,$s1,$t1
    jr   $ra
    addi   $s4,$s4,0x20
.L8004BBF0:
    addi   $s3,$s3,0x28
    addi   $a0,$a0,-0x1
    sw   $ra,0($s3)
    sh   $a0,4($s3)
    lw   $t0,-32($s3)
    lw   $t1,-28($s3)
    sw   $t0,8($s3)
    sw   $t1,12($s3)
    addi   $a0,$s3,-0x20
    addi   $a1,$s3,-0x18
    jal   func_8004C388
    addi   $a2,$s3,0x10
    addi   $a0,$s3,-0x20
    addi   $a1,$s3,-0x10
    jal   func_8004C388
    addi   $a2,$s3,0x18
    lh   $a0,4($s3)
    jal   func_8004BB68
    nop
    addi   $a0,$s3,-0x18
    addi   $a1,$s3,-0x10
    jal   func_8004C388
    addi   $a2,$s3,0x8
    lh   $a0,4($s3)
    jal   func_8004BB68
    nop
    lw   $t0,16($s3)
    lw   $t1,20($s3)
    sw   $t0,32($s3)
    sw   $t1,36($s3)
    lw   $t0,-16($s3)
    lw   $t1,-12($s3)
    sw   $t0,16($s3)
    sw   $t1,20($s3)
    lh   $a0,4($s3)
    jal   func_8004BB68
    nop
    lw   $t0,32($s3)
    lw   $t1,36($s3)
    sw   $t0,16($s3)
    sw   $t1,20($s3)
    lw   $t0,-24($s3)
    lw   $t1,-20($s3)
    sw   $t0,24($s3)
    sw   $t1,28($s3)
    lh   $a0,4($s3)
    jal   func_8004BB68
    nop
    lw   $ra,0($s3)
    nop
    jr   $ra
    addi   $s3,$s3,-0x28
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel saTan2LineDraw
    lui   $t0,0x1F80
    sw   $ra,492($t0)
    sw   $fp,496($t0)
    sw   $s7,500($t0)
    sw   $s6,504($t0)
    sw   $s5,508($t0)
    sw   $s4,512($t0)
    sw   $s3,516($t0)
    sw   $s2,520($t0)
    sw   $s1,524($t0)
    sw   $s0,528($t0)
    addu   $s7,$t0,$zero
    sh   $a3,480($s7)
    sw   $a1,472($s7)
    addu   $s0,$a2,$zero
    lw   $s2,12($s7)
    lui   $s4,%hi(D_800A38B4)
    lw   $s4,%lo(D_800A38B4)($s4)
    addi   $s5,$s7,32
    addi   $s6,$s7,272
    addi   $s3,$s7,532
    lui   $fp,0xFF
    ori   $fp,$fp,65535
    addi   $a0,$a0,-0x1
.L8004BD20:
    lb   $t1,481($s7)
    lw   $t0,0($s0)
    andi   $t1,$t1,0x1
    sll   $t1,$t1,25
    or   $t0,$t0,$t1
    mtc2   $t0,$6
    srl   $t0,$t0,16
    sh   $t0,452($s7)
    lhu   $v1,16($s0)
    lhu   $v0,14($s0)
    sll   $v1,$v1,16
    or   $v0,$v0,$v1
    sw   $a0,468($s7)
    sll   $t4,$v0,2
    andi   $t4,$t4,0x3FC
    addu   $t0,$t4,$s5
    lw   $t0,0($t0)
    srl   $t5,$v0,6
    andi   $t5,$t5,0x3FC
    addu   $t1,$t5,$s5
    lw   $t1,0($t1)
    srl   $t6,$v0,14
    andi   $t6,$t6,0x3FC
    addu   $t2,$t6,$s5
    lw   $t2,0($t2)
    srl   $t7,$v0,22
    andi   $t7,$t7,0x3FC
    addu   $t3,$t7,$s5
    lw   $t3,0($t3)
    mtc2   $t0,$12
    mtc2   $t1,$13
    mtc2   $t2,$14
    and   $v1,$t0,$t1
    and   $v1,$v1,$t2
    and   $v1,$v1,$t3
    nclip
    bltz   $v1,.L8004C1A4
    nop
    andi   $v1,$v1,0x8000
    mfc2   $v0,$24
    bnez   $v1,.L8004C1A4
    nop
    bgez   $v0,.L8004C1A4
    neg   $v1,$v0
    sra   $a0,$t0,16
    addi   $a0,$a0,-0xF0
    sra   $a1,$t1,16
    addi   $a1,$a1,-0xF0
    or   $a0,$a0,$a1
    sra   $a1,$t2,16
    addi   $a1,$a1,-0xF0
    or   $a0,$a0,$a1
    sra   $a1,$t3,16
    addi   $a1,$a1,-0xF0
    or   $a0,$a0,$a1
    andi   $a0,$a0,0x8000
    beqz   $a0,.L8004C1A4
    nop
    srl   $t4,$t4,1
    add   $a0,$t4,$s6
    lh   $a0,0($a0)
    srl   $t5,$t5,1
    add   $a1,$t5,$s6
    lh   $a1,0($a1)
    srl   $t6,$t6,1
    add   $a2,$t6,$s6
    lh   $a2,0($a2)
    srl   $t7,$t7,1
    add   $a3,$t7,$s6
    lh   $a3,0($a3)
    slt   $v0,$a0,$a1
    beqz   $v0,.L8004BE4C
    slt   $v0,$a0,$a2
    addu   $a0,$a1,$zero
    slt   $v0,$a0,$a2
.L8004BE4C:
    beqz   $v0,.L8004BE5C
    slt   $v0,$a0,$a3
    addu   $a0,$a2,$zero
    slt   $v0,$a0,$a3
.L8004BE5C:
    beqz   $v0,.L8004BE68
    nop
    addu   $a0,$a3,$zero
.L8004BE68:
    addu   $v0,$a0,$zero
    addu   $a3,$v0,$zero
    lbu   $t8,2($s0)
    nop
    andi   $t8,$t8,0x1
    beqz   $t8,.L8004BE88
    nop
    addi   $v0,$v0,0x3E8
.L8004BE88:
    lh   $t8,454($s7)
    lw   $a1,16($s7)
    lw   $a2,24($s7)
    srlv   $v0,$v0,$t8
    srl   $t8,$v0,11
    andi   $v0,$v0,0x7FF
    addi   $v0,$v0,-0x1000
    srav   $v0,$v0,$t8
    andi   $v0,$v0,0xFFF
    slt   $at,$a1,$v0
    bnez   $at,.L8004C1A4
    nop
    slt   $at,$v0,$a2
    bnez   $at,.L8004C1A4
    nop
    lhu   $a1,18($s0)
    lwc2   $0,20($s0)
    mtc2   $a1,$1
    lh   $a0,4($s0)
    lh   $a1,0($s0)
    sh   $a0,460($s7)
    sh   $a1,462($s7)
    ncs
    slti   $a0,$v1,0x400
    slti   $v1,$v1,0x700
    add   $v1,$a0,$v1
    lw   $a1,448($s7)
    nop
    andi   $a1,$a1,0x3
    beqz   $a1,.L8004BF44
    addu   $a0,$zero,$zero
    addi   $a2,$a1,-0x2
    beqz   $a2,.L8004BF48
    nop
    lb   $a0,480($s7)
    nop
    addi   $a0,$a0,-0x2
    neg   $a0,$a0
    addi   $a2,$a1,-0x1
    beqz   $a2,.L8004BF44
    nop
    lb   $a0,480($s7)
    nop
    slt   $a1,$a0,$v1
    neg   $a1,$a1
    sub   $a0,$v1,$a0
    and   $a0,$a0,$a1
.L8004BF44:
    addu   $v1,$a0,$zero
.L8004BF48:
    lhu   $a0,6($s0)
    lhu   $a1,8($s0)
    lhu   $a2,10($s0)
    lhu   $a3,12($s0)
    beqz   $v1,.L8004BF8C
    addiu   $t8,$zero,0xFF
    srlv   $t8,$t8,$v1
    sll   $t9,$t8,8
    or   $t8,$t8,$t9
    srlv   $a0,$a0,$v1
    and   $a0,$a0,$t8
    srlv   $a1,$a1,$v1
    and   $a1,$a1,$t8
    srlv   $a2,$a2,$v1
    and   $a2,$a2,$t8
    srlv   $a3,$a3,$v1
    and   $a3,$a3,$t8
.L8004BF8C:
    sh   $a0,482($s7)
    sh   $a1,484($s7)
    sh   $a2,486($s7)
    sh   $a3,488($s7)
    lbu   $t8,2($s0)
    lb   $a3,480($s7)
    srl   $t8,$t8,1
    andi   $t8,$t8,0x3
    beqz   $t8,.L8004BFC0
    addi   $t8,$t8,-0x1
    sub   $a3,$a3,$t8
    bgtz   $a3,.L8004C048
    nop
.L8004BFC0:
    lh   $t4,460($s7)
    lh   $t5,462($s7)
    sw   $t0,8($s4)
    sw   $t1,16($s4)
    sw   $t2,24($s4)
    sw   $t3,32($s4)
    sll   $t4,$t4,16
    sll   $t5,$t5,16
    lhu   $t0,482($s7)
    lhu   $t1,484($s7)
    lhu   $t2,486($s7)
    lhu   $t3,488($s7)
    or   $t0,$t0,$t4
    or   $t1,$t1,$t5
    sw   $t0,12($s4)
    sw   $t1,20($s4)
    sh   $t2,28($s4)
    sh   $t3,36($s4)
    swc2   $22,4($s4)
    sll   $v0,$v0,2
    addu   $v0,$v0,$s2
    lw   $t1,0($v0)
    and   $t0,$s4,$fp
    sw   $t0,0($v0)
    lui   $t2,0x900
    or   $t1,$t1,$t2
    sw   $t1,0($s4)
    lw   $a0,468($s7)
    addi   $s0,$s0,0x18
    addi   $s4,$s4,0x28
    bnez   $a0,.L8004BD20
    addi   $a0,$a0,-0x1
    j   .L8004C1B4
    nop
.L8004C048:
    lw   $a0,448($s7)
    nop
    andi   $a0,$a0,0x4
    beqz   $a0,.L8004C0A8
    nop
    addu   $a0,$a3,$zero
    lw   $a1,0($s0)
    nop
    lui   $at,0xFF
    ori   $at,$at,65535
    or   $a1,$a1,$at
    beqz   $a0,.L8004C09C
    nop
    addiu   $at,$zero,-0x100
    and   $a1,$a1,$at
    addi   $a0,$a0,-0x1
    beqz   $a0,.L8004C09C
    nop
    lui   $at,0xFFFF
    ori   $at,$at,16384
    and   $a1,$a1,$at
.L8004C09C:
    mtc2   $a1,$22
    nop
    nop
.L8004C0A8:
    sll   $v0,$v0,2
    addu   $v0,$v0,$s2
    lw   $s1,0($v0)
    sw   $v0,476($s7)
    lui   $t0,0x900
    or   $s1,$s1,$t0
    lw   $a1,472($s7)
    swc2   $22,464($s7)
    add   $t0,$t4,$t4
    add   $t4,$t4,$t0
    add   $t4,$t4,$a1
    lh   $t0,0($t4)
    lh   $t1,2($t4)
    lh   $t2,4($t4)
    lh   $t3,482($s7)
    sh   $t0,8($s3)
    sh   $t1,10($s3)
    sh   $t2,12($s3)
    sh   $t3,14($s3)
    add   $t0,$t5,$t5
    add   $t5,$t5,$t0
    add   $t5,$t5,$a1
    lh   $t0,0($t5)
    lh   $t1,2($t5)
    lh   $t2,4($t5)
    lh   $t3,484($s7)
    sh   $t0,16($s3)
    sh   $t1,18($s3)
    sh   $t2,20($s3)
    sh   $t3,22($s3)
    add   $t0,$t6,$t6
    add   $t6,$t6,$t0
    add   $t6,$t6,$a1
    lh   $t0,0($t6)
    lh   $t1,2($t6)
    lh   $t2,4($t6)
    lh   $t3,486($s7)
    sh   $t0,24($s3)
    sh   $t1,26($s3)
    sh   $t2,28($s3)
    sh   $t3,30($s3)
    add   $t0,$t7,$t7
    add   $t7,$t7,$t0
    add   $t7,$t7,$a1
    lh   $t0,0($t7)
    lh   $t1,2($t7)
    lh   $t2,4($t7)
    lh   $t3,488($s7)
    sh   $t0,32($s3)
    sh   $t1,34($s3)
    sh   $t2,36($s3)
    sh   $t3,38($s3)
    jal   func_8004C1F4
    addu   $a0,$a3,$zero
    lw   $t0,476($s7)
    and   $t1,$s1,$fp
    sw   $t1,0($t0)
    lw   $a0,468($s7)
    addi   $s0,$s0,0x18
    bnez   $a0,.L8004BD20
    addi   $a0,$a0,-0x1
    j   .L8004C1B4
    nop
.L8004C1A4:
    lw   $a0,468($s7)
    addi   $s0,$s0,0x18
    bnez   $a0,.L8004BD20
    addi   $a0,$a0,-0x1
.L8004C1B4:
    lui   $at,%hi(D_800A38B4)
    sw   $s4,%lo(D_800A38B4)($at)
    addu   $v0,$s0,$zero
    addu   $t0,$s7,$zero
    lw   $ra,492($t0)
    lw   $fp,496($t0)
    lw   $s7,500($t0)
    lw   $s6,504($t0)
    lw   $s5,508($t0)
    lw   $s4,512($t0)
    lw   $s3,516($t0)
    lw   $s2,520($t0)
    lw   $s1,524($t0)
    lw   $s0,528($t0)
    jr   $ra
    nop
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_8004C1F4
    bnez   $a0,.L8004C298
    nop
    lwc2   $0,8($s3)
    lwc2   $1,12($s3)
    lwc2   $2,16($s3)
    lwc2   $3,20($s3)
    lwc2   $4,24($s3)
    lwc2   $5,28($s3)
    nop
    nop
    rtpt
    lhu   $t4,460($s7)
    lhu   $t5,462($s7)
    lhu   $t0,14($s3)
    lhu   $t1,22($s3)
    lhu   $t2,30($s3)
    lhu   $t3,38($s3)
    sll   $t4,$t4,16
    sll   $t5,$t5,16
    or   $t0,$t0,$t4
    or   $t1,$t1,$t5
    sw   $t0,12($s4)
    sw   $t1,20($s4)
    sh   $t2,28($s4)
    sh   $t3,36($s4)
    swc2   $12,8($s4)
    swc2   $13,16($s4)
    swc2   $14,24($s4)
    lwc2   $0,32($s3)
    lwc2   $1,36($s3)
    lw   $t0,464($s7)
    nop
    rtps
    sw   $t0,4($s4)
    sw   $s1,0($s4)
    swc2   $14,32($s4)
    lui   $t1,0x900
    and   $s1,$s4,$fp
    or   $s1,$s1,$t1
    jr   $ra
    addi   $s4,$s4,0x28
.L8004C298:
    addi   $s3,$s3,0x28
    addi   $a0,$a0,-0x1
    sw   $ra,0($s3)
    sh   $a0,4($s3)
    lw   $t0,-32($s3)
    lw   $t1,-28($s3)
    sw   $t0,8($s3)
    sw   $t1,12($s3)
    addi   $a0,$s3,-0x20
    addi   $a1,$s3,-0x18
    jal   func_8004C388
    addi   $a2,$s3,0x10
    addi   $a0,$s3,-0x20
    addi   $a1,$s3,-0x10
    jal   func_8004C388
    addi   $a2,$s3,0x18
    addi   $a0,$s3,-0x20
    addi   $a1,$s3,-0x8
    jal   func_8004C388
    addi   $a2,$s3,0x20
    lh   $a0,4($s3)
    jal   func_8004C1F4
    nop
    lw   $t0,-24($s3)
    lw   $t1,-20($s3)
    sw   $t0,8($s3)
    sw   $t1,12($s3)
    addi   $a0,$s3,-0x18
    addi   $a1,$s3,-0x8
    jal   func_8004C388
    addi   $a2,$s3,0x18
    lh   $a0,4($s3)
    jal   func_8004C1F4
    nop
    lw   $t0,-8($s3)
    lw   $t1,-4($s3)
    sw   $t0,8($s3)
    sw   $t1,12($s3)
    addi   $a0,$s3,-0x10
    addi   $a1,$s3,-0x8
    jal   func_8004C388
    addi   $a2,$s3,0x10
    lh   $a0,4($s3)
    jal   func_8004C1F4
    nop
    lw   $t0,-16($s3)
    lw   $t1,-12($s3)
    sw   $t0,8($s3)
    sw   $t1,12($s3)
    addi   $a0,$s3,-0x20
    addi   $a1,$s3,-0x10
    jal   func_8004C388
    addi   $a2,$s3,0x18
    lh   $a0,4($s3)
    jal   func_8004C1F4
    nop
    lw   $ra,0($s3)
    nop
    jr   $ra
    addi   $s3,$s3,-0x28
.set	reorder
.set	at
.set reorder
.set at

 #NO_APP
	.align	2
	.globl	func_8004C388
	.ent	func_8004C388
func_8004C388:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lh	$8,0($4)
	lh	$9,2($4)
	lh	$10,4($4)
	lh	$11,0($5)
	lh	$12,2($5)
	lh	$13,4($5)
 #APP
	add $8, $8, $11
	add $9, $9, $12
	add $10, $10, $13
 #NO_APP
	sra	$8,$8,1
	sra	$9,$9,1
	sra	$10,$10,1
	sh	$8,0($6)
	sh	$9,2($6)
	sh	$10,4($6)
	lhu	$11,6($4)
	lhu	$12,6($5)
	andi	$8,$11,0xff00
	andi	$9,$12,0xff00
	andi	$11,$11,0x00ff
	andi	$12,$12,0x00ff
 #APP
	add $11, $11, $12
	add $8, $8, $9
 #NO_APP
	srl	$11,$11,1
	srl	$8,$8,1
	andi	$11,$11,0x00ff
	andi	$8,$8,0xff00
	or	$11,$11,$8
	.set	noreorder
	.set	nomacro
	j	$31
	sh	$11,6($6)
	.set	macro
	.set	reorder

	.end	func_8004C388
 #APP
	.section .text
    nop

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_8004C404
    addiu   $sp,$sp,-0x38
    sw   $ra,48($sp)
    sw   $fp,44($sp)
    sw   $s7,40($sp)
    sw   $s6,36($sp)
    sw   $s5,32($sp)
    sw   $s4,28($sp)
    sw   $s3,24($sp)
    sw   $s2,20($sp)
    sw   $s1,16($sp)
    addu   $s2,$a0,$zero
    addu   $s1,$a1,$zero
    lui   $s3,0x1F80
    lui   $s4,%hi(g_game_p2_ctrl)
    lh   $s4,%lo(g_game_p2_ctrl)($s4)
    addiu   $t0,$zero,0x3
    sub   $t0,$t0,$s4
    sh   $t0,454($s3)
    lui   $t1,%hi(D_80103624)
    lw   $t1,%lo(D_80103624)($t1)
    nop
    sw   $t1,456($s3)
    lui   $a0,%hi(g_game_timer)
    lw   $a0,%lo(g_game_timer)($a0)
    nop
    sw   $a0,448($s3)
    lw   $t0,0($a2)
    lw   $t1,4($a2)
    lw   $t2,8($a2)
    lw   $t3,12($a2)
    lh   $t4,16($a2)
    sw   $t0,392($s3)
    sw   $t1,396($s3)
    sw   $t2,400($s3)
    sw   $t3,404($s3)
    sh   $t4,408($s3)
    addi   $s4,$s4,0x10
    srav   $t0,$t0,$s4
    srav   $t1,$t1,$s4
    srav   $t2,$t2,$s4
    srav   $t3,$t3,$s4
    addi   $s4,$s4,-0x10
    lh   $t5,392($s3)
    lh   $t6,396($s3)
    lh   $t7,400($s3)
    lh   $t8,404($s3)
    srav   $t4,$t4,$s4
    srav   $t5,$t5,$s4
    srav   $t6,$t6,$s4
    srav   $t7,$t7,$s4
    srav   $t8,$t8,$s4
    sra   $t1,$t1,1
    sra   $t7,$t7,1
    sra   $t2,$t2,1
    sh   $t5,412($s3)
    sh   $t0,414($s3)
    sh   $t6,416($s3)
    sh   $t1,418($s3)
    sh   $t7,420($s3)
    sh   $t2,422($s3)
    sh   $t8,424($s3)
    sh   $t3,426($s3)
    sh   $t4,428($s3)
    lui   $t0,%hi(D_800A3708)
    lw   $t0,%lo(D_800A3708)($t0)
    nop
    lw   $t1,44($t0)
    lw   $t2,48($t0)
    lw   $t3,52($t0)
    sw   $t1,436($s3)
    sw   $t2,440($s3)
    sw   $t3,444($s3)
    addiu   $t0,$zero,0x4
    lui   $t2,%hi(D_800F62E0)
    addiu   $t2,$t2,%lo(D_800F62E0)
    sll   $t1,$t0,1
    add   $t1,$t1,$t0
    sll   $t1,$t1,5
    addu   $t0,$t1,$t2
    lw   $t1,24($t0)
    lw   $t2,28($t0)
    lw   $t3,32($t0)
    lw   $t4,36($t0)
    lw   $t5,40($t0)
    ctc2   $t1,$8
    ctc2   $t2,$9
    ctc2   $t3,$10
    ctc2   $t4,$11
    ctc2   $t5,$12
    lw   $t6,88($t0)
    lw   $t1,56($t0)
    lw   $t2,60($t0)
    lw   $t3,64($t0)
    lw   $t4,68($t0)
    lw   $t5,72($t0)
    ctc2   $t1,$16
    ctc2   $t2,$17
    ctc2   $t3,$18
    ctc2   $t4,$19
    ctc2   $t5,$20
    addiu   $t0,$zero,0xFF0
    sll   $t1,$t6,4
    srl   $t2,$t6,4
    srl   $t3,$t6,12
    and   $t1,$t1,$t0
    and   $t2,$t2,$t0
    and   $t3,$t3,$t0
    ctc2   $t1,$13
    ctc2   $t2,$14
    ctc2   $t3,$15
.L8004C5BC:
    lw   $t0,436($s3)
    lw   $t1,440($s3)
    lw   $t2,444($s3)
    lw   $t3,8($s1)
    addu   $t4,$zero,$zero
    lw   $t5,12($s1)
    sub   $t3,$t3,$t0
    sub   $t4,$t4,$t1
    sub   $t5,$t5,$t2
    srav   $t3,$t3,$s4
    srav   $t4,$t4,$s4
    srav   $t5,$t5,$s4
    andi   $t3,$t3,0xFFFF
    sll   $t4,$t4,16
    or   $t3,$t3,$t4
    mtc2   $t3,$0
    mtc2   $t5,$1
    lw   $t0,392($s3)
    lw   $t1,396($s3)
    lw   $t2,400($s3)
    lw   $t3,404($s3)
    lw   $t4,408($s3)
    ctc2   $t0,$0
    ctc2   $t1,$1
    ctc2   $t2,$2
    ctc2   $t3,$3
    ctc2   $t4,$4
    ctc2   $zero,$5
    ctc2   $zero,$6
    ctc2   $zero,$7
    nop
    nop
    mvmva   1,0,0,0,0
    nop
    nop
    mfc2   $t0,$9
    mfc2   $t1,$10
    mfc2   $t2,$11
    sra   $t1,$t1,1
    ctc2   $t0,$5
    ctc2   $t1,$6
    ctc2   $t2,$7
    lw   $t0,412($s3)
    lw   $t1,416($s3)
    lw   $t2,420($s3)
    lw   $t3,424($s3)
    lw   $t4,428($s3)
    ctc2   $t0,$0
    ctc2   $t1,$1
    ctc2   $t2,$2
    ctc2   $t3,$3
    ctc2   $t4,$4
    lh   $t0,2($s1)
    lh   $t1,4($s1)
    sll   $t0,$t0,2
    lui   $t2,%hi(D_80103608)
    addiu   $t2,$t2,%lo(D_80103608)
    addu   $t0,$t0,$t2
    lw   $t0,0($t0)
    sll   $t1,$t1,2
    addu   $t0,$t0,$t1
    lw   $s0,0($t0)
    lh   $s7,6($s1)
    nop
    lw   $a1,0($s0)
    nop
    andi   $a0,$a1,0xFFFF
    srl   $a1,$a1,16
    beqz   $a0,.L8004C930
    addi   $s0,$s0,0x4
    sw   $s0,432($s3)
    addiu   $t0,$zero,0x4
    bne   $t0,$a0,.L8004C7A8
    nop
    lhu   $t6,0($s0)
    lhu   $t7,2($s0)
    lhu   $t8,4($s0)
    sll   $t7,$t7,16
    or   $t6,$t6,$t7
    mtc2   $t6,$0
    mtc2   $t8,$1
    lhu   $t6,6($s0)
    lhu   $t7,8($s0)
    lhu   $t8,10($s0)
    sll   $t7,$t7,16
    or   $t6,$t6,$t7
    mtc2   $t6,$2
    mtc2   $t8,$3
    lhu   $t6,12($s0)
    lhu   $t7,14($s0)
    lhu   $t8,16($s0)
    sll   $t7,$t7,16
    or   $t6,$t6,$t7
    mtc2   $t6,$4
    mtc2   $t8,$5
    lhu   $t6,18($s0)
    lhu   $t7,20($s0)
    rtpt
    lhu   $t8,22($s0)
    sll   $t7,$t7,16
    or   $t6,$t6,$t7
    addi   $s0,$s0,0x18
    addiu   $s5,$s3,%lo(D_1F800020)
    addiu   $s6,$s3,%lo(D_1F800110)
    swc2   $12,0($s5)
    swc2   $13,4($s5)
    swc2   $14,8($s5)
    mfc2   $t0,$17
    mfc2   $t1,$18
    mfc2   $t2,$19
    mtc2   $t6,$0
    mtc2   $t8,$1
    nop
    nop
    rtps
    sh   $t0,0($s6)
    sh   $t1,2($s6)
    sh   $t2,4($s6)
    mfc2   $t0,$19
    swc2   $14,12($s5)
    sh   $t0,6($s6)
    bgez   $zero,.L8004C8D0
    nop
.L8004C7A8:
    addiu   $a0,$a0,-0x3
    lhu   $t6,0($s0)
    lhu   $t7,2($s0)
    lhu   $t8,4($s0)
    sll   $t7,$t7,16
    or   $t6,$t6,$t7
    mtc2   $t6,$0
    mtc2   $t8,$1
    lhu   $t6,6($s0)
    lhu   $t7,8($s0)
    lhu   $t8,10($s0)
    sll   $t7,$t7,16
    or   $t6,$t6,$t7
    mtc2   $t6,$2
    mtc2   $t8,$3
    lhu   $t6,12($s0)
    lhu   $t7,14($s0)
    lhu   $t8,16($s0)
    sll   $t7,$t7,16
    or   $t6,$t6,$t7
    mtc2   $t6,$4
    mtc2   $t8,$5
    addiu   $s5,$s3,%lo(D_1F800020)
    addiu   $s6,$s3,%lo(D_1F800110)
    rtpt
    j   .L8004C828
    addiu   $s0,$s0,0x12
.L8004C814:
    rtpt
    addiu   $s6,$s6,0x6
    sh   $t0,-6($s6)
    sh   $t1,-4($s6)
    sh   $t2,-2($s6)
.L8004C828:
    swc2   $12,0($s5)
    swc2   $13,4($s5)
    swc2   $14,8($s5)
    mfc2   $t0,$17
    mfc2   $t1,$18
    mfc2   $t2,$19
    addiu   $s5,$s5,0xC
    blez   $a0,.L8004C8AC
    nop
    addiu   $a0,$a0,-0x3
    lhu   $t6,0($s0)
    lhu   $t7,2($s0)
    lhu   $t8,4($s0)
    sll   $t7,$t7,16
    or   $t6,$t6,$t7
    mtc2   $t6,$0
    mtc2   $t8,$1
    lhu   $t6,6($s0)
    lhu   $t7,8($s0)
    lhu   $t8,10($s0)
    sll   $t7,$t7,16
    or   $t6,$t6,$t7
    mtc2   $t6,$2
    mtc2   $t8,$3
    lhu   $t6,12($s0)
    lhu   $t7,14($s0)
    lhu   $t8,16($s0)
    sll   $t7,$t7,16
    or   $t6,$t6,$t7
    mtc2   $t6,$4
    mtc2   $t8,$5
    j   .L8004C814
    addiu   $s0,$s0,0x12
.L8004C8AC:
    sh   $t0,0($s6)
    sh   $t1,2($s6)
    sh   $t2,4($s6)
    add   $a0,$a0,$a0
    add   $t0,$a0,$a0
    add   $a0,$t0,$a0
    add   $s0,$s0,$a0
    andi   $t0,$s0,0x3
    add   $s0,$s0,$t0
.L8004C8D0:
    lhu   $a0,0($s0)
    addiu   $s0,$s0,0x2
.L8004C8D8:
    lhu   $t0,0($s0)
    lw   $a1,432($s3)
    addiu   $s0,$s0,0x2
    srl   $t0,$t0,3
    sll   $t0,$t0,2
    lui   $at,%hi(D_80015470)
    addu   $at,$at,$t0
    lw   $t0,%lo(D_80015470)($at)
    addu   $a2,$s0,$zero
    jalr   $t0
    addu   $a3,$s7,$zero
    addu   $s0,$v0,$zero
    lhu   $a0,0($s0)
    addiu   $s0,$s0,0x2
    bnez   $a0,.L8004C8D8
    nop
    lhu   $t0,0($s0)
    addiu   $s0,$s0,0x2
    beqz   $t0,.L8004C930
    nop
    j   InitFadePanel
    nop
.L8004C930:
    lui   $v0,%hi(D_800A3820)
    lw   $v0,%lo(D_800A3820)($v0)
    nop
    beq   $v0,$s2,.L8004C964
    nop
    lw   $s1,0($s2)
    nop
    lh   $v0,0($s1)
    nop
    addiu   $at,$zero,0xC
    beq   $v0,$at,.L8004C5BC
    addi   $s2,$s2,0x4
    addi   $s2,$s2,-0x4
.L8004C964:
    addu   $v0,$s2,$zero
    lw   $ra,48($sp)
    lw   $fp,44($sp)
    lw   $s7,40($sp)
    lw   $s6,36($sp)
    lw   $s5,32($sp)
    lw   $s4,28($sp)
    lw   $s3,24($sp)
    lw   $s2,20($sp)
    lw   $s1,16($sp)
    jr   $ra
    addiu   $sp,$sp,0x38
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_8004C994
    addiu   $sp,$sp,-0x38
    sw   $ra,44($sp)
    sw   $fp,40($sp)
    sw   $s6,36($sp)
    sw   $s5,32($sp)
    sw   $s4,28($sp)
    sw   $s3,24($sp)
    sw   $s2,20($sp)
    sw   $s1,16($sp)
    beqz   $a0,.L8004CB5C
    addiu   $s3,$a0,-0x1
    lui   $s1,0x1F80
    ori   $s1,$s1,32
    lui   $s2,0x1F80
    ori   $s2,$s2,692
    lui   $s4,0x1F80
    lw   $s4,12($s4)
    lui   $s5,0x700
    lui   $fp,0xFF
    ori   $fp,$fp,65535
    lui   $s6,%hi(D_800A38B4)
    lw   $s6,%lo(D_800A38B4)($s6)
    lui   $v1,0x1F80
    lw   $v1,8($v1)
.L8004C9F4:
    lw   $a0,12($s0)
    lwc2   $6,0($s0)
    sll   $a1,$a0,2
    andi   $t3,$a1,0x3FC
    addu   $a1,$t3,$s1
    lw   $t0,0($a1)
    srl   $a1,$a0,6
    andi   $t4,$a1,0x3FC
    addu   $a1,$t4,$s1
    lw   $t1,0($a1)
    srl   $a1,$a0,14
    andi   $t5,$a1,0x3FC
    addu   $a1,$t5,$s1
    lw   $t2,0($a1)
    mtc2   $t0,$12
    mtc2   $t1,$13
    mtc2   $t2,$14
    and   $t6,$t0,$t1
    and   $t6,$t6,$t2
    nclip
    bltz   $t6,.L8004CB50
    mfc2   $v0,$24
    andi   $t6,$t6,0x8000
    bnez   $t6,.L8004CB50
    slt   $a3,$v0,$zero
    addi   $a3,$a3,-0x1
    srl   $v0,$t3,1
    addu   $v0,$v0,$s2
    lh   $a0,0($v0)
    srl   $v0,$t4,1
    addu   $v0,$v0,$s2
    lh   $a1,0($v0)
    srl   $v0,$t5,1
    addu   $v0,$v0,$s2
    lh   $a2,0($v0)
    mtc2   $a0,$17
    mtc2   $a1,$18
    mtc2   $a2,$19
    sw   $t0,8($s6)
    nop
    avsz3
    sw   $t1,16($s6)
    mfc2   $v0,$7
    sw   $t2,24($s6)
    blez   $v0,.L8004CB50
    sll   $v0,$v0,2
    lui   $at,0x1
    slt   $t9,$v0,$at
    beqz   $t9,.L8004CB50
    nop
    lw   $t0,16($s0)
    lw   $t1,20($s0)
    xor   $t0,$t0,$a3
    mtc2   $t0,$0
    xor   $t1,$t1,$a3
    mtc2   $t1,$1
    addiu   $at,$zero,-0x50
    xor   $t0,$a3,$at
    add   $v0,$v0,$t0
    srlv   $v0,$v0,$v1
    srl   $t0,$v0,11
    andi   $v0,$v0,0x7FF
    addi   $v0,$v0,-0x1000
    srav   $v0,$v0,$t0
    andi   $v0,$v0,0xFFF
    ncs
    lh   $t4,4($s0)
    lh   $t5,0($s0)
    sll   $t4,$t4,16
    sll   $t5,$t5,16
    swc2   $22,4($s6)
    lhu   $t0,6($s0)
    lhu   $t1,8($s0)
    lhu   $t2,10($s0)
    or   $t0,$t0,$t4
    or   $t1,$t1,$t5
    sw   $t0,12($s6)
    sw   $t1,20($s6)
    sh   $t2,28($s6)
    sll   $v0,$v0,2
    addu   $v0,$v0,$s4
    lw   $t1,0($v0)
    and   $t0,$s6,$fp
    sw   $t0,0($v0)
    or   $t1,$t1,$s5
    sw   $t1,0($s6)
    addiu   $s6,$s6,0x20
.L8004CB50:
    addiu   $s0,$s0,0x18
    bnez   $s3,.L8004C9F4
    addiu   $s3,$s3,-0x1
.L8004CB5C:
    lui   $at,%hi(D_800A38B4)
    sw   $s6,%lo(D_800A38B4)($at)
    lw   $ra,44($sp)
    lw   $fp,40($sp)
    lw   $s6,36($sp)
    lw   $s5,32($sp)
    lw   $s4,28($sp)
    lw   $s3,24($sp)
    lw   $s2,20($sp)
    lw   $s1,16($sp)
    jr   $ra
    addiu   $sp,$sp,0x38
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_8004CB8C
    addiu   $sp,$sp,-0x38
    sw   $ra,44($sp)
    sw   $fp,40($sp)
    sw   $s6,36($sp)
    sw   $s5,32($sp)
    sw   $s4,28($sp)
    sw   $s3,24($sp)
    sw   $s2,20($sp)
    sw   $s1,16($sp)
    beqz   $a0,.L8004CD80
    addiu   $s3,$a0,-0x1
    lui   $s1,0x1F80
    ori   $s1,$s1,32
    lui   $s2,0x1F80
    ori   $s2,$s2,692
    lui   $s4,0x1F80
    lw   $s4,12($s4)
    lui   $s5,0x900
    lui   $fp,0xFF
    ori   $fp,$fp,65535
    lui   $s6,%hi(D_800A38B4)
    lw   $s6,%lo(D_800A38B4)($s6)
    lui   $v1,0x1F80
    lw   $v1,8($v1)
.L8004CBEC:
    lhu   $a0,14($s0)
    lhu   $a1,16($s0)
    lwc2   $6,0($s0)
    sll   $a1,$a1,16
    or   $a0,$a0,$a1
    sll   $a1,$a0,2
    andi   $t3,$a1,0x3FC
    addu   $a1,$t3,$s1
    lw   $t0,0($a1)
    srl   $a1,$a0,6
    andi   $t4,$a1,0x3FC
    addu   $a1,$t4,$s1
    lw   $t1,0($a1)
    srl   $a1,$a0,14
    andi   $t5,$a1,0x3FC
    addu   $a1,$t5,$s1
    lw   $t2,0($a1)
    srl   $a1,$a0,22
    andi   $t6,$a1,0x3FC
    addu   $a1,$t6,$s1
    lw   $t7,0($a1)
    mtc2   $t0,$12
    mtc2   $t1,$13
    mtc2   $t2,$14
    and   $t8,$t0,$t1
    and   $t8,$t8,$t2
    and   $t8,$t8,$t7
    nclip
    bltz   $t8,.L8004CD74
    mfc2   $v0,$24
    andi   $t8,$t8,0x8000
    bnez   $t8,.L8004CD74
    slt   $a3,$v0,$zero
    addi   $a3,$a3,-0x1
    srl   $v0,$t3,1
    addu   $v0,$v0,$s2
    lh   $a0,0($v0)
    srl   $v0,$t4,1
    addu   $v0,$v0,$s2
    lh   $a1,0($v0)
    srl   $v0,$t5,1
    addu   $v0,$v0,$s2
    lh   $a2,0($v0)
    srl   $v0,$t6,1
    addu   $v0,$v0,$s2
    lh   $t3,0($v0)
    add   $a0,$a0,$a1
    add   $a0,$a0,$a2
    add   $a0,$a0,$t3
    sra   $v0,$a0,2
    blez   $v0,.L8004CD74
    lui   $at,0x1
    slt   $t9,$v0,$at
    beqz   $t9,.L8004CD74
    nop
    sw   $t0,8($s6)
    sw   $t1,16($s6)
    sw   $t2,24($s6)
    sw   $t7,32($s6)
    lhu   $t0,18($s0)
    lw   $t1,20($s0)
    xor   $t0,$t0,$a3
    mtc2   $t0,$1
    xor   $t1,$t1,$a3
    mtc2   $t1,$0
    addiu   $at,$zero,-0x50
    xor   $t0,$a3,$at
    add   $v0,$v0,$t0
    srlv   $v0,$v0,$v1
    srl   $t0,$v0,11
    andi   $v0,$v0,0x7FF
    addi   $v0,$v0,-0x1000
    srav   $v0,$v0,$t0
    andi   $v0,$v0,0xFFF
    ncs
    lh   $t4,4($s0)
    lh   $t5,0($s0)
    sll   $t4,$t4,16
    sll   $t5,$t5,16
    swc2   $22,4($s6)
    lhu   $t0,6($s0)
    lhu   $t1,8($s0)
    lhu   $t2,10($s0)
    lhu   $t3,12($s0)
    or   $t0,$t0,$t4
    or   $t1,$t1,$t5
    sw   $t0,12($s6)
    sw   $t1,20($s6)
    sh   $t2,28($s6)
    sh   $t3,36($s6)
    sll   $v0,$v0,2
    addu   $v0,$v0,$s4
    lw   $t1,0($v0)
    and   $t0,$s6,$fp
    sw   $t0,0($v0)
    or   $t1,$t1,$s5
    sw   $t1,0($s6)
    addiu   $s6,$s6,0x28
.L8004CD74:
    addiu   $s0,$s0,0x18
    bnez   $s3,.L8004CBEC
    addiu   $s3,$s3,-0x1
.L8004CD80:
    lui   $at,%hi(D_800A38B4)
    sw   $s6,%lo(D_800A38B4)($at)
    lw   $ra,44($sp)
    lw   $fp,40($sp)
    lw   $s6,36($sp)
    lw   $s5,32($sp)
    lw   $s4,28($sp)
    lw   $s3,24($sp)
    lw   $s2,20($sp)
    lw   $s1,16($sp)
    jr   $ra
    addiu   $sp,$sp,0x38
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_8004CDB0
    addiu   $sp,$sp,-0x38
    sw   $ra,44($sp)
    sw   $fp,40($sp)
    sw   $s6,36($sp)
    sw   $s5,32($sp)
    sw   $s4,28($sp)
    sw   $s3,24($sp)
    sw   $s2,20($sp)
    sw   $s1,16($sp)
    beqz   $a0,.L8004CFB0
    addiu   $s3,$a0,-0x1
    lui   $s1,0x1F80
    ori   $s1,$s1,32
    lui   $s2,0x1F80
    ori   $s2,$s2,692
    lui   $s4,0x1F80
    lw   $s4,12($s4)
    lui   $s5,0x900
    lui   $fp,0xFF
    ori   $fp,$fp,65535
    lui   $s6,%hi(D_800A38B4)
    lw   $s6,%lo(D_800A38B4)($s6)
    lui   $v1,0x1F80
    lw   $v1,8($v1)
    lwc2   $6,0($s0)
.L8004CE14:
    lw   $a0,12($s0)
    nop
    sll   $a1,$a0,2
    andi   $t3,$a1,0x3FC
    addu   $a1,$t3,$s1
    lw   $t0,0($a1)
    srl   $a1,$a0,6
    andi   $t4,$a1,0x3FC
    addu   $a1,$t4,$s1
    lw   $t1,0($a1)
    srl   $a1,$a0,14
    andi   $t5,$a1,0x3FC
    addu   $a1,$t5,$s1
    lw   $t2,0($a1)
    mtc2   $t0,$12
    mtc2   $t1,$13
    mtc2   $t2,$14
    and   $t6,$t0,$t1
    and   $t6,$t6,$t2
    nclip
    bltz   $t6,.L8004CFA4
    mfc2   $v0,$24
    andi   $t6,$t6,0x8000
    bnez   $t6,.L8004CFA4
    slt   $a3,$v0,$zero
    addi   $a3,$a3,-0x1
    srl   $v0,$t3,1
    addu   $v0,$v0,$s2
    lh   $a0,0($v0)
    srl   $v0,$t4,1
    addu   $v0,$v0,$s2
    lh   $a1,0($v0)
    srl   $v0,$t5,1
    addu   $v0,$v0,$s2
    lh   $a2,0($v0)
    mtc2   $a0,$17
    mtc2   $a1,$18
    mtc2   $a2,$19
    sw   $t0,8($s6)
    nop
    avsz3
    sw   $t1,20($s6)
    mfc2   $v0,$7
    sw   $t2,32($s6)
    blez   $v0,.L8004CFA4
    sll   $v0,$v0,2
    lui   $at,0x1
    slt   $t9,$v0,$at
    beqz   $t9,.L8004CFA4
    nop
    lw   $t0,16($s0)
    lw   $t1,20($s0)
    xor   $t0,$t0,$a3
    xor   $t1,$t1,$a3
    mtc2   $t0,$0
    mtc2   $t1,$1
    lw   $t2,24($s0)
    srl   $t1,$t1,16
    xor   $t2,$t2,$a3
    mtc2   $t2,$2
    mtc2   $t1,$3
    lw   $t0,28($s0)
    lw   $t1,32($s0)
    xor   $t0,$t0,$a3
    xor   $t1,$t1,$a3
    mtc2   $t0,$4
    mtc2   $t1,$5
    addiu   $at,$zero,-0x50
    xor   $t0,$a3,$at
    add   $v0,$v0,$t0
    srlv   $v0,$v0,$v1
    srl   $t0,$v0,11
    andi   $v0,$v0,0x7FF
    addi   $v0,$v0,-0x1000
    srav   $v0,$v0,$t0
    andi   $v0,$v0,0xFFF
    nct
    lh   $t4,4($s0)
    lh   $t5,0($s0)
    sll   $t4,$t4,16
    sll   $t5,$t5,16
    lhu   $t0,6($s0)
    lhu   $t1,8($s0)
    lhu   $t2,10($s0)
    or   $t0,$t0,$t4
    or   $t1,$t1,$t5
    sw   $t0,12($s6)
    sw   $t1,24($s6)
    sh   $t2,36($s6)
    sll   $v0,$v0,2
    addu   $v0,$v0,$s4
    lw   $t1,0($v0)
    and   $t0,$s6,$fp
    sw   $t0,0($v0)
    or   $t1,$t1,$s5
    sw   $t1,0($s6)
    swc2   $20,4($s6)
    swc2   $21,16($s6)
    swc2   $22,28($s6)
    addiu   $s6,$s6,0x28
.L8004CFA4:
    addiu   $s0,$s0,0x24
    bnez   $s3,.L8004CE14
    addiu   $s3,$s3,-0x1
.L8004CFB0:
    lui   $at,%hi(D_800A38B4)
    sw   $s6,%lo(D_800A38B4)($at)
    lw   $ra,44($sp)
    lw   $fp,40($sp)
    lw   $s6,36($sp)
    lw   $s5,32($sp)
    lw   $s4,28($sp)
    lw   $s3,24($sp)
    lw   $s2,20($sp)
    lw   $s1,16($sp)
    jr   $ra
    addiu   $sp,$sp,0x38
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_8004CFE0
    addiu   $sp,$sp,-0x38
    sw   $ra,44($sp)
    sw   $fp,40($sp)
    sw   $s6,36($sp)
    sw   $s5,32($sp)
    sw   $s4,28($sp)
    sw   $s3,24($sp)
    sw   $s2,20($sp)
    sw   $s1,16($sp)
    beqz   $a0,.L8004D214
    addiu   $s3,$a0,-0x1
    lui   $s1,0x1F80
    ori   $s1,$s1,32
    lui   $s2,0x1F80
    ori   $s2,$s2,692
    lui   $s4,0x1F80
    lw   $s4,12($s4)
    lui   $s5,0xC00
    lui   $fp,0xFF
    ori   $fp,$fp,65535
    lui   $s6,%hi(D_800A38B4)
    lw   $s6,%lo(D_800A38B4)($s6)
    lui   $v1,0x1F80
    lw   $v1,8($v1)
    lwc2   $6,0($s0)
.L8004D044:
    lw   $a0,16($s0)
    nop
    sll   $a1,$a0,2
    andi   $t3,$a1,0x3FC
    addu   $a1,$t3,$s1
    lw   $t0,0($a1)
    srl   $a1,$a0,6
    andi   $t4,$a1,0x3FC
    addu   $a1,$t4,$s1
    lw   $t1,0($a1)
    srl   $a1,$a0,14
    andi   $t5,$a1,0x3FC
    addu   $a1,$t5,$s1
    lw   $t2,0($a1)
    srl   $a1,$a0,22
    andi   $t6,$a1,0x3FC
    addu   $a1,$t6,$s1
    lw   $t7,0($a1)
    mtc2   $t0,$12
    mtc2   $t1,$13
    mtc2   $t2,$14
    and   $t8,$t0,$t1
    and   $t8,$t8,$t2
    and   $t8,$t8,$t7
    nclip
    bltz   $t8,.L8004D208
    mfc2   $v0,$24
    andi   $t8,$t8,0x8000
    bnez   $t8,.L8004D208
    slt   $a3,$v0,$zero
    addi   $a3,$a3,-0x1
    srl   $v0,$t3,1
    addu   $v0,$v0,$s2
    lh   $a0,0($v0)
    srl   $v0,$t4,1
    addu   $v0,$v0,$s2
    lh   $a1,0($v0)
    srl   $v0,$t5,1
    addu   $v0,$v0,$s2
    lh   $a2,0($v0)
    srl   $v0,$t6,1
    addu   $v0,$v0,$s2
    lh   $t3,0($v0)
    add   $a0,$a0,$a1
    add   $a0,$a0,$a2
    add   $a0,$a0,$t3
    sra   $v0,$a0,2
    blez   $v0,.L8004D208
    lui   $at,0x1
    slt   $t9,$v0,$at
    beqz   $t9,.L8004D208
    nop
    sw   $t0,8($s6)
    sw   $t1,20($s6)
    sw   $t2,32($s6)
    sw   $t7,44($s6)
    lw   $t2,20($s0)
    lw   $t1,24($s0)
    xor   $t2,$t2,$a3
    xor   $t1,$t1,$a3
    mtc2   $t2,$0
    mtc2   $t1,$1
    addiu   $at,$zero,-0x50
    xor   $t0,$a3,$at
    add   $v0,$v0,$t0
    srlv   $v0,$v0,$v1
    srl   $t0,$v0,11
    andi   $v0,$v0,0x7FF
    ncs
    addi   $v0,$v0,-0x1000
    srav   $v0,$v0,$t0
    andi   $v0,$v0,0xFFF
    swc2   $22,4($s6)
    lw   $t0,28($s0)
    srl   $t1,$t1,16
    mtc2   $t0,$0
    mtc2   $t1,$1
    lw   $t2,32($s0)
    lw   $t1,36($s0)
    xor   $t2,$t2,$a3
    xor   $t1,$t1,$a3
    mtc2   $t2,$2
    mtc2   $t1,$3
    lw   $t0,40($s0)
    srl   $t1,$t1,16
    mtc2   $t0,$4
    mtc2   $t1,$5
    lh   $t4,4($s0)
    lh   $t5,0($s0)
    sll   $t4,$t4,16
    sll   $t5,$t5,16
    nct
    lhu   $t0,6($s0)
    lhu   $t1,8($s0)
    lhu   $t2,10($s0)
    lhu   $t3,12($s0)
    or   $t0,$t0,$t4
    or   $t1,$t1,$t5
    sw   $t0,12($s6)
    sw   $t1,24($s6)
    sh   $t2,36($s6)
    sh   $t3,48($s6)
    sll   $v0,$v0,2
    addu   $v0,$v0,$s4
    lw   $t1,0($v0)
    and   $t0,$s6,$fp
    sw   $t0,0($v0)
    or   $t1,$t1,$s5
    sw   $t1,0($s6)
    swc2   $20,16($s6)
    swc2   $21,28($s6)
    swc2   $22,40($s6)
    addiu   $s6,$s6,0x34
.L8004D208:
    addiu   $s0,$s0,0x2C
    bnez   $s3,.L8004D044
    addiu   $s3,$s3,-0x1
.L8004D214:
    lui   $at,%hi(D_800A38B4)
    sw   $s6,%lo(D_800A38B4)($at)
    lw   $ra,44($sp)
    lw   $fp,40($sp)
    lw   $s6,36($sp)
    lw   $s5,32($sp)
    lw   $s4,28($sp)
    lw   $s3,24($sp)
    lw   $s2,20($sp)
    lw   $s1,16($sp)
    jr   $ra
    addiu   $sp,$sp,0x38
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_8004D244
    addiu   $sp,$sp,-0x38
    sw   $ra,44($sp)
    sw   $fp,40($sp)
    sw   $s6,36($sp)
    sw   $s5,32($sp)
    sw   $s4,28($sp)
    sw   $s3,24($sp)
    sw   $s2,20($sp)
    sw   $s1,16($sp)
    beqz   $a0,.L8004D3F4
    addiu   $s3,$a0,-0x1
    lui   $s1,0x1F80
    ori   $s1,$s1,32
    lui   $s2,0x1F80
    ori   $s2,$s2,692
    lui   $s4,0x1F80
    lw   $s4,12($s4)
    lui   $s5,0x700
    lui   $fp,0xFF
    ori   $fp,$fp,65535
    lui   $s6,%hi(D_800A38B4)
    lw   $s6,%lo(D_800A38B4)($s6)
    lui   $v1,0x1F80
    lw   $v1,8($v1)
    lwc2   $6,0($s0)
.L8004D2A8:
    lw   $a0,12($s0)
    nop
    sll   $a1,$a0,2
    andi   $t3,$a1,0x3FC
    addu   $a1,$t3,$s1
    lw   $t0,0($a1)
    srl   $a1,$a0,6
    andi   $t4,$a1,0x3FC
    addu   $a1,$t4,$s1
    lw   $t1,0($a1)
    srl   $a1,$a0,14
    andi   $t5,$a1,0x3FC
    addu   $a1,$t5,$s1
    lw   $t2,0($a1)
    mtc2   $t0,$12
    mtc2   $t1,$13
    mtc2   $t2,$14
    and   $t6,$t0,$t1
    and   $t6,$t6,$t2
    nclip
    bltz   $t6,.L8004D3E8
    mfc2   $v0,$24
    andi   $t6,$t6,0x8000
    bgez   $v0,.L8004D3E8
    nop
    bnez   $t6,.L8004D3E8
    srl   $v0,$t3,1
    addu   $v0,$v0,$s2
    lh   $a0,0($v0)
    srl   $v0,$t4,1
    addu   $v0,$v0,$s2
    lh   $a1,0($v0)
    srl   $v0,$t5,1
    addu   $v0,$v0,$s2
    lh   $a2,0($v0)
    mtc2   $a0,$17
    mtc2   $a1,$18
    mtc2   $a2,$19
    sw   $t0,8($s6)
    nop
    avsz3
    sw   $t1,16($s6)
    mfc2   $v0,$7
    sw   $t2,24($s6)
    blez   $v0,.L8004D3E8
    sll   $v0,$v0,2
    lwc2   $0,16($s0)
    lwc2   $1,20($s0)
    srlv   $v0,$v0,$v1
    srl   $t0,$v0,11
    andi   $v0,$v0,0x7FF
    ncs
    lui   $a0,0x1F80
    lw   $a0,24($a0)
    addi   $v0,$v0,-0x1000
    srav   $v0,$v0,$t0
    andi   $v0,$v0,0xFFF
    slt   $at,$v0,$a0
    bnez   $at,.L8004D3E8
    lh   $t4,4($s0)
    lh   $t5,0($s0)
    sll   $t4,$t4,16
    sll   $t5,$t5,16
    lhu   $t0,6($s0)
    lhu   $t1,8($s0)
    lhu   $t2,10($s0)
    or   $t0,$t0,$t4
    or   $t1,$t1,$t5
    sw   $t0,12($s6)
    sw   $t1,20($s6)
    sh   $t2,28($s6)
    swc2   $22,4($s6)
    sll   $v0,$v0,2
    addu   $v0,$v0,$s4
    lw   $t1,0($v0)
    and   $t0,$s6,$fp
    sw   $t0,0($v0)
    or   $t1,$t1,$s5
    sw   $t1,0($s6)
    addiu   $s6,$s6,0x20
.L8004D3E8:
    addiu   $s0,$s0,0x18
    bnez   $s3,.L8004D2A8
    addiu   $s3,$s3,-0x1
.L8004D3F4:
    lui   $at,%hi(D_800A38B4)
    sw   $s6,%lo(D_800A38B4)($at)
    lw   $ra,44($sp)
    lw   $fp,40($sp)
    lw   $s6,36($sp)
    lw   $s5,32($sp)
    lw   $s4,28($sp)
    lw   $s3,24($sp)
    lw   $s2,20($sp)
    lw   $s1,16($sp)
    jr   $ra
    addiu   $sp,$sp,0x38
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_8004D424
    addiu   $sp,$sp,-0x38
    sw   $ra,44($sp)
    sw   $fp,40($sp)
    sw   $s6,36($sp)
    sw   $s5,32($sp)
    sw   $s4,28($sp)
    sw   $s3,24($sp)
    sw   $s2,20($sp)
    sw   $s1,16($sp)
    beqz   $a0,.L8004D604
    addiu   $s3,$a0,-0x1
    lui   $s1,0x1F80
    ori   $s1,$s1,32
    lui   $s2,0x1F80
    ori   $s2,$s2,692
    lui   $s4,0x1F80
    lw   $s4,12($s4)
    lui   $s5,0x900
    lui   $fp,0xFF
    ori   $fp,$fp,65535
    lui   $s6,%hi(D_800A38B4)
    lw   $s6,%lo(D_800A38B4)($s6)
    lui   $v1,0x1F80
    lw   $v1,8($v1)
.L8004D484:
    lhu   $a0,14($s0)
    lhu   $a1,16($s0)
    lwc2   $6,0($s0)
    sll   $a1,$a1,16
    or   $a0,$a0,$a1
    sll   $a1,$a0,2
    andi   $t3,$a1,0x3FC
    addu   $a1,$t3,$s1
    lw   $t0,0($a1)
    srl   $a1,$a0,6
    andi   $t4,$a1,0x3FC
    addu   $a1,$t4,$s1
    lw   $t1,0($a1)
    srl   $a1,$a0,14
    andi   $t5,$a1,0x3FC
    addu   $a1,$t5,$s1
    lw   $t2,0($a1)
    srl   $a1,$a0,22
    andi   $t6,$a1,0x3FC
    addu   $a1,$t6,$s1
    lw   $t7,0($a1)
    mtc2   $t0,$12
    mtc2   $t1,$13
    mtc2   $t2,$14
    and   $t8,$t0,$t1
    and   $t8,$t8,$t2
    and   $t8,$t8,$t7
    nclip
    bltz   $t8,.L8004D5F8
    mfc2   $v0,$24
    andi   $t8,$t8,0x8000
    bgez   $v0,.L8004D5F8
    nop
    bnez   $t8,.L8004D5F8
    srl   $v0,$t3,1
    addu   $v0,$v0,$s2
    lh   $a0,0($v0)
    srl   $v0,$t4,1
    addu   $v0,$v0,$s2
    lh   $a1,0($v0)
    srl   $v0,$t5,1
    addu   $v0,$v0,$s2
    lh   $a2,0($v0)
    srl   $v0,$t6,1
    addu   $v0,$v0,$s2
    lh   $a3,0($v0)
    add   $a0,$a0,$a1
    add   $a0,$a0,$a2
    add   $a0,$a0,$a3
    sra   $v0,$a0,2
    blez   $v0,.L8004D5F8
    nop
    sw   $t0,8($s6)
    sw   $t1,16($s6)
    sw   $t2,24($s6)
    sw   $t7,32($s6)
    lhu   $t0,18($s0)
    lwc2   $0,20($s0)
    mtc2   $t0,$1
    srlv   $v0,$v0,$v1
    srl   $t0,$v0,11
    andi   $v0,$v0,0x7FF
    ncs
    lui   $a0,0x1F80
    lw   $a0,24($a0)
    addi   $v0,$v0,-0x1000
    srav   $v0,$v0,$t0
    andi   $v0,$v0,0xFFF
    slt   $at,$v0,$a0
    bnez   $at,.L8004D5F8
    lh   $t4,4($s0)
    lh   $t5,0($s0)
    sll   $t4,$t4,16
    sll   $t5,$t5,16
    lhu   $t0,6($s0)
    lhu   $t1,8($s0)
    lhu   $t2,10($s0)
    lhu   $t3,12($s0)
    or   $t0,$t0,$t4
    or   $t1,$t1,$t5
    sw   $t0,12($s6)
    sw   $t1,20($s6)
    sh   $t2,28($s6)
    sh   $t3,36($s6)
    swc2   $22,4($s6)
    sll   $v0,$v0,2
    addu   $v0,$v0,$s4
    lw   $t1,0($v0)
    and   $t0,$s6,$fp
    sw   $t0,0($v0)
    or   $t1,$t1,$s5
    sw   $t1,0($s6)
    addiu   $s6,$s6,0x28
.L8004D5F8:
    addiu   $s0,$s0,0x18
    bnez   $s3,.L8004D484
    addiu   $s3,$s3,-0x1
.L8004D604:
    lui   $at,%hi(D_800A38B4)
    sw   $s6,%lo(D_800A38B4)($at)
    lw   $ra,44($sp)
    lw   $fp,40($sp)
    lw   $s6,36($sp)
    lw   $s5,32($sp)
    lw   $s4,28($sp)
    lw   $s3,24($sp)
    lw   $s2,20($sp)
    lw   $s1,16($sp)
    jr   $ra
    addiu   $sp,$sp,0x38
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_8004D634
    addiu   $sp,$sp,-0x38
    sw   $ra,44($sp)
    sw   $fp,40($sp)
    sw   $s6,36($sp)
    sw   $s5,32($sp)
    sw   $s4,28($sp)
    sw   $s3,24($sp)
    sw   $s2,20($sp)
    sw   $s1,16($sp)
    beqz   $a0,.L8004D808
    addiu   $s3,$a0,-0x1
    lui   $s1,0x1F80
    ori   $s1,$s1,32
    lui   $s2,0x1F80
    ori   $s2,$s2,692
    lui   $s4,0x1F80
    lw   $s4,12($s4)
    lui   $s5,0x900
    lui   $fp,0xFF
    ori   $fp,$fp,65535
    lui   $s6,%hi(D_800A38B4)
    lw   $s6,%lo(D_800A38B4)($s6)
    lui   $v1,0x1F80
    lw   $v1,8($v1)
    lwc2   $6,0($s0)
.L8004D698:
    lw   $a0,12($s0)
    nop
    sll   $a1,$a0,2
    andi   $t3,$a1,0x3FC
    addu   $a1,$t3,$s1
    lw   $t0,0($a1)
    srl   $a1,$a0,6
    andi   $t4,$a1,0x3FC
    addu   $a1,$t4,$s1
    lw   $t1,0($a1)
    srl   $a1,$a0,14
    andi   $t5,$a1,0x3FC
    addu   $a1,$t5,$s1
    lw   $t2,0($a1)
    mtc2   $t0,$12
    mtc2   $t1,$13
    mtc2   $t2,$14
    and   $t6,$t0,$t1
    and   $t6,$t6,$t2
    nclip
    bltz   $t6,.L8004D7FC
    mfc2   $v0,$24
    andi   $t6,$t6,0x8000
    bgez   $v0,.L8004D7FC
    nop
    bnez   $t6,.L8004D7FC
    srl   $v0,$t3,1
    addu   $v0,$v0,$s2
    lh   $a0,0($v0)
    srl   $v0,$t4,1
    addu   $v0,$v0,$s2
    lh   $a1,0($v0)
    srl   $v0,$t5,1
    addu   $v0,$v0,$s2
    lh   $a2,0($v0)
    mtc2   $a0,$17
    mtc2   $a1,$18
    mtc2   $a2,$19
    sw   $t0,8($s6)
    nop
    avsz3
    sw   $t1,20($s6)
    mfc2   $v0,$7
    sw   $t2,32($s6)
    blez   $v0,.L8004D7FC
    sll   $v0,$v0,2
    lui   $at,0x1
    slt   $t9,$v0,$at
    beqz   $t9,.L8004D7FC
    nop
    lwc2   $0,16($s0)
    lw   $t0,20($s0)
    lwc2   $2,24($s0)
    mtc2   $t0,$1
    lwc2   $4,28($s0)
    lwc2   $5,32($s0)
    srl   $t0,$t0,16
    mtc2   $t0,$3
    srlv   $v0,$v0,$v1
    srl   $t0,$v0,11
    andi   $v0,$v0,0x7FF
    addi   $v0,$v0,-0x1000
    srav   $v0,$v0,$t0
    andi   $v0,$v0,0xFFF
    nct
    lh   $t4,4($s0)
    lh   $t5,0($s0)
    sll   $t4,$t4,16
    sll   $t5,$t5,16
    lhu   $t0,6($s0)
    lhu   $t1,8($s0)
    lhu   $t2,10($s0)
    or   $t0,$t0,$t4
    or   $t1,$t1,$t5
    sw   $t0,12($s6)
    sw   $t1,24($s6)
    sh   $t2,36($s6)
    sll   $v0,$v0,2
    addu   $v0,$v0,$s4
    lw   $t1,0($v0)
    and   $t0,$s6,$fp
    sw   $t0,0($v0)
    or   $t1,$t1,$s5
    sw   $t1,0($s6)
    swc2   $20,4($s6)
    swc2   $21,16($s6)
    swc2   $22,28($s6)
    nop
    addiu   $s6,$s6,0x28
.L8004D7FC:
    addiu   $s0,$s0,0x24
    bnez   $s3,.L8004D698
    addiu   $s3,$s3,-0x1
.L8004D808:
    lui   $at,%hi(D_800A38B4)
    sw   $s6,%lo(D_800A38B4)($at)
    lw   $ra,44($sp)
    lw   $fp,40($sp)
    lw   $s6,36($sp)
    lw   $s5,32($sp)
    lw   $s4,28($sp)
    lw   $s3,24($sp)
    lw   $s2,20($sp)
    lw   $s1,16($sp)
    jr   $ra
    addiu   $sp,$sp,0x38
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_8004D838
    addiu   $sp,$sp,-0x38
    sw   $ra,44($sp)
    sw   $fp,40($sp)
    sw   $s6,36($sp)
    sw   $s5,32($sp)
    sw   $s4,28($sp)
    sw   $s3,24($sp)
    sw   $s2,20($sp)
    sw   $s1,16($sp)
    beqz   $a0,.L8004DA44
    addiu   $s3,$a0,-0x1
    lui   $s1,0x1F80
    ori   $s1,$s1,32
    lui   $s2,0x1F80
    ori   $s2,$s2,692
    lui   $s4,0x1F80
    lw   $s4,12($s4)
    lui   $s5,0xC00
    lui   $fp,0xFF
    ori   $fp,$fp,65535
    lui   $s6,%hi(D_800A38B4)
    lw   $s6,%lo(D_800A38B4)($s6)
    lui   $v1,0x1F80
    lw   $v1,8($v1)
    lwc2   $6,0($s0)
.L8004D89C:
    lw   $a0,16($s0)
    nop
    sll   $a1,$a0,2
    andi   $t3,$a1,0x3FC
    addu   $a1,$t3,$s1
    lw   $t0,0($a1)
    srl   $a1,$a0,6
    andi   $t4,$a1,0x3FC
    addu   $a1,$t4,$s1
    lw   $t1,0($a1)
    srl   $a1,$a0,14
    andi   $t5,$a1,0x3FC
    addu   $a1,$t5,$s1
    lw   $t2,0($a1)
    srl   $a1,$a0,22
    andi   $t6,$a1,0x3FC
    addu   $a1,$t6,$s1
    lw   $t7,0($a1)
    mtc2   $t0,$12
    mtc2   $t1,$13
    mtc2   $t2,$14
    and   $t8,$t0,$t1
    and   $t8,$t8,$t2
    and   $t8,$t8,$t7
    nclip
    bltz   $t8,.L8004DA38
    mfc2   $v0,$24
    andi   $t8,$t8,0x8000
    bgez   $v0,.L8004DA38
    nop
    bnez   $t8,.L8004DA38
    srl   $v0,$t3,1
    addu   $v0,$v0,$s2
    lh   $a0,0($v0)
    srl   $v0,$t4,1
    addu   $v0,$v0,$s2
    lh   $a1,0($v0)
    srl   $v0,$t5,1
    addu   $v0,$v0,$s2
    lh   $a2,0($v0)
    srl   $v0,$t6,1
    addu   $v0,$v0,$s2
    lh   $a3,0($v0)
    add   $a0,$a0,$a1
    add   $a0,$a0,$a2
    add   $a0,$a0,$a3
    sra   $v0,$a0,2
    blez   $v0,.L8004DA38
    lui   $at,0x1
    slt   $t9,$v0,$at
    beqz   $t9,.L8004DA38
    nop
    sw   $t0,8($s6)
    sw   $t1,20($s6)
    sw   $t2,32($s6)
    sw   $t7,44($s6)
    lw   $t9,24($s0)
    lwc2   $0,20($s0)
    mtc2   $t9,$1
    srlv   $v0,$v0,$v1
    srl   $t0,$v0,11
    andi   $v0,$v0,0x7FF
    ncs
    addi   $v0,$v0,-0x1000
    srav   $v0,$v0,$t0
    andi   $v0,$v0,0xFFF
    swc2   $22,4($s6)
    lwc2   $0,28($s0)
    srl   $t9,$t9,16
    mtc2   $t9,$1
    lwc2   $2,32($s0)
    lw   $t9,36($s0)
    lwc2   $4,40($s0)
    mtc2   $t9,$3
    srl   $t8,$t9,16
    mtc2   $t8,$5
    lh   $t4,4($s0)
    lh   $t5,0($s0)
    sll   $t4,$t4,16
    sll   $t5,$t5,16
    nct
    lhu   $t0,6($s0)
    lhu   $t1,8($s0)
    lhu   $t2,10($s0)
    lhu   $t3,12($s0)
    or   $t0,$t0,$t4
    or   $t1,$t1,$t5
    sw   $t0,12($s6)
    sw   $t1,24($s6)
    sh   $t2,36($s6)
    sh   $t3,48($s6)
    sll   $v0,$v0,2
    addu   $v0,$v0,$s4
    lw   $t1,0($v0)
    and   $t0,$s6,$fp
    sw   $t0,0($v0)
    or   $t1,$t1,$s5
    sw   $t1,0($s6)
    swc2   $20,16($s6)
    swc2   $21,28($s6)
    swc2   $22,40($s6)
    nop
    addiu   $s6,$s6,0x34
.L8004DA38:
    addiu   $s0,$s0,0x2C
    bnez   $s3,.L8004D89C
    addiu   $s3,$s3,-0x1
.L8004DA44:
    lui   $at,%hi(D_800A38B4)
    sw   $s6,%lo(D_800A38B4)($at)
    lw   $ra,44($sp)
    lw   $fp,40($sp)
    lw   $s6,36($sp)
    lw   $s5,32($sp)
    lw   $s4,28($sp)
    lw   $s3,24($sp)
    lw   $s2,20($sp)
    lw   $s1,16($sp)
    jr   $ra
    addiu   $sp,$sp,0x38
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_8004DA74
    addiu   $sp,$sp,-0x38
    sw   $ra,48($sp)
    sw   $fp,44($sp)
    sw   $s7,40($sp)
    sw   $s6,36($sp)
    sw   $s5,32($sp)
    sw   $s4,28($sp)
    sw   $s3,24($sp)
    sw   $s2,20($sp)
    sw   $s1,16($sp)
    addu   $s1,$a0,$zero
    addu   $s5,$a1,$zero
    lh   $t0,4($s1)
    lh   $t1,2($s1)
    sll   $t0,$t0,2
    lui   $t2,%hi(D_80103608)
    addiu   $t2,$t2,%lo(D_80103608)
    addu   $t0,$t0,$t2
    lw   $t0,0($t0)
    sll   $t1,$t1,2
    addu   $t0,$t0,$t1
    lw   $s0,0($t0)
    nop
    lw   $a1,0($s0)
    nop
    andi   $a0,$a1,0xFFFF
    srl   $a1,$a1,16
    beqz   $a0,.L8004DD84
    addi   $s0,$s0,0x4
    add   $t0,$a0,$a0
    add   $t0,$t0,$a0
    add   $t0,$t0,$t0
    add   $s0,$s0,$t0
    andi   $t0,$s0,0x3
    add   $s0,$s0,$t0
    lw   $s2,96($s1)
    lui   $v0,%hi(D_800A3708)
    lw   $v0,%lo(D_800A3708)($v0)
    addiu   $a0,$a0,-0x1
    lw   $t3,44($v0)
    lw   $t4,48($v0)
    lw   $t5,52($v0)
    lw   $t0,0($s2)
    lw   $t1,4($s2)
    lw   $t2,8($s2)
    sra   $t0,$t0,7
    sra   $t1,$t1,7
    sra   $t2,$t2,7
    sub   $t0,$t0,$t3
    sub   $t1,$t1,$t4
    sub   $t2,$t2,$t5
    srav   $t0,$t0,$s5
    srav   $t1,$t1,$s5
    srav   $t2,$t2,$s5
    sll   $t1,$t1,16
    andi   $t0,$t0,0xFFFF
    or   $t0,$t0,$t1
    mtc2   $t0,$0
    mtc2   $t2,$1
    lw   $t0,64($s2)
    lw   $t1,68($s2)
    lw   $t2,72($s2)
    sra   $t0,$t0,7
    sra   $t1,$t1,7
    sra   $t2,$t2,7
    sub   $t0,$t0,$t3
    sub   $t1,$t1,$t4
    sub   $t2,$t2,$t5
    srav   $t0,$t0,$s5
    srav   $t1,$t1,$s5
    srav   $t2,$t2,$s5
    sll   $t1,$t1,16
    andi   $t0,$t0,0xFFFF
    or   $t0,$t0,$t1
    mtc2   $t0,$2
    mtc2   $t2,$3
    lw   $t0,128($s2)
    lw   $t1,132($s2)
    lw   $t2,136($s2)
    sra   $t0,$t0,7
    sra   $t1,$t1,7
    sra   $t2,$t2,7
    sub   $t0,$t0,$t3
    sub   $t1,$t1,$t4
    sub   $t2,$t2,$t5
    srav   $t0,$t0,$s5
    srav   $t1,$t1,$s5
    srav   $t2,$t2,$s5
    sll   $t1,$t1,16
    andi   $t0,$t0,0xFFFF
    or   $t0,$t0,$t1
    mtc2   $t0,$4
    mtc2   $t2,$5
    lui   $s3,0x1F80
    ori   $s3,$s3,32
    lui   $s4,0x1F80
    ori   $s4,$s4,692
    rtpt
    j   .L8004DC18
    addi   $s2,$s2,0xC0
.L8004DC04:
    rtpt
    addiu   $s4,$s4,0x6
    sh   $t6,-6($s4)
    sh   $t7,-4($s4)
    sh   $t8,-2($s4)
.L8004DC18:
    swc2   $12,0($s3)
    swc2   $13,4($s3)
    swc2   $14,8($s3)
    mfc2   $t6,$17
    mfc2   $t7,$18
    mfc2   $t8,$19
    addiu   $s3,$s3,0xC
    beqz   $a0,.L8004DD10
    addiu   $a0,$a0,-0x1
    lw   $t0,0($s2)
    lw   $t1,4($s2)
    lw   $t2,8($s2)
    sra   $t0,$t0,7
    sra   $t1,$t1,7
    sra   $t2,$t2,7
    sub   $t0,$t0,$t3
    sub   $t1,$t1,$t4
    sub   $t2,$t2,$t5
    srav   $t0,$t0,$s5
    srav   $t1,$t1,$s5
    srav   $t2,$t2,$s5
    sll   $t1,$t1,16
    andi   $t0,$t0,0xFFFF
    or   $t0,$t0,$t1
    mtc2   $t0,$0
    mtc2   $t2,$1
    lw   $t0,64($s2)
    lw   $t1,68($s2)
    lw   $t2,72($s2)
    sra   $t0,$t0,7
    sra   $t1,$t1,7
    sra   $t2,$t2,7
    sub   $t0,$t0,$t3
    sub   $t1,$t1,$t4
    sub   $t2,$t2,$t5
    srav   $t0,$t0,$s5
    srav   $t1,$t1,$s5
    srav   $t2,$t2,$s5
    sll   $t1,$t1,16
    andi   $t0,$t0,0xFFFF
    or   $t0,$t0,$t1
    mtc2   $t0,$2
    mtc2   $t2,$3
    lw   $t0,128($s2)
    lw   $t1,132($s2)
    lw   $t2,136($s2)
    sra   $t0,$t0,7
    sra   $t1,$t1,7
    sra   $t2,$t2,7
    sub   $t0,$t0,$t3
    sub   $t1,$t1,$t4
    sub   $t2,$t2,$t5
    srav   $t0,$t0,$s5
    srav   $t1,$t1,$s5
    srav   $t2,$t2,$s5
    sll   $t1,$t1,16
    andi   $t0,$t0,0xFFFF
    or   $t0,$t0,$t1
    mtc2   $t0,$4
    mtc2   $t2,$5
    j   .L8004DC04
    addiu   $s2,$s2,0xC0
.L8004DD10:
    sh   $t6,0($s4)
    sh   $t7,2($s4)
    sh   $t8,4($s4)
    addiu   $t0,$zero,0x3
    subu   $t0,$t0,$s5
    lui   $at,0x1F80
    sw   $t0,8($at)
    lhu   $a0,0($s0)
    addiu   $s0,$s0,0x2
.L8004DD34:
    lhu   $t0,0($s0)
    addiu   $s0,$s0,0x2
    srl   $t0,$t0,3
    sll   $t0,$t0,2
    lbu   $t1,1($s1)
    lui   $t2,%hi(D_80015480)
    addiu   $t2,$t2,%lo(D_80015480)
    add   $t0,$t0,$t2
    andi   $t1,$t1,0x1
    beqz   $t1,.L8004DD64
    nop
    addi   $t0,$t0,0x10
.L8004DD64:
    lw   $t0,0($t0)
    addu   $a1,$s0,$zero
    jalr   $t0
    nop
    lhu   $a0,0($s0)
    addiu   $s0,$s0,0x2
    bnez   $a0,.L8004DD34
    nop
.L8004DD84:
    addu   $v0,$s1,$zero
    lw   $ra,48($sp)
    lw   $fp,44($sp)
    lw   $s7,40($sp)
    lw   $s6,36($sp)
    lw   $s5,32($sp)
    lw   $s4,28($sp)
    lw   $s3,24($sp)
    lw   $s2,20($sp)
    lw   $s1,16($sp)
    jr   $ra
    addiu   $sp,$sp,0x38
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_8004DDB4
    addiu   $sp,$sp,-0x8C
    sw   $ra,136($sp)
    sw   $fp,132($sp)
    sw   $s7,128($sp)
    sw   $s6,124($sp)
    sw   $s5,120($sp)
    sw   $s4,116($sp)
    sw   $s3,112($sp)
    sw   $s2,108($sp)
    sw   $s1,104($sp)
    sw   $s0,100($sp)
    addu   $fp,$a0,$zero
    addu   $s0,$a1,$zero
    addu   $s7,$a2,$zero
    addu   $s1,$a3,$zero
    addiu   $s5,$zero,0xC
    lui   $s6,0x1F80
    ori   $s6,$s6,32
    addu   $s3,$s6,$zero
    addi   $s4,$s6,0x224
    addi   $a0,$s0,0x2
    jal   func_80054440
    addu   $a1,$fp,$zero
    addi   $s0,$v0,-0x2
.L8004DE14:
    lui   $a0,%hi(D_800A3708)
    lw   $a0,%lo(D_800A3708)($a0)
    lw   $s2,0($fp)
    lw   $t0,44($a0)
    lw   $t1,48($a0)
    lw   $t2,52($a0)
    lw   $t3,20($s2)
    lw   $t4,24($s2)
    lw   $t5,28($s2)
    sub   $t3,$t3,$t0
    sub   $t4,$t4,$t1
    sub   $t5,$t5,$t2
    srav   $t3,$t3,$s1
    srav   $t4,$t4,$s1
    srav   $t5,$t5,$s1
    sw   $t3,872($s6)
    sw   $t4,876($s6)
    sw   $t5,880($s6)
    addi   $v0,$s6,0x340
    lh   $t0,0($s2)
    lh   $t1,2($s2)
    lh   $t2,4($s2)
    lh   $t3,6($s2)
    lh   $t4,8($s2)
    lh   $t5,10($s2)
    lh   $t6,12($s2)
    lh   $t7,14($s2)
    lh   $t8,16($s2)
    srav   $t0,$t0,$s1
    srav   $t1,$t1,$s1
    srav   $t2,$t2,$s1
    srav   $t3,$t3,$s1
    srav   $t4,$t4,$s1
    srav   $t5,$t5,$s1
    srav   $t6,$t6,$s1
    srav   $t7,$t7,$s1
    srav   $t8,$t8,$s1
    sh   $t0,0($v0)
    sh   $t1,2($v0)
    sh   $t2,4($v0)
    sh   $t3,6($v0)
    sh   $t4,8($v0)
    sh   $t5,10($v0)
    sh   $t6,12($v0)
    sh   $t7,14($v0)
    sh   $t8,16($v0)
    addu   $s2,$v0,$zero
    addi   $fp,$fp,0x4
    addu   $a0,$s7,$zero
    addu   $a1,$s2,$zero
    jal   func_80052930
    addi   $a2,$s6,0x354
    lw   $t0,0($s7)
    lw   $t1,4($s7)
    lw   $t2,8($s7)
    lw   $t3,12($s7)
    lw   $t4,16($s7)
    ctc2   $t0,$0
    ctc2   $t1,$1
    ctc2   $t2,$2
    ctc2   $t3,$3
    ctc2   $t4,$4
    ctc2   $zero,$5
    ctc2   $zero,$6
    ctc2   $zero,$7
    lw   $t0,872($s6)
    lw   $t1,876($s6)
    lw   $t2,880($s6)
    andi   $t0,$t0,0xFFFF
    sll   $t1,$t1,16
    or   $t1,$t1,$t0
    mtc2   $t1,$0
    mtc2   $t2,$1
    nop
    nop
    mvmva   1,0,0,0,0
    nop
    nop
    swc2   $25,884($s6)
    swc2   $26,888($s6)
    swc2   $27,892($s6)
    nop
    addi   $s0,$s0,0x2
    lh   $v1,0($s0)
    nop
    beqz   $v1,.L8004E01C
    addi   $s0,$s0,0x2
    addi   $v1,$v1,-0x1
    lw   $t0,0($s2)
    lw   $t1,4($s2)
    lw   $t2,8($s2)
    lw   $t3,12($s2)
    lw   $t4,16($s2)
    lw   $t5,872($s6)
    lw   $t6,876($s6)
    lw   $t7,880($s6)
    ctc2   $t0,$0
    ctc2   $t1,$1
    ctc2   $t2,$2
    ctc2   $t3,$3
    ctc2   $t4,$4
    ctc2   $t5,$5
    ctc2   $t6,$6
    ctc2   $t7,$7
.L8004DFB4:
    lhu   $t0,0($s0)
    lh   $t1,2($s0)
    lh   $t2,4($s0)
    sll   $t1,$t1,16
    or   $t1,$t1,$t0
    mtc2   $t1,$0
    mtc2   $t2,$1
    lh   $t0,6($s0)
    nop
    mvmva   1,0,0,0,0
    lh   $t1,8($s0)
    lh   $t2,10($s0)
    addi   $s0,$s0,0xC
    addi   $s3,$s3,0x4
    addi   $s4,$s4,0x2
    mfc2   $t3,$25
    mfc2   $t4,$26
    mfc2   $t5,$27
    add   $t0,$t0,$t3
    add   $t1,$t1,$t4
    add   $t2,$t2,$t5
    sh   $t0,-4($s3)
    sh   $t1,-2($s3)
    sh   $t2,-2($s4)
    bnez   $v1,.L8004DFB4
    addi   $v1,$v1,-0x1
.L8004E01C:
    lh   $v1,0($s0)
    nop
    beqz   $v1,.L8004E140
    addi   $s0,$s0,0x2
    addi   $v1,$v1,-0x1
.L8004E030:
    lhu   $t0,2($s0)
    lh   $t1,4($s0)
    lh   $t2,6($s0)
    sll   $t1,$t1,16
    or   $t1,$t1,$t0
    mtc2   $t1,$0
    mtc2   $t2,$1
    lh   $t0,0($s0)
    lh   $t3,8($s0)
    lh   $t4,10($s0)
    lh   $t5,12($s0)
    add   $t0,$t0,$t0
    addi   $t9,$s6,0x224
    add   $t9,$t9,$t0
    add   $t0,$t0,$t0
    add   $t8,$s6,$t0
    lh   $t0,0($t8)
    lh   $t1,2($t8)
    lh   $t2,0($t9)
    add   $t0,$t0,$t3
    add   $t1,$t1,$t4
    add   $t2,$t2,$t5
    lw   $t3,0($s2)
    lw   $t4,4($s2)
    lw   $t5,8($s2)
    lw   $t6,12($s2)
    lw   $t7,16($s2)
    ctc2   $t3,$0
    ctc2   $t4,$1
    ctc2   $t5,$2
    ctc2   $t6,$3
    ctc2   $t7,$4
    ctc2   $t0,$5
    ctc2   $t1,$6
    ctc2   $t2,$7
    nop
    nop
    mvmva   1,0,0,0,0
    lw   $t0,0($s7)
    lw   $t1,4($s7)
    lw   $t2,8($s7)
    lw   $t3,12($s7)
    lw   $t4,16($s7)
    ctc2   $t0,$0
    ctc2   $t1,$1
    ctc2   $t2,$2
    ctc2   $t3,$3
    ctc2   $t4,$4
    ctc2   $zero,$5
    ctc2   $zero,$6
    ctc2   $zero,$7
    mfc2   $t0,$25
    mfc2   $t1,$26
    mfc2   $t2,$27
    andi   $t0,$t0,0xFFFF
    sll   $t1,$t1,16
    or   $t1,$t1,$t0
    mtc2   $t1,$0
    mtc2   $t2,$1
    nop
    nop
    rtps
    addi   $s0,$s0,0xE
    mfc2   $t0,$19
    swc2   $14,0($t8)
    sh   $t0,0($t9)
    bnez   $v1,.L8004E030
    addi   $v1,$v1,-0x1
.L8004E140:
    lh   $v1,0($s0)
    nop
    beqz   $v1,.L8004E1DC
    addi   $s0,$s0,0x2
    addi   $v1,$v1,-0x1
    lw   $t0,852($s6)
    lw   $t1,856($s6)
    lw   $t2,860($s6)
    lw   $t3,864($s6)
    lw   $t4,868($s6)
    ctc2   $t0,$0
    ctc2   $t1,$1
    ctc2   $t2,$2
    ctc2   $t3,$3
    ctc2   $t4,$4
    ctc2   $zero,$5
    ctc2   $zero,$6
    ctc2   $zero,$7
.L8004E188:
    lhu   $t0,0($s0)
    lh   $t1,2($s0)
    lh   $t2,4($s0)
    sll   $t1,$t1,16
    or   $t1,$t1,$t0
    mtc2   $t1,$0
    mtc2   $t2,$1
    nop
    nop
    mvmva   1,0,0,0,0
    addi   $s0,$s0,0x6
    addi   $s3,$s3,0x4
    addi   $s4,$s4,0x2
    mfc2   $t0,$25
    mfc2   $t1,$26
    mfc2   $t2,$27
    sh   $t0,-4($s3)
    sh   $t1,-2($s3)
    sh   $t2,-2($s4)
    bnez   $v1,.L8004E188
    addi   $v1,$v1,-0x1
.L8004E1DC:
    lh   $v1,0($s0)
    nop
    beqz   $v1,.L8004E2A0
    addi   $s0,$s0,0x2
    lw   $t0,852($s6)
    lw   $t1,856($s6)
    lw   $t2,860($s6)
    lw   $t3,864($s6)
    lw   $t4,868($s6)
    ctc2   $t0,$0
    ctc2   $t1,$1
    ctc2   $t2,$2
    ctc2   $t3,$3
    ctc2   $t4,$4
    lw   $t3,884($s6)
    lw   $t4,888($s6)
    lw   $t5,892($s6)
    addi   $v1,$v1,-0x1
.L8004E224:
    lhu   $t0,2($s0)
    lh   $t1,4($s0)
    lh   $t2,6($s0)
    sll   $t1,$t1,16
    or   $t1,$t1,$t0
    lh   $t0,0($s0)
    mtc2   $t1,$0
    mtc2   $t2,$1
    add   $t0,$t0,$t0
    addi   $t9,$s6,0x224
    add   $t9,$t9,$t0
    add   $t0,$t0,$t0
    add   $t8,$s6,$t0
    lh   $t0,0($t8)
    lh   $t1,2($t8)
    lh   $t2,0($t9)
    add   $t0,$t0,$t3
    add   $t1,$t1,$t4
    add   $t2,$t2,$t5
    ctc2   $t0,$5
    ctc2   $t1,$6
    ctc2   $t2,$7
    nop
    nop
    rtps
    addi   $s0,$s0,0x8
    mfc2   $t0,$19
    swc2   $14,0($t8)
    sh   $t0,0($t9)
    bnez   $v1,.L8004E224
    addi   $v1,$v1,-0x1
.L8004E2A0:
    lh   $v1,0($s0)
    nop
    beqz   $v1,.L8004E428
    addi   $s0,$s0,0x2
    lw   $t0,852($s6)
    lw   $t1,856($s6)
    lw   $t2,860($s6)
    lw   $t3,864($s6)
    lw   $t4,868($s6)
    lw   $t5,884($s6)
    lw   $t6,888($s6)
    lw   $t7,892($s6)
    ctc2   $t0,$0
    ctc2   $t1,$1
    ctc2   $t2,$2
    ctc2   $t3,$3
    ctc2   $t4,$4
    ctc2   $t5,$5
    ctc2   $t6,$6
    ctc2   $t7,$7
    addiu   $v1,$v1,-0x3
    lhu   $t0,0($s0)
    lh   $t1,2($s0)
    lh   $t2,4($s0)
    sll   $t1,$t1,16
    or   $t1,$t1,$t0
    mtc2   $t1,$0
    mtc2   $t2,$1
    lhu   $t0,6($s0)
    lh   $t1,8($s0)
    lh   $t2,10($s0)
    sll   $t1,$t1,16
    or   $t1,$t1,$t0
    mtc2   $t1,$2
    mtc2   $t2,$3
    lhu   $t0,12($s0)
    lh   $t1,14($s0)
    lh   $t2,16($s0)
    sll   $t1,$t1,16
    or   $t1,$t1,$t0
    mtc2   $t1,$4
    mtc2   $t2,$5
    nop
    nop
    rtpt
    j   .L8004E370
    addiu   $s0,$s0,0x12
.L8004E35C:
    rtpt
    sh   $t0,0($s4)
    sh   $t1,2($s4)
    sh   $t2,4($s4)
    addiu   $s4,$s4,0x6
.L8004E370:
    blez   $v1,.L8004E3F4
    nop
    addiu   $v1,$v1,-0x3
    lhu   $t0,0($s0)
    lh   $t2,2($s0)
    lh   $t1,4($s0)
    sll   $t2,$t2,16
    or   $t0,$t0,$t2
    lhu   $t2,6($s0)
    lh   $t4,8($s0)
    lh   $t3,10($s0)
    sll   $t4,$t4,16
    or   $t2,$t2,$t4
    lhu   $t4,12($s0)
    lh   $t6,14($s0)
    lh   $t5,16($s0)
    sll   $t6,$t6,16
    or   $t4,$t4,$t6
    swc2   $12,0($s3)
    swc2   $13,4($s3)
    swc2   $14,8($s3)
    addiu   $s3,$s3,0xC
    mtc2   $t0,$0
    mtc2   $t1,$1
    mtc2   $t2,$2
    mtc2   $t3,$3
    mtc2   $t4,$4
    mtc2   $t5,$5
    mfc2   $t0,$17
    mfc2   $t1,$18
    mfc2   $t2,$19
    j   .L8004E35C
    addiu   $s0,$s0,0x12
.L8004E3F4:
    swc2   $12,0($s3)
    swc2   $13,4($s3)
    swc2   $14,8($s3)
    mfc2   $t0,$17
    mfc2   $t1,$18
    mfc2   $t2,$19
    sh   $t0,0($s4)
    sh   $t1,2($s4)
    sh   $t2,4($s4)
    add   $v1,$v1,$v1
    add   $t0,$v1,$v1
    add   $v1,$t0,$v1
    add   $s0,$s0,$v1
.L8004E428:
    addi   $s0,$s0,0x2
    addiu   $t1,$zero,0x4
    andi   $t0,$s0,0x3
    sub   $t0,$t1,$t0
    andi   $t0,$s0,0x3
    add   $s0,$s0,$t0
    addi   $s4,$s6,-0x20
    lw   $s3,28($s4)
.L8004E448:
    lh   $a0,0($s0)
    addi   $s0,$s0,0x2
    beqz   $a0,.L8004E480
    lhu   $t0,0($s0)
    addi   $s0,$s0,0x2
    sll   $t0,$t0,2
    add   $t0,$t0,$s3
    lw   $t0,0($t0)
    nop
    jalr   $t0
    nop
    nop
    j   .L8004E448
    nop
.L8004E480:
    beqz   $s5,.L8004E52C
    ori   $s2,$zero,0xFFFF
.L8004E488:
    lhu   $t0,0($s0)
    lhu   $t1,2($s0)
    beq   $t0,$s2,.L8004E500
    addu   $t4,$s6,$zero
    addi   $t6,$s6,0x224
    lh   $t3,4($s0)
    addu   $t5,$t4,$zero
    addu   $t7,$t6,$zero
    add   $t0,$t0,$t0
    add   $t1,$t1,$t1
    add   $t6,$t6,$t0
    add   $t7,$t7,$t1
    add   $t0,$t0,$t0
    add   $t1,$t1,$t1
    add   $t4,$t4,$t0
    add   $t5,$t5,$t1
    addi   $s0,$s0,0x6
    addi   $t3,$t3,-0x1
.L8004E4D0:
    lw   $t0,0($t4)
    lh   $t1,0($t6)
    sw   $t0,0($t5)
    sh   $t1,0($t7)
    addi   $t4,$t4,-0x4
    addi   $t5,$t5,0x4
    addi   $t6,$t6,-0x2
    addi   $t7,$t7,0x2
    bnez   $t3,.L8004E4D0
    addi   $t3,$t3,-0x1
    j   .L8004E488
    nop
.L8004E500:
    addi   $s0,$s0,0x2
    lh   $t0,0($s0)
    addu   $s3,$s6,$zero
    addi   $s4,$s6,0x224
    add   $t0,$t0,$t0
    add   $s4,$s4,$t0
    add   $t0,$t0,$t0
    add   $s3,$s3,$t0
    addi   $s0,$s0,0x2
    bgez   $zero,.L8004DE14
    addi   $s5,$s5,-0x1
.L8004E52C:
    addu   $v0,$s0,$zero
    lw   $ra,136($sp)
    lw   $fp,132($sp)
    lw   $s7,128($sp)
    lw   $s6,124($sp)
    lw   $s5,120($sp)
    lw   $s4,116($sp)
    lw   $s3,112($sp)
    lw   $s2,108($sp)
    lw   $s1,104($sp)
    lw   $s0,100($sp)
    jr   $ra
    addiu   $sp,$sp,0x8C
.set	reorder
.set	at
.set reorder
.set at

	.section .text
    nop

 #NO_APP
	.align	2
	.globl	func_8004E564
	.ent	func_8004E564
func_8004E564:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_8004E564
	.align	2
	.globl	func_8004E56C
	.ent	func_8004E56C
func_8004E56C:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_8004E56C
 #APP
	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_8004E574
    addiu   $sp,$sp,-0x38
    sw   $ra,48($sp)
    sw   $fp,44($sp)
    sw   $s7,40($sp)
    sw   $s6,36($sp)
    sw   $s5,32($sp)
    sw   $s4,28($sp)
    sw   $s3,24($sp)
    sw   $s2,20($sp)
    sw   $s1,16($sp)
    beqz   $a0,.L8004E7B0
    addiu   $s3,$a0,-0x1
    lui   $s1,0x1F80
    ori   $s1,$s1,32
    lui   $s2,0x1F80
    ori   $s2,$s2,580
    lui   $s4,0x1F80
    lw   $s4,12($s4)
    lui   $s5,0x700
    lui   $fp,0xFF
    ori   $fp,$fp,65535
    lui   $s6,%hi(D_800A38B4)
    lw   $s6,%lo(D_800A38B4)($s6)
    lui   $v1,0x1F80
    lw   $v1,8($v1)
.L8004E5D8:
    lw   $a0,12($s0)
    lwc2   $6,8($s0)
    sll   $a1,$a0,2
    andi   $t3,$a1,0x3FC
    addu   $a1,$t3,$s1
    lw   $t0,0($a1)
    srl   $a1,$a0,6
    andi   $t4,$a1,0x3FC
    addu   $a1,$t4,$s1
    lw   $t1,0($a1)
    srl   $a1,$a0,14
    andi   $t5,$a1,0x3FC
    addu   $a1,$t5,$s1
    lw   $t2,0($a1)
    mtc2   $t0,$12
    mtc2   $t1,$13
    mtc2   $t2,$14
    and   $t6,$t0,$t1
    and   $t6,$t6,$t2
    nclip
    bltz   $t6,.L8004E7A4
    mfc2   $v0,$24
    andi   $t6,$t6,0x8000
    bgez   $v0,.L8004E7A4
    nop
    bnez   $t6,.L8004E7A4
    srl   $v0,$t3,1
    addu   $v0,$v0,$s2
    lh   $a0,0($v0)
    srl   $v0,$t4,1
    addu   $v0,$v0,$s2
    lh   $a1,0($v0)
    srl   $v0,$t5,1
    addu   $v0,$v0,$s2
    lh   $a2,0($v0)
    mtc2   $a0,$17
    mtc2   $a1,$18
    mtc2   $a2,$19
    sw   $t0,8($s6)
    nop
    avsz3
    sw   $t1,16($s6)
    mfc2   $v0,$7
    sw   $t2,24($s6)
    blez   $v0,.L8004E7A4
    sll   $v0,$v0,2
    lw   $a0,16($s0)
    addiu   $t0,$zero,0x555
    mtc2   $t0,$8
    lui   $t0,%hi(D_800F2B70)
    addiu   $t0,$t0,%lo(D_800F2B70)
    srl   $t4,$a0,18
    andi   $t4,$t4,0xFFC
    add   $t4,$t4,$t0
    lw   $t4,0($t4)
    nop
    srl   $t2,$t4,4
    srl   $t3,$t4,12
    sll   $t1,$t4,4
    andi   $t1,$t1,0xFF0
    andi   $t2,$t2,0xFF0
    andi   $t3,$t3,0xFF0
    mtc2   $t1,$9
    mtc2   $t2,$10
    mtc2   $t3,$11
    srl   $t4,$a0,8
    andi   $t4,$t4,0xFFC
    add   $t4,$t4,$t0
    lw   $t4,0($t4)
    gpf   1
    srl   $t2,$t4,4
    srl   $t3,$t4,12
    sll   $t1,$t4,4
    andi   $t1,$t1,0xFF0
    andi   $t2,$t2,0xFF0
    andi   $t3,$t3,0xFF0
    sll   $t4,$a0,2
    andi   $t4,$t4,0xFFC
    mtc2   $t1,$9
    mtc2   $t2,$10
    mtc2   $t3,$11
    add   $t4,$t4,$t0
    lw   $t4,0($t4)
    gpl   1
    srl   $t2,$t4,4
    srl   $t3,$t4,12
    sll   $t1,$t4,4
    andi   $t1,$t1,0xFF0
    andi   $t2,$t2,0xFF0
    andi   $t3,$t3,0xFF0
    mtc2   $t1,$9
    mtc2   $t2,$10
    mtc2   $t3,$11
    srlv   $v0,$v0,$v1
    srl   $t0,$v0,11
    andi   $v0,$v0,0x7FF
    addi   $v0,$v0,-0x1000
    srav   $v0,$v0,$t0
    andi   $v0,$v0,0xFFF
    gpl   1
    lw   $t0,0($s0)
    lw   $t1,4($s0)
    lhu   $t2,8($s0)
    sw   $t0,12($s6)
    sw   $t1,20($s6)
    sh   $t2,28($s6)
    sll   $v0,$v0,2
    addu   $v0,$v0,$s4
    lw   $t1,0($v0)
    and   $t0,$s6,$fp
    sw   $t0,0($v0)
    or   $t1,$t1,$s5
    sw   $t1,0($s6)
    swc2   $22,4($s6)
    addiu   $s6,$s6,0x20
.L8004E7A4:
    addiu   $s0,$s0,0x14
    bnez   $s3,.L8004E5D8
    addiu   $s3,$s3,-0x1
.L8004E7B0:
    lui   $at,%hi(D_800A38B4)
    sw   $s6,%lo(D_800A38B4)($at)
    lw   $ra,48($sp)
    lw   $fp,44($sp)
    lw   $s7,40($sp)
    lw   $s6,36($sp)
    lw   $s5,32($sp)
    lw   $s4,28($sp)
    lw   $s3,24($sp)
    lw   $s2,20($sp)
    lw   $s1,16($sp)
    jr   $ra
    addiu   $sp,$sp,0x38
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_8004E7E4
    addiu   $sp,$sp,-0x38
    sw   $ra,48($sp)
    sw   $fp,44($sp)
    sw   $s7,40($sp)
    sw   $s6,36($sp)
    sw   $s5,32($sp)
    sw   $s4,28($sp)
    sw   $s3,24($sp)
    sw   $s2,20($sp)
    sw   $s1,16($sp)
    beqz   $a0,.L8004EA94
    addiu   $s3,$a0,-0x1
    lui   $s1,0x1F80
    ori   $s1,$s1,32
    lui   $s2,0x1F80
    ori   $s2,$s2,580
    lui   $s4,0x1F80
    lw   $s4,12($s4)
    lui   $s5,0x900
    lui   $fp,0xFF
    ori   $fp,$fp,65535
    lui   $s6,%hi(D_800A38B4)
    lw   $s6,%lo(D_800A38B4)($s6)
    lui   $v1,0x1F80
    lw   $v1,8($v1)
.L8004E848:
    lw   $a0,16($s0)
    lwc2   $6,8($s0)
    sll   $a1,$a0,2
    andi   $t3,$a1,0x3FC
    addu   $a1,$t3,$s1
    lw   $t0,0($a1)
    srl   $a1,$a0,6
    andi   $t4,$a1,0x3FC
    addu   $a1,$t4,$s1
    lw   $t1,0($a1)
    srl   $a1,$a0,14
    andi   $t5,$a1,0x3FC
    addu   $a1,$t5,$s1
    lw   $t2,0($a1)
    srl   $a1,$a0,22
    andi   $t6,$a1,0x3FC
    addu   $a1,$t6,$s1
    lw   $t7,0($a1)
    mtc2   $t0,$12
    mtc2   $t1,$13
    mtc2   $t2,$14
    and   $t8,$t0,$t1
    and   $t8,$t8,$t2
    and   $t8,$t8,$t7
    nclip
    bltz   $t8,.L8004EA88
    mfc2   $v0,$24
    andi   $t8,$t8,0x8000
    bgez   $v0,.L8004EA88
    nop
    bnez   $t8,.L8004EA88
    srl   $v0,$t3,1
    addu   $v0,$v0,$s2
    lh   $a0,0($v0)
    srl   $v0,$t4,1
    addu   $v0,$v0,$s2
    lh   $a1,0($v0)
    srl   $v0,$t5,1
    addu   $v0,$v0,$s2
    lh   $a2,0($v0)
    srl   $v0,$t6,1
    addu   $v0,$v0,$s2
    lh   $a3,0($v0)
    add   $a0,$a0,$a1
    add   $a0,$a0,$a2
    add   $a0,$a0,$a3
    sra   $v0,$a0,2
    blez   $v0,.L8004EA88
    nop
    sw   $t0,8($s6)
    sw   $t1,16($s6)
    sw   $t2,24($s6)
    sw   $t7,32($s6)
    lw   $a2,20($s0)
    lh   $a3,14($s0)
    addu   $a0,$a2,$zero
    andi   $a0,$a0,0x3FF
    srl   $a2,$a2,10
    addu   $a1,$a2,$zero
    andi   $a1,$a1,0x3FF
    srl   $a2,$a2,10
    andi   $a2,$a2,0x3FF
    addiu   $t0,$zero,0x400
    mtc2   $t0,$8
    lui   $t0,%hi(D_800F2B70)
    addiu   $t0,$t0,%lo(D_800F2B70)
    sll   $a0,$a0,2
    add   $a0,$a0,$t0
    lw   $t4,0($a0)
    nop
    srl   $t2,$t4,4
    srl   $t3,$t4,12
    sll   $t1,$t4,4
    andi   $t1,$t1,0xFF0
    andi   $t2,$t2,0xFF0
    andi   $t3,$t3,0xFF0
    mtc2   $t1,$9
    mtc2   $t2,$10
    mtc2   $t3,$11
    sll   $a1,$a1,2
    add   $a1,$a1,$t0
    lw   $t4,0($a1)
    gpf   1
    srl   $t2,$t4,4
    srl   $t3,$t4,12
    sll   $t1,$t4,4
    andi   $t1,$t1,0xFF0
    andi   $t2,$t2,0xFF0
    andi   $t3,$t3,0xFF0
    mtc2   $t1,$9
    mtc2   $t2,$10
    mtc2   $t3,$11
    sll   $a2,$a2,2
    add   $a2,$a2,$t0
    lw   $t4,0($a2)
    gpl   1
    srl   $t2,$t4,4
    srl   $t3,$t4,12
    sll   $t1,$t4,4
    andi   $t1,$t1,0xFF0
    andi   $t2,$t2,0xFF0
    andi   $t3,$t3,0xFF0
    mtc2   $t1,$9
    mtc2   $t2,$10
    mtc2   $t3,$11
    sll   $a3,$a3,2
    add   $a3,$a3,$t0
    lw   $t4,0($a3)
    gpl   1
    srl   $t2,$t4,4
    srl   $t3,$t4,12
    sll   $t1,$t4,4
    andi   $t1,$t1,0xFF0
    andi   $t2,$t2,0xFF0
    andi   $t3,$t3,0xFF0
    mtc2   $t1,$9
    mtc2   $t2,$10
    mtc2   $t3,$11
    nop
    nop
    gpl   1
    srlv   $v0,$v0,$v1
    srl   $t0,$v0,11
    andi   $v0,$v0,0x7FF
    addi   $v0,$v0,-0x1000
    srav   $v0,$v0,$t0
    andi   $v0,$v0,0xFFF
    lw   $t0,0($s0)
    lw   $t1,4($s0)
    lh   $t2,8($s0)
    lh   $t3,12($s0)
    sw   $t0,12($s6)
    sw   $t1,20($s6)
    sh   $t2,28($s6)
    sh   $t3,36($s6)
    sll   $v0,$v0,2
    addu   $v0,$v0,$s4
    lw   $t1,0($v0)
    and   $t0,$s6,$fp
    sw   $t0,0($v0)
    or   $t1,$t1,$s5
    sw   $t1,0($s6)
    swc2   $22,4($s6)
    addiu   $s6,$s6,0x28
.L8004EA88:
    addiu   $s0,$s0,0x18
    bnez   $s3,.L8004E848
    addiu   $s3,$s3,-0x1
.L8004EA94:
    lui   $at,%hi(D_800A38B4)
    sw   $s6,%lo(D_800A38B4)($at)
    lw   $ra,48($sp)
    lw   $fp,44($sp)
    lw   $s7,40($sp)
    lw   $s6,36($sp)
    lw   $s5,32($sp)
    lw   $s4,28($sp)
    lw   $s3,24($sp)
    lw   $s2,20($sp)
    lw   $s1,16($sp)
    jr   $ra
    addiu   $sp,$sp,0x38
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_8004EAC8
    addiu   $sp,$sp,-0x38
    sw   $ra,48($sp)
    sw   $fp,44($sp)
    sw   $s7,40($sp)
    sw   $s6,36($sp)
    sw   $s5,32($sp)
    sw   $s4,28($sp)
    sw   $s3,24($sp)
    sw   $s2,20($sp)
    sw   $s1,16($sp)
    beqz   $a0,.L8004EC94
    addiu   $s3,$a0,-0x1
    lui   $s1,0x1F80
    ori   $s1,$s1,32
    lui   $s2,0x1F80
    ori   $s2,$s2,580
    lui   $s4,0x1F80
    lw   $s4,12($s4)
    lui   $s5,0x900
    lui   $fp,0xFF
    ori   $fp,$fp,65535
    lui   $s6,%hi(D_800A38B4)
    lw   $s6,%lo(D_800A38B4)($s6)
    lui   $v1,0x1F80
    lw   $v1,8($v1)
.L8004EB2C:
    lw   $a0,12($s0)
    nop
    sll   $a1,$a0,2
    andi   $t3,$a1,0x3FC
    addu   $a1,$t3,$s1
    lw   $t0,0($a1)
    srl   $a1,$a0,6
    andi   $t4,$a1,0x3FC
    addu   $a1,$t4,$s1
    lw   $t1,0($a1)
    srl   $a1,$a0,14
    andi   $t5,$a1,0x3FC
    addu   $a1,$t5,$s1
    lw   $t2,0($a1)
    mtc2   $t0,$12
    mtc2   $t1,$13
    mtc2   $t2,$14
    and   $t6,$t0,$t1
    and   $t6,$t6,$t2
    nclip
    bltz   $t6,.L8004EC88
    mfc2   $v0,$24
    andi   $t6,$t6,0x8000
    bgez   $v0,.L8004EC88
    nop
    bnez   $t6,.L8004EC88
    srl   $v0,$t3,1
    addu   $v0,$v0,$s2
    lh   $a0,0($v0)
    srl   $v0,$t4,1
    addu   $v0,$v0,$s2
    lh   $a1,0($v0)
    srl   $v0,$t5,1
    addu   $v0,$v0,$s2
    lh   $a2,0($v0)
    mtc2   $a0,$17
    mtc2   $a1,$18
    mtc2   $a2,$19
    sw   $t0,8($s6)
    nop
    avsz3
    sw   $t1,20($s6)
    mfc2   $v0,$7
    sw   $t2,32($s6)
    blez   $v0,.L8004EC88
    sll   $v0,$v0,2
    lw   $a0,16($s0)
    lui   $t0,%hi(D_800F2B70)
    addiu   $t0,$t0,%lo(D_800F2B70)
    srl   $t1,$a0,18
    srl   $t2,$a0,8
    sll   $a0,$a0,2
    andi   $t1,$t1,0xFFC
    andi   $t2,$t2,0xFFC
    andi   $a0,$a0,0xFFC
    add   $t1,$t1,$t0
    add   $t2,$t2,$t0
    add   $a0,$a0,$t0
    lw   $t0,0($t1)
    lw   $t1,0($t2)
    lw   $t2,0($a0)
    lui   $a0,0x3400
    or   $t0,$t0,$a0
    sw   $t0,4($s6)
    sw   $t1,16($s6)
    sw   $t2,28($s6)
    srlv   $v0,$v0,$v1
    srl   $t0,$v0,11
    andi   $v0,$v0,0x7FF
    addi   $v0,$v0,-0x1000
    srav   $v0,$v0,$t0
    andi   $v0,$v0,0xFFF
    lw   $t0,0($s0)
    lw   $t1,4($s0)
    lh   $t2,8($s0)
    sw   $t0,12($s6)
    sw   $t1,24($s6)
    sh   $t2,36($s6)
    sll   $v0,$v0,2
    addu   $v0,$v0,$s4
    lw   $t1,0($v0)
    and   $t0,$s6,$fp
    sw   $t0,0($v0)
    or   $t1,$t1,$s5
    sw   $t1,0($s6)
    nop
    addiu   $s6,$s6,0x28
.L8004EC88:
    addiu   $s0,$s0,0x14
    bnez   $s3,.L8004EB2C
    addiu   $s3,$s3,-0x1
.L8004EC94:
    lui   $at,%hi(D_800A38B4)
    sw   $s6,%lo(D_800A38B4)($at)
    lw   $ra,48($sp)
    lw   $fp,44($sp)
    lw   $s7,40($sp)
    lw   $s6,36($sp)
    lw   $s5,32($sp)
    lw   $s4,28($sp)
    lw   $s3,24($sp)
    lw   $s2,20($sp)
    lw   $s1,16($sp)
    jr   $ra
    addiu   $sp,$sp,0x38
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_8004ECC8
    addiu   $sp,$sp,-0x38
    sw   $ra,48($sp)
    sw   $fp,44($sp)
    sw   $s7,40($sp)
    sw   $s6,36($sp)
    sw   $s5,32($sp)
    sw   $s4,28($sp)
    sw   $s3,24($sp)
    sw   $s2,20($sp)
    sw   $s1,16($sp)
    beqz   $a0,.L8004EEDC
    addiu   $s3,$a0,-0x1
    lui   $s1,0x1F80
    ori   $s1,$s1,32
    lui   $s2,0x1F80
    ori   $s2,$s2,580
    lui   $s4,0x1F80
    lw   $s4,12($s4)
    lui   $s5,0xC00
    lui   $fp,0xFF
    ori   $fp,$fp,65535
    lui   $s6,%hi(D_800A38B4)
    lw   $s6,%lo(D_800A38B4)($s6)
    lui   $v1,0x1F80
    lw   $v1,8($v1)
.L8004ED2C:
    lw   $a0,16($s0)
    nop
    sll   $a1,$a0,2
    andi   $t3,$a1,0x3FC
    addu   $a1,$t3,$s1
    lw   $t0,0($a1)
    srl   $a1,$a0,6
    andi   $t4,$a1,0x3FC
    addu   $a1,$t4,$s1
    lw   $t1,0($a1)
    srl   $a1,$a0,14
    andi   $t5,$a1,0x3FC
    addu   $a1,$t5,$s1
    lw   $t2,0($a1)
    srl   $a1,$a0,22
    andi   $t6,$a1,0x3FC
    addu   $a1,$t6,$s1
    lw   $t7,0($a1)
    mtc2   $t0,$12
    mtc2   $t1,$13
    mtc2   $t2,$14
    and   $t8,$t0,$t1
    and   $t8,$t8,$t2
    and   $t8,$t8,$t7
    nclip
    bltz   $t8,.L8004EED0
    mfc2   $v0,$24
    andi   $t8,$t8,0x8000
    bgez   $v0,.L8004EED0
    nop
    bnez   $t8,.L8004EED0
    srl   $v0,$t3,1
    addu   $v0,$v0,$s2
    lh   $a0,0($v0)
    srl   $v0,$t4,1
    addu   $v0,$v0,$s2
    lh   $a1,0($v0)
    srl   $v0,$t5,1
    addu   $v0,$v0,$s2
    lh   $a2,0($v0)
    srl   $v0,$t6,1
    addu   $v0,$v0,$s2
    lh   $a3,0($v0)
    add   $a0,$a0,$a1
    add   $a0,$a0,$a2
    add   $a0,$a0,$a3
    sra   $v0,$a0,2
    blez   $v0,.L8004EED0
    nop
    sw   $t0,8($s6)
    sw   $t1,20($s6)
    sw   $t2,32($s6)
    sw   $t7,44($s6)
    lw   $a2,20($s0)
    lh   $a3,14($s0)
    addu   $a0,$a2,$zero
    andi   $a0,$a0,0x3FF
    srl   $a2,$a2,10
    addu   $a1,$a2,$zero
    andi   $a1,$a1,0x3FF
    srl   $a2,$a2,10
    andi   $a2,$a2,0x3FF
    lui   $t0,%hi(D_800F2B70)
    addiu   $t0,$t0,%lo(D_800F2B70)
    sll   $a0,$a0,2
    sll   $a1,$a1,2
    sll   $a2,$a2,2
    sll   $a3,$a3,2
    add   $a0,$a0,$t0
    add   $a1,$a1,$t0
    add   $a2,$a2,$t0
    add   $a3,$a3,$t0
    lw   $t0,0($a0)
    lw   $t1,0($a1)
    lw   $t2,0($a2)
    lw   $t3,0($a3)
    lui   $a0,0x3C00
    or   $t0,$t0,$a0
    sw   $t0,4($s6)
    sw   $t1,16($s6)
    sw   $t2,28($s6)
    sw   $t3,40($s6)
    srlv   $v0,$v0,$v1
    srl   $t0,$v0,11
    andi   $v0,$v0,0x7FF
    addi   $v0,$v0,-0x1000
    srav   $v0,$v0,$t0
    andi   $v0,$v0,0xFFF
    lw   $t0,0($s0)
    lw   $t1,4($s0)
    lh   $t2,8($s0)
    lh   $t3,12($s0)
    sw   $t0,12($s6)
    sw   $t1,24($s6)
    sh   $t2,36($s6)
    sh   $t3,48($s6)
    sll   $v0,$v0,2
    addu   $v0,$v0,$s4
    lw   $t1,0($v0)
    and   $t0,$s6,$fp
    sw   $t0,0($v0)
    or   $t1,$t1,$s5
    sw   $t1,0($s6)
    nop
    addiu   $s6,$s6,0x34
.L8004EED0:
    addiu   $s0,$s0,0x18
    bnez   $s3,.L8004ED2C
    addiu   $s3,$s3,-0x1
.L8004EEDC:
    lui   $at,%hi(D_800A38B4)
    sw   $s6,%lo(D_800A38B4)($at)
    lw   $ra,48($sp)
    lw   $fp,44($sp)
    lw   $s7,40($sp)
    lw   $s6,36($sp)
    lw   $s5,32($sp)
    lw   $s4,28($sp)
    lw   $s3,24($sp)
    lw   $s2,20($sp)
    lw   $s1,16($sp)
    jr   $ra
    addiu   $sp,$sp,0x38
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_8004EF10
    addiu   $sp,$sp,-0x38
    sw   $ra,44($sp)
    sw   $fp,40($sp)
    sw   $s6,36($sp)
    sw   $s5,32($sp)
    sw   $s4,28($sp)
    sw   $s3,24($sp)
    sw   $s2,20($sp)
    sw   $s1,16($sp)
    beqz   $a0,.L8004F0CC
    addiu   $s3,$a0,-0x1
    lui   $s1,0x1F80
    ori   $s1,$s1,32
    lui   $s2,0x1F80
    ori   $s2,$s2,692
    lui   $s4,0x1F80
    lw   $s4,12($s4)
    lui   $s5,0x700
    lui   $fp,0xFF
    ori   $fp,$fp,65535
    lui   $s6,%hi(D_800A38B4)
    lw   $s6,%lo(D_800A38B4)($s6)
    lui   $v1,0x1F80
    lw   $v1,8($v1)
.L8004EF70:
    lw   $a0,12($s0)
    lwc2   $6,0($s0)
    sll   $a1,$a0,2
    andi   $t3,$a1,0x3FC
    addu   $a1,$t3,$s1
    lw   $t0,0($a1)
    srl   $a1,$a0,6
    andi   $t4,$a1,0x3FC
    addu   $a1,$t4,$s1
    lw   $t1,0($a1)
    srl   $a1,$a0,14
    andi   $t5,$a1,0x3FC
    addu   $a1,$t5,$s1
    lw   $t2,0($a1)
    mtc2   $t0,$12
    mtc2   $t1,$13
    mtc2   $t2,$14
    and   $t6,$t0,$t1
    and   $t6,$t6,$t2
    nclip
    bltz   $t6,.L8004F0C0
    mfc2   $v0,$24
    andi   $t6,$t6,0x8000
    bnez   $t6,.L8004F0C0
    slt   $a3,$v0,$zero
    addi   $a3,$a3,-0x1
    srl   $v0,$t3,1
    addu   $v0,$v0,$s2
    lh   $a0,0($v0)
    srl   $v0,$t4,1
    addu   $v0,$v0,$s2
    lh   $a1,0($v0)
    srl   $v0,$t5,1
    addu   $v0,$v0,$s2
    lh   $a2,0($v0)
    mtc2   $a0,$17
    mtc2   $a1,$18
    mtc2   $a2,$19
    sw   $t0,8($s6)
    nop
    avsz3
    sw   $t1,16($s6)
    mfc2   $v0,$7
    sw   $t2,24($s6)
    blez   $v0,.L8004F0C0
    sll   $v0,$v0,2
    lui   $at,0x1
    slt   $t9,$v0,$at
    beqz   $t9,.L8004F0C0
    nop
    lw   $t0,16($s0)
    lw   $t1,20($s0)
    xor   $t0,$t0,$a3
    mtc2   $t0,$0
    xor   $t1,$t1,$a3
    mtc2   $t1,$1
    srlv   $v0,$v0,$v1
    srl   $t0,$v0,11
    andi   $v0,$v0,0x7FF
    addi   $v0,$v0,-0x1000
    srav   $v0,$v0,$t0
    andi   $v0,$v0,0xFFF
    ncs
    lh   $t4,4($s0)
    lh   $t5,0($s0)
    sll   $t4,$t4,16
    sll   $t5,$t5,16
    swc2   $22,4($s6)
    lhu   $t0,6($s0)
    lhu   $t1,8($s0)
    lhu   $t2,10($s0)
    or   $t0,$t0,$t4
    or   $t1,$t1,$t5
    sw   $t0,12($s6)
    sw   $t1,20($s6)
    sh   $t2,28($s6)
    sll   $v0,$v0,2
    addu   $v0,$v0,$s4
    lw   $t1,0($v0)
    and   $t0,$s6,$fp
    sw   $t0,0($v0)
    or   $t1,$t1,$s5
    sw   $t1,0($s6)
    addiu   $s6,$s6,0x20
.L8004F0C0:
    addiu   $s0,$s0,0x18
    bnez   $s3,.L8004EF70
    addiu   $s3,$s3,-0x1
.L8004F0CC:
    lui   $at,%hi(D_800A38B4)
    sw   $s6,%lo(D_800A38B4)($at)
    lw   $ra,44($sp)
    lw   $fp,40($sp)
    lw   $s6,36($sp)
    lw   $s5,32($sp)
    lw   $s4,28($sp)
    lw   $s3,24($sp)
    lw   $s2,20($sp)
    lw   $s1,16($sp)
    jr   $ra
    addiu   $sp,$sp,0x38
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_8004F0FC
    addiu   $sp,$sp,-0x38
    sw   $ra,44($sp)
    sw   $fp,40($sp)
    sw   $s6,36($sp)
    sw   $s5,32($sp)
    sw   $s4,28($sp)
    sw   $s3,24($sp)
    sw   $s2,20($sp)
    sw   $s1,16($sp)
    beqz   $a0,.L8004F2E4
    addiu   $s3,$a0,-0x1
    lui   $s1,0x1F80
    ori   $s1,$s1,32
    lui   $s2,0x1F80
    ori   $s2,$s2,692
    lui   $s4,0x1F80
    lw   $s4,12($s4)
    lui   $s5,0x900
    lui   $fp,0xFF
    ori   $fp,$fp,65535
    lui   $s6,%hi(D_800A38B4)
    lw   $s6,%lo(D_800A38B4)($s6)
    lui   $v1,0x1F80
    lw   $v1,8($v1)
.L8004F15C:
    lhu   $a0,14($s0)
    lhu   $a1,16($s0)
    lwc2   $6,0($s0)
    sll   $a1,$a1,16
    or   $a0,$a0,$a1
    sll   $a1,$a0,2
    andi   $t3,$a1,0x3FC
    addu   $a1,$t3,$s1
    lw   $t0,0($a1)
    srl   $a1,$a0,6
    andi   $t4,$a1,0x3FC
    addu   $a1,$t4,$s1
    lw   $t1,0($a1)
    srl   $a1,$a0,14
    andi   $t5,$a1,0x3FC
    addu   $a1,$t5,$s1
    lw   $t2,0($a1)
    srl   $a1,$a0,22
    andi   $t6,$a1,0x3FC
    addu   $a1,$t6,$s1
    lw   $t7,0($a1)
    mtc2   $t0,$12
    mtc2   $t1,$13
    mtc2   $t2,$14
    and   $t8,$t0,$t1
    and   $t8,$t8,$t2
    and   $t8,$t8,$t7
    nclip
    bltz   $t8,.L8004F2D8
    mfc2   $v0,$24
    andi   $t8,$t8,0x8000
    bnez   $t8,.L8004F2D8
    slt   $a3,$v0,$zero
    addi   $a3,$a3,-0x1
    srl   $v0,$t3,1
    addu   $v0,$v0,$s2
    lh   $a0,0($v0)
    srl   $v0,$t4,1
    addu   $v0,$v0,$s2
    lh   $a1,0($v0)
    srl   $v0,$t5,1
    addu   $v0,$v0,$s2
    lh   $a2,0($v0)
    srl   $v0,$t6,1
    addu   $v0,$v0,$s2
    lh   $t3,0($v0)
    add   $a0,$a0,$a1
    add   $a0,$a0,$a2
    add   $a0,$a0,$t3
    sra   $v0,$a0,2
    blez   $v0,.L8004F2D8
    lui   $at,0x1
    slt   $t9,$v0,$at
    beqz   $t9,.L8004F2D8
    nop
    sw   $t0,8($s6)
    sw   $t1,16($s6)
    sw   $t2,24($s6)
    sw   $t7,32($s6)
    lhu   $t0,18($s0)
    lw   $t1,20($s0)
    xor   $t0,$t0,$a3
    mtc2   $t0,$1
    xor   $t1,$t1,$a3
    mtc2   $t1,$0
    srlv   $v0,$v0,$v1
    srl   $t0,$v0,11
    andi   $v0,$v0,0x7FF
    addi   $v0,$v0,-0x1000
    srav   $v0,$v0,$t0
    andi   $v0,$v0,0xFFF
    ncs
    lh   $t4,4($s0)
    lh   $t5,0($s0)
    sll   $t4,$t4,16
    sll   $t5,$t5,16
    swc2   $22,4($s6)
    lhu   $t0,6($s0)
    lhu   $t1,8($s0)
    lhu   $t2,10($s0)
    lhu   $t3,12($s0)
    or   $t0,$t0,$t4
    or   $t1,$t1,$t5
    sw   $t0,12($s6)
    sw   $t1,20($s6)
    sh   $t2,28($s6)
    sh   $t3,36($s6)
    sll   $v0,$v0,2
    addu   $v0,$v0,$s4
    lw   $t1,0($v0)
    and   $t0,$s6,$fp
    sw   $t0,0($v0)
    or   $t1,$t1,$s5
    sw   $t1,0($s6)
    addiu   $s6,$s6,0x28
.L8004F2D8:
    addiu   $s0,$s0,0x18
    bnez   $s3,.L8004F15C
    addiu   $s3,$s3,-0x1
.L8004F2E4:
    lui   $at,%hi(D_800A38B4)
    sw   $s6,%lo(D_800A38B4)($at)
    lw   $ra,44($sp)
    lw   $fp,40($sp)
    lw   $s6,36($sp)
    lw   $s5,32($sp)
    lw   $s4,28($sp)
    lw   $s3,24($sp)
    lw   $s2,20($sp)
    lw   $s1,16($sp)
    jr   $ra
    addiu   $sp,$sp,0x38
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_8004F314
    addiu   $sp,$sp,-0x38
    sw   $ra,44($sp)
    sw   $fp,40($sp)
    sw   $s6,36($sp)
    sw   $s5,32($sp)
    sw   $s4,28($sp)
    sw   $s3,24($sp)
    sw   $s2,20($sp)
    sw   $s1,16($sp)
    beqz   $a0,.L8004F50C
    addiu   $s3,$a0,-0x1
    lui   $s1,0x1F80
    ori   $s1,$s1,32
    lui   $s2,0x1F80
    ori   $s2,$s2,692
    lui   $s4,0x1F80
    lw   $s4,12($s4)
    lui   $s5,0x900
    lui   $fp,0xFF
    ori   $fp,$fp,65535
    lui   $s6,%hi(D_800A38B4)
    lw   $s6,%lo(D_800A38B4)($s6)
    lui   $v1,0x1F80
    lw   $v1,8($v1)
    lwc2   $6,0($s0)
.L8004F378:
    lw   $a0,12($s0)
    nop
    sll   $a1,$a0,2
    andi   $t3,$a1,0x3FC
    addu   $a1,$t3,$s1
    lw   $t0,0($a1)
    srl   $a1,$a0,6
    andi   $t4,$a1,0x3FC
    addu   $a1,$t4,$s1
    lw   $t1,0($a1)
    srl   $a1,$a0,14
    andi   $t5,$a1,0x3FC
    addu   $a1,$t5,$s1
    lw   $t2,0($a1)
    mtc2   $t0,$12
    mtc2   $t1,$13
    mtc2   $t2,$14
    and   $t6,$t0,$t1
    and   $t6,$t6,$t2
    nclip
    bltz   $t6,.L8004F500
    mfc2   $v0,$24
    andi   $t6,$t6,0x8000
    bnez   $t6,.L8004F500
    slt   $a3,$v0,$zero
    addi   $a3,$a3,-0x1
    srl   $v0,$t3,1
    addu   $v0,$v0,$s2
    lh   $a0,0($v0)
    srl   $v0,$t4,1
    addu   $v0,$v0,$s2
    lh   $a1,0($v0)
    srl   $v0,$t5,1
    addu   $v0,$v0,$s2
    lh   $a2,0($v0)
    mtc2   $a0,$17
    mtc2   $a1,$18
    mtc2   $a2,$19
    sw   $t0,8($s6)
    nop
    avsz3
    sw   $t1,20($s6)
    mfc2   $v0,$7
    sw   $t2,32($s6)
    blez   $v0,.L8004F500
    sll   $v0,$v0,2
    lui   $at,0x1
    slt   $t9,$v0,$at
    beqz   $t9,.L8004F500
    nop
    lw   $t0,16($s0)
    lw   $t1,20($s0)
    xor   $t0,$t0,$a3
    xor   $t1,$t1,$a3
    mtc2   $t0,$0
    mtc2   $t1,$1
    lw   $t2,24($s0)
    srl   $t1,$t1,16
    xor   $t2,$t2,$a3
    mtc2   $t2,$2
    mtc2   $t1,$3
    lw   $t0,28($s0)
    lw   $t1,32($s0)
    xor   $t0,$t0,$a3
    xor   $t1,$t1,$a3
    mtc2   $t0,$4
    mtc2   $t1,$5
    srlv   $v0,$v0,$v1
    srl   $t0,$v0,11
    andi   $v0,$v0,0x7FF
    addi   $v0,$v0,-0x1000
    srav   $v0,$v0,$t0
    andi   $v0,$v0,0xFFF
    nct
    lh   $t4,4($s0)
    lh   $t5,0($s0)
    sll   $t4,$t4,16
    sll   $t5,$t5,16
    lhu   $t0,6($s0)
    lhu   $t1,8($s0)
    lhu   $t2,10($s0)
    or   $t0,$t0,$t4
    or   $t1,$t1,$t5
    sw   $t0,12($s6)
    sw   $t1,24($s6)
    sh   $t2,36($s6)
    sll   $v0,$v0,2
    addu   $v0,$v0,$s4
    lw   $t1,0($v0)
    and   $t0,$s6,$fp
    sw   $t0,0($v0)
    or   $t1,$t1,$s5
    sw   $t1,0($s6)
    swc2   $20,4($s6)
    swc2   $21,16($s6)
    swc2   $22,28($s6)
    nop
    addiu   $s6,$s6,0x28
.L8004F500:
    addiu   $s0,$s0,0x24
    bnez   $s3,.L8004F378
    addiu   $s3,$s3,-0x1
.L8004F50C:
    lui   $at,%hi(D_800A38B4)
    sw   $s6,%lo(D_800A38B4)($at)
    lw   $ra,44($sp)
    lw   $fp,40($sp)
    lw   $s6,36($sp)
    lw   $s5,32($sp)
    lw   $s4,28($sp)
    lw   $s3,24($sp)
    lw   $s2,20($sp)
    lw   $s1,16($sp)
    jr   $ra
    addiu   $sp,$sp,0x38
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_8004F53C
    addiu   $sp,$sp,-0x38
    sw   $ra,44($sp)
    sw   $fp,40($sp)
    sw   $s6,36($sp)
    sw   $s5,32($sp)
    sw   $s4,28($sp)
    sw   $s3,24($sp)
    sw   $s2,20($sp)
    sw   $s1,16($sp)
    beqz   $a0,.L8004F768
    addiu   $s3,$a0,-0x1
    lui   $s1,0x1F80
    ori   $s1,$s1,32
    lui   $s2,0x1F80
    ori   $s2,$s2,692
    lui   $s4,0x1F80
    lw   $s4,12($s4)
    lui   $s5,0xC00
    lui   $fp,0xFF
    ori   $fp,$fp,65535
    lui   $s6,%hi(D_800A38B4)
    lw   $s6,%lo(D_800A38B4)($s6)
    lui   $v1,0x1F80
    lw   $v1,8($v1)
    lwc2   $6,0($s0)
.L8004F5A0:
    lw   $a0,16($s0)
    nop
    sll   $a1,$a0,2
    andi   $t3,$a1,0x3FC
    addu   $a1,$t3,$s1
    lw   $t0,0($a1)
    srl   $a1,$a0,6
    andi   $t4,$a1,0x3FC
    addu   $a1,$t4,$s1
    lw   $t1,0($a1)
    srl   $a1,$a0,14
    andi   $t5,$a1,0x3FC
    addu   $a1,$t5,$s1
    lw   $t2,0($a1)
    srl   $a1,$a0,22
    andi   $t6,$a1,0x3FC
    addu   $a1,$t6,$s1
    lw   $t7,0($a1)
    mtc2   $t0,$12
    mtc2   $t1,$13
    mtc2   $t2,$14
    and   $t8,$t0,$t1
    and   $t8,$t8,$t2
    and   $t8,$t8,$t7
    nclip
    bltz   $t8,.L8004F75C
    mfc2   $v0,$24
    andi   $t8,$t8,0x8000
    bnez   $t8,.L8004F75C
    slt   $a3,$v0,$zero
    addi   $a3,$a3,-0x1
    srl   $v0,$t3,1
    addu   $v0,$v0,$s2
    lh   $a0,0($v0)
    srl   $v0,$t4,1
    addu   $v0,$v0,$s2
    lh   $a1,0($v0)
    srl   $v0,$t5,1
    addu   $v0,$v0,$s2
    lh   $a2,0($v0)
    srl   $v0,$t6,1
    addu   $v0,$v0,$s2
    lh   $t3,0($v0)
    add   $a0,$a0,$a1
    add   $a0,$a0,$a2
    add   $a0,$a0,$t3
    sra   $v0,$a0,2
    blez   $v0,.L8004F75C
    lui   $at,0x1
    slt   $t9,$v0,$at
    beqz   $t9,.L8004F75C
    nop
    sw   $t0,8($s6)
    sw   $t1,20($s6)
    sw   $t2,32($s6)
    sw   $t7,44($s6)
    lw   $t2,20($s0)
    lw   $t1,24($s0)
    xor   $t2,$t2,$a3
    xor   $t1,$t1,$a3
    mtc2   $t2,$0
    mtc2   $t1,$1
    srlv   $v0,$v0,$v1
    srl   $t0,$v0,11
    andi   $v0,$v0,0x7FF
    ncs
    addi   $v0,$v0,-0x1000
    srav   $v0,$v0,$t0
    andi   $v0,$v0,0xFFF
    swc2   $22,4($s6)
    lw   $t0,28($s0)
    srl   $t1,$t1,16
    mtc2   $t0,$0
    mtc2   $t1,$1
    lw   $t2,32($s0)
    lw   $t1,36($s0)
    xor   $t2,$t2,$a3
    xor   $t1,$t1,$a3
    mtc2   $t2,$2
    mtc2   $t1,$3
    lw   $t0,40($s0)
    srl   $t1,$t1,16
    mtc2   $t0,$4
    mtc2   $t1,$5
    lh   $t4,4($s0)
    lh   $t5,0($s0)
    sll   $t4,$t4,16
    sll   $t5,$t5,16
    nct
    lhu   $t0,6($s0)
    lhu   $t1,8($s0)
    lhu   $t2,10($s0)
    lhu   $t3,12($s0)
    or   $t0,$t0,$t4
    or   $t1,$t1,$t5
    sw   $t0,12($s6)
    sw   $t1,24($s6)
    sh   $t2,36($s6)
    sh   $t3,48($s6)
    sll   $v0,$v0,2
    addu   $v0,$v0,$s4
    lw   $t1,0($v0)
    and   $t0,$s6,$fp
    sw   $t0,0($v0)
    or   $t1,$t1,$s5
    sw   $t1,0($s6)
    swc2   $20,16($s6)
    swc2   $21,28($s6)
    swc2   $22,40($s6)
    nop
    addiu   $s6,$s6,0x34
.L8004F75C:
    addiu   $s0,$s0,0x2C
    bnez   $s3,.L8004F5A0
    addiu   $s3,$s3,-0x1
.L8004F768:
    lui   $at,%hi(D_800A38B4)
    sw   $s6,%lo(D_800A38B4)($at)
    lw   $ra,44($sp)
    lw   $fp,40($sp)
    lw   $s6,36($sp)
    lw   $s5,32($sp)
    lw   $s4,28($sp)
    lw   $s3,24($sp)
    lw   $s2,20($sp)
    lw   $s1,16($sp)
    jr   $ra
    addiu   $sp,$sp,0x38
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_8004F798
    addiu   $sp,$sp,-0x38
    sw   $ra,44($sp)
    sw   $fp,40($sp)
    sw   $s6,36($sp)
    sw   $s5,32($sp)
    sw   $s4,28($sp)
    sw   $s3,24($sp)
    sw   $s2,20($sp)
    sw   $s1,16($sp)
    beqz   $a0,.L8004F940
    addiu   $s3,$a0,-0x1
    lui   $s1,0x1F80
    ori   $s1,$s1,32
    lui   $s2,0x1F80
    ori   $s2,$s2,692
    lui   $s4,0x1F80
    lw   $s4,12($s4)
    lui   $s5,0x700
    lui   $fp,0xFF
    ori   $fp,$fp,65535
    lui   $s6,%hi(D_800A38B4)
    lw   $s6,%lo(D_800A38B4)($s6)
    lui   $v1,0x1F80
    lw   $v1,8($v1)
.L8004F7F8:
    lw   $a0,12($s0)
    nop
    sll   $a1,$a0,2
    andi   $t3,$a1,0x3FC
    addu   $a1,$t3,$s1
    lw   $t0,0($a1)
    srl   $a1,$a0,6
    andi   $t4,$a1,0x3FC
    addu   $a1,$t4,$s1
    lw   $t1,0($a1)
    srl   $a1,$a0,14
    andi   $t5,$a1,0x3FC
    addu   $a1,$t5,$s1
    lw   $t2,0($a1)
    mtc2   $t0,$12
    mtc2   $t1,$13
    mtc2   $t2,$14
    and   $t6,$t0,$t1
    and   $t6,$t6,$t2
    nclip
    bltz   $t6,.L8004F934
    mfc2   $v0,$24
    andi   $t6,$t6,0x8000
    bgez   $v0,.L8004F934
    nop
    bnez   $t6,.L8004F934
    srl   $v0,$t3,1
    addu   $v0,$v0,$s2
    lh   $a0,0($v0)
    srl   $v0,$t4,1
    addu   $v0,$v0,$s2
    lh   $a1,0($v0)
    srl   $v0,$t5,1
    addu   $v0,$v0,$s2
    lh   $a2,0($v0)
    mtc2   $a0,$17
    mtc2   $a1,$18
    mtc2   $a2,$19
    sw   $t0,8($s6)
    nop
    avsz3
    sw   $t1,16($s6)
    mfc2   $v0,$7
    sw   $t2,24($s6)
    blez   $v0,.L8004F934
    sll   $v0,$v0,2
    srlv   $v0,$v0,$v1
    srl   $t0,$v0,11
    andi   $v0,$v0,0x7FF
    lui   $a0,0x1F80
    lw   $a0,24($a0)
    addi   $v0,$v0,-0x1000
    srav   $v0,$v0,$t0
    andi   $v0,$v0,0xFFF
    slt   $at,$v0,$a0
    bnez   $at,.L8004F934
    lh   $t4,4($s0)
    lh   $t5,0($s0)
    sll   $t4,$t4,16
    sll   $t5,$t5,16
    lhu   $t0,6($s0)
    lhu   $t1,8($s0)
    lhu   $t2,10($s0)
    or   $t0,$t0,$t4
    or   $t1,$t1,$t5
    lui   $t4,0x2580
    ori   $t4,$t4,32896
    sw   $t0,12($s6)
    sw   $t1,20($s6)
    sh   $t2,28($s6)
    sw   $t4,4($s6)
    sll   $v0,$v0,2
    addu   $v0,$v0,$s4
    lw   $t1,0($v0)
    and   $t0,$s6,$fp
    sw   $t0,0($v0)
    or   $t1,$t1,$s5
    sw   $t1,0($s6)
    addiu   $s6,$s6,0x20
.L8004F934:
    addiu   $s0,$s0,0x10
    bnez   $s3,.L8004F7F8
    addiu   $s3,$s3,-0x1
.L8004F940:
    lui   $at,%hi(D_800A38B4)
    sw   $s6,%lo(D_800A38B4)($at)
    lw   $ra,44($sp)
    lw   $fp,40($sp)
    lw   $s6,36($sp)
    lw   $s5,32($sp)
    lw   $s4,28($sp)
    lw   $s3,24($sp)
    lw   $s2,20($sp)
    lw   $s1,16($sp)
    jr   $ra
    addiu   $sp,$sp,0x38
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_8004F970
    addiu   $sp,$sp,-0x38
    sw   $ra,44($sp)
    sw   $fp,40($sp)
    sw   $s6,36($sp)
    sw   $s5,32($sp)
    sw   $s4,28($sp)
    sw   $s3,24($sp)
    sw   $s2,20($sp)
    sw   $s1,16($sp)
    beqz   $a0,.L8004FB44
    addiu   $s3,$a0,-0x1
    lui   $s1,0x1F80
    ori   $s1,$s1,32
    lui   $s2,0x1F80
    ori   $s2,$s2,692
    lui   $s4,0x1F80
    lw   $s4,12($s4)
    lui   $s5,0x900
    lui   $fp,0xFF
    ori   $fp,$fp,65535
    lui   $s6,%hi(D_800A38B4)
    lw   $s6,%lo(D_800A38B4)($s6)
    lui   $v1,0x1F80
    lw   $v1,8($v1)
.L8004F9D0:
    lhu   $a1,16($s0)
    lhu   $a0,14($s0)
    sll   $a1,$a1,16
    or   $a0,$a0,$a1
    sll   $a1,$a0,2
    andi   $t3,$a1,0x3FC
    addu   $a1,$t3,$s1
    lw   $t0,0($a1)
    srl   $a1,$a0,6
    andi   $t4,$a1,0x3FC
    addu   $a1,$t4,$s1
    lw   $t1,0($a1)
    srl   $a1,$a0,14
    andi   $t5,$a1,0x3FC
    addu   $a1,$t5,$s1
    lw   $t2,0($a1)
    srl   $a1,$a0,22
    andi   $t6,$a1,0x3FC
    addu   $a1,$t6,$s1
    lw   $t7,0($a1)
    mtc2   $t0,$12
    mtc2   $t1,$13
    mtc2   $t2,$14
    and   $t8,$t0,$t1
    and   $t8,$t8,$t2
    and   $t8,$t8,$t7
    nclip
    bltz   $t8,.L8004FB38
    mfc2   $v0,$24
    andi   $t8,$t8,0x8000
    bgez   $v0,.L8004FB38
    nop
    bnez   $t8,.L8004FB38
    srl   $v0,$t3,1
    addu   $v0,$v0,$s2
    lh   $a0,0($v0)
    srl   $v0,$t4,1
    addu   $v0,$v0,$s2
    lh   $a1,0($v0)
    srl   $v0,$t5,1
    addu   $v0,$v0,$s2
    lh   $a2,0($v0)
    srl   $v0,$t6,1
    addu   $v0,$v0,$s2
    lh   $a3,0($v0)
    add   $a0,$a0,$a1
    add   $a0,$a0,$a2
    add   $a0,$a0,$a3
    sra   $v0,$a0,2
    blez   $v0,.L8004FB38
    nop
    sw   $t0,8($s6)
    sw   $t1,16($s6)
    sw   $t2,24($s6)
    sw   $t7,32($s6)
    srlv   $v0,$v0,$v1
    srl   $t0,$v0,11
    andi   $v0,$v0,0x7FF
    lui   $a0,0x1F80
    lw   $a0,24($a0)
    addi   $v0,$v0,-0x1000
    srav   $v0,$v0,$t0
    andi   $v0,$v0,0xFFF
    slt   $at,$v0,$a0
    bnez   $at,.L8004FB38
    lh   $t4,4($s0)
    lh   $t5,0($s0)
    sll   $t4,$t4,16
    sll   $t5,$t5,16
    lhu   $t0,6($s0)
    lhu   $t1,8($s0)
    lhu   $t2,10($s0)
    lhu   $t3,12($s0)
    or   $t0,$t0,$t4
    or   $t1,$t1,$t5
    lui   $t4,0x2D80
    ori   $t4,$t4,32896
    sw   $t0,12($s6)
    sw   $t1,20($s6)
    sh   $t2,28($s6)
    sh   $t3,36($s6)
    sw   $t4,4($s6)
    sll   $v0,$v0,2
    addu   $v0,$v0,$s4
    lw   $t1,0($v0)
    and   $t0,$s6,$fp
    sw   $t0,0($v0)
    or   $t1,$t1,$s5
    sw   $t1,0($s6)
    addiu   $s6,$s6,0x28
.L8004FB38:
    addiu   $s0,$s0,0x14
    bnez   $s3,.L8004F9D0
    addiu   $s3,$s3,-0x1
.L8004FB44:
    lui   $at,%hi(D_800A38B4)
    sw   $s6,%lo(D_800A38B4)($at)
    lw   $ra,44($sp)
    lw   $fp,40($sp)
    lw   $s6,36($sp)
    lw   $s5,32($sp)
    lw   $s4,28($sp)
    lw   $s3,24($sp)
    lw   $s2,20($sp)
    lw   $s1,16($sp)
    jr   $ra
    addiu   $sp,$sp,0x38
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_8004FB74
    addiu   $sp,$sp,-0x38
    sw   $ra,44($sp)
    sw   $fp,40($sp)
    sw   $s6,36($sp)
    sw   $s5,32($sp)
    sw   $s4,28($sp)
    sw   $s3,24($sp)
    sw   $s2,20($sp)
    sw   $s1,16($sp)
    beqz   $a0,.L8004FD10
    addiu   $s3,$a0,-0x1
    lui   $s1,0x1F80
    ori   $s1,$s1,32
    lui   $s2,0x1F80
    ori   $s2,$s2,692
    lui   $s4,0x1F80
    lw   $s4,12($s4)
    lui   $s5,0x700
    lui   $fp,0xFF
    ori   $fp,$fp,65535
    lui   $s6,%hi(D_800A38B4)
    lw   $s6,%lo(D_800A38B4)($s6)
    lui   $v1,0x1F80
    lw   $v1,8($v1)
.L8004FBD4:
    lw   $a0,12($s0)
    lwc2   $6,0($s0)
    sll   $a1,$a0,2
    andi   $t3,$a1,0x3FC
    addu   $a1,$t3,$s1
    lw   $t0,0($a1)
    srl   $a1,$a0,6
    andi   $t4,$a1,0x3FC
    addu   $a1,$t4,$s1
    lw   $t1,0($a1)
    srl   $a1,$a0,14
    andi   $t5,$a1,0x3FC
    addu   $a1,$t5,$s1
    lw   $t2,0($a1)
    mtc2   $t0,$12
    mtc2   $t1,$13
    mtc2   $t2,$14
    and   $t6,$t0,$t1
    and   $t6,$t6,$t2
    nclip
    bltz   $t6,.L8004FD04
    mfc2   $v0,$24
    andi   $t6,$t6,0x8000
    bgez   $v0,.L8004FD04
    nop
    bnez   $t6,.L8004FD04
    srl   $v0,$t3,1
    addu   $v0,$v0,$s2
    lh   $a0,0($v0)
    srl   $v0,$t4,1
    addu   $v0,$v0,$s2
    lh   $a1,0($v0)
    srl   $v0,$t5,1
    addu   $v0,$v0,$s2
    lh   $a2,0($v0)
    mtc2   $a0,$17
    mtc2   $a1,$18
    mtc2   $a2,$19
    sw   $t0,8($s6)
    nop
    avsz3
    sw   $t1,16($s6)
    mfc2   $v0,$7
    sw   $t2,24($s6)
    blez   $v0,.L8004FD04
    sll   $v0,$v0,2
    lwc2   $0,16($s0)
    lwc2   $1,20($s0)
    srlv   $v0,$v0,$v1
    srl   $t0,$v0,11
    andi   $v0,$v0,0x7FF
    ncs
    addi   $v0,$v0,-0x1000
    srav   $v0,$v0,$t0
    andi   $v0,$v0,0xFFF
    lh   $t4,4($s0)
    lh   $t5,0($s0)
    sll   $t4,$t4,16
    sll   $t5,$t5,16
    lhu   $t0,6($s0)
    lhu   $t1,8($s0)
    lhu   $t2,10($s0)
    or   $t0,$t0,$t4
    or   $t1,$t1,$t5
    sw   $t0,12($s6)
    sw   $t1,20($s6)
    sh   $t2,28($s6)
    swc2   $22,4($s6)
    sll   $v0,$v0,2
    addu   $v0,$v0,$s4
    lw   $t1,0($v0)
    and   $t0,$s6,$fp
    sw   $t0,0($v0)
    or   $t1,$t1,$s5
    sw   $t1,0($s6)
    addiu   $s6,$s6,0x20
.L8004FD04:
    addiu   $s0,$s0,0x18
    bnez   $s3,.L8004FBD4
    addiu   $s3,$s3,-0x1
.L8004FD10:
    lui   $at,%hi(D_800A38B4)
    sw   $s6,%lo(D_800A38B4)($at)
    lw   $ra,44($sp)
    lw   $fp,40($sp)
    lw   $s6,36($sp)
    lw   $s5,32($sp)
    lw   $s4,28($sp)
    lw   $s3,24($sp)
    lw   $s2,20($sp)
    lw   $s1,16($sp)
    jr   $ra
    addiu   $sp,$sp,0x38
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_8004FD40
    addiu   $sp,$sp,-0x38
    sw   $ra,44($sp)
    sw   $fp,40($sp)
    sw   $s6,36($sp)
    sw   $s5,32($sp)
    sw   $s4,28($sp)
    sw   $s3,24($sp)
    sw   $s2,20($sp)
    sw   $s1,16($sp)
    beqz   $a0,.L8004FF10
    addiu   $s3,$a0,-0x1
    lui   $s1,0x1F80
    ori   $s1,$s1,32
    lui   $s2,0x1F80
    ori   $s2,$s2,692
    lui   $s4,0x1F80
    lw   $s4,12($s4)
    lui   $s5,0x900
    lui   $fp,0xFF
    ori   $fp,$fp,65535
    lui   $s6,%hi(D_800A38B4)
    lw   $s6,%lo(D_800A38B4)($s6)
    lui   $v1,0x1F80
    lw   $v1,8($v1)
.L8004FDA0:
    lhu   $a0,14($s0)
    lhu   $a1,16($s0)
    lwc2   $6,0($s0)
    sll   $a1,$a1,16
    or   $a0,$a0,$a1
    sll   $a1,$a0,2
    andi   $t3,$a1,0x3FC
    addu   $a1,$t3,$s1
    lw   $t0,0($a1)
    srl   $a1,$a0,6
    andi   $t4,$a1,0x3FC
    addu   $a1,$t4,$s1
    lw   $t1,0($a1)
    srl   $a1,$a0,14
    andi   $t5,$a1,0x3FC
    addu   $a1,$t5,$s1
    lw   $t2,0($a1)
    srl   $a1,$a0,22
    andi   $t6,$a1,0x3FC
    addu   $a1,$t6,$s1
    lw   $t7,0($a1)
    mtc2   $t0,$12
    mtc2   $t1,$13
    mtc2   $t2,$14
    and   $t8,$t0,$t1
    and   $t8,$t8,$t2
    and   $t8,$t8,$t7
    nclip
    bltz   $t8,.L8004FF04
    mfc2   $v0,$24
    andi   $t8,$t8,0x8000
    bgez   $v0,.L8004FF04
    nop
    bnez   $t8,.L8004FF04
    srl   $v0,$t3,1
    addu   $v0,$v0,$s2
    lh   $a0,0($v0)
    srl   $v0,$t4,1
    addu   $v0,$v0,$s2
    lh   $a1,0($v0)
    srl   $v0,$t5,1
    addu   $v0,$v0,$s2
    lh   $a2,0($v0)
    srl   $v0,$t6,1
    addu   $v0,$v0,$s2
    lh   $a3,0($v0)
    add   $a0,$a0,$a1
    add   $a0,$a0,$a2
    add   $a0,$a0,$a3
    sra   $v0,$a0,2
    blez   $v0,.L8004FF04
    nop
    sw   $t0,8($s6)
    sw   $t1,16($s6)
    sw   $t2,24($s6)
    sw   $t7,32($s6)
    lhu   $t0,18($s0)
    lwc2   $0,20($s0)
    mtc2   $t0,$1
    srlv   $v0,$v0,$v1
    srl   $t0,$v0,11
    andi   $v0,$v0,0x7FF
    ncs
    addi   $v0,$v0,-0x1000
    srav   $v0,$v0,$t0
    andi   $v0,$v0,0xFFF
    lh   $t4,4($s0)
    lh   $t5,0($s0)
    sll   $t4,$t4,16
    sll   $t5,$t5,16
    lhu   $t0,6($s0)
    lhu   $t1,8($s0)
    lhu   $t2,10($s0)
    lhu   $t3,12($s0)
    or   $t0,$t0,$t4
    or   $t1,$t1,$t5
    sw   $t0,12($s6)
    sw   $t1,20($s6)
    sh   $t2,28($s6)
    sh   $t3,36($s6)
    swc2   $22,4($s6)
    sll   $v0,$v0,2
    addu   $v0,$v0,$s4
    lw   $t1,0($v0)
    and   $t0,$s6,$fp
    sw   $t0,0($v0)
    or   $t1,$t1,$s5
    sw   $t1,0($s6)
    addiu   $s6,$s6,0x28
.L8004FF04:
    addiu   $s0,$s0,0x18
    bnez   $s3,.L8004FDA0
    addiu   $s3,$s3,-0x1
.L8004FF10:
    lui   $at,%hi(D_800A38B4)
    sw   $s6,%lo(D_800A38B4)($at)
    lw   $ra,44($sp)
    lw   $fp,40($sp)
    lw   $s6,36($sp)
    lw   $s5,32($sp)
    lw   $s4,28($sp)
    lw   $s3,24($sp)
    lw   $s2,20($sp)
    lw   $s1,16($sp)
    jr   $ra
    addiu   $sp,$sp,0x38
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_8004FF40
    addiu   $sp,$sp,-0x38
    sw   $ra,48($sp)
    sw   $fp,44($sp)
    sw   $s7,40($sp)
    sw   $s6,36($sp)
    sw   $s5,32($sp)
    sw   $s4,28($sp)
    sw   $s3,24($sp)
    sw   $s2,20($sp)
    sw   $s1,16($sp)
    beqz   $a0,.L800500EC
    lh   $s7,96($s2)
    addiu   $s3,$a0,-0x1
    lui   $s1,0x1F80
    ori   $s1,$s1,32
    lui   $s2,0x1F80
    ori   $s2,$s2,692
    lui   $s4,0x1F80
    lw   $s4,12($s4)
    lui   $s5,0x700
    lui   $fp,0xFF
    ori   $fp,$fp,65535
    lui   $s6,%hi(D_800A38B4)
    lw   $s6,%lo(D_800A38B4)($s6)
    lui   $v1,0x1F80
    lw   $v1,8($v1)
.L8004FFA8:
    lw   $a0,12($s0)
    lwc2   $6,0($s0)
    sll   $a1,$a0,2
    andi   $t3,$a1,0x3FC
    addu   $a1,$t3,$s1
    lw   $t0,0($a1)
    srl   $a1,$a0,6
    andi   $t4,$a1,0x3FC
    addu   $a1,$t4,$s1
    lw   $t1,0($a1)
    srl   $a1,$a0,14
    andi   $t5,$a1,0x3FC
    addu   $a1,$t5,$s1
    lw   $t2,0($a1)
    mtc2   $t0,$12
    mtc2   $t1,$13
    mtc2   $t2,$14
    and   $t6,$t0,$t1
    and   $t6,$t6,$t2
    nclip
    bltz   $t6,.L800500DC
    mfc2   $v0,$24
    andi   $t6,$t6,0x8000
    bgez   $v0,.L800500DC
    nop
    bnez   $t6,.L800500DC
    srl   $v0,$t3,1
    addu   $v0,$v0,$s2
    lh   $a0,0($v0)
    srl   $v0,$t4,1
    addu   $v0,$v0,$s2
    lh   $a1,0($v0)
    srl   $v0,$t5,1
    addu   $v0,$v0,$s2
    lh   $a2,0($v0)
    mtc2   $a0,$17
    mtc2   $a1,$18
    mtc2   $a2,$19
    sw   $t0,8($s6)
    nop
    avsz3
    sw   $t1,16($s6)
    mfc2   $v0,$7
    sw   $t2,24($s6)
    blez   $v0,.L800500DC
    sll   $v0,$v0,2
    lwc2   $0,16($s0)
    lwc2   $1,20($s0)
    srlv   $v0,$v0,$v1
    srl   $t0,$v0,11
    andi   $v0,$v0,0x7FF
    ncs
    addi   $v0,$v0,-0x1000
    srav   $v0,$v0,$t0
    andi   $v0,$v0,0xFFF
    lh   $t4,4($s0)
    lh   $t5,0($s0)
    sll   $t4,$t4,16
    sll   $t5,$t5,16
    lhu   $t0,6($s0)
    lhu   $t1,8($s0)
    lhu   $t2,10($s0)
    or   $t0,$t0,$t4
    or   $t1,$t1,$t5
    mtc2   $s7,$8
    sw   $t0,12($s6)
    sw   $t1,20($s6)
    sh   $t2,28($s6)
    gpf   1
    sll   $v0,$v0,2
    addu   $v0,$v0,$s4
    lw   $t1,0($v0)
    and   $t0,$s6,$fp
    sw   $t0,0($v0)
    or   $t1,$t1,$s5
    sw   $t1,0($s6)
    swc2   $22,4($s6)
.L800500DC:
    addiu   $s0,$s0,0x18
    addiu   $s6,$s6,0x20
    bnez   $s3,.L8004FFA8
    addiu   $s3,$s3,-0x1
.L800500EC:
    lui   $at,%hi(D_800A38B4)
    sw   $s6,%lo(D_800A38B4)($at)
    lw   $ra,48($sp)
    lw   $fp,44($sp)
    lw   $s7,40($sp)
    lw   $s6,36($sp)
    lw   $s5,32($sp)
    lw   $s4,28($sp)
    lw   $s3,24($sp)
    lw   $s2,20($sp)
    lw   $s1,16($sp)
    jr   $ra
    addiu   $sp,$sp,0x38
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_80050120
    addiu   $sp,$sp,-0x38
    sw   $ra,48($sp)
    sw   $fp,44($sp)
    sw   $s7,40($sp)
    sw   $s6,36($sp)
    sw   $s5,32($sp)
    sw   $s4,28($sp)
    sw   $s3,24($sp)
    sw   $s2,20($sp)
    sw   $s1,16($sp)
    beqz   $a0,.L80050300
    lh   $s7,96($s2)
    addiu   $s3,$a0,-0x1
    lui   $s1,0x1F80
    ori   $s1,$s1,32
    lui   $s2,0x1F80
    ori   $s2,$s2,692
    lui   $s4,0x1F80
    lw   $s4,12($s4)
    lui   $s5,0x900
    lui   $fp,0xFF
    ori   $fp,$fp,65535
    lui   $s6,%hi(D_800A38B4)
    lw   $s6,%lo(D_800A38B4)($s6)
    lui   $v1,0x1F80
    lw   $v1,8($v1)
.L80050188:
    lhu   $a0,14($s0)
    lhu   $a1,16($s0)
    lwc2   $6,0($s0)
    sll   $a1,$a1,16
    or   $a0,$a0,$a1
    sll   $a1,$a0,2
    andi   $t3,$a1,0x3FC
    addu   $a1,$t3,$s1
    lw   $t0,0($a1)
    srl   $a1,$a0,6
    andi   $t4,$a1,0x3FC
    addu   $a1,$t4,$s1
    lw   $t1,0($a1)
    srl   $a1,$a0,14
    andi   $t5,$a1,0x3FC
    addu   $a1,$t5,$s1
    lw   $t2,0($a1)
    srl   $a1,$a0,22
    andi   $t6,$a1,0x3FC
    addu   $a1,$t6,$s1
    lw   $t7,0($a1)
    mtc2   $t0,$12
    mtc2   $t1,$13
    mtc2   $t2,$14
    and   $t8,$t0,$t1
    and   $t8,$t8,$t2
    and   $t8,$t8,$t7
    nclip
    bltz   $t8,.L800502F0
    mfc2   $v0,$24
    andi   $t8,$t8,0x8000
    bgez   $v0,.L800502F0
    nop
    bnez   $t8,.L800502F0
    srl   $v0,$t3,1
    addu   $v0,$v0,$s2
    lh   $a0,0($v0)
    srl   $v0,$t4,1
    addu   $v0,$v0,$s2
    lh   $a1,0($v0)
    srl   $v0,$t5,1
    addu   $v0,$v0,$s2
    lh   $a2,0($v0)
    srl   $v0,$t6,1
    addu   $v0,$v0,$s2
    lh   $a3,0($v0)
    add   $a0,$a0,$a1
    add   $a0,$a0,$a2
    add   $a0,$a0,$a3
    sra   $v0,$a0,2
    blez   $v0,.L800502F0
    nop
    sw   $t0,8($s6)
    sw   $t1,16($s6)
    sw   $t2,24($s6)
    sw   $t7,32($s6)
    lhu   $t0,18($s0)
    lwc2   $0,20($s0)
    mtc2   $t0,$1
    srlv   $v0,$v0,$v1
    srl   $t0,$v0,11
    andi   $v0,$v0,0x7FF
    ncs
    addi   $v0,$v0,-0x1000
    srav   $v0,$v0,$t0
    andi   $v0,$v0,0xFFF
    lh   $t4,4($s0)
    lh   $t5,0($s0)
    sll   $t4,$t4,16
    sll   $t5,$t5,16
    lhu   $t0,6($s0)
    lhu   $t1,8($s0)
    lhu   $t2,10($s0)
    lhu   $t3,12($s0)
    or   $t0,$t0,$t4
    or   $t1,$t1,$t5
    mtc2   $s7,$8
    sw   $t0,12($s6)
    sw   $t1,20($s6)
    sh   $t2,28($s6)
    sh   $t3,36($s6)
    gpf   1
    sll   $v0,$v0,2
    addu   $v0,$v0,$s4
    lw   $t1,0($v0)
    and   $t0,$s6,$fp
    sw   $t0,0($v0)
    or   $t1,$t1,$s5
    sw   $t1,0($s6)
    swc2   $22,4($s6)
.L800502F0:
    addiu   $s0,$s0,0x18
    addiu   $s6,$s6,0x28
    bnez   $s3,.L80050188
    addiu   $s3,$s3,-0x1
.L80050300:
    lui   $at,%hi(D_800A38B4)
    sw   $s6,%lo(D_800A38B4)($at)
    lw   $ra,48($sp)
    lw   $fp,44($sp)
    lw   $s7,40($sp)
    lw   $s6,36($sp)
    lw   $s5,32($sp)
    lw   $s4,28($sp)
    lw   $s3,24($sp)
    lw   $s2,20($sp)
    lw   $s1,16($sp)
    jr   $ra
    addiu   $sp,$sp,0x38
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_80050334
    addiu   $sp,$sp,-0x38
    sw   $ra,44($sp)
    sw   $fp,40($sp)
    sw   $s6,36($sp)
    sw   $s5,32($sp)
    sw   $s4,28($sp)
    sw   $s3,24($sp)
    sw   $s2,20($sp)
    sw   $s1,16($sp)
    beqz   $a0,.L80050508
    addiu   $s3,$a0,-0x1
    lui   $s1,0x1F80
    ori   $s1,$s1,32
    lui   $s2,0x1F80
    ori   $s2,$s2,692
    lui   $s4,0x1F80
    lw   $s4,12($s4)
    lui   $s5,0x900
    lui   $fp,0xFF
    ori   $fp,$fp,65535
    lui   $s6,%hi(D_800A38B4)
    lw   $s6,%lo(D_800A38B4)($s6)
    lui   $v1,0x1F80
    lw   $v1,8($v1)
    lwc2   $6,0($s0)
.L80050398:
    lw   $a0,12($s0)
    nop
    sll   $a1,$a0,2
    andi   $t3,$a1,0x3FC
    addu   $a1,$t3,$s1
    lw   $t0,0($a1)
    srl   $a1,$a0,6
    andi   $t4,$a1,0x3FC
    addu   $a1,$t4,$s1
    lw   $t1,0($a1)
    srl   $a1,$a0,14
    andi   $t5,$a1,0x3FC
    addu   $a1,$t5,$s1
    lw   $t2,0($a1)
    mtc2   $t0,$12
    mtc2   $t1,$13
    mtc2   $t2,$14
    and   $t6,$t0,$t1
    and   $t6,$t6,$t2
    nclip
    bltz   $t6,.L800504FC
    mfc2   $v0,$24
    andi   $t6,$t6,0x8000
    bgez   $v0,.L800504FC
    nop
    bnez   $t6,.L800504FC
    srl   $v0,$t3,1
    addu   $v0,$v0,$s2
    lh   $a0,0($v0)
    srl   $v0,$t4,1
    addu   $v0,$v0,$s2
    lh   $a1,0($v0)
    srl   $v0,$t5,1
    addu   $v0,$v0,$s2
    lh   $a2,0($v0)
    mtc2   $a0,$17
    mtc2   $a1,$18
    mtc2   $a2,$19
    sw   $t0,8($s6)
    nop
    avsz3
    sw   $t1,20($s6)
    mfc2   $v0,$7
    sw   $t2,32($s6)
    blez   $v0,.L800504FC
    sll   $v0,$v0,2
    lui   $at,0x1
    slt   $t9,$v0,$at
    beqz   $t9,.L800504FC
    nop
    lwc2   $0,16($s0)
    lw   $t0,20($s0)
    lwc2   $2,24($s0)
    mtc2   $t0,$1
    lwc2   $4,28($s0)
    lwc2   $5,32($s0)
    srl   $t0,$t0,16
    mtc2   $t0,$3
    srlv   $v0,$v0,$v1
    srl   $t0,$v0,11
    andi   $v0,$v0,0x7FF
    addi   $v0,$v0,-0x1000
    srav   $v0,$v0,$t0
    andi   $v0,$v0,0xFFF
    nct
    lh   $t4,4($s0)
    lh   $t5,0($s0)
    sll   $t4,$t4,16
    sll   $t5,$t5,16
    lhu   $t0,6($s0)
    lhu   $t1,8($s0)
    lhu   $t2,10($s0)
    or   $t0,$t0,$t4
    or   $t1,$t1,$t5
    sw   $t0,12($s6)
    sw   $t1,24($s6)
    sh   $t2,36($s6)
    sll   $v0,$v0,2
    addu   $v0,$v0,$s4
    lw   $t1,0($v0)
    and   $t0,$s6,$fp
    sw   $t0,0($v0)
    or   $t1,$t1,$s5
    sw   $t1,0($s6)
    swc2   $20,4($s6)
    swc2   $21,16($s6)
    swc2   $22,28($s6)
    nop
    addiu   $s6,$s6,0x28
.L800504FC:
    addiu   $s0,$s0,0x24
    bnez   $s3,.L80050398
    addiu   $s3,$s3,-0x1
.L80050508:
    lui   $at,%hi(D_800A38B4)
    sw   $s6,%lo(D_800A38B4)($at)
    lw   $ra,44($sp)
    lw   $fp,40($sp)
    lw   $s6,36($sp)
    lw   $s5,32($sp)
    lw   $s4,28($sp)
    lw   $s3,24($sp)
    lw   $s2,20($sp)
    lw   $s1,16($sp)
    jr   $ra
    addiu   $sp,$sp,0x38
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_80050538
    addiu   $sp,$sp,-0x38
    sw   $ra,44($sp)
    sw   $fp,40($sp)
    sw   $s6,36($sp)
    sw   $s5,32($sp)
    sw   $s4,28($sp)
    sw   $s3,24($sp)
    sw   $s2,20($sp)
    sw   $s1,16($sp)
    beqz   $a0,.L80050744
    addiu   $s3,$a0,-0x1
    lui   $s1,0x1F80
    ori   $s1,$s1,32
    lui   $s2,0x1F80
    ori   $s2,$s2,692
    lui   $s4,0x1F80
    lw   $s4,12($s4)
    lui   $s5,0xC00
    lui   $fp,0xFF
    ori   $fp,$fp,65535
    lui   $s6,%hi(D_800A38B4)
    lw   $s6,%lo(D_800A38B4)($s6)
    lui   $v1,0x1F80
    lw   $v1,8($v1)
    lwc2   $6,0($s0)
.L8005059C:
    lw   $a0,16($s0)
    nop
    sll   $a1,$a0,2
    andi   $t3,$a1,0x3FC
    addu   $a1,$t3,$s1
    lw   $t0,0($a1)
    srl   $a1,$a0,6
    andi   $t4,$a1,0x3FC
    addu   $a1,$t4,$s1
    lw   $t1,0($a1)
    srl   $a1,$a0,14
    andi   $t5,$a1,0x3FC
    addu   $a1,$t5,$s1
    lw   $t2,0($a1)
    srl   $a1,$a0,22
    andi   $t6,$a1,0x3FC
    addu   $a1,$t6,$s1
    lw   $t7,0($a1)
    mtc2   $t0,$12
    mtc2   $t1,$13
    mtc2   $t2,$14
    and   $t8,$t0,$t1
    and   $t8,$t8,$t2
    and   $t8,$t8,$t7
    nclip
    bltz   $t8,.L80050738
    mfc2   $v0,$24
    andi   $t8,$t8,0x8000
    bgez   $v0,.L80050738
    nop
    bnez   $t8,.L80050738
    srl   $v0,$t3,1
    addu   $v0,$v0,$s2
    lh   $a0,0($v0)
    srl   $v0,$t4,1
    addu   $v0,$v0,$s2
    lh   $a1,0($v0)
    srl   $v0,$t5,1
    addu   $v0,$v0,$s2
    lh   $a2,0($v0)
    srl   $v0,$t6,1
    addu   $v0,$v0,$s2
    lh   $a3,0($v0)
    add   $a0,$a0,$a1
    add   $a0,$a0,$a2
    add   $a0,$a0,$a3
    sra   $v0,$a0,2
    blez   $v0,.L80050738
    lui   $at,0x1
    slt   $t9,$v0,$at
    beqz   $t9,.L80050738
    nop
    sw   $t0,8($s6)
    sw   $t1,20($s6)
    sw   $t2,32($s6)
    sw   $t7,44($s6)
    lw   $t9,24($s0)
    lwc2   $0,20($s0)
    mtc2   $t9,$1
    srlv   $v0,$v0,$v1
    srl   $t0,$v0,11
    andi   $v0,$v0,0x7FF
    ncs
    addi   $v0,$v0,-0x1000
    srav   $v0,$v0,$t0
    andi   $v0,$v0,0xFFF
    swc2   $22,4($s6)
    lwc2   $0,28($s0)
    srl   $t9,$t9,16
    mtc2   $t9,$1
    lwc2   $2,32($s0)
    lw   $t9,36($s0)
    lwc2   $4,40($s0)
    mtc2   $t9,$3
    srl   $t8,$t9,16
    mtc2   $t8,$5
    lh   $t4,4($s0)
    lh   $t5,0($s0)
    sll   $t4,$t4,16
    sll   $t5,$t5,16
    nct
    lhu   $t0,6($s0)
    lhu   $t1,8($s0)
    lhu   $t2,10($s0)
    lhu   $t3,12($s0)
    or   $t0,$t0,$t4
    or   $t1,$t1,$t5
    sw   $t0,12($s6)
    sw   $t1,24($s6)
    sh   $t2,36($s6)
    sh   $t3,48($s6)
    sll   $v0,$v0,2
    addu   $v0,$v0,$s4
    lw   $t1,0($v0)
    and   $t0,$s6,$fp
    sw   $t0,0($v0)
    or   $t1,$t1,$s5
    sw   $t1,0($s6)
    swc2   $20,16($s6)
    swc2   $21,28($s6)
    swc2   $22,40($s6)
    nop
    addiu   $s6,$s6,0x34
.L80050738:
    addiu   $s0,$s0,0x2C
    bnez   $s3,.L8005059C
    addiu   $s3,$s3,-0x1
.L80050744:
    lui   $at,%hi(D_800A38B4)
    sw   $s6,%lo(D_800A38B4)($at)
    lw   $ra,44($sp)
    lw   $fp,40($sp)
    lw   $s6,36($sp)
    lw   $s5,32($sp)
    lw   $s4,28($sp)
    lw   $s3,24($sp)
    lw   $s2,20($sp)
    lw   $s1,16($sp)
    jr   $ra
    addiu   $sp,$sp,0x38
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_80050774
    addiu   $sp,$sp,-0x38
    sw   $ra,44($sp)
    sw   $fp,40($sp)
    sw   $s6,36($sp)
    sw   $s5,32($sp)
    sw   $s4,28($sp)
    sw   $s3,24($sp)
    sw   $s2,20($sp)
    sw   $s1,16($sp)
    beqz   $a0,.L800508D8
    addiu   $s3,$a0,-0x1
    lui   $s1,0x1F80
    ori   $s1,$s1,32
    lui   $s2,0x1F80
    ori   $s2,$s2,692
    lui   $s4,0x1F80
    lw   $s4,12($s4)
    lui   $s5,0x400
    lui   $fp,0xFF
    ori   $fp,$fp,65535
    lui   $s6,%hi(D_800A38B4)
    lw   $s6,%lo(D_800A38B4)($s6)
    lui   $v1,0x1F80
    lw   $v1,8($v1)
.L800507D4:
    lw   $a0,0($s0)
    nop
    sll   $a1,$a0,2
    andi   $t3,$a1,0x3FC
    addu   $a1,$t3,$s1
    lw   $t0,0($a1)
    srl   $a1,$a0,6
    andi   $t4,$a1,0x3FC
    addu   $a1,$t4,$s1
    lw   $t1,0($a1)
    srl   $a1,$a0,14
    andi   $t5,$a1,0x3FC
    addu   $a1,$t5,$s1
    lw   $t2,0($a1)
    mtc2   $t0,$12
    mtc2   $t1,$13
    mtc2   $t2,$14
    and   $t6,$t0,$t1
    and   $t6,$t6,$t2
    nclip
    bltz   $t6,.L800508C8
    andi   $t6,$t6,0x8000
    mfc2   $v0,$24
    bnez   $t6,.L800508C8
    nop
    bgez   $v0,.L800508C8
    srl   $v0,$t3,1
    addu   $v0,$v0,$s2
    lh   $a0,0($v0)
    srl   $v0,$t4,1
    addu   $v0,$v0,$s2
    lh   $a1,0($v0)
    srl   $v0,$t5,1
    addu   $v0,$v0,$s2
    lh   $a2,0($v0)
    mtc2   $a0,$17
    mtc2   $a1,$18
    mtc2   $a2,$19
    sw   $t0,8($s6)
    nop
    avsz3
    sw   $t1,12($s6)
    mfc2   $v0,$7
    sw   $t2,16($s6)
    blez   $v0,.L800508C8
    sll   $v0,$v0,2
    lui   $t0,0x2000
    sw   $t0,4($s6)
    srlv   $v0,$v0,$v1
    srl   $t0,$v0,11
    andi   $v0,$v0,0x7FF
    addi   $v0,$v0,-0x1000
    srav   $v0,$v0,$t0
    andi   $v0,$v0,0xFFF
    sll   $v0,$v0,2
    addu   $v0,$v0,$s4
    lw   $t1,0($v0)
    and   $t0,$s6,$fp
    sw   $t0,0($v0)
    or   $t1,$t1,$s5
    sw   $t1,0($s6)
.L800508C8:
    addiu   $s0,$s0,0x4
    addiu   $s6,$s6,0x14
    bnez   $s3,.L800507D4
    addiu   $s3,$s3,-0x1
.L800508D8:
    lui   $at,%hi(D_800A38B4)
    sw   $s6,%lo(D_800A38B4)($at)
    lw   $ra,44($sp)
    lw   $fp,40($sp)
    lw   $s6,36($sp)
    lw   $s5,32($sp)
    lw   $s4,28($sp)
    lw   $s3,24($sp)
    lw   $s2,20($sp)
    lw   $s1,16($sp)
    jr   $ra
    addiu   $sp,$sp,0x38
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_80050908
    addiu   $sp,$sp,-0x38
    sw   $ra,44($sp)
    sw   $fp,40($sp)
    sw   $s6,36($sp)
    sw   $s5,32($sp)
    sw   $s4,28($sp)
    sw   $s3,24($sp)
    sw   $s2,20($sp)
    sw   $s1,16($sp)
    beqz   $a0,.L80050A88
    addiu   $s3,$a0,-0x1
    lui   $s1,0x1F80
    ori   $s1,$s1,32
    lui   $s2,0x1F80
    ori   $s2,$s2,692
    lui   $s4,0x1F80
    lw   $s4,12($s4)
    lui   $s5,0x500
    lui   $fp,0xFF
    ori   $fp,$fp,65535
    lui   $s6,%hi(D_800A38B4)
    lw   $s6,%lo(D_800A38B4)($s6)
    lui   $v1,0x1F80
    lw   $v1,8($v1)
.L80050968:
    lw   $a0,0($s0)
    nop
    sll   $a1,$a0,2
    andi   $t3,$a1,0x3FC
    addu   $a1,$t3,$s1
    lw   $t0,0($a1)
    srl   $a1,$a0,6
    andi   $t4,$a1,0x3FC
    addu   $a1,$t4,$s1
    lw   $t1,0($a1)
    srl   $a1,$a0,14
    andi   $t5,$a1,0x3FC
    addu   $a1,$t5,$s1
    lw   $t2,0($a1)
    srl   $a1,$a0,22
    andi   $t6,$a1,0x3FC
    addu   $a1,$t6,$s1
    lw   $t7,0($a1)
    mtc2   $t0,$12
    mtc2   $t1,$13
    mtc2   $t2,$14
    and   $t8,$t0,$t1
    and   $t8,$t8,$t2
    and   $t8,$t8,$t7
    nclip
    bltz   $t8,.L80050A78
    mfc2   $v0,$24
    andi   $t8,$t8,0x8000
    bgez   $v0,.L80050A78
    nop
    bnez   $t8,.L80050A78
    srl   $v0,$t3,1
    addu   $v0,$v0,$s2
    lh   $a0,0($v0)
    srl   $v0,$t4,1
    addu   $v0,$v0,$s2
    lh   $a1,0($v0)
    srl   $v0,$t5,1
    addu   $v0,$v0,$s2
    lh   $a2,0($v0)
    srl   $v0,$t6,1
    addu   $v0,$v0,$s2
    lh   $a3,0($v0)
    add   $a0,$a0,$a1
    add   $a0,$a0,$a2
    add   $a0,$a0,$a3
    sra   $v0,$a0,2
    blez   $v0,.L80050A78
    nop
    sw   $t0,8($s6)
    sw   $t1,12($s6)
    sw   $t2,16($s6)
    sw   $t7,20($s6)
    lui   $t0,0x2800
    sw   $t0,4($s6)
    srlv   $v0,$v0,$v1
    srl   $t0,$v0,11
    andi   $v0,$v0,0x7FF
    addi   $v0,$v0,-0x1000
    srav   $v0,$v0,$t0
    andi   $v0,$v0,0xFFF
    sll   $v0,$v0,2
    addu   $v0,$v0,$s4
    lw   $t1,0($v0)
    and   $t0,$s6,$fp
    sw   $t0,0($v0)
    or   $t1,$t1,$s5
    sw   $t1,0($s6)
.L80050A78:
    addiu   $s0,$s0,0x4
    addiu   $s6,$s6,0x18
    bnez   $s3,.L80050968
    addiu   $s3,$s3,-0x1
.L80050A88:
    lui   $at,%hi(D_800A38B4)
    sw   $s6,%lo(D_800A38B4)($at)
    lw   $ra,44($sp)
    lw   $fp,40($sp)
    lw   $s6,36($sp)
    lw   $s5,32($sp)
    lw   $s4,28($sp)
    lw   $s3,24($sp)
    lw   $s2,20($sp)
    lw   $s1,16($sp)
    jr   $ra
    addiu   $sp,$sp,0x38
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_80050AB8
    addiu   $sp,$sp,-0x38
    sw   $ra,48($sp)
    sw   $fp,44($sp)
    sw   $s7,40($sp)
    sw   $s6,36($sp)
    sw   $s5,32($sp)
    sw   $s4,28($sp)
    sw   $s3,24($sp)
    sw   $s2,20($sp)
    sw   $s1,16($sp)
    beqz   $a0,.L80050C34
    addiu   $s3,$a0,-0x1
    lui   $s1,0x1F80
    ori   $s1,$s1,32
    lui   $s2,0x1F80
    ori   $s2,$s2,580
    lui   $s4,0x1F80
    lw   $s4,12($s4)
    lui   $s5,0x600
    lui   $fp,0xFF
    ori   $fp,$fp,65535
    lui   $s6,%hi(D_800A38B4)
    lw   $s6,%lo(D_800A38B4)($s6)
    lui   $v1,0x1F80
    lw   $v1,8($v1)
.L80050B1C:
    lw   $a0,12($s0)
    nop
    sll   $a1,$a0,2
    andi   $t3,$a1,0x3FC
    addu   $a1,$t3,$s1
    lw   $t0,0($a1)
    srl   $a1,$a0,6
    andi   $t4,$a1,0x3FC
    addu   $a1,$t4,$s1
    lw   $t1,0($a1)
    srl   $a1,$a0,14
    andi   $t5,$a1,0x3FC
    addu   $a1,$t5,$s1
    lw   $t2,0($a1)
    mtc2   $t0,$12
    mtc2   $t1,$13
    mtc2   $t2,$14
    and   $t6,$t0,$t1
    and   $t6,$t6,$t2
    nclip
    bltz   $t6,.L80050C28
    mfc2   $v0,$24
    andi   $t6,$t6,0x8000
    bgez   $v0,.L80050C28
    nop
    bnez   $t6,.L80050C28
    srl   $v0,$t3,1
    addu   $v0,$v0,$s2
    lh   $a0,0($v0)
    srl   $v0,$t4,1
    addu   $v0,$v0,$s2
    lh   $a1,0($v0)
    srl   $v0,$t5,1
    addu   $v0,$v0,$s2
    lh   $a2,0($v0)
    mtc2   $a0,$17
    mtc2   $a1,$18
    mtc2   $a2,$19
    sw   $t0,8($s6)
    sw   $t0,20($s6)
    avsz3
    sw   $t1,12($s6)
    mfc2   $v0,$7
    sw   $t2,16($s6)
    sll   $v0,$v0,2
    slti   $t9,$v0,0x1
    bnez   $t9,.L80050C28
    srlv   $v0,$v0,$v1
    srl   $t0,$v0,11
    andi   $v0,$v0,0x7FF
    addi   $v0,$v0,-0x1000
    srav   $v0,$v0,$t0
    andi   $v0,$v0,0xFFF
    sll   $v0,$v0,2
    addu   $v0,$v0,$s4
    lw   $t1,0($v0)
    and   $t0,$s6,$fp
    sw   $t0,0($v0)
    or   $t1,$t1,$s5
    sw   $t1,0($s6)
    lui   $t0,0x4C80
    ori   $t0,$t0,32896
    lui   $t1,0x5555
    ori   $t1,$t1,21845
    sw   $t0,4($s6)
    sw   $t1,24($s6)
    addiu   $s6,$s6,0x1C
.L80050C28:
    addiu   $s0,$s0,0x14
    bnez   $s3,.L80050B1C
    addiu   $s3,$s3,-0x1
.L80050C34:
    lui   $at,%hi(D_800A38B4)
    sw   $s6,%lo(D_800A38B4)($at)
    lw   $ra,48($sp)
    lw   $fp,44($sp)
    lw   $s7,40($sp)
    lw   $s6,36($sp)
    lw   $s5,32($sp)
    lw   $s4,28($sp)
    lw   $s3,24($sp)
    lw   $s2,20($sp)
    lw   $s1,16($sp)
    jr   $ra
    addiu   $sp,$sp,0x38
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_80050C68
    addiu   $sp,$sp,-0x38
    sw   $ra,48($sp)
    sw   $fp,44($sp)
    sw   $s7,40($sp)
    sw   $s6,36($sp)
    sw   $s5,32($sp)
    sw   $s4,28($sp)
    sw   $s3,24($sp)
    sw   $s2,20($sp)
    sw   $s1,16($sp)
    beqz   $a0,.L80050E2C
    addiu   $s3,$a0,-0x1
    lui   $s1,0x1F80
    ori   $s1,$s1,32
    lui   $s2,0x1F80
    ori   $s2,$s2,580
    lui   $s4,0x1F80
    lw   $s4,12($s4)
    lui   $s5,0x500
    lui   $fp,0xFF
    ori   $fp,$fp,65535
    lui   $s6,%hi(D_800A38B4)
    lw   $s6,%lo(D_800A38B4)($s6)
    lui   $v1,0x1F80
    lw   $v1,8($v1)
.L80050CCC:
    lw   $a0,16($s0)
    nop
    sll   $a1,$a0,2
    andi   $t3,$a1,0x3FC
    addu   $a1,$t3,$s1
    lw   $t0,0($a1)
    srl   $a1,$a0,6
    andi   $t4,$a1,0x3FC
    addu   $a1,$t4,$s1
    lw   $t1,0($a1)
    srl   $a1,$a0,14
    andi   $t5,$a1,0x3FC
    addu   $a1,$t5,$s1
    lw   $t2,0($a1)
    srl   $a1,$a0,22
    andi   $t6,$a1,0x3FC
    addu   $a1,$t6,$s1
    lw   $t7,0($a1)
    mtc2   $t0,$12
    mtc2   $t1,$13
    mtc2   $t2,$14
    and   $t8,$t0,$t1
    and   $t8,$t8,$t2
    and   $t8,$t8,$t7
    nclip
    bltz   $t8,.L80050E20
    mfc2   $v0,$24
    andi   $t8,$t8,0x8000
    bgez   $v0,.L80050E20
    nop
    bnez   $t8,.L80050E20
    srl   $v0,$t3,1
    addu   $v0,$v0,$s2
    lh   $a0,0($v0)
    srl   $v0,$t4,1
    addu   $v0,$v0,$s2
    lh   $a1,0($v0)
    srl   $v0,$t5,1
    addu   $v0,$v0,$s2
    lh   $a2,0($v0)
    srl   $v0,$t6,1
    addu   $v0,$v0,$s2
    lh   $a3,0($v0)
    add   $a0,$a0,$a1
    add   $a0,$a0,$a2
    add   $a0,$a0,$a3
    sra   $v0,$a0,2
    slti   $t9,$v0,0x1
    bnez   $t9,.L80050E20
    nop
    sw   $t1,8($s6)
    sw   $t0,12($s6)
    sw   $t2,16($s6)
    sw   $t2,32($s6)
    sw   $t7,36($s6)
    sw   $t1,40($s6)
    lui   $t0,0x4880
    ori   $t0,$t0,32896
    lui   $t1,0x5555
    ori   $t1,$t1,21845
    sw   $t0,4($s6)
    sw   $t1,20($s6)
    sw   $t0,28($s6)
    sw   $t1,44($s6)
    srlv   $v0,$v0,$v1
    srl   $t0,$v0,11
    andi   $v0,$v0,0x7FF
    addi   $v0,$v0,-0x1000
    srav   $v0,$v0,$t0
    andi   $v0,$v0,0xFFF
    sll   $v0,$v0,2
    addu   $v0,$v0,$s4
    lw   $t1,0($v0)
    and   $t0,$s6,$fp
    sw   $t0,0($v0)
    or   $t1,$t1,$s5
    sw   $t1,0($s6)
    nop
    addiu   $s6,$s6,0x18
    lw   $t1,0($v0)
    and   $t0,$s6,$fp
    sw   $t0,0($v0)
    or   $t1,$t1,$s5
    sw   $t1,0($s6)
    addiu   $s6,$s6,0x18
.L80050E20:
    addiu   $s0,$s0,0x18
    bnez   $s3,.L80050CCC
    addiu   $s3,$s3,-0x1
.L80050E2C:
    lui   $at,%hi(D_800A38B4)
    sw   $s6,%lo(D_800A38B4)($at)
    lw   $ra,48($sp)
    lw   $fp,44($sp)
    lw   $s7,40($sp)
    lw   $s6,36($sp)
    lw   $s5,32($sp)
    lw   $s4,28($sp)
    lw   $s3,24($sp)
    lw   $s2,20($sp)
    lw   $s1,16($sp)
    jr   $ra
    addiu   $sp,$sp,0x38
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_80050E60
    addiu   $sp,$sp,-0x38
    sw   $ra,48($sp)
    sw   $fp,44($sp)
    sw   $s7,40($sp)
    sw   $s6,36($sp)
    sw   $s5,32($sp)
    sw   $s4,28($sp)
    sw   $s3,24($sp)
    sw   $s2,20($sp)
    sw   $s1,16($sp)
    beqz   $a0,.L80050FDC
    addiu   $s3,$a0,-0x1
    lui   $s1,0x1F80
    ori   $s1,$s1,32
    lui   $s2,0x1F80
    ori   $s2,$s2,580
    lui   $s4,0x1F80
    lw   $s4,12($s4)
    lui   $s5,0x600
    lui   $fp,0xFF
    ori   $fp,$fp,65535
    lui   $s6,%hi(D_800A38B4)
    lw   $s6,%lo(D_800A38B4)($s6)
    lui   $v1,0x1F80
    lw   $v1,8($v1)
.L80050EC4:
    lw   $a0,12($s0)
    nop
    sll   $a1,$a0,2
    andi   $t3,$a1,0x3FC
    addu   $a1,$t3,$s1
    lw   $t0,0($a1)
    srl   $a1,$a0,6
    andi   $t4,$a1,0x3FC
    addu   $a1,$t4,$s1
    lw   $t1,0($a1)
    srl   $a1,$a0,14
    andi   $t5,$a1,0x3FC
    addu   $a1,$t5,$s1
    lw   $t2,0($a1)
    mtc2   $t0,$12
    mtc2   $t1,$13
    mtc2   $t2,$14
    and   $t6,$t0,$t1
    and   $t6,$t6,$t2
    nclip
    bltz   $t6,.L80050FD0
    mfc2   $v0,$24
    andi   $t6,$t6,0x8000
    bgez   $v0,.L80050FD0
    nop
    bnez   $t6,.L80050FD0
    srl   $v0,$t3,1
    addu   $v0,$v0,$s2
    lh   $a0,0($v0)
    srl   $v0,$t4,1
    addu   $v0,$v0,$s2
    lh   $a1,0($v0)
    srl   $v0,$t5,1
    addu   $v0,$v0,$s2
    lh   $a2,0($v0)
    mtc2   $a0,$17
    mtc2   $a1,$18
    mtc2   $a2,$19
    sw   $t0,8($s6)
    sw   $t0,20($s6)
    avsz3
    sw   $t1,12($s6)
    mfc2   $v0,$7
    sw   $t2,16($s6)
    sll   $v0,$v0,2
    slti   $t9,$v0,0x1
    bnez   $t9,.L80050FD0
    srlv   $v0,$v0,$v1
    srl   $t0,$v0,11
    andi   $v0,$v0,0x7FF
    addi   $v0,$v0,-0x1000
    srav   $v0,$v0,$t0
    andi   $v0,$v0,0xFFF
    sll   $v0,$v0,2
    addu   $v0,$v0,$s4
    lw   $t1,0($v0)
    and   $t0,$s6,$fp
    sw   $t0,0($v0)
    or   $t1,$t1,$s5
    sw   $t1,0($s6)
    lui   $t0,0x4C80
    ori   $t0,$t0,32896
    lui   $t1,0x5555
    ori   $t1,$t1,21845
    sw   $t0,4($s6)
    sw   $t1,24($s6)
    addiu   $s6,$s6,0x1C
.L80050FD0:
    addiu   $s0,$s0,0x14
    bnez   $s3,.L80050EC4
    addiu   $s3,$s3,-0x1
.L80050FDC:
    lui   $at,%hi(D_800A38B4)
    sw   $s6,%lo(D_800A38B4)($at)
    lw   $ra,48($sp)
    lw   $fp,44($sp)
    lw   $s7,40($sp)
    lw   $s6,36($sp)
    lw   $s5,32($sp)
    lw   $s4,28($sp)
    lw   $s3,24($sp)
    lw   $s2,20($sp)
    lw   $s1,16($sp)
    jr   $ra
    addiu   $sp,$sp,0x38
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_80051010
    addiu   $sp,$sp,-0x38
    sw   $ra,48($sp)
    sw   $fp,44($sp)
    sw   $s7,40($sp)
    sw   $s6,36($sp)
    sw   $s5,32($sp)
    sw   $s4,28($sp)
    sw   $s3,24($sp)
    sw   $s2,20($sp)
    sw   $s1,16($sp)
    beqz   $a0,.L800511D4
    addiu   $s3,$a0,-0x1
    lui   $s1,0x1F80
    ori   $s1,$s1,32
    lui   $s2,0x1F80
    ori   $s2,$s2,580
    lui   $s4,0x1F80
    lw   $s4,12($s4)
    lui   $s5,0x500
    lui   $fp,0xFF
    ori   $fp,$fp,65535
    lui   $s6,%hi(D_800A38B4)
    lw   $s6,%lo(D_800A38B4)($s6)
    lui   $v1,0x1F80
    lw   $v1,8($v1)
.L80051074:
    lw   $a0,16($s0)
    nop
    sll   $a1,$a0,2
    andi   $t3,$a1,0x3FC
    addu   $a1,$t3,$s1
    lw   $t0,0($a1)
    srl   $a1,$a0,6
    andi   $t4,$a1,0x3FC
    addu   $a1,$t4,$s1
    lw   $t1,0($a1)
    srl   $a1,$a0,14
    andi   $t5,$a1,0x3FC
    addu   $a1,$t5,$s1
    lw   $t2,0($a1)
    srl   $a1,$a0,22
    andi   $t6,$a1,0x3FC
    addu   $a1,$t6,$s1
    lw   $t7,0($a1)
    mtc2   $t0,$12
    mtc2   $t1,$13
    mtc2   $t2,$14
    and   $t8,$t0,$t1
    and   $t8,$t8,$t2
    and   $t8,$t8,$t7
    nclip
    bltz   $t8,.L800511C8
    mfc2   $v0,$24
    andi   $t8,$t8,0x8000
    bgez   $v0,.L800511C8
    nop
    bnez   $t8,.L800511C8
    srl   $v0,$t3,1
    addu   $v0,$v0,$s2
    lh   $a0,0($v0)
    srl   $v0,$t4,1
    addu   $v0,$v0,$s2
    lh   $a1,0($v0)
    srl   $v0,$t5,1
    addu   $v0,$v0,$s2
    lh   $a2,0($v0)
    srl   $v0,$t6,1
    addu   $v0,$v0,$s2
    lh   $a3,0($v0)
    add   $a0,$a0,$a1
    add   $a0,$a0,$a2
    add   $a0,$a0,$a3
    sra   $v0,$a0,2
    slti   $t9,$v0,0x1
    bnez   $t9,.L800511C8
    nop
    sw   $t1,8($s6)
    sw   $t0,12($s6)
    sw   $t2,16($s6)
    sw   $t2,32($s6)
    sw   $t7,36($s6)
    sw   $t1,40($s6)
    lui   $t0,0x4880
    ori   $t0,$t0,32896
    lui   $t1,0x5555
    ori   $t1,$t1,21845
    sw   $t0,4($s6)
    sw   $t1,20($s6)
    sw   $t0,28($s6)
    sw   $t1,44($s6)
    srlv   $v0,$v0,$v1
    srl   $t0,$v0,11
    andi   $v0,$v0,0x7FF
    addi   $v0,$v0,-0x1000
    srav   $v0,$v0,$t0
    andi   $v0,$v0,0xFFF
    sll   $v0,$v0,2
    addu   $v0,$v0,$s4
    lw   $t1,0($v0)
    and   $t0,$s6,$fp
    sw   $t0,0($v0)
    or   $t1,$t1,$s5
    sw   $t1,0($s6)
    nop
    addiu   $s6,$s6,0x18
    lw   $t1,0($v0)
    and   $t0,$s6,$fp
    sw   $t0,0($v0)
    or   $t1,$t1,$s5
    sw   $t1,0($s6)
    addiu   $s6,$s6,0x18
.L800511C8:
    addiu   $s0,$s0,0x18
    bnez   $s3,.L80051074
    addiu   $s3,$s3,-0x1
.L800511D4:
    lui   $at,%hi(D_800A38B4)
    sw   $s6,%lo(D_800A38B4)($at)
    lw   $ra,48($sp)
    lw   $fp,44($sp)
    lw   $s7,40($sp)
    lw   $s6,36($sp)
    lw   $s5,32($sp)
    lw   $s4,28($sp)
    lw   $s3,24($sp)
    lw   $s2,20($sp)
    lw   $s1,16($sp)
    jr   $ra
    addiu   $sp,$sp,0x38
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_80051208
    addiu   $sp,$sp,-0x38
    sw   $ra,44($sp)
    sw   $fp,40($sp)
    sw   $s6,36($sp)
    sw   $s5,32($sp)
    sw   $s4,28($sp)
    sw   $s3,24($sp)
    sw   $s2,20($sp)
    sw   $s1,16($sp)
    beqz   $a0,.L80051380
    addiu   $s3,$a0,-0x1
    lui   $s1,0x1F80
    ori   $s1,$s1,32
    lui   $s2,0x1F80
    ori   $s2,$s2,692
    lui   $s4,0x1F80
    lw   $s4,12($s4)
    lui   $s5,0x600
    lui   $fp,0xFF
    ori   $fp,$fp,65535
    lui   $s6,%hi(D_800A38B4)
    lw   $s6,%lo(D_800A38B4)($s6)
    lui   $v1,0x1F80
    lw   $v1,8($v1)
.L80051268:
    lw   $a0,12($s0)
    lwc2   $6,0($s0)
    sll   $a1,$a0,2
    andi   $t3,$a1,0x3FC
    addu   $a1,$t3,$s1
    lw   $t0,0($a1)
    srl   $a1,$a0,6
    andi   $t4,$a1,0x3FC
    addu   $a1,$t4,$s1
    lw   $t1,0($a1)
    srl   $a1,$a0,14
    andi   $t5,$a1,0x3FC
    addu   $a1,$t5,$s1
    lw   $t2,0($a1)
    mtc2   $t0,$12
    mtc2   $t1,$13
    mtc2   $t2,$14
    and   $t6,$t0,$t1
    and   $t6,$t6,$t2
    nclip
    bltz   $t6,.L80051374
    mfc2   $v0,$24
    andi   $t6,$t6,0x8000
    bgez   $v0,.L80051374
    nop
    bnez   $t6,.L80051374
    srl   $v0,$t3,1
    addu   $v0,$v0,$s2
    lh   $a0,0($v0)
    srl   $v0,$t4,1
    addu   $v0,$v0,$s2
    lh   $a1,0($v0)
    srl   $v0,$t5,1
    addu   $v0,$v0,$s2
    lh   $a2,0($v0)
    mtc2   $a0,$17
    mtc2   $a1,$18
    mtc2   $a2,$19
    sw   $t0,8($s6)
    sw   $t0,20($s6)
    avsz3
    sw   $t1,12($s6)
    mfc2   $v0,$7
    sw   $t2,16($s6)
    sll   $v0,$v0,2
    slti   $t9,$v0,0x1
    bnez   $t9,.L80051374
    srlv   $v0,$v0,$v1
    srl   $t0,$v0,11
    andi   $v0,$v0,0x7FF
    addi   $v0,$v0,-0x1000
    srav   $v0,$v0,$t0
    andi   $v0,$v0,0xFFF
    sll   $v0,$v0,2
    addu   $v0,$v0,$s4
    lw   $t1,0($v0)
    and   $t0,$s6,$fp
    sw   $t0,0($v0)
    or   $t1,$t1,$s5
    sw   $t1,0($s6)
    lui   $t0,0x4C80
    ori   $t0,$t0,32896
    lui   $t1,0x5555
    ori   $t1,$t1,21845
    sw   $t0,4($s6)
    sw   $t1,24($s6)
    addiu   $s6,$s6,0x1C
.L80051374:
    addiu   $s0,$s0,0x18
    bnez   $s3,.L80051268
    addiu   $s3,$s3,-0x1
.L80051380:
    lui   $at,%hi(D_800A38B4)
    sw   $s6,%lo(D_800A38B4)($at)
    lw   $ra,44($sp)
    lw   $fp,40($sp)
    lw   $s6,36($sp)
    lw   $s5,32($sp)
    lw   $s4,28($sp)
    lw   $s3,24($sp)
    lw   $s2,20($sp)
    lw   $s1,16($sp)
    jr   $ra
    addiu   $sp,$sp,0x38
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_800513B0
    addiu   $sp,$sp,-0x38
    sw   $ra,44($sp)
    sw   $fp,40($sp)
    sw   $s6,36($sp)
    sw   $s5,32($sp)
    sw   $s4,28($sp)
    sw   $s3,24($sp)
    sw   $s2,20($sp)
    sw   $s1,16($sp)
    beqz   $a0,.L8005157C
    addiu   $s3,$a0,-0x1
    lui   $s1,0x1F80
    ori   $s1,$s1,32
    lui   $s2,0x1F80
    ori   $s2,$s2,692
    lui   $s4,0x1F80
    lw   $s4,12($s4)
    lui   $s5,0x500
    lui   $fp,0xFF
    ori   $fp,$fp,65535
    lui   $s6,%hi(D_800A38B4)
    lw   $s6,%lo(D_800A38B4)($s6)
    lui   $v1,0x1F80
    lw   $v1,8($v1)
.L80051410:
    lhu   $a0,14($s0)
    lhu   $a1,16($s0)
    lwc2   $6,0($s0)
    sll   $a1,$a1,16
    or   $a0,$a0,$a1
    sll   $a1,$a0,2
    andi   $t3,$a1,0x3FC
    addu   $a1,$t3,$s1
    lw   $t0,0($a1)
    srl   $a1,$a0,6
    andi   $t4,$a1,0x3FC
    addu   $a1,$t4,$s1
    lw   $t1,0($a1)
    srl   $a1,$a0,14
    andi   $t5,$a1,0x3FC
    addu   $a1,$t5,$s1
    lw   $t2,0($a1)
    srl   $a1,$a0,22
    andi   $t6,$a1,0x3FC
    addu   $a1,$t6,$s1
    lw   $t7,0($a1)
    mtc2   $t0,$12
    mtc2   $t1,$13
    mtc2   $t2,$14
    and   $t8,$t0,$t1
    and   $t8,$t8,$t2
    and   $t8,$t8,$t7
    nclip
    bltz   $t8,.L80051570
    mfc2   $v0,$24
    andi   $t8,$t8,0x8000
    bgez   $v0,.L80051570
    nop
    bnez   $t8,.L80051570
    srl   $v0,$t3,1
    addu   $v0,$v0,$s2
    lh   $a0,0($v0)
    srl   $v0,$t4,1
    addu   $v0,$v0,$s2
    lh   $a1,0($v0)
    srl   $v0,$t5,1
    addu   $v0,$v0,$s2
    lh   $a2,0($v0)
    srl   $v0,$t6,1
    addu   $v0,$v0,$s2
    lh   $a3,0($v0)
    add   $a0,$a0,$a1
    add   $a0,$a0,$a2
    add   $a0,$a0,$a3
    sra   $v0,$a0,2
    slti   $t9,$v0,0x1
    bnez   $t9,.L80051570
    nop
    sw   $t1,8($s6)
    sw   $t0,12($s6)
    sw   $t2,16($s6)
    sw   $t2,32($s6)
    sw   $t7,36($s6)
    sw   $t1,40($s6)
    lui   $t0,0x4880
    ori   $t0,$t0,32896
    lui   $t1,0x5555
    ori   $t1,$t1,21845
    sw   $t0,4($s6)
    sw   $t1,20($s6)
    sw   $t0,28($s6)
    sw   $t1,44($s6)
    srlv   $v0,$v0,$v1
    srl   $t0,$v0,11
    andi   $v0,$v0,0x7FF
    addi   $v0,$v0,-0x1000
    srav   $v0,$v0,$t0
    andi   $v0,$v0,0xFFF
    sll   $v0,$v0,2
    addu   $v0,$v0,$s4
    lw   $t1,0($v0)
    and   $t0,$s6,$fp
    sw   $t0,0($v0)
    or   $t1,$t1,$s5
    sw   $t1,0($s6)
    nop
    addiu   $s6,$s6,0x18
    lw   $t1,0($v0)
    and   $t0,$s6,$fp
    sw   $t0,0($v0)
    or   $t1,$t1,$s5
    sw   $t1,0($s6)
    addiu   $s6,$s6,0x18
.L80051570:
    addiu   $s0,$s0,0x18
    bnez   $s3,.L80051410
    addiu   $s3,$s3,-0x1
.L8005157C:
    lui   $at,%hi(D_800A38B4)
    sw   $s6,%lo(D_800A38B4)($at)
    lw   $ra,44($sp)
    lw   $fp,40($sp)
    lw   $s6,36($sp)
    lw   $s5,32($sp)
    lw   $s4,28($sp)
    lw   $s3,24($sp)
    lw   $s2,20($sp)
    lw   $s1,16($sp)
    jr   $ra
    addiu   $sp,$sp,0x38
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_800515AC
    addiu   $sp,$sp,-0x38
    sw   $ra,44($sp)
    sw   $fp,40($sp)
    sw   $s6,36($sp)
    sw   $s5,32($sp)
    sw   $s4,28($sp)
    sw   $s3,24($sp)
    sw   $s2,20($sp)
    sw   $s1,16($sp)
    beqz   $a0,.L80051724
    addiu   $s3,$a0,-0x1
    lui   $s1,0x1F80
    ori   $s1,$s1,32
    lui   $s2,0x1F80
    ori   $s2,$s2,692
    lui   $s4,0x1F80
    lw   $s4,12($s4)
    lui   $s5,0x600
    lui   $fp,0xFF
    ori   $fp,$fp,65535
    lui   $s6,%hi(D_800A38B4)
    lw   $s6,%lo(D_800A38B4)($s6)
    lui   $v1,0x1F80
    lw   $v1,8($v1)
.L8005160C:
    lw   $a0,12($s0)
    nop
    sll   $a1,$a0,2
    andi   $t3,$a1,0x3FC
    addu   $a1,$t3,$s1
    lw   $t0,0($a1)
    srl   $a1,$a0,6
    andi   $t4,$a1,0x3FC
    addu   $a1,$t4,$s1
    lw   $t1,0($a1)
    srl   $a1,$a0,14
    andi   $t5,$a1,0x3FC
    addu   $a1,$t5,$s1
    lw   $t2,0($a1)
    mtc2   $t0,$12
    mtc2   $t1,$13
    mtc2   $t2,$14
    and   $t6,$t0,$t1
    and   $t6,$t6,$t2
    nclip
    bltz   $t6,.L80051718
    mfc2   $v0,$24
    andi   $t6,$t6,0x8000
    bgez   $v0,.L80051718
    nop
    bnez   $t6,.L80051718
    srl   $v0,$t3,1
    addu   $v0,$v0,$s2
    lh   $a0,0($v0)
    srl   $v0,$t4,1
    addu   $v0,$v0,$s2
    lh   $a1,0($v0)
    srl   $v0,$t5,1
    addu   $v0,$v0,$s2
    lh   $a2,0($v0)
    mtc2   $a0,$17
    mtc2   $a1,$18
    mtc2   $a2,$19
    sw   $t0,8($s6)
    sw   $t0,20($s6)
    avsz3
    sw   $t1,12($s6)
    mfc2   $v0,$7
    sw   $t2,16($s6)
    sll   $v0,$v0,2
    slti   $t9,$v0,0x1
    bnez   $t9,.L80051718
    srlv   $v0,$v0,$v1
    srl   $t0,$v0,11
    andi   $v0,$v0,0x7FF
    addi   $v0,$v0,-0x1000
    srav   $v0,$v0,$t0
    andi   $v0,$v0,0xFFF
    sll   $v0,$v0,2
    addu   $v0,$v0,$s4
    lw   $t1,0($v0)
    and   $t0,$s6,$fp
    sw   $t0,0($v0)
    or   $t1,$t1,$s5
    sw   $t1,0($s6)
    lui   $t0,0x4C80
    ori   $t0,$t0,32896
    lui   $t1,0x5555
    ori   $t1,$t1,21845
    sw   $t0,4($s6)
    sw   $t1,24($s6)
    addiu   $s6,$s6,0x1C
.L80051718:
    addiu   $s0,$s0,0x24
    bnez   $s3,.L8005160C
    addiu   $s3,$s3,-0x1
.L80051724:
    lui   $at,%hi(D_800A38B4)
    sw   $s6,%lo(D_800A38B4)($at)
    lw   $ra,44($sp)
    lw   $fp,40($sp)
    lw   $s6,36($sp)
    lw   $s5,32($sp)
    lw   $s4,28($sp)
    lw   $s3,24($sp)
    lw   $s2,20($sp)
    lw   $s1,16($sp)
    jr   $ra
    addiu   $sp,$sp,0x38
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_80051754
    addiu   $sp,$sp,-0x38
    sw   $ra,44($sp)
    sw   $fp,40($sp)
    sw   $s6,36($sp)
    sw   $s5,32($sp)
    sw   $s4,28($sp)
    sw   $s3,24($sp)
    sw   $s2,20($sp)
    sw   $s1,16($sp)
    beqz   $a0,.L80051914
    addiu   $s3,$a0,-0x1
    lui   $s1,0x1F80
    ori   $s1,$s1,32
    lui   $s2,0x1F80
    ori   $s2,$s2,692
    lui   $s4,0x1F80
    lw   $s4,12($s4)
    lui   $s5,0x500
    lui   $fp,0xFF
    ori   $fp,$fp,65535
    lui   $s6,%hi(D_800A38B4)
    lw   $s6,%lo(D_800A38B4)($s6)
    lui   $v1,0x1F80
    lw   $v1,8($v1)
.L800517B4:
    lw   $a0,16($s0)
    nop
    sll   $a1,$a0,2
    andi   $t3,$a1,0x3FC
    addu   $a1,$t3,$s1
    lw   $t0,0($a1)
    srl   $a1,$a0,6
    andi   $t4,$a1,0x3FC
    addu   $a1,$t4,$s1
    lw   $t1,0($a1)
    srl   $a1,$a0,14
    andi   $t5,$a1,0x3FC
    addu   $a1,$t5,$s1
    lw   $t2,0($a1)
    srl   $a1,$a0,22
    andi   $t6,$a1,0x3FC
    addu   $a1,$t6,$s1
    lw   $t7,0($a1)
    mtc2   $t0,$12
    mtc2   $t1,$13
    mtc2   $t2,$14
    and   $t8,$t0,$t1
    and   $t8,$t8,$t2
    and   $t8,$t8,$t7
    nclip
    bltz   $t8,.L80051908
    mfc2   $v0,$24
    andi   $t8,$t8,0x8000
    bgez   $v0,.L80051908
    nop
    bnez   $t8,.L80051908
    srl   $v0,$t3,1
    addu   $v0,$v0,$s2
    lh   $a0,0($v0)
    srl   $v0,$t4,1
    addu   $v0,$v0,$s2
    lh   $a1,0($v0)
    srl   $v0,$t5,1
    addu   $v0,$v0,$s2
    lh   $a2,0($v0)
    srl   $v0,$t6,1
    addu   $v0,$v0,$s2
    lh   $a3,0($v0)
    add   $a0,$a0,$a1
    add   $a0,$a0,$a2
    add   $a0,$a0,$a3
    sra   $v0,$a0,2
    slti   $t9,$v0,0x1
    bnez   $t9,.L80051908
    nop
    sw   $t1,8($s6)
    sw   $t0,12($s6)
    sw   $t2,16($s6)
    sw   $t2,32($s6)
    sw   $t7,36($s6)
    sw   $t1,40($s6)
    lui   $t0,0x4880
    ori   $t0,$t0,32896
    lui   $t1,0x5555
    ori   $t1,$t1,21845
    sw   $t0,4($s6)
    sw   $t1,20($s6)
    sw   $t0,28($s6)
    sw   $t1,44($s6)
    srlv   $v0,$v0,$v1
    srl   $t0,$v0,11
    andi   $v0,$v0,0x7FF
    addi   $v0,$v0,-0x1000
    srav   $v0,$v0,$t0
    andi   $v0,$v0,0xFFF
    sll   $v0,$v0,2
    addu   $v0,$v0,$s4
    lw   $t1,0($v0)
    and   $t0,$s6,$fp
    sw   $t0,0($v0)
    or   $t1,$t1,$s5
    sw   $t1,0($s6)
    nop
    addiu   $s6,$s6,0x18
    lw   $t1,0($v0)
    and   $t0,$s6,$fp
    sw   $t0,0($v0)
    or   $t1,$t1,$s5
    sw   $t1,0($s6)
    addiu   $s6,$s6,0x18
.L80051908:
    addiu   $s0,$s0,0x2C
    bnez   $s3,.L800517B4
    addiu   $s3,$s3,-0x1
.L80051914:
    lui   $at,%hi(D_800A38B4)
    sw   $s6,%lo(D_800A38B4)($at)
    lw   $ra,44($sp)
    lw   $fp,40($sp)
    lw   $s6,36($sp)
    lw   $s5,32($sp)
    lw   $s4,28($sp)
    lw   $s3,24($sp)
    lw   $s2,20($sp)
    lw   $s1,16($sp)
    jr   $ra
    addiu   $sp,$sp,0x38
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_80051944
    addiu   $sp,$sp,-0x38
    sw   $ra,44($sp)
    sw   $fp,40($sp)
    sw   $s6,36($sp)
    sw   $s5,32($sp)
    sw   $s4,28($sp)
    sw   $s3,24($sp)
    sw   $s2,20($sp)
    sw   $s1,16($sp)
    beqz   $a0,.L80051AD8
    addiu   $s3,$a0,-0x1
    lui   $s1,0x1F80
    ori   $s1,$s1,32
    lui   $s2,0x1F80
    ori   $s2,$s2,692
    lui   $s4,0x1F80
    lw   $s4,12($s4)
    lui   $s5,0x400
    lui   $fp,0xFF
    ori   $fp,$fp,65535
    lui   $t0,0x1F80
    lw   $t0,20($t0)
    addiu   $t1,$zero,0x14
    and   $t0,$t0,$t1
    add   $s6,$s0,$t0
    addi   $s0,$s0,0x28
    lui   $v1,0x1F80
    lw   $v1,8($v1)
    lwc2   $6,4($s6)
.L800519B8:
    lw   $a0,0($s0)
    nop
    sll   $a1,$a0,2
    andi   $t3,$a1,0x3FC
    addu   $a1,$t3,$s1
    lw   $t0,0($a1)
    srl   $a1,$a0,6
    andi   $t4,$a1,0x3FC
    addu   $a1,$t4,$s1
    lw   $t1,0($a1)
    srl   $a1,$a0,14
    andi   $t5,$a1,0x3FC
    addu   $a1,$t5,$s1
    lw   $t2,0($a1)
    mtc2   $t0,$12
    mtc2   $t1,$13
    mtc2   $t2,$14
    and   $t6,$t0,$t1
    and   $t6,$t6,$t2
    nclip
    bltz   $t6,.L80051AC8
    mfc2   $v0,$24
    andi   $t6,$t6,0x8000
    bgez   $v0,.L80051AC8
    nop
    bnez   $t6,.L80051AC8
    srl   $v0,$t3,1
    addu   $v0,$v0,$s2
    lh   $a0,0($v0)
    srl   $v0,$t4,1
    addu   $v0,$v0,$s2
    lh   $a1,0($v0)
    srl   $v0,$t5,1
    addu   $v0,$v0,$s2
    lh   $a2,0($v0)
    mtc2   $a0,$17
    mtc2   $a1,$18
    mtc2   $a2,$19
    sw   $t0,8($s6)
    nop
    avsz3
    sw   $t1,12($s6)
    mfc2   $v0,$7
    sw   $t2,16($s6)
    blez   $v0,.L80051AC8
    sll   $v0,$v0,2
    lui   $at,0x1
    slt   $t9,$v0,$at
    beqz   $t9,.L80051AC8
    nop
    lwc2   $0,4($s0)
    lwc2   $1,8($s0)
    lwc2   $6,12($s0)
    srlv   $v0,$v0,$v1
    srl   $t0,$v0,11
    andi   $v0,$v0,0x7FF
    addi   $v0,$v0,-0x1000
    srav   $v0,$v0,$t0
    andi   $v0,$v0,0xFFF
    nccs
    sll   $v0,$v0,2
    addu   $v0,$v0,$s4
    lw   $t1,0($v0)
    and   $t0,$s6,$fp
    sw   $t0,0($v0)
    or   $t1,$t1,$s5
    sw   $t1,0($s6)
    swc2   $22,4($s6)
.L80051AC8:
    addiu   $s0,$s0,0x38
    addiu   $s6,$s6,0x38
    bnez   $s3,.L800519B8
    addiu   $s3,$s3,-0x1
.L80051AD8:
    addi   $s0,$s0,-0x28
    lw   $ra,44($sp)
    lw   $fp,40($sp)
    lw   $s6,36($sp)
    lw   $s5,32($sp)
    lw   $s4,28($sp)
    lw   $s3,24($sp)
    lw   $s2,20($sp)
    lw   $s1,16($sp)
    jr   $ra
    addiu   $sp,$sp,0x38
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_80051B04
    addiu   $sp,$sp,-0x38
    sw   $ra,48($sp)
    sw   $fp,44($sp)
    sw   $s7,40($sp)
    sw   $s6,36($sp)
    sw   $s5,32($sp)
    sw   $s4,28($sp)
    sw   $s3,24($sp)
    sw   $s2,20($sp)
    sw   $s1,16($sp)
    beqz   $a0,.L80051CD8
    addiu   $s3,$a0,-0x1
    lui   $s1,0x1F80
    ori   $s1,$s1,32
    lui   $s2,0x1F80
    ori   $s2,$s2,692
    lui   $s4,0x1F80
    lw   $s4,12($s4)
    lui   $s5,0x500
    lui   $fp,0xFF
    ori   $fp,$fp,65535
    lui   $t0,0x1F80
    lw   $t0,20($t0)
    addiu   $t1,$zero,0x18
    and   $t1,$t0,$t1
    add   $s6,$s0,$t1
    addi   $s0,$s0,0x30
    addiu   $t1,$zero,0xC
    and   $t1,$t0,$t1
    addi   $t1,$t1,0x8
    add   $s7,$s0,$t1
    lui   $v1,0x1F80
    lw   $v1,8($v1)
.L80051B88:
    lw   $a0,0($s0)
    nop
    sll   $a1,$a0,2
    andi   $t3,$a1,0x3FC
    addu   $a1,$t3,$s1
    lw   $t0,0($a1)
    srl   $a1,$a0,6
    andi   $t4,$a1,0x3FC
    addu   $a1,$t4,$s1
    lw   $t1,0($a1)
    srl   $a1,$a0,14
    andi   $t5,$a1,0x3FC
    addu   $a1,$t5,$s1
    lw   $t2,0($a1)
    srl   $a1,$a0,22
    andi   $t6,$a1,0x3FC
    addu   $a1,$t6,$s1
    lw   $t7,0($a1)
    mtc2   $t0,$12
    mtc2   $t1,$13
    mtc2   $t2,$14
    and   $t8,$t0,$t1
    and   $t8,$t8,$t2
    and   $t8,$t8,$t7
    nclip
    bltz   $t8,.L80051CC4
    mfc2   $v0,$24
    andi   $t8,$t8,0x8000
    bgez   $v0,.L80051CC4
    nop
    bnez   $t8,.L80051CC4
    srl   $v0,$t3,1
    addu   $v0,$v0,$s2
    lh   $a0,0($v0)
    srl   $v0,$t4,1
    addu   $v0,$v0,$s2
    lh   $a1,0($v0)
    srl   $v0,$t5,1
    addu   $v0,$v0,$s2
    lh   $a2,0($v0)
    srl   $v0,$t6,1
    addu   $v0,$v0,$s2
    lh   $a3,0($v0)
    add   $a0,$a0,$a1
    add   $a0,$a0,$a2
    add   $a0,$a0,$a3
    sra   $v0,$a0,2
    blez   $v0,.L80051CC4
    lui   $at,0x1
    slt   $t9,$v0,$at
    beqz   $t9,.L80051CC4
    nop
    sw   $t0,8($s6)
    sw   $t1,12($s6)
    sw   $t2,16($s6)
    sw   $t7,20($s6)
    lw   $t2,4($s0)
    nop
    add   $v0,$v0,$t2
    srlv   $v0,$v0,$v1
    srl   $t0,$v0,11
    andi   $v0,$v0,0x7FF
    addi   $v0,$v0,-0x1000
    srav   $v0,$v0,$t0
    andi   $v0,$v0,0xFFF
    sll   $v0,$v0,2
    addu   $v0,$v0,$s4
    lw   $t1,0($v0)
    and   $t0,$s6,$fp
    sw   $t0,0($v0)
    or   $t1,$t1,$s5
    sw   $t1,0($s6)
    nop
    lw   $t1,0($v0)
    and   $t0,$s7,$fp
    sw   $t0,0($v0)
    lui   $at,0x200
    or   $t1,$t1,$at
    sw   $t1,0($s7)
.L80051CC4:
    addiu   $s0,$s0,0x50
    addiu   $s6,$s6,0x50
    addiu   $s7,$s7,0x50
    bnez   $s3,.L80051B88
    addiu   $s3,$s3,-0x1
.L80051CD8:
    addi   $s0,$s0,-0x30
    lw   $ra,48($sp)
    lw   $fp,44($sp)
    lw   $s7,40($sp)
    lw   $s6,36($sp)
    lw   $s5,32($sp)
    lw   $s4,28($sp)
    lw   $s3,24($sp)
    lw   $s2,20($sp)
    lw   $s1,16($sp)
    jr   $ra
    addiu   $sp,$sp,0x38
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_80051D08
    addiu   $sp,$sp,-0x38
    sw   $ra,44($sp)
    sw   $fp,40($sp)
    sw   $s6,36($sp)
    sw   $s5,32($sp)
    sw   $s4,28($sp)
    sw   $s3,24($sp)
    sw   $s2,20($sp)
    sw   $s1,16($sp)
    beqz   $a0,.L80051EA8
    addiu   $s3,$a0,-0x1
    lui   $s1,0x1F80
    ori   $s1,$s1,32
    lui   $s2,0x1F80
    ori   $s2,$s2,692
    lui   $s4,%hi(D_800A38D8)
    lw   $s4,%lo(D_800A38D8)($s4)
    lui   $s5,0x400
    lui   $fp,0xFF
    ori   $fp,$fp,65535
    lui   $t0,0x1F80
    lw   $t0,20($t0)
    addiu   $t1,$zero,0x14
    and   $t0,$t0,$t1
    add   $s6,$s0,$t0
    addi   $s0,$s0,0x28
    lui   $v1,0x1F80
    lw   $v1,8($v1)
    lwc2   $6,4($s6)
.L80051D7C:
    lw   $a0,0($s0)
    nop
    sll   $a1,$a0,2
    andi   $t3,$a1,0x3FC
    addu   $a1,$t3,$s1
    lw   $t0,0($a1)
    srl   $a1,$a0,6
    andi   $t4,$a1,0x3FC
    addu   $a1,$t4,$s1
    lw   $t1,0($a1)
    srl   $a1,$a0,14
    andi   $t5,$a1,0x3FC
    addu   $a1,$t5,$s1
    lw   $t2,0($a1)
    mtc2   $t0,$12
    mtc2   $t1,$13
    mtc2   $t2,$14
    and   $t6,$t0,$t1
    and   $t6,$t6,$t2
    nclip
    bltz   $t6,.L80051E98
    mfc2   $v0,$24
    andi   $t6,$t6,0x8000
    bgez   $v0,.L80051E98
    nop
    bnez   $t6,.L80051E98
    srl   $v0,$t3,1
    addu   $v0,$v0,$s2
    lh   $a0,0($v0)
    srl   $v0,$t4,1
    addu   $v0,$v0,$s2
    lh   $a1,0($v0)
    srl   $v0,$t5,1
    addu   $v0,$v0,$s2
    lh   $a2,0($v0)
    mtc2   $a0,$17
    mtc2   $a1,$18
    mtc2   $a2,$19
    sw   $t0,8($s6)
    nop
    avsz3
    sw   $t1,12($s6)
    mfc2   $v0,$7
    sw   $t2,16($s6)
    blez   $v0,.L80051E98
    sll   $v0,$v0,2
    lui   $at,0x1
    slt   $t9,$v0,$at
    beqz   $t9,.L80051E98
    nop
    addi   $v0,$v0,-0x3E8
    lwc2   $0,4($s0)
    lwc2   $1,8($s0)
    lwc2   $6,12($s0)
    srlv   $v0,$v0,$v1
    srl   $t0,$v0,11
    andi   $v0,$v0,0x7FF
    nccs
    addi   $v0,$v0,-0x1000
    srav   $v0,$v0,$t0
    andi   $v0,$v0,0xFFF
    srl   $v0,$v0,4
    andi   $v0,$v0,0xFF
    sll   $v0,$v0,2
    addu   $v0,$v0,$s4
    lw   $t1,0($v0)
    and   $t0,$s6,$fp
    sw   $t0,0($v0)
    or   $t1,$t1,$s5
    sw   $t1,0($s6)
    swc2   $22,4($s6)
.L80051E98:
    addiu   $s0,$s0,0x38
    addiu   $s6,$s6,0x38
    bnez   $s3,.L80051D7C
    addiu   $s3,$s3,-0x1
.L80051EA8:
    addi   $s0,$s0,-0x28
    lw   $ra,44($sp)
    lw   $fp,40($sp)
    lw   $s6,36($sp)
    lw   $s5,32($sp)
    lw   $s4,28($sp)
    lw   $s3,24($sp)
    lw   $s2,20($sp)
    lw   $s1,16($sp)
    jr   $ra
    addiu   $sp,$sp,0x38
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_80051ED4
    addiu   $sp,$sp,-0x38
    sw   $ra,44($sp)
    sw   $fp,40($sp)
    sw   $s6,36($sp)
    sw   $s5,32($sp)
    sw   $s4,28($sp)
    sw   $s3,24($sp)
    sw   $s2,20($sp)
    sw   $s1,16($sp)
    beqz   $a0,.L8005208C
    addiu   $s3,$a0,-0x1
    lui   $s1,0x1F80
    ori   $s1,$s1,32
    lui   $s2,0x1F80
    ori   $s2,$s2,692
    lui   $s4,%hi(D_800A38D8)
    lw   $s4,%lo(D_800A38D8)($s4)
    lui   $s5,0x500
    lui   $fp,0xFF
    ori   $fp,$fp,65535
    lui   $t0,0x1F80
    lw   $t0,20($t0)
    addiu   $t1,$zero,0x18
    and   $t0,$t0,$t1
    add   $s6,$s0,$t0
    addi   $s0,$s0,0x30
    lui   $v1,0x1F80
    lw   $v1,8($v1)
    lwc2   $6,4($s6)
.L80051F48:
    lw   $a0,0($s0)
    nop
    sll   $a1,$a0,2
    andi   $t3,$a1,0x3FC
    addu   $a1,$t3,$s1
    lw   $t0,0($a1)
    srl   $a1,$a0,6
    andi   $t4,$a1,0x3FC
    addu   $a1,$t4,$s1
    lw   $t1,0($a1)
    srl   $a1,$a0,14
    andi   $t5,$a1,0x3FC
    addu   $a1,$t5,$s1
    lw   $t2,0($a1)
    srl   $a1,$a0,22
    andi   $t6,$a1,0x3FC
    addu   $a1,$t6,$s1
    lw   $t7,0($a1)
    mtc2   $t0,$12
    mtc2   $t1,$13
    mtc2   $t2,$14
    and   $t8,$t0,$t1
    and   $t8,$t8,$t2
    and   $t8,$t8,$t7
    nclip
    bltz   $t8,.L8005207C
    mfc2   $v0,$24
    andi   $t8,$t8,0x8000
    bgez   $v0,.L8005207C
    nop
    bnez   $t8,.L8005207C
    srl   $v0,$t3,1
    addu   $v0,$v0,$s2
    lh   $a0,0($v0)
    srl   $v0,$t4,1
    addu   $v0,$v0,$s2
    lh   $a1,0($v0)
    srl   $v0,$t5,1
    addu   $v0,$v0,$s2
    lh   $a2,0($v0)
    srl   $v0,$t6,1
    addu   $v0,$v0,$s2
    lh   $a3,0($v0)
    add   $a0,$a0,$a1
    add   $a0,$a0,$a2
    add   $a0,$a0,$a3
    sra   $v0,$a0,2
    blez   $v0,.L8005207C
    lui   $at,0x1
    slt   $t9,$v0,$at
    beqz   $t9,.L8005207C
    nop
    sw   $t0,8($s6)
    sw   $t1,12($s6)
    sw   $t2,16($s6)
    sw   $t7,20($s6)
    addi   $v0,$v0,-0x3E8
    lwc2   $0,4($s0)
    lwc2   $1,8($s0)
    lwc2   $6,12($s0)
    srlv   $v0,$v0,$v1
    srl   $t0,$v0,11
    andi   $v0,$v0,0x7FF
    nccs
    addi   $v0,$v0,-0x1000
    srav   $v0,$v0,$t0
    andi   $v0,$v0,0xFFF
    srl   $v0,$v0,4
    andi   $v0,$v0,0xFF
    sll   $v0,$v0,2
    addu   $v0,$v0,$s4
    lw   $t1,0($v0)
    and   $t0,$s6,$fp
    sw   $t0,0($v0)
    or   $t1,$t1,$s5
    sw   $t1,0($s6)
    swc2   $22,4($s6)
.L8005207C:
    addiu   $s0,$s0,0x40
    addiu   $s6,$s6,0x40
    bnez   $s3,.L80051F48
    addiu   $s3,$s3,-0x1
.L8005208C:
    addi   $s0,$s0,-0x30
    lw   $ra,44($sp)
    lw   $fp,40($sp)
    lw   $s6,36($sp)
    lw   $s5,32($sp)
    lw   $s4,28($sp)
    lw   $s3,24($sp)
    lw   $s2,20($sp)
    lw   $s1,16($sp)
    jr   $ra
    addiu   $sp,$sp,0x38
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_800520B8
    slt  $at,$a0,$a1
    bnez  $at,.L80052248
    nop
    addiu  $sp,$sp,-24
    sw  $s1,20($sp)
    sw  $s0,16($sp)
    beqz  $a2,.L80052238
    andi  $t0,$a2,3
    slt  $t0,$zero,$t0
    srl  $a2,$a2,2
    add  $a2,$a2,$t0
    andi  $v0,$a2,15
    srl  $a2,$a2,4
    beqz  $a2,.L8005218C
    addi  $a2,$a2,-1
.L800520F4:
    lw  $t0,0($a0)
    lw  $t1,4($a0)
    lw  $t2,8($a0)
    lw  $t3,12($a0)
    lw  $t4,16($a0)
    lw  $t5,20($a0)
    lw  $t6,24($a0)
    lw  $t7,28($a0)
    sw  $t0,0($a1)
    sw  $t1,4($a1)
    sw  $t2,8($a1)
    sw  $t3,12($a1)
    sw  $t4,16($a1)
    sw  $t5,20($a1)
    sw  $t6,24($a1)
    sw  $t7,28($a1)
    lw  $t0,32($a0)
    lw  $t1,36($a0)
    lw  $t2,40($a0)
    lw  $t3,44($a0)
    lw  $t4,48($a0)
    lw  $t5,52($a0)
    lw  $t6,56($a0)
    lw  $t7,60($a0)
    sw  $t0,32($a1)
    sw  $t1,36($a1)
    sw  $t2,40($a1)
    sw  $t3,44($a1)
    sw  $t4,48($a1)
    sw  $t5,52($a1)
    sw  $t6,56($a1)
    sw  $t7,60($a1)
    addi  $a0,$a0,64
    addi  $a1,$a1,64
    bnez  $a2,.L800520F4
    addi  $a2,$a2,-1
    beqz  $v0,.L80052238
    nop
.L8005218C:
    addiu  $v1,$zero,15
    sub  $v1,$v1,$v0
    sll  $v1,$v1,2
    lui  $t9,%hi(D_800521AC)
    addiu  $t9,$t9,%lo(D_800521AC)
    add  $t9,$t9,$v1
    jr  $t9
    nop
alabel D_800521AC
    lw  $t0,56($a0)
    lw  $t1,52($a0)
    lw  $t2,48($a0)
    lw  $t3,44($a0)
    lw  $t4,40($a0)
    lw  $t5,36($a0)
    lw  $t6,32($a0)
    lw  $t7,28($a0)
    lw  $t8,24($a0)
    lw  $t9,20($a0)
    lw  $a3,16($a0)
    lw  $a2,12($a0)
    lw  $v0,8($a0)
    lw  $s1,4($a0)
    lw  $s0,0($a0)
    lui  $a0,%hi(D_800521FC)
    addiu  $a0,$a0,%lo(D_800521FC)
    add  $a0,$a0,$v1
    jr  $a0
    nop
alabel D_800521FC
    sw  $t0,56($a1)
    sw  $t1,52($a1)
    sw  $t2,48($a1)
    sw  $t3,44($a1)
    sw  $t4,40($a1)
    sw  $t5,36($a1)
    sw  $t6,32($a1)
    sw  $t7,28($a1)
    sw  $t8,24($a1)
    sw  $t9,20($a1)
    sw  $a3,16($a1)
    sw  $a2,12($a1)
    sw  $v0,8($a1)
    sw  $s1,4($a1)
    sw  $s0,0($a1)
.L80052238:
    lw  $s1,20($sp)
    lw  $s0,16($sp)
    jr  $ra
    addiu  $sp,$sp,24
.L80052248:
    addiu  $sp,$sp,-24
    sw  $s1,20($sp)
    sw  $s0,16($sp)
    beqz  $a2,.L800523D0
    andi  $t0,$a2,3
    slt  $t0,$zero,$t0
    srl  $a2,$a2,2
    add  $a2,$a2,$t0
    sll  $t0,$a2,2
    add  $a0,$a0,$t0
    add  $a1,$a1,$t0
    addi  $a0,$a0,-4
    addi  $a1,$a1,-4
    andi  $v0,$a2,15
    srl  $a2,$a2,4
    beqz  $a2,.L80052324
    addi  $a2,$a2,-1
.L8005228C:
    lw  $t0,0($a0)
    lw  $t1,-4($a0)
    lw  $t2,-8($a0)
    lw  $t3,-12($a0)
    lw  $t4,-16($a0)
    lw  $t5,-20($a0)
    lw  $t6,-24($a0)
    lw  $t7,-28($a0)
    sw  $t0,0($a1)
    sw  $t1,-4($a1)
    sw  $t2,-8($a1)
    sw  $t3,-12($a1)
    sw  $t4,-16($a1)
    sw  $t5,-20($a1)
    sw  $t6,-24($a1)
    sw  $t7,-28($a1)
    lw  $t0,-32($a0)
    lw  $t1,-36($a0)
    lw  $t2,-40($a0)
    lw  $t3,-44($a0)
    lw  $t4,-48($a0)
    lw  $t5,-52($a0)
    lw  $t6,-56($a0)
    lw  $t7,-60($a0)
    sw  $t0,-32($a1)
    sw  $t1,-36($a1)
    sw  $t2,-40($a1)
    sw  $t3,-44($a1)
    sw  $t4,-48($a1)
    sw  $t5,-52($a1)
    sw  $t6,-56($a1)
    sw  $t7,-60($a1)
    addi  $a0,$a0,-64
    addi  $a1,$a1,-64
    bnez  $a2,.L8005228C
    addi  $a2,$a2,-1
    beqz  $v0,.L800523D0
    nop
.L80052324:
    addiu  $v1,$zero,15
    sub  $v1,$v1,$v0
    sll  $v1,$v1,2
    lui  $t9,%hi(D_80052344)
    addiu  $t9,$t9,%lo(D_80052344)
    add  $t9,$t9,$v1
    jr  $t9
    nop
alabel D_80052344
    lw  $t0,-56($a0)
    lw  $t1,-52($a0)
    lw  $t2,-48($a0)
    lw  $t3,-44($a0)
    lw  $t4,-40($a0)
    lw  $t5,-36($a0)
    lw  $t6,-32($a0)
    lw  $t7,-28($a0)
    lw  $t8,-24($a0)
    lw  $t9,-20($a0)
    lw  $a3,-16($a0)
    lw  $a2,-12($a0)
    lw  $v0,-8($a0)
    lw  $s1,-4($a0)
    lw  $s0,0($a0)
    lui  $a0,%hi(D_80052394)
    addiu  $a0,$a0,%lo(D_80052394)
    add  $a0,$a0,$v1
    jr  $a0
    nop
alabel D_80052394
    sw  $t0,-56($a1)
    sw  $t1,-52($a1)
    sw  $t2,-48($a1)
    sw  $t3,-44($a1)
    sw  $t4,-40($a1)
    sw  $t5,-36($a1)
    sw  $t6,-32($a1)
    sw  $t7,-28($a1)
    sw  $t8,-24($a1)
    sw  $t9,-20($a1)
    sw  $a3,-16($a1)
    sw  $a2,-12($a1)
    sw  $v0,-8($a1)
    sw  $s1,-4($a1)
    sw  $s0,0($a1)
.L800523D0:
    lw  $s1,20($sp)
    lw  $s0,16($sp)
    jr  $ra
    addiu  $sp,$sp,24
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_800523E0
    addiu   $sp,$sp,-0x38
    sw   $ra,44($sp)
    sw   $fp,40($sp)
    sw   $s5,36($sp)
    sw   $s4,32($sp)
    sw   $s3,28($sp)
    sw   $s2,24($sp)
    sw   $s1,20($sp)
    sw   $s0,16($sp)
    addu   $s0,$a0,$zero
    addu   $s1,$a1,$zero
    addu   $s3,$a2,$zero
    addu   $s2,$a3,$zero
    addiu   $s4,$zero,0x1000
    sub   $s4,$s4,$s3
    lh   $t0,0($s0)
    lh   $t1,2($s0)
    lh   $t2,4($s0)
    mtc2   $s4,$8
    mtc2   $t0,$9
    mtc2   $t1,$10
    mtc2   $t2,$11
    lh   $t3,0($s1)
    lh   $t4,2($s1)
    gpf   1
    lh   $t5,4($s1)
    lh   $a0,6($s0)
    lh   $a1,8($s0)
    lh   $a2,10($s0)
    mtc2   $s3,$8
    mtc2   $t3,$9
    mtc2   $t4,$10
    mtc2   $t5,$11
    lh   $s5,6($s1)
    lh   $fp,8($s1)
    gpl   1
    lh   $a3,10($s1)
    nop
    jal   func_800525D8
    nop
    mtc2   $s4,$8
    mtc2   $a0,$9
    mtc2   $a1,$10
    mtc2   $a2,$11
    addu   $a0,$t0,$zero
    addu   $a1,$t1,$zero
    gpf   1
    addu   $a2,$t2,$zero
    sh   $a0,0($s2)
    sh   $a1,2($s2)
    sh   $a2,4($s2)
    mtc2   $s3,$8
    mtc2   $s5,$9
    mtc2   $fp,$10
    mtc2   $a3,$11
    nop
    nop
    gpl   1
    nop
    nop
    mfc2   $t0,$9
    mfc2   $t1,$10
    mfc2   $t2,$11
    mult   $a0,$t0
    mflo   $t3
    nop
    nop
    mult   $a1,$t1
    mflo   $t4
    nop
    nop
    mult   $a2,$t2
    mflo   $t5
    nop
    add   $t3,$t3,$t4
    add   $t3,$t3,$t5
    sra   $t3,$t3,12
    neg   $t3,$t3
    mtc2   $t3,$8
    mtc2   $a0,$9
    mtc2   $a1,$10
    mtc2   $a2,$11
    mtc2   $t0,$25
    mtc2   $t1,$26
    mtc2   $t2,$27
    nop
    nop
    gpl   1
    nop
    nop
    jal   func_800525D8
    nop
    cfc2   $t3,$0
    cfc2   $t4,$2
    cfc2   $t5,$4
    ctc2   $a0,$0
    ctc2   $a1,$2
    ctc2   $a2,$4
    mtc2   $t0,$9
    mtc2   $t1,$10
    mtc2   $t2,$11
    nop
    nop
    op   1
    sh   $t0,6($s2)
    sh   $t1,8($s2)
    sh   $t2,10($s2)
    mfc2   $t0,$25
    mfc2   $t1,$26
    mfc2   $t2,$27
    sh   $t0,12($s2)
    sh   $t1,14($s2)
    sh   $t2,16($s2)
    ctc2   $t3,$0
    ctc2   $t4,$2
    ctc2   $t5,$4
    lw   $ra,44($sp)
    lw   $fp,40($sp)
    lw   $s5,36($sp)
    lw   $s4,32($sp)
    lw   $s3,28($sp)
    lw   $s2,24($sp)
    lw   $s1,20($sp)
    lw   $s0,16($sp)
    jr   $ra
    addiu   $sp,$sp,0x38
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_800525D8
    mfc2   $t0, $9
    mfc2   $t1, $10
    mfc2   $t2, $11
    nop
    nop
    sqr    0
    nop
    mfc2   $t3, $25
    mfc2   $t4, $26
    mfc2   $t5, $27
    add    $t3, $t3, $t4
    add    $v0, $t3, $t5
    mtc2   $v0, $30
    nop
    nop
    mfc2   $v1, $31
    nop
    andi   $v1, $v1, 0x1E
    addiu  $t6, $zero, 0x1F
    sub    $t6, $t6, $v1
    addi   $t3, $v1, -0x18
    bltz   $t3, .L8005263C
    sra    $t6, $t6, 1
    j      .L80052648
    sllv   $t4, $v0, $t3
.L8005263C:
    addiu  $t3, $zero, 0x18
    sub    $t3, $t3, $v1
    srav   $t4, $v0, $t3
.L80052648:
    addi   $t4, $t4, -0x40
    sll    $t4, $t4, 1
    lui    $t5, %hi(D_800154A0)
    addiu  $t5, $t5, %lo(D_800154A0)
    addu   $t5, $t5, $t4
    lh     $t5, 0($t5)
    nop
    mtc2   $t5, $8
    mtc2   $t0, $9
    mtc2   $t1, $10
    mtc2   $t2, $11
    nop
    nop
    gpf    0
    mfc2   $t0, $25
    mfc2   $t1, $26
    mfc2   $t2, $27
    srav   $t0, $t0, $t6
    srav   $t1, $t1, $t6
    srav   $t2, $t2, $t6
    jr     $ra
    nop
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_800526A0
    mtc2       $a0, $30
    beqz       $a0, .L80052710
     addiu     $t0, $zero, 0x1F
    mfc2       $v0, $31
    lui        $t1, %hi(D_80015620)
    addiu      $t1, $t1, %lo(D_80015620)
    andi       $v0, $v0, 0x1E
    addi       $t0, $v0, -0x18
    bltz       $t0, .L800526E0
     nop
    sll        $v0, $a0, 1
    add        $v0, $v0, $t1
    lh         $v0, 0($v0)
    nop
    jr         $ra
     srl       $v0, $v0, 9
.L800526E0:
    addiu      $t0, $zero, 0x18
    sub        $t0, $t0, $v0
    srav       $t0, $a0, $t0
    sll        $t0, $t0, 1
    add        $t0, $t0, $t1
    lh         $t0, 0($t0)
    addiu      $t1, $zero, 0x1F
    sub        $t1, $t1, $v0
    sra        $t1, $t1, 1
    sllv       $v0, $t0, $t1
    jr         $ra
     srl       $v0, $v0, 12
.L80052710:
    jr         $ra
     addu      $v0, $zero, $zero
.set	reorder
.set	at
.set reorder
.set at

	.section .text
    nop
    nop

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_80052720
    mtc2   $a0, $9
    mtc2   $a1, $10
    mtc2   $a2, $11
    nop
    nop
    .word  0x4AA00428
    nop
    mfc2   $t0, $25
    mfc2   $t1, $26
    mfc2   $t2, $27
    add    $a0, $t0, $t1
    j      func_800526A0
    add    $a0, $a0, $t2
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_80052754
    mtc2   $a0, $9
    mtc2   $a1, $10
    mtc2   $a2, $11
    nop
    nop
    .word  0x4AA00428
    nop
    mfc2   $t0, $25
    mfc2   $t1, $26
    mfc2   $t2, $27
    addu   $v0, $t0, $t1
    jr     $ra
    addu   $v0, $v0, $t2
.set	reorder
.set	at
.set reorder
.set at

 #NO_APP
	.align	2
	.globl	func_80052788
	.ent	func_80052788
func_80052788:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lh	$8,0($4)
	lh	$9,2($4)
	lh	$10,4($4)
 #APP
	ori $11, $zero, 0x1000
	sub $11, $11, $6
	mtc2 $11, $8
	mtc2 $8, $9
	mtc2 $9, $10
	mtc2 $10, $11
 #NO_APP
	lh	$8,0($5)
 #APP
	nop
	.word 0x4B98003D
 #NO_APP
	lh	$9,2($5)
	lh	$10,4($5)
 #APP
	mtc2 $6, $8
	mtc2 $8, $9
	mtc2 $9, $10
	mtc2 $10, $11
	nop
	nop
	.word 0x4BA8003E
	mfc2 $8, $9
	mfc2 $8, $9
	mfc2 $9, $10
	mfc2 $10, $11
 #NO_APP
	sh	$8,0($7)
	sh	$9,2($7)
	.set	noreorder
	.set	nomacro
	j	$31
	sh	$10,4($7)
	.set	macro
	.set	reorder

	.end	func_80052788
 #APP
	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_800527FC
    lw     $t0, 0($a0)
    lh     $t2, 4($a0)
    srl    $t1, $t0, 16
    ori    $v0, $zero, 0x1000
    sub    $v0, $v0, $a2
    mtc2   $v0, $8
    mtc2   $t0, $9
    mtc2   $t1, $10
    mtc2   $t2, $11
    lw     $t0, 0($a1)
    nop
    gpf    1
    lh     $t2, 4($a1)
    sra    $t1, $t0, 16
    mtc2   $a2, $8
    mtc2   $t0, $9
    mtc2   $t1, $10
    mtc2   $t2, $11
    lw     $t1, 8($a0)
    nop
    gpl    1
    lh     $t0, 6($a0)
    srl    $t2, $t1, 16
    mfc2   $t3, $9
    mfc2   $t4, $10
    mfc2   $t5, $11
    sh     $t3, 0($a3)
    sh     $t4, 2($a3)
    sh     $t5, 4($a3)
    mtc2   $v0, $8
    mtc2   $t0, $9
    mtc2   $t1, $10
    mtc2   $t2, $11
    lw     $t1, 8($a1)
    nop
    gpf    1
    lh     $t0, 6($a1)
    srl    $t2, $t1, 16
    mtc2   $a2, $8
    mtc2   $t0, $9
    mtc2   $t1, $10
    mtc2   $t2, $11
    lw     $t0, 12($a0)
    nop
    gpl    1
    lh     $t2, 16($a0)
    srl    $t1, $t0, 16
    mfc2   $t3, $9
    mfc2   $t4, $10
    mfc2   $t5, $11
    sh     $t3, 6($a3)
    sh     $t4, 8($a3)
    sh     $t5, 10($a3)
    mtc2   $v0, $8
    mtc2   $t0, $9
    mtc2   $t1, $10
    mtc2   $t2, $11
    lw     $t0, 12($a1)
    nop
    gpf    1
    lh     $t2, 16($a1)
    srl    $t1, $t0, 16
    mtc2   $a2, $8
    mtc2   $t0, $9
    mtc2   $t1, $10
    mtc2   $t2, $11
    nop
    nop
    gpl    1
    mfc2   $t3, $9
    mfc2   $t3, $9
    mfc2   $t4, $10
    mfc2   $t5, $11
    sh     $t3, 12($a3)
    sh     $t4, 14($a3)
    jr     $ra
    sh     $t5, 16($a3)
.set	reorder
.set	at
.set reorder
.set at

 #NO_APP
	.align	2
	.globl	func_80052930
	.ent	func_80052930
func_80052930:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$8,0($4)
	lw	$9,4($4)
	lw	$10,8($4)
	lw	$11,12($4)
	lw	$12,16($4)
 #APP
	lui $25, 0xFFFF
	ctc2 $8, $0
	ctc2 $9, $1
	ctc2 $10, $2
	ctc2 $11, $3
	ctc2 $12, $4
	ctc2 $zero, $5
	ctc2 $zero, $6
	ctc2 $zero, $7
 #NO_APP
	lw	$8,0($5)
	lw	$9,4($5)
	lw	$10,8($5)
	lw	$11,12($5)
	lw	$12,16($5)
	and	$13,$9,$25
	andi	$14,$8,0xffff
	or	$13,$13,$14
 #APP
	mtc2 $13, $0
 #NO_APP
	andi	$14,$11,0xffff
 #APP
	mtc2 $14, $1
 #NO_APP
	sll	$2,$10,16
 #APP
	nop
	.word 0x4A480012
 #NO_APP
	srl	$3,$8,16
	or	$2,$2,$3
	srl	$3,$11,16
 #APP
	mfc2 $13, $9
	mfc2 $14, $10
	mfc2 $15, $11
	mtc2 $2, $0
	mtc2 $3, $1
 #NO_APP
	sh	$13,0($6)
	sh	$14,6($6)
	sh	$15,12($6)
 #APP
	.word 0x4A480012
 #NO_APP
	and	$2,$10,$25
	andi	$3,$9,0xffff
	or	$2,$2,$3
	andi	$3,$12,0xffff
 #APP
	mfc2 $13, $9
	mfc2 $14, $10
	mfc2 $15, $11
	mtc2 $2, $0
	mtc2 $3, $1
 #NO_APP
	sh	$13,2($6)
	sh	$14,8($6)
	sh	$15,14($6)
 #APP
	.word 0x4A480012
	mfc2 $13, $9
	mfc2 $14, $10
	mfc2 $15, $11
 #NO_APP
	sh	$13,4($6)
	sh	$14,10($6)
	.set	noreorder
	.set	nomacro
	j	$31
	sh	$15,16($6)
	.set	macro
	.set	reorder

	.end	func_80052930
	.align	2
	.globl	game_2d_CheckLifeGaugeNoDisp
	.ent	game_2d_CheckLifeGaugeNoDisp
game_2d_CheckLifeGaugeNoDisp:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$8,0($4)
	lw	$9,4($4)
	lw	$10,8($4)
	lw	$11,12($4)
	lw	$12,16($4)
	lw	$13,20($4)
	lw	$14,24($4)
	lw	$15,28($4)
 #APP
	ctc2 $8, $0
	ctc2 $9, $1
	ctc2 $10, $2
	ctc2 $11, $3
	ctc2 $12, $4
	ctc2 $13, $5
	ctc2 $14, $6
	ctc2 $15, $7
	lwc2 $0, 0($5)
	lwc2 $1, 4($5)
	nop
	nop
	.word 0x4A480012
	nop
	swc2 $9, 0($6)
	swc2 $10, 4($6)
	swc2 $11, 8($6)
 #NO_APP
	j	$31
	.end	game_2d_CheckLifeGaugeNoDisp
	.align	2
	.globl	func_80052A88
	.ent	func_80052A88
func_80052A88:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$8,0($4)
	lw	$9,4($4)
	lw	$10,8($4)
	lw	$11,12($4)
	lw	$12,16($4)
	lw	$13,20($4)
	lw	$14,24($4)
	lw	$15,28($4)
 #APP
	ctc2 $8, $0
	ctc2 $9, $1
	ctc2 $10, $2
	ctc2 $11, $3
 #NO_APP
	lh	$9,4($5)
	lhu	$8,0($5)
	sll	$9,$9,16
	or	$8,$8,$9
 #APP
	ctc2 $12, $4
	ctc2 $13, $5
	ctc2 $14, $6
	ctc2 $15, $7
	mtc2 $8, $0
	lwc2 $1, 8($5)
	nop
	nop
	.word 0x4A480012
	nop
	swc2 $9, 0($6)
	swc2 $10, 4($6)
	swc2 $11, 8($6)
 #NO_APP
	j	$31
	.end	func_80052A88
	.align	2
	.globl	func_80052B00
	.ent	func_80052B00
func_80052B00:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$8,0($4)
	lw	$9,4($4)
	lw	$10,8($4)
	lw	$11,12($4)
	lw	$12,16($4)
	lw	$13,20($4)
	lw	$14,24($4)
	lw	$15,28($4)
 #APP
	ctc2 $8, $0
	ctc2 $9, $1
	ctc2 $10, $2
	ctc2 $11, $3
	ctc2 $12, $4
	ctc2 $13, $5
	ctc2 $14, $6
	ctc2 $15, $7
 #NO_APP
	j	$31
	.end	func_80052B00
	.align	2
	.globl	func_80052B44
	.ent	func_80052B44
func_80052B44:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$8,0($4)
	lw	$9,4($4)
	lw	$10,8($4)
	lw	$11,12($4)
	lw	$12,16($4)
 #APP
	ctc2 $8, $0
	ctc2 $9, $1
	ctc2 $10, $2
	ctc2 $11, $3
	ctc2 $12, $4
	ctc2 $0, $5
	ctc2 $0, $6
	ctc2 $0, $7
 #NO_APP
	j	$31
	.end	func_80052B44
	.align	2
	.globl	func_80052B7C
	.ent	func_80052B7C
func_80052B7C:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$8,0($4)
	lw	$9,4($4)
	lw	$10,8($4)
	lw	$11,12($4)
	lw	$12,16($4)
	lh	$13,0($5)
	lh	$14,2($5)
	lh	$15,4($5)
 #APP
	ctc2 $8, $0
	ctc2 $9, $1
	ctc2 $10, $2
	ctc2 $11, $3
	ctc2 $12, $4
	ctc2 $13, $5
	ctc2 $14, $6
	ctc2 $15, $7
	lwc2 $0, 0($6)
	lwc2 $1, 4($6)
	nop
	nop
	.word 0x4A480012
	nop
	swc2 $9, 0($7)
	swc2 $10, 4($7)
	swc2 $11, 8($7)
 #NO_APP
	j	$31
	.end	func_80052B7C
 #APP
	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_80052BE4
    cfc2   $t0, $21
    cfc2   $t1, $22
    cfc2   $t2, $23
    srl    $t0, $t0, 4
    srl    $t1, $t1, 4
    srl    $t2, $t2, 4
    sb     $t0, 0($a0)
    sb     $t1, 1($a0)
    sb     $t2, 2($a0)
    jr     $ra
    nop
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel InitFadePanel
    lui    $t9, 0x1F80
    ori    $t9, $t9, 0x0400
    sw     $zero, 0($t9)
    jr     $ra
    nop
.set	reorder
.set	at
.set reorder
.set at

	.section .text
    nop

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_80052C28
    addiu  $t0, $zero, 3
    sub    $a1, $t0, $a1
    srlv   $a0, $a0, $a1
    srl    $t0, $a0, 0xb
    andi   $a0, $a0, 0x7ff
    addi   $a0, $a0, -4096
    srav   $a0, $a0, $t0
    jr     $ra
    andi   $v0, $a0, 0xfff
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_80052C4C
    lhu    $t0, 6($a0)
    lh     $t1, 8($a0)
    lhu    $t2, 10($a0)
    lh     $t3, 12($a0)
    lhu    $t4, 14($a0)
    lh     $t5, 16($a0)
    sll    $t1, $t1, 16
    sll    $t3, $t3, 16
    sll    $t5, $t5, 16
    or     $t0, $t0, $t1
    or     $t2, $t2, $t3
    or     $t4, $t4, $t5
    ctc2   $t0, $0
    ctc2   $t2, $1
    ctc2   $t4, $2
    ctc2   $zero, $5
    ctc2   $zero, $6
    ctc2   $zero, $7
    lh     $t0, 0($a0)
    lh     $t1, 2($a0)
    lh     $t2, 4($a0)
    sub    $a1, $a1, $t0
    sub    $a2, $a2, $t1
    sub    $a3, $a3, $t2
    andi   $a1, $a1, 0xFFFF
    sll    $a2, $a2, 16
    or     $a1, $a1, $a2
    mtc2   $a1, $0
    mtc2   $a3, $1
    nop
    nop
    rtv0tr
    jr     $ra
    nop
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_80052CD4
    mfc2   $t0, $9
    mfc2   $t1, $10
    sra    $t0, $t0, 2
    sra    $t1, $t1, 2
    sw     $t0, 0($a0)
    sw     $t1, 0($a1)
    jr     $ra
    nop
.set	reorder
.set	at
.set reorder
.set at

	.section .text
    nop
    nop
    nop

 #NO_APP
	.align	2
	.globl	func_80052D00
	.ent	func_80052D00
func_80052D00:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	j	$31
	move	$2,$0
	.set	macro
	.set	reorder

	.end	func_80052D00
	.align	2
	.globl	func_80053304
	.ent	func_80053304
func_80053304:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	la	$2,D_800EF9F8
	sw	$2,D_800A33F4
	lw	$2,D_800A33F4
	subu	$sp,$sp,32
	sw	$16,16($sp)
	move	$16,$6
	sw	$17,20($sp)
	move	$17,$7
	sw	$31,24($sp)
	la	$8,D_800EFA00
	lw	$3,0($4)
	lw	$6,4($4)
	lw	$7,8($4)
	sw	$3,0($8)
	sw	$6,4($8)
	sw	$7,8($8)
	lw	$3,12($4)
	sw	$3,12($8)
	lw	$3,0($5)
	lw	$4,4($5)
	lw	$6,8($5)
	lw	$7,12($5)
	sw	$3,24($2)
	sw	$4,28($2)
	sw	$6,32($2)
	sw	$7,36($2)
	lw	$2,D_800A33F4
	#nop
	lw	$8,24($2)
	lw	$4,8($2)
	lw	$7,28($2)
	lw	$5,12($2)
	lw	$3,32($2)
	lw	$6,16($2)
	subu	$4,$8,$4
	subu	$5,$7,$5
	.set	noreorder
	.set	nomacro
	jal	func_80052754
	subu	$6,$3,$6
	.set	macro
	.set	reorder

	li	$3,0x00009c3f		# 39999
	slt	$3,$3,$2
	bne	$3,$0,$L241
	lw	$3,D_800A33F4
	#nop
	lw	$4,24($3)
	lw	$5,8($3)
	lw	$6,28($3)
	lw	$7,12($3)
	la	$2,func_80053754
	sw	$2,92($3)
	lw	$2,32($3)
	subu	$4,$4,$5
	sll	$4,$4,1
	subu	$5,$5,$4
	lw	$4,16($3)
	subu	$6,$6,$7
	sll	$6,$6,1
	subu	$7,$7,$6
	sw	$5,8($3)
	sw	$7,12($3)
	subu	$2,$2,$4
	sll	$2,$2,1
	subu	$4,$4,$2
	.set	noreorder
	.set	nomacro
	j	$L242
	sw	$4,16($3)
	.set	macro
	.set	reorder

$L241:
	lw	$3,D_800A33F4
	la	$2,func_80053E9C
	sw	$2,92($3)
$L242:
	move	$4,$16
	.set	noreorder
	.set	nomacro
	jal	func_80052D00
	move	$5,$17
	.set	macro
	.set	reorder

	lw	$31,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,32
	j	$31
	.end	func_80053304
	.align	2
	.globl	func_8005344C
	.ent	func_8005344C
func_8005344C:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	lw	$2,48($sp)
	sw	$16,16($sp)
	move	$16,$6
	sw	$17,20($sp)
	move	$17,$7
	sw	$31,24($sp)
	sw	$2,D_800A33F4
	lw	$3,0($4)
	lw	$6,4($4)
	lw	$7,8($4)
	lw	$8,12($4)
	sw	$3,8($2)
	sw	$6,12($2)
	sw	$7,16($2)
	sw	$8,20($2)
	lw	$2,D_800A33F4
	#nop
	lw	$3,0($5)
	lw	$4,4($5)
	lw	$6,8($5)
	lw	$7,12($5)
	sw	$3,24($2)
	sw	$4,28($2)
	sw	$6,32($2)
	sw	$7,36($2)
	lw	$2,D_800A33F4
	#nop
	lw	$8,24($2)
	lw	$4,8($2)
	lw	$7,28($2)
	lw	$5,12($2)
	lw	$3,32($2)
	lw	$6,16($2)
	subu	$4,$8,$4
	subu	$5,$7,$5
	.set	noreorder
	.set	nomacro
	jal	func_80052754
	subu	$6,$3,$6
	.set	macro
	.set	reorder

	li	$3,0x00009c3f		# 39999
	slt	$3,$3,$2
	bne	$3,$0,$L244
	lw	$3,D_800A33F4
	#nop
	lw	$4,24($3)
	lw	$5,8($3)
	lw	$6,28($3)
	lw	$7,12($3)
	la	$2,func_80053754
	sw	$2,92($3)
	lw	$2,32($3)
	subu	$4,$4,$5
	sll	$4,$4,1
	subu	$5,$5,$4
	lw	$4,16($3)
	subu	$6,$6,$7
	sll	$6,$6,1
	subu	$7,$7,$6
	sw	$5,8($3)
	sw	$7,12($3)
	subu	$2,$2,$4
	sll	$2,$2,1
	subu	$4,$4,$2
	.set	noreorder
	.set	nomacro
	j	$L245
	sw	$4,16($3)
	.set	macro
	.set	reorder

$L244:
	lw	$3,D_800A33F4
	la	$2,func_80053E9C
	sw	$2,92($3)
$L245:
	move	$4,$16
	.set	noreorder
	.set	nomacro
	jal	func_80052D00
	move	$5,$17
	.set	macro
	.set	reorder

	lw	$31,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,32
	j	$31
	.end	func_8005344C
	.align	2
	.globl	func_80053584
	.ent	func_80053584
func_80053584:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	la	$2,D_800EF9F8
	sw	$2,D_800A33F4
	lw	$2,D_800A33F4
	subu	$sp,$sp,24
	sw	$31,16($sp)
	la	$10,D_800EFA00
	lw	$3,0($4)
	lw	$8,4($4)
	lw	$9,8($4)
	sw	$3,0($10)
	sw	$8,4($10)
	sw	$9,8($10)
	lw	$3,12($4)
	sw	$3,12($10)
	lw	$3,0($5)
	lw	$4,4($5)
	lw	$8,8($5)
	lw	$9,12($5)
	sw	$3,24($2)
	sw	$4,28($2)
	sw	$8,32($2)
	sw	$9,36($2)
	lw	$3,D_800A33F4
	la	$2,func_80053E9C
	move	$4,$6
	move	$5,$7
	.set	noreorder
	.set	nomacro
	jal	func_80052D00
	sw	$2,92($3)
	.set	macro
	.set	reorder

	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80053584
	.align	2
	.globl	camera_check_inside_screen_rob_dpos
	.ent	camera_check_inside_screen_rob_dpos
camera_check_inside_screen_rob_dpos:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	lw	$2,40($sp)
	sw	$31,16($sp)
	sw	$2,D_800A33F4
	lw	$3,0($4)
	lw	$8,4($4)
	lw	$9,8($4)
	lw	$10,12($4)
	sw	$3,8($2)
	sw	$8,12($2)
	sw	$9,16($2)
	sw	$10,20($2)
	lw	$2,D_800A33F4
	#nop
	lw	$3,0($5)
	lw	$4,4($5)
	lw	$8,8($5)
	lw	$9,12($5)
	sw	$3,24($2)
	sw	$4,28($2)
	sw	$8,32($2)
	sw	$9,36($2)
	lw	$3,D_800A33F4
	la	$2,func_80053E9C
	move	$4,$6
	move	$5,$7
	.set	noreorder
	.set	nomacro
	jal	func_80052D00
	sw	$2,92($3)
	.set	macro
	.set	reorder

	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	camera_check_inside_screen_rob_dpos
	.align	2
	.globl	func_80053694
	.ent	func_80053694
func_80053694:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$6,D_800A33F4
	#nop
	lw	$3,0($6)
	li	$2,0x7fff0000		# 2147418112
	ori	$2,$2,0xffff
	.set	noreorder
	.set	nomacro
	bne	$3,$2,$L249
	move	$7,$4
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	$L250
	move	$2,$0
	.set	macro
	.set	reorder

$L249:
	lh	$3,72($6)
	lw	$4,56($6)
	sll	$2,$3,5
	subu	$2,$2,$3
	sll	$2,$2,2
	addu	$2,$2,$3
	sll	$2,$2,4
	addu	$2,$2,-32000
	addu	$4,$4,$2
	sw	$4,0($7)
	lw	$2,60($6)
	#nop
	sw	$2,4($7)
	lh	$3,74($6)
	lw	$4,64($6)
	sll	$2,$3,5
	subu	$2,$2,$3
	sll	$2,$2,2
	addu	$2,$2,$3
	sll	$2,$2,4
	addu	$2,$2,-32000
	addu	$4,$4,$2
	sw	$4,8($7)
	lw	$2,40($6)
	#nop
	sra	$2,$2,2
	sh	$2,0($5)
	lw	$2,44($6)
	#nop
	sra	$2,$2,2
	sh	$2,2($5)
	lw	$2,48($6)
	#nop
	sra	$2,$2,2
	sh	$2,4($5)
	lhu	$3,4($6)
	li	$2,0x00000001		# 1
	sh	$3,D_800A33F8
$L250:
	j	$31
	.end	func_80053694
	.align	2
	.globl	func_80053754
	.ent	func_80053754
func_80053754:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_80053754
	.align	2
	.globl	func_80053E9C
	.ent	func_80053E9C
func_80053E9C:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_80053E9C
	.align	2
	.globl	func_80054410
	.ent	func_80054410
func_80054410:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	sw	$4,D_800A33F0
	j	$31
	.end	func_80054410
	.align	2
	.globl	func_8005441C
	.ent	func_8005441C
func_8005441C:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$2,D_800A33F0
	#nop
	addu	$2,$2,$4
	sw	$2,D_800A33F0
	j	$31
	.end	func_8005441C
	.align	2
	.globl	func_80054434
	.ent	func_80054434
func_80054434:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lh	$2,D_800A33F8
	j	$31
	.end	func_80054434
 #APP
	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_80054440
    addiu  $sp, $sp, -0x38
    sw     $ra, 40($sp)
    sw     $fp, 36($sp)
    sw     $s5, 32($sp)
    sw     $s4, 28($sp)
    sw     $s3, 24($sp)
    sw     $s2, 20($sp)
    sw     $s1, 16($sp)
    addu   $s1, $a0, $zero
    addu   $s2, $a1, $zero
    lui    $s4, %hi(D_800A3828)
    lw     $s4, %lo(D_800A3828)($s4)
    nop
    addi   $s4, $s4, 24
    lui    $s5, 0x1F80
    mtc2   $zero, $6
    lui    $s3, %hi(D_800F2B70)
    addiu  $s3, $s3, %lo(D_800F2B70)
    bgez   $zero, .L800545B8
    nop
.L80054490:
    addi   $a2, $s5, 0x0020
    sll    $t0, $v0, 2
    add    $a1, $s2, $t0
    lw     $a1, 0($a1)
    jal    func_80052930
    addu   $a0, $s4, $zero
    lw     $t0, 32($s5)
    lw     $t1, 36($s5)
    lw     $t2, 40($s5)
    lw     $t3, 44($s5)
    lw     $t4, 48($s5)
    ctc2   $t0, $8
    ctc2   $t1, $9
    ctc2   $t2, $10
    ctc2   $t3, $11
    ctc2   $t4, $12
    lh     $v0, 0($s1)
    addi   $s1, $s1, 2
    lhu    $t0, 0($s1)
    lh     $t2, 2($s1)
    lh     $t1, 4($s1)
    sll    $t2, $t2, 16
    or     $t0, $t0, $t2
    lhu    $t2, 6($s1)
    lh     $t4, 8($s1)
    lh     $t3, 10($s1)
    sll    $t4, $t4, 16
    or     $t2, $t2, $t4
    lhu    $t4, 12($s1)
    lh     $t6, 14($s1)
    lh     $t5, 16($s1)
    sll    $t6, $t6, 16
    or     $t4, $t4, $t6
    bgez   $zero, .L80054568
    nop
.L8005451C:
    lhu    $t0, 0($s1)
    lh     $t2, 2($s1)
    lh     $t1, 4($s1)
    sll    $t2, $t2, 16
    or     $t0, $t0, $t2
    lhu    $t2, 6($s1)
    lh     $t4, 8($s1)
    lh     $t3, 10($s1)
    sll    $t4, $t4, 16
    or     $t2, $t2, $t4
    lhu    $t4, 12($s1)
    lh     $t6, 14($s1)
    lh     $t5, 16($s1)
    sll    $t6, $t6, 16
    or     $t4, $t4, $t6
    swc2   $20, 0($s3)
    swc2   $21, 4($s3)
    swc2   $22, 8($s3)
    addi   $s3, $s3, 12
.L80054568:
    mtc2   $t0, $0
    mtc2   $t1, $1
    mtc2   $t2, $2
    mtc2   $t3, $3
    mtc2   $t4, $4
    mtc2   $t5, $5
    addi   $v0, $v0, -3
    nop
    nct
    bgtz   $v0, .L8005451C
    addi   $s1, $s1, 18
    swc2   $20, 0($s3)
    swc2   $21, 4($s3)
    swc2   $22, 8($s3)
    addi   $s3, $s3, 12
    add    $v0, $v0, $v0
    add    $t0, $v0, $v0
    add    $s3, $s3, $t0
    add    $t0, $t0, $v0
    add    $s1, $s1, $t0
.L800545B8:
    lh     $v0, 0($s1)
    nop
    addi   $t0, $v0, 1
    bnez   $t0, .L80054490
    addi   $s1, $s1, 2
    addu   $v0, $s1, $zero
    lw     $ra, 40($sp)
    lw     $fp, 36($sp)
    lw     $s5, 32($sp)
    lw     $s4, 28($sp)
    lw     $s3, 24($sp)
    lw     $s2, 20($sp)
    lw     $s1, 16($sp)
    jr     $ra
    addiu  $sp, $sp, 0x38
.set	reorder
.set	at
.set reorder
.set at

	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel myRobGeneiOpen
    lui  $t0,19584
alabel D_800545F8
    ori  $t0,$t0,32896
alabel D_800545FC
    lui  $t0,18560
alabel D_80054600
    ori  $t0,$t0,32896
.set	reorder
.set	at
.set reorder
.set at

 #NO_APP
	.align	2
	.globl	func_80054604
	.ent	func_80054604
func_80054604:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_80054604
	.align	2
	.globl	func_80054884
	.ent	func_80054884
func_80054884:
	.frame	$sp,40,$31		# vars= 0, regs= 1/0, args= 32, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	sll	$4,$4,1
	sw	$31,32($sp)
	lh	$4,InfoPosYTbl1($4)
	lw	$2,60($sp)
	lw	$3,64($sp)
	lw	$8,68($sp)
	addu	$4,$4,$5
	move	$5,$6
	move	$6,$7
	sw	$2,16($sp)
	sw	$3,20($sp)
	sw	$8,24($sp)
	lw	$7,56($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80054604
	addu	$4,$4,-305
	.set	macro
	.set	reorder

	lw	$31,32($sp)
	addu	$sp,$sp,40
	j	$31
	.end	func_80054884
	.align	2
	.globl	katinuki_game_setData_800548DC
	.ent	katinuki_game_setData_800548DC
katinuki_game_setData_800548DC:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	gpu_DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_8004659C
	li	$4,-1			# 0xffffffff
	.set	macro
	.set	reorder

	jal	snd_StopSelection
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	katinuki_game_setData_800548DC
	.align	2
	.globl	func_8005490C
	.ent	func_8005490C
func_8005490C:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	j	$31
	move	$2,$0
	.set	macro
	.set	reorder

	.end	func_8005490C
	.align	2
	.globl	func_80054F68
	.ent	func_80054F68
func_80054F68:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	lw	$4,D_800A374C
	lhu	$2,D_800A38D6
	subu	$sp,$sp,24
	la	$3,D_80102C00
	sw	$31,20($sp)
	sw	$16,16($sp)
	sw	$3,D_800A3820
	addu	$2,$2,1
	sw	$4,D_800A3808
	addu	$4,$4,16
	sh	$2,D_800A38D6
	sw	$4,D_800A378C
	jal	func_8005490C
	.set	noreorder
	.set	nomacro
	jal	leaf_muki_awase_800444E0
	move	$16,$2
	.set	macro
	.set	reorder

	move	$2,$16
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80054F68
	.align	2
	.globl	func_80054FDC
	.ent	func_80054FDC
func_80054FDC:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	move	$5,$4
	la	$2,D_800EFB14
	lw	$3,0($2)
	lw	$4,D_800EFB18
	lw	$6,D_800EFB1C
	addu	$3,$5,$3
	addu	$4,$5,$4
	sw	$3,0($2)
	sw	$4,D_800EFB18
	.set	noreorder
	.set	nomacro
	beq	$6,$0,$L262
	addu	$2,$5,$6
	.set	macro
	.set	reorder

	sw	$2,D_800EFB1C
$L262:
	lw	$2,D_800EFB20
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L263
	addu	$2,$5,$2
	.set	macro
	.set	reorder

	sw	$2,D_800EFB20
$L263:
	lw	$2,D_800EFB24
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L264
	addu	$2,$5,$2
	.set	macro
	.set	reorder

	sw	$2,D_800EFB24
$L264:
	lw	$2,D_800EFB28
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L265
	addu	$2,$5,$2
	.set	macro
	.set	reorder

	sw	$2,D_800EFB28
$L265:
	j	$31
	.end	func_80054FDC
	.align	2
	.globl	func_8005507C
	.ent	func_8005507C
func_8005507C:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	la	$2,D_800EFB0C
	j	$31
	.end	func_8005507C
	.align	2
	.globl	func_8005508C
	.ent	func_8005508C
func_8005508C:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	la	$2,D_80101E1C
	j	$31
	.end	func_8005508C
	.align	2
	.globl	func_8005509C
	.ent	func_8005509C
func_8005509C:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	move	$5,$0
	sll	$2,$4,4
	addu	$2,$2,$4
	sll	$2,$2,2
	addu	$2,$2,$4
	sll	$2,$2,2
	subu	$2,$2,$4
	sll	$2,$2,2
	la	$3,D_80101EC8
	addu	$3,$2,$3
$L269:
	sb	$0,1045($3)
	sb	$0,1044($3)
	addu	$5,$5,1
	slt	$2,$5,8
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L269
	addu	$3,$3,2
	.set	macro
	.set	reorder

	j	$31
	.end	func_8005509C
	.align	2
	.globl	func_800550E8
	.ent	func_800550E8
func_800550E8:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	move	$5,$0
	sll	$2,$4,4
	addu	$2,$2,$4
	sll	$2,$2,2
	addu	$2,$2,$4
	sll	$2,$2,2
	subu	$2,$2,$4
	sll	$2,$2,2
	la	$3,D_80101EC8
	addu	$3,$2,$3
$L274:
	lbu	$2,1045($3)
	addu	$5,$5,1
	srl	$2,$2,1
	sb	$2,1045($3)
	slt	$2,$5,8
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L274
	addu	$3,$3,2
	.set	macro
	.set	reorder

	j	$31
	.end	func_800550E8
	.align	2
	.globl	single_game_SetStatusUpData
	.ent	single_game_SetStatusUpData
single_game_SetStatusUpData:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	single_game_SetStatusUpData
	.align	2
	.globl	func_80055948
	.ent	func_80055948
func_80055948:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lbu	$3,952($4)
	lw	$6,948($4)
	beq	$3,$0,$L280
	lh	$2,70($4)
	#nop
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L282
	addu	$2,$3,-1
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	$L282
	sb	$2,952($4)
	.set	macro
	.set	reorder

$L280:
	lbu	$2,956($4)
	#nop
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L284
	li	$2,0x00000016		# 22
	.set	macro
	.set	reorder

	lbu	$3,1091($4)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$3,$2,$L284
	sll	$2,$3,1
	.set	macro
	.set	reorder

	addu	$2,$2,$3
	sll	$2,$2,3
	lhu	$2,D_80099D88($2)
	#nop
	andi	$2,$2,0xbf00
	bne	$2,$0,$L284
	lw	$2,1072($4)
	#nop
	andi	$2,$2,0x0200
	beq	$2,$0,$L287
	lh	$2,1084($4)
	.set	noreorder
	.set	nomacro
	j	$L288
	slt	$2,$2,2049
	.set	macro
	.set	reorder

$L287:
	lh	$2,1084($4)
	#nop
	slt	$2,$2,1025
$L288:
	beq	$2,$0,$L290
	lw	$2,1072($4)
	#nop
	andi	$2,$2,0x0800
	bne	$2,$0,$L290
	lbu	$2,1061($4)
	#nop
	addu	$2,$2,-1
	sltu	$2,$2,2
	bne	$2,$0,$L290
	lbu	$2,1090($4)
	#nop
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L290
	li	$2,0x0000002d		# 45
	.set	macro
	.set	reorder

	lw	$5,0($4)
	#nop
	lhu	$3,106($5)
	#nop
	beq	$3,$2,$L290
	lh	$3,1038($4)
	lw	$2,244($5)
	#nop
	subu	$2,$2,$3
	mult	$2,$2
	lh	$3,1040($4)
	lw	$2,252($5)
	mflo	$7
	#nop
	subu	$2,$2,$3
	mult	$2,$2
	lh	$2,1042($4)
	mflo	$3
	#nop
	#nop
	mult	$2,$2
	addu	$2,$7,$3
	mflo	$5
	#nop
	#nop
	slt	$2,$5,$2
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L309
	li	$8,0x00000080		# 128
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	$L310
	sw	$0,948($4)
	.set	macro
	.set	reorder

$L284:
	lbu	$3,956($4)
	li	$2,0x00000001		# 1
	.set	noreorder
	.set	nomacro
	bne	$3,$2,$L309
	li	$8,0x00000080		# 128
	.set	macro
	.set	reorder

	lw	$2,1072($4)
	#nop
	andi	$2,$2,0x0800
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L302
	li	$7,0x00000001		# 1
	.set	macro
	.set	reorder

$L290:
	sw	$0,948($4)
$L310:
	.set	noreorder
	.set	nomacro
	j	$L308
	li	$2,-1			# 0xffffffff
	.set	macro
	.set	reorder

$L299:
	.set	noreorder
	.set	nomacro
	j	$L282
	sw	$0,948($4)
	.set	macro
	.set	reorder

$L309:
	li	$7,0x00000001		# 1
$L302:
	lbu	$3,0($6)
	#nop
	andi	$2,$3,0x0080
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L303
	addu	$6,$6,1
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	beq	$3,$8,$L299
	andi	$2,$3,0x007f
	.set	macro
	.set	reorder

	addu	$2,$2,-1
	sw	$6,948($4)
	.set	noreorder
	.set	nomacro
	j	$L282
	sb	$2,952($4)
	.set	macro
	.set	reorder

$L303:
	andi	$2,$3,0x000f
	sll	$5,$7,$2
	andi	$2,$3,0x0010
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L305
	nor	$3,$0,$5
	.set	macro
	.set	reorder

	lw	$2,968($4)
	#nop
	and	$2,$2,$3
	.set	noreorder
	.set	nomacro
	j	$L302
	sw	$2,968($4)
	.set	macro
	.set	reorder

$L305:
	lw	$2,968($4)
	#nop
	or	$2,$2,$5
	.set	noreorder
	.set	nomacro
	j	$L302
	sw	$2,968($4)
	.set	macro
	.set	reorder

$L282:
	lw	$2,968($4)
$L308:
	j	$31
	.end	func_80055948
	.align	2
	.globl	func_80055B44
	.ent	func_80055B44
func_80055B44:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	li	$2,-1			# 0xffffffff
	sw	$5,948($4)
	sb	$6,956($4)
	sb	$7,952($4)
	sw	$0,968($4)
	.set	noreorder
	.set	nomacro
	j	$31
	sw	$2,972($4)
	.set	macro
	.set	reorder

	.end	func_80055B44
	.align	2
	.globl	calc_loc_mat_fw_80055B60
	.ent	calc_loc_mat_fw_80055B60
calc_loc_mat_fw_80055B60:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	calc_loc_mat_fw_80055B60
	.align	2
	.globl	func_80056CB8
	.ent	func_80056CB8
func_80056CB8:
	.frame	$sp,168,$31		# vars= 104, regs= 10/0, args= 24, extra= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,168
	sw	$23,156($sp)
	move	$23,$4
	sw	$31,164($sp)
	sw	$fp,160($sp)
	sw	$22,152($sp)
	sw	$21,148($sp)
	sw	$20,144($sp)
	sw	$19,140($sp)
	sw	$18,136($sp)
	sw	$17,132($sp)
	sw	$16,128($sp)
	lhu	$2,1000($23)
 #APP
	andi $3,$2,0x3
 #NO_APP
	sll	$22,$3,1
 #APP
	addiu $2,$0,1
 #NO_APP
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L314
	li	$2,0x1f800000		# 528482304
	.set	macro
	.set	reorder

	ori	$2,$2,0x02b8
	sll	$fp,$3,2
	addu	$3,$sp,40
	sw	$3,104($sp)
	addu	$3,$sp,88
	sw	$22,96($sp)
	sw	$3,112($sp)
	sw	$2,120($sp)
$L315:
 #APP
 #NO_APP
	sw	$0,24($sp)
	sw	$0,28($sp)
	sw	$0,32($sp)
	sw	$0,40($sp)
	sw	$0,44($sp)
	sw	$0,48($sp)
	sw	$0,56($sp)
	sw	$0,60($sp)
	sw	$0,64($sp)
	sw	$0,72($sp)
	sw	$0,76($sp)
	sw	$0,80($sp)
	sw	$0,88($sp)
	sw	$0,92($sp)
	sw	$fp,16($sp)
	lw	$5,104($sp)
	lw	$7,112($sp)
	addu	$4,$sp,24
	.set	noreorder
	.set	nomacro
	jal	camera_check_inside_screen_rob_dpos
	addu	$6,$sp,56
	.set	macro
	.set	reorder

	lw	$2,120($sp)
	#nop
	sw	$2,16($sp)
	lw	$5,104($sp)
	lw	$7,112($sp)
	addu	$4,$sp,24
	.set	noreorder
	.set	nomacro
	jal	camera_check_inside_screen_rob_dpos
	addu	$6,$sp,72
	.set	macro
	.set	reorder

	addu	$2,$22,$23
	sb	$0,1092($2)
	lw	$2,96($sp)
	addu	$22,$22,1
	addu	$2,$2,2
	slt	$2,$22,$2
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L315
	addu	$fp,$fp,2
	.set	macro
	.set	reorder

$L314:
	lw	$31,164($sp)
	lw	$fp,160($sp)
	lw	$23,156($sp)
	lw	$22,152($sp)
	lw	$21,148($sp)
	lw	$20,144($sp)
	lw	$19,140($sp)
	lw	$18,136($sp)
	lw	$17,132($sp)
	lw	$16,128($sp)
	addu	$sp,$sp,168
	j	$31
	.end	func_80056CB8
	.align	2
	.globl	ang_hosei_80056FE8
	.ent	ang_hosei_80056FE8
ang_hosei_80056FE8:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	move	$7,$4
	lw	$6,0($7)
	#nop
	lw	$2,88($6)
	#nop
	lbu	$3,3($2)
	lbu	$4,163($6)
	sll	$2,$3,2
	addu	$2,$2,$3
	sll	$5,$2,3
	li	$2,0x000000ff		# 255
	beq	$4,$2,$L320
	lh	$2,94($7)
	#nop
	bne	$2,$0,$L321
	lh	$2,14($6)
	#nop
	lbu	$2,D_8009A830($2)
	.set	noreorder
	.set	nomacro
	j	$L323
	sll	$2,$2,1
	.set	macro
	.set	reorder

$L321:
	lh	$2,14($6)
	#nop
	lb	$2,D_8009A838($2)
	.set	noreorder
	.set	nomacro
	j	$L323
	sll	$2,$2,3
	.set	macro
	.set	reorder

$L320:
	lh	$2,20($6)
	#nop
	lbu	$2,D_8009A840($2)
	#nop
	sll	$2,$2,1
$L323:
	addu	$5,$5,$2
 #APP
 #NO_APP
	lw	$2,0($7)
	#nop
	lh	$2,1034($2)
	#nop
	addu	$2,$5,$2
	.set	noreorder
	.set	nomacro
	j	$31
	addu	$2,$2,300
	.set	macro
	.set	reorder

	.end	ang_hosei_80056FE8
	.align	2
	.globl	func_80057094
	.ent	func_80057094
func_80057094:
	.frame	$sp,48,$31		# vars= 8, regs= 5/0, args= 16, extra= 0
	.mask	0x800f0000,-8
	.fmask	0x00000000,0
	lw	$3,D_800F6608
	subu	$sp,$sp,48
	sw	$18,32($sp)
	move	$18,$4
	sw	$16,24($sp)
	move	$16,$5
	sw	$31,40($sp)
	sw	$19,36($sp)
	sw	$17,28($sp)
	lw	$4,244($18)
	lw	$2,D_800F6610
	lw	$5,252($18)
	move	$17,$6
	move	$19,$7
	subu	$4,$3,$4
	.set	noreorder
	.set	nomacro
	jal	single_game_getEnemyCharId
	subu	$5,$2,$5
	.set	macro
	.set	reorder

	lw	$4,244($18)
	lw	$5,252($18)
	subu	$4,$16,$4
	subu	$5,$17,$5
	.set	noreorder
	.set	nomacro
	jal	single_game_getEnemyCharId
	move	$16,$2
	.set	macro
	.set	reorder

	subu	$16,$16,$2
	addu	$16,$16,-256
	sra	$2,$16,9
	andi	$3,$2,0x0007
	.set	noreorder
	.set	nomacro
	bne	$19,$0,$L326
	sw	$3,16($sp)
	.set	macro
	.set	reorder

	andi	$2,$2,0x0001
	bne	$2,$0,$L326
	lhu	$2,1000($18)
	#nop
	andi	$2,$2,0x0010
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L327
	addu	$2,$3,1
	.set	macro
	.set	reorder

	sw	$2,16($sp)
	slt	$2,$2,8
	bne	$2,$0,$L326
	.set	noreorder
	.set	nomacro
	j	$L326
	sw	$0,16($sp)
	.set	macro
	.set	reorder

$L327:
	addu	$2,$3,-1
	.set	noreorder
	.set	nomacro
	bgez	$2,$L326
	sw	$2,16($sp)
	.set	macro
	.set	reorder

	li	$2,0x00000007		# 7
	sw	$2,16($sp)
$L326:
	lw	$2,16($sp)
	#nop
	andi	$2,$2,0x0007
	sll	$2,$2,2
	lw	$16,D_8009AA50($2)
	li	$2,0x00000001		# 1
	.set	noreorder
	.set	nomacro
	bne	$19,$2,$L333
	move	$4,$18
	.set	macro
	.set	reorder

	ori	$16,$16,0x0004
$L333:
	.set	noreorder
	.set	nomacro
	jal	func_800233AC
	addu	$5,$sp,16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L334
	move	$2,$16
	.set	macro
	.set	reorder

	ori	$16,$16,0x0008
	move	$2,$16
$L334:
	lw	$31,40($sp)
	lw	$19,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,48
	j	$31
	.end	func_80057094
	.align	2
	.globl	func_800571C0
	.ent	func_800571C0
func_800571C0:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_800571C0
	.align	2
	.globl	func_8005763C
	.ent	func_8005763C
func_8005763C:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_8005763C
	.align	2
	.globl	func_80057ACC
	.ent	func_80057ACC
func_80057ACC:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_80057ACC
	.align	2
	.globl	func_80057CC8
	.ent	func_80057CC8
func_80057CC8:
	.frame	$sp,64,$31		# vars= 8, regs= 9/0, args= 16, extra= 0
	.mask	0x80ff0000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,64
	sw	$18,32($sp)
	move	$18,$4
	sw	$22,48($sp)
	move	$22,$6
	sw	$23,52($sp)
	sw	$31,56($sp)
	sw	$21,44($sp)
	sw	$20,40($sp)
	sw	$19,36($sp)
	sw	$17,28($sp)
	sw	$16,24($sp)
	lw	$6,4($18)
	addu	$3,$5,-1
	move	$4,$3
	sll	$2,$5,2
	sll	$3,$3,16
	addu	$2,$2,$6
	lhu	$20,0($2)
	lhu	$21,2($2)
	.set	noreorder
	.set	nomacro
	bgez	$3,$L339
	move	$23,$7
	.set	macro
	.set	reorder

	lbu	$2,3($18)
	#nop
	addu	$4,$2,-1
$L339:
	addu	$2,$5,1
	lbu	$3,3($18)
	move	$19,$2
	sll	$2,$2,16
	sra	$2,$2,16
	slt	$2,$2,$3
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L343
	sll	$2,$4,16
	.set	macro
	.set	reorder

	move	$19,$0
$L343:
	sra	$2,$2,14
	addu	$3,$6,$2
	lh	$4,0($3)
	sll	$17,$20,16
	sra	$17,$17,16
	lh	$5,2($3)
	sll	$16,$21,16
	sra	$16,$16,16
	subu	$4,$4,$17
	.set	noreorder
	.set	nomacro
	jal	single_game_getEnemyCharId
	subu	$5,$5,$16
	.set	macro
	.set	reorder

	lw	$3,4($18)
	sll	$19,$19,16
	sra	$19,$19,14
	addu	$3,$3,$19
	lh	$4,0($3)
	lh	$5,2($3)
	subu	$4,$4,$17
	subu	$5,$5,$16
	.set	noreorder
	.set	nomacro
	jal	single_game_getEnemyCharId
	andi	$16,$2,0x0fff
	.set	macro
	.set	reorder

	andi	$3,$2,0x0fff
	slt	$2,$3,$16
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L341
	addu	$2,$16,2048
	.set	macro
	.set	reorder

	subu	$3,$16,$3
	srl	$4,$3,31
	addu	$3,$3,$4
	sra	$3,$3,1
	.set	noreorder
	.set	nomacro
	j	$L342
	subu	$5,$2,$3
	.set	macro
	.set	reorder

$L341:
	subu	$2,$3,$16
	srl	$3,$2,31
	addu	$2,$2,$3
	sra	$2,$2,1
	addu	$5,$2,$16
$L342:
	lbu	$4,2($18)
	andi	$2,$5,0x0fff
	sll	$2,$2,1
	lh	$2,Judge($2)
	sll	$3,$4,2
	addu	$3,$3,$4
	sll	$3,$3,3
	mult	$3,$2
	mflo	$8
	#nop
	#nop
	sra	$2,$8,12
	addu	$2,$20,$2
	sh	$2,0($22)
	sll	$2,$5,16
	sra	$2,$2,16
	addu	$2,$2,1024
	andi	$2,$2,0x0fff
	sll	$2,$2,1
	lh	$2,Judge($2)
	#nop
	mult	$3,$2
	mflo	$8
	#nop
	#nop
	sra	$2,$8,12
	addu	$2,$21,$2
	sh	$2,0($23)
	lw	$31,56($sp)
	lw	$23,52($sp)
	lw	$22,48($sp)
	lw	$21,44($sp)
	lw	$20,40($sp)
	lw	$19,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,64
	j	$31
	.end	func_80057CC8
	.align	2
	.globl	func_80057E84
	.ent	func_80057E84
func_80057E84:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_80057E84
	.align	2
	.globl	func_80058580
	.ent	func_80058580
func_80058580:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_80058580
	.align	2
	.globl	func_8005B43C
	.ent	func_8005B43C
func_8005B43C:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	move	$5,$0
	la	$4,D_800EFB38
	la	$3,D_800EFC38
$L347:
	sw	$0,0($3)
	sw	$0,0($4)
	addu	$4,$4,4
	addu	$5,$5,1
	slt	$2,$5,16
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L347
	addu	$3,$3,4
	.set	macro
	.set	reorder

	jal	sys_Shutdown
	.set	noreorder
	.set	nomacro
	jal	title_mv_exec2
	move	$4,$0
	.set	macro
	.set	reorder

	jal	func_80085F98
	.set	noreorder
	.set	nomacro
	jal	func_80085EE4
	move	$4,$0
	.set	macro
	.set	reorder

	move	$4,$0
	.set	noreorder
	.set	nomacro
	jal	func_80085E4C
	move	$5,$0
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	memcard_SetSlot
	move	$4,$0
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	SetBloodSpot
	li	$4,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$5,0x0000007f		# 127
	la	$4,D_800EFB78
	move	$3,$0
$L351:
	sw	$0,D_800EFB78($3)
	sb	$5,5($4)
	sb	$5,D_800EFB7C($3)
	addu	$3,$3,8
	slt	$2,$3,192
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L351
	addu	$4,$4,8
	.set	macro
	.set	reorder

	jal	DispStuff
	sw	$0,D_800A3408
	sh	$0,D_800A3400
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_8005B43C
	.align	2
	.globl	get_point_value
	.ent	get_point_value
get_point_value:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_800858D0
	move	$4,$0
	.set	macro
	.set	reorder

	jal	func_80085F98
	.set	noreorder
	.set	nomacro
	jal	func_80085EE4
	move	$4,$0
	.set	macro
	.set	reorder

	move	$4,$0
	.set	noreorder
	.set	nomacro
	jal	func_80085E4C
	move	$5,$0
	.set	macro
	.set	reorder

	jal	irq_ProcessPending
	jal	spu_Reset
	move	$5,$0
	la	$4,D_800EFB38
	la	$3,D_800EFC38
$L356:
	sw	$0,0($3)
	sw	$0,0($4)
	addu	$4,$4,4
	addu	$5,$5,1
	slt	$2,$5,16
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L356
	addu	$3,$3,4
	.set	macro
	.set	reorder

	sw	$0,D_800A3408
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	get_point_value
	.align	2
	.globl	func_8005B58C
	.ent	func_8005B58C
func_8005B58C:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_800858D0
	move	$4,$0
	.set	macro
	.set	reorder

	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_8005B58C
	.align	2
	.globl	obj_InitChars
	.ent	obj_InitChars
obj_InitChars:
	.frame	$sp,40,$31		# vars= 0, regs= 5/0, args= 16, extra= 0
	.mask	0x800f0000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	move	$4,$0
	sw	$31,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	.set	noreorder
	.set	nomacro
	jal	func_800858D0
	sw	$16,16($sp)
	.set	macro
	.set	reorder

	move	$17,$0
	li	$19,0x0000007f		# 127
	la	$18,D_800EFB78
	move	$16,$0
$L362:
	sll	$4,$17,16
	sra	$4,$4,16
	move	$5,$0
	sw	$0,D_800EFB78($16)
	sb	$19,5($18)
	sb	$19,D_800EFB7C($16)
	.set	noreorder
	.set	nomacro
	jal	func_80086130
	move	$6,$0
	.set	macro
	.set	reorder

	addu	$18,$18,8
	addu	$17,$17,1
	slt	$2,$17,24
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L362
	addu	$16,$16,8
	.set	macro
	.set	reorder

	lw	$31,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,40
	j	$31
	.end	obj_InitChars
	.align	2
	.globl	GetAllocPacketSize
	.ent	GetAllocPacketSize
GetAllocPacketSize:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	sw	$16,16($sp)
	move	$16,$4
	move	$4,$0
	sw	$31,24($sp)
	.set	noreorder
	.set	nomacro
	jal	func_800858D0
	sw	$17,20($sp)
	.set	macro
	.set	reorder

	sll	$17,$16,1
	addu	$17,$17,$16
	addu	$17,$17,1
	sll	$4,$17,16
	.set	noreorder
	.set	nomacro
	jal	func_80087F64
	sra	$4,$4,16
	.set	macro
	.set	reorder

	sll	$17,$17,2
	sw	$0,D_800EFC38($17)
	sw	$0,D_800EFB38($17)
	lw	$31,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,32
	j	$31
	.end	GetAllocPacketSize
	.align	2
	.globl	func_8005B6AC
	.ent	func_8005B6AC
func_8005B6AC:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_800858D0
	move	$4,$0
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_80087F64
	li	$4,0x00000002		# 2
	.set	macro
	.set	reorder

	sw	$0,D_800EFC40
	sw	$0,D_800EFB40
	.set	noreorder
	.set	nomacro
	jal	func_80087F64
	li	$4,0x00000005		# 5
	.set	macro
	.set	reorder

	sw	$0,D_800EFC4C
	sw	$0,D_800EFB4C
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_8005B6AC
	.align	2
	.globl	func_8005B6FC
	.ent	func_8005B6FC
func_8005B6FC:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80087F64
	li	$4,0x00000001		# 1
	.set	macro
	.set	reorder

	sw	$0,D_800EFC3C
	sw	$0,D_800EFB3C
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_8005B6FC
	.align	2
	.globl	obj_InitAll
	.ent	obj_InitAll
obj_InitAll:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, extra= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	move	$4,$0
	sw	$31,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	.set	noreorder
	.set	nomacro
	jal	func_800858D0
	sw	$16,16($sp)
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_80085F98
	li	$16,0x00000001		# 1
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_80085EE4
	move	$4,$0
	.set	macro
	.set	reorder

	move	$4,$0
	.set	noreorder
	.set	nomacro
	jal	func_80085E4C
	move	$5,$0
	.set	macro
	.set	reorder

	la	$18,D_800EFB3C
	la	$17,D_800EFC3C
$L373:
	sll	$4,$16,16
	.set	noreorder
	.set	nomacro
	jal	func_80087F64
	sra	$4,$4,16
	.set	macro
	.set	reorder

	sw	$0,0($17)
	sw	$0,0($18)
	addu	$18,$18,4
	addu	$16,$16,1
	slt	$2,$16,16
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L373
	addu	$17,$17,4
	.set	macro
	.set	reorder

	sw	$0,D_800A3408
	jal	obj_InitChars
	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,32
	j	$31
	.end	obj_InitAll
	.align	2
	.globl	func_8005B7C4
	.ent	func_8005B7C4
func_8005B7C4:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	sw	$17,20($sp)
	move	$17,$4
	move	$4,$0
	sw	$31,24($sp)
	.set	noreorder
	.set	nomacro
	jal	title_mv_exec2
	sw	$16,16($sp)
	.set	macro
	.set	reorder

	la	$4,D_800158B4
	.set	noreorder
	.set	nomacro
	jal	debug_printf
	move	$5,$17
	.set	macro
	.set	reorder

	jal	game_FrameLoop
	li	$4,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	jal	func_80036EA8
	li	$5,0x00000001		# 1
	.set	macro
	.set	reorder

	move	$16,$2
	move	$4,$16
	.set	noreorder
	.set	nomacro
	jal	replay_camera_Init
	move	$5,$17
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_80036F28
	move	$4,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	game_FrameLoop
	move	$16,$2
	.set	macro
	.set	reorder

	move	$4,$17
	move	$5,$0
	li	$2,0x00001010		# 4112
	sw	$0,D_800A3408
	sw	$2,D_800A340C
	sw	$2,D_800A3404
	.set	noreorder
	.set	nomacro
	jal	tslGlobalMemFree_8005C2A8
	addu	$6,$4,$16
	.set	macro
	.set	reorder

	lw	$3,D_800A3404
	#nop
	sw	$3,D_800A340C
	lw	$31,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,32
	j	$31
	.end	func_8005B7C4
	.align	2
	.globl	obj_InitPair
	.ent	obj_InitPair
obj_InitPair:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_800858D0
	move	$4,$0
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_80087F64
	li	$4,0x00000008		# 8
	.set	macro
	.set	reorder

	sw	$0,D_800EFC58
	sw	$0,D_800EFB58
	.set	noreorder
	.set	nomacro
	jal	func_80087F64
	li	$4,0x00000004		# 4
	.set	macro
	.set	reorder

	sw	$0,D_800EFC48
	sw	$0,D_800EFB48
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	obj_InitPair
	.align	2
	.globl	func_8005B8B8
	.ent	func_8005B8B8
func_8005B8B8:
	.frame	$sp,40,$31		# vars= 0, regs= 5/0, args= 16, extra= 0
	.mask	0x800f0000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	sw	$19,28($sp)
	move	$19,$4
	sw	$31,32($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	.set	noreorder
	.set	nomacro
	jal	obj_InitPair
	sw	$16,16($sp)
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_800858D0
	move	$4,$0
	.set	macro
	.set	reorder

	li	$4,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	jal	func_80036EA8
	li	$5,0x0000005d		# 93
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	game_FrameLoop
	move	$16,$2
	.set	macro
	.set	reorder

	move	$4,$16
	.set	noreorder
	.set	nomacro
	jal	replay_camera_Init
	move	$5,$19
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_80036F28
	move	$4,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	game_FrameLoop
	move	$17,$2
	.set	macro
	.set	reorder

	move	$4,$19
	li	$5,0x00000008		# 8
	.set	noreorder
	.set	nomacro
	jal	tslGlobalMemFree_8005C2A8
	addu	$6,$19,$17
	.set	macro
	.set	reorder

	li	$4,0x00000002		# 2
	li	$5,0x0000005e		# 94
	.set	noreorder
	.set	nomacro
	jal	func_80036EA8
	move	$16,$2
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	game_FrameLoop
	move	$17,$2
	.set	macro
	.set	reorder

	move	$4,$17
	addu	$18,$19,$16
	.set	noreorder
	.set	nomacro
	jal	replay_camera_Init
	move	$5,$18
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_80036F28
	move	$4,$17
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	game_FrameLoop
	addu	$17,$2,$16
	.set	macro
	.set	reorder

	move	$4,$18
	li	$5,0x00000004		# 4
	.set	noreorder
	.set	nomacro
	jal	tslGlobalMemFree_8005C2A8
	addu	$6,$19,$17
	.set	macro
	.set	reorder

	addu	$2,$2,$16
	lw	$31,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,40
	j	$31
	.end	func_8005B8B8
	.align	2
	.globl	motion_LoadPreCalcData_8005B98C
	.ent	motion_LoadPreCalcData_8005B98C
motion_LoadPreCalcData_8005B98C:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$16,16($sp)
	move	$16,$4
	sw	$31,20($sp)
	.set	noreorder
	.set	nomacro
	jal	saFidLoad
	li	$5,0x00000008		# 8
	.set	macro
	.set	reorder

	move	$4,$16
	.set	noreorder
	.set	nomacro
	jal	saFidLoad
	li	$5,0x00000004		# 4
	.set	macro
	.set	reorder

	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	motion_LoadPreCalcData_8005B98C
	.align	2
	.globl	obj_InitTask
	.ent	obj_InitTask
obj_InitTask:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_800858D0
	move	$4,$0
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_80087F64
	li	$4,0x00000009		# 9
	.set	macro
	.set	reorder

	sw	$0,D_800EFC5C
	sw	$0,D_800EFB5C
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	obj_InitTask
	.align	2
	.globl	obj_InitTaskCamera
	.ent	obj_InitTaskCamera
obj_InitTaskCamera:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	sw	$16,16($sp)
	move	$16,$4
	sw	$31,24($sp)
	.set	noreorder
	.set	nomacro
	jal	obj_InitTask
	sw	$17,20($sp)
	.set	macro
	.set	reorder

	li	$4,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	jal	func_80036EA8
	li	$5,0x00000008		# 8
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	game_FrameLoop
	move	$17,$2
	.set	macro
	.set	reorder

	move	$4,$17
	.set	noreorder
	.set	nomacro
	jal	replay_camera_Init
	move	$5,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_80036F28
	move	$4,$17
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	game_FrameLoop
	move	$17,$2
	.set	macro
	.set	reorder

	move	$4,$16
	li	$5,0x00000009		# 9
	.set	noreorder
	.set	nomacro
	jal	tslGlobalMemFree_8005C2A8
	addu	$6,$4,$17
	.set	macro
	.set	reorder

	lw	$31,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,32
	j	$31
	.end	obj_InitTaskCamera
	.align	2
	.globl	obj_ExecTask
	.ent	obj_ExecTask
obj_ExecTask:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	saFidLoad
	li	$5,0x00000009		# 9
	.set	macro
	.set	reorder

	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	obj_ExecTask
	.align	2
	.globl	func_8005BA8C
	.ent	func_8005BA8C
func_8005BA8C:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	j	$31
	move	$2,$0
	.set	macro
	.set	reorder

	.end	func_8005BA8C
	.align	2
	.globl	func_8005BD30
	.ent	func_8005BD30
func_8005BD30:
	.frame	$sp,40,$31		# vars= 0, regs= 5/0, args= 16, extra= 0
	.mask	0x800f0000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	sw	$19,28($sp)
	move	$19,$4
	move	$4,$0
	sw	$31,32($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	.set	noreorder
	.set	nomacro
	jal	title_mv_exec2
	sw	$16,16($sp)
	.set	macro
	.set	reorder

	lw	$3,D_800EFC50
	lw	$2,D_800EFC44
	#nop
	.set	noreorder
	.set	nomacro
	bne	$3,$2,$L384
	li	$17,0x00000003		# 3
	.set	macro
	.set	reorder

	li	$17,0x00000002		# 2
$L384:
	andi	$2,$17,0x00ff
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L386
	move	$16,$0
	.set	macro
	.set	reorder

	move	$18,$2
	andi	$2,$16,0x00ff
$L392:
	lbu	$5,D_8009AD18($2)
	move	$4,$19
	.set	noreorder
	.set	nomacro
	jal	saFidLoad
	addu	$16,$16,1
	.set	macro
	.set	reorder

	andi	$2,$16,0x00ff
	sltu	$2,$2,$18
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L392
	andi	$2,$16,0x00ff
	.set	macro
	.set	reorder

$L386:
	andi	$3,$17,0x00ff
	li	$2,0x00000002		# 2
	bne	$3,$2,$L391
	lw	$2,D_800EFC44
	#nop
	sw	$2,D_800EFC50
$L391:
	lw	$31,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,40
	j	$31
	.end	func_8005BD30
	.align	2
	.globl	func_8005BDF0
	.ent	func_8005BDF0
func_8005BDF0:
	.frame	$sp,40,$31		# vars= 0, regs= 5/0, args= 16, extra= 0
	.mask	0x800f0000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	sw	$19,28($sp)
	la	$19,D_800EFC38
	sw	$18,24($sp)
	la	$18,D_800EFB38
	sw	$16,16($sp)
	la	$16,D_8009AD18
	sw	$17,20($sp)
	addu	$17,$16,3
	sw	$31,32($sp)
$L394:
	lbu	$4,0($16)
	jal	func_80087F64
	lbu	$2,0($16)
	#nop
	sll	$2,$2,2
	addu	$2,$2,$19
	sw	$0,0($2)
	lbu	$2,0($16)
	addu	$16,$16,1
	sll	$2,$2,2
	addu	$2,$2,$18
	sw	$0,0($2)
	slt	$2,$16,$17
	bne	$2,$0,$L394
	lw	$31,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,40
	j	$31
	.end	func_8005BDF0
	.align	2
	.globl	mario_getMarioVoiceData_8005BE84
	.ent	mario_getMarioVoiceData_8005BE84
mario_getMarioVoiceData_8005BE84:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	sw	$16,16($sp)
	move	$16,$4
	move	$4,$0
	sw	$31,24($sp)
	.set	noreorder
	.set	nomacro
	jal	title_mv_exec2
	sw	$17,20($sp)
	.set	macro
	.set	reorder

	la	$3,D_8009AD1C
	sll	$2,$16,2
	addu	$17,$2,$3
	lh	$2,0($17)
	#nop
	.set	noreorder
	.set	nomacro
	bltz	$2,$L399
	sll	$16,$16,1
	.set	macro
	.set	reorder

	jal	func_80085F98
	.set	noreorder
	.set	nomacro
	jal	func_80085EE4
	move	$4,$0
	.set	macro
	.set	reorder

	move	$4,$0
	.set	noreorder
	.set	nomacro
	jal	func_80085E4C
	move	$5,$0
	.set	macro
	.set	reorder

	lh	$4,0($17)
	jal	func_80085EE4
	lh	$4,0($17)
	.set	noreorder
	.set	nomacro
	jal	md_game_check_change_main_mode_katinuki
	move	$17,$2
	.set	macro
	.set	reorder

	addu	$4,$16,1
	sll	$4,$4,16
	sra	$4,$4,16
	.set	noreorder
	.set	nomacro
	jal	func_80085E4C
	move	$5,$4
	.set	macro
	.set	reorder

	jal	func_80085FB8
	.set	noreorder
	.set	nomacro
	j	$L401
	sll	$2,$17,16
	.set	macro
	.set	reorder

$L399:
	li	$17,-1			# 0xffffffff
	sll	$2,$17,16
$L401:
	sra	$2,$2,16
	lw	$31,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,32
	j	$31
	.end	mario_getMarioVoiceData_8005BE84
	.align	2
	.globl	obj_Reset
	.ent	obj_Reset
obj_Reset:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_800858D0
	move	$4,$0
	.set	macro
	.set	reorder

	jal	func_80085F98
	.set	noreorder
	.set	nomacro
	jal	func_80085EE4
	move	$4,$0
	.set	macro
	.set	reorder

	move	$4,$0
	.set	noreorder
	.set	nomacro
	jal	func_80085E4C
	move	$5,$0
	.set	macro
	.set	reorder

	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	obj_Reset
	.align	2
	.globl	func_8005BF78
	.ent	func_8005BF78
func_8005BF78:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, extra= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	sw	$20,32($sp)
	move	$20,$4
	sw	$18,24($sp)
	move	$18,$5
	sw	$19,28($sp)
	move	$19,$6
	sw	$16,16($sp)
	move	$16,$7
	move	$4,$0
	sw	$31,36($sp)
	.set	noreorder
	.set	nomacro
	jal	func_800858D0
	sw	$17,20($sp)
	.set	macro
	.set	reorder

	sll	$17,$18,16
	sra	$17,$17,16
	.set	noreorder
	.set	nomacro
	jal	func_80087F64
	move	$4,$17
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_8008AE24
	move	$4,$16
	.set	macro
	.set	reorder

	la	$16,D_800EFC38
	sll	$18,$18,2
	addu	$16,$18,$16
	lw	$2,0($16)
	#nop
	lw	$5,12($2)
	.set	noreorder
	.set	nomacro
	jal	func_8008AD64
	move	$4,$20
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_8008AEB0
	li	$4,0x00000001		# 1
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_8008AE24
	move	$4,$19
	.set	macro
	.set	reorder

	lw	$2,0($16)
	#nop
	lw	$5,12($2)
	.set	noreorder
	.set	nomacro
	jal	func_8008ADC4
	move	$4,$20
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_8008AEB0
	li	$4,0x00000001		# 1
	.set	macro
	.set	reorder

	lw	$2,0($16)
	#nop
	lw	$4,4($2)
	move	$5,$17
	.set	noreorder
	.set	nomacro
	jal	coli_CheckBukiPreHit_800880B8
	move	$6,$19
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	tslCDFileRead
	move	$4,$17
	.set	macro
	.set	reorder

	sw	$19,D_800EFB38($18)
	lw	$2,0($16)
	#nop
	lw	$2,12($2)
	#nop
	addu	$2,$19,$2
	lw	$31,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,40
	j	$31
	.end	func_8005BF78
	.align	2
	.globl	func_8005C074
	.ent	func_8005C074
func_8005C074:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_8005C074
	.align	2
	.globl	tslGlobalMemFree_8005C2A8
	.ent	tslGlobalMemFree_8005C2A8
tslGlobalMemFree_8005C2A8:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	j	$31
	move	$2,$0
	.set	macro
	.set	reorder

	.end	tslGlobalMemFree_8005C2A8
	.align	2
	.globl	saFidLoad
	.ent	saFidLoad
saFidLoad:
	.frame	$sp,40,$31		# vars= 0, regs= 5/0, args= 16, extra= 0
	.mask	0x800f0000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	sw	$17,20($sp)
	move	$17,$4
	sw	$16,16($sp)
	move	$16,$5
	move	$4,$0
	sw	$31,32($sp)
	sw	$19,28($sp)
	.set	noreorder
	.set	nomacro
	jal	title_mv_exec2
	sw	$18,24($sp)
	.set	macro
	.set	reorder

	sll	$16,$16,16
	sra	$18,$16,16
	la	$2,D_800EFC38
	sll	$19,$18,2
	addu	$16,$19,$2
	lw	$3,0($16)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$3,$0,$L407
	addu	$3,$3,$17
	.set	macro
	.set	reorder

	sw	$3,0($16)
	lw	$2,0($3)
	#nop
	addu	$2,$2,$17
	sw	$2,0($3)
	lw	$3,0($16)
	#nop
	lw	$2,4($3)
	move	$4,$18
	addu	$2,$2,$17
	.set	noreorder
	.set	nomacro
	jal	func_80087F64
	sw	$2,4($3)
	.set	macro
	.set	reorder

	lw	$2,0($16)
	lw	$6,D_800EFB38($19)
	lw	$4,4($2)
	.set	noreorder
	.set	nomacro
	jal	coli_CheckBukiPreHit_800880B8
	move	$5,$18
	.set	macro
	.set	reorder

	sll	$2,$2,16
	sra	$2,$2,16
	bne	$2,$18,$L410
	.set	noreorder
	.set	nomacro
	jal	tslCDFileRead
	move	$4,$2
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	$L411
	sll	$2,$2,16
	.set	macro
	.set	reorder

$L407:
	li	$2,-1			# 0xffffffff
	sll	$2,$2,16
$L411:
	sra	$2,$2,16
$L410:
	lw	$31,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,40
	j	$31
	.end	saFidLoad
	.align	2
	.globl	func_8005C5A8
	.ent	func_8005C5A8
func_8005C5A8:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	sw	$17,20($sp)
	move	$17,$4
	sw	$16,16($sp)
	sll	$16,$5,16
	sra	$16,$16,16
	sw	$31,24($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80087F64
	move	$4,$16
	.set	macro
	.set	reorder

	lw	$4,4($17)
	lw	$6,D_800A3404
	.set	noreorder
	.set	nomacro
	jal	coli_CheckBukiPreHit_80088088
	move	$5,$16
	.set	macro
	.set	reorder

	lw	$2,4($17)
	#nop
	sw	$16,8($2)
	lw	$4,8($17)
	.set	noreorder
	.set	nomacro
	jal	func_800884C4
	move	$5,$16
	.set	macro
	.set	reorder

	sll	$2,$2,16
	sra	$2,$2,16
	lw	$31,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,32
	j	$31
	.end	func_8005C5A8
	.align	2
	.globl	func_8005C614
	.ent	func_8005C614
func_8005C614:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	li	$4,0x0000007f		# 127
	.set	noreorder
	.set	nomacro
	jal	func_80083BE4
	li	$5,0x0000007f		# 127
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_800858D0
	move	$4,$0
	.set	macro
	.set	reorder

	jal	memcard_ClearBusy
	.set	noreorder
	.set	nomacro
	jal	memcard_SetData
	move	$4,$0
	.set	macro
	.set	reorder

	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_8005C614
	.align	2
	.globl	func_8005C650
	.ent	func_8005C650
func_8005C650:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	move	$7,$0
	sll	$4,$4,2
	la	$2,D_8009AA70
	addu	$4,$4,$2
	sll	$2,$7,16
$L420:
	sra	$3,$2,13
	lw	$2,D_800EFB78($3)
	#nop
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L418
	addu	$2,$7,1
	.set	macro
	.set	reorder

	sw	$4,D_800EFB78($3)
	sb	$5,D_800EFB7C($3)
	sb	$6,D_800EFB7D($3)
	j	$L414
$L418:
	move	$7,$2
	sll	$2,$2,16
	sra	$2,$2,16
	slt	$2,$2,24
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L420
	sll	$2,$7,16
	.set	macro
	.set	reorder

$L414:
	j	$31
	.end	func_8005C650
	.align	2
	.globl	func_8005C6D0
	.ent	func_8005C6D0
func_8005C6D0:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	j	$31
	move	$2,$0
	.set	macro
	.set	reorder

	.end	func_8005C6D0
	.align	2
	.globl	func_8005C8A8
	.ent	func_8005C8A8
func_8005C8A8:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	j	$31
	move	$2,$0
	.set	macro
	.set	reorder

	.end	func_8005C8A8
	.align	2
	.globl	func_8005D46C
	.ent	func_8005D46C
func_8005D46C:
	.frame	$sp,88,$31		# vars= 48, regs= 5/0, args= 16, extra= 0
	.mask	0x800f0000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,88
	move	$3,$4
	move	$2,$5
	sw	$31,80($sp)
	sw	$19,76($sp)
	sw	$18,72($sp)
	sw	$17,68($sp)
	.set	noreorder
	.set	nomacro
	blez	$2,$L424
	sw	$16,64($sp)
	.set	macro
	.set	reorder

	addu	$2,$2,-1
$L424:
	addu	$4,$sp,16
	move	$5,$0
	sll	$16,$2,4
	subu	$16,$16,$2
	sll	$16,$16,2
	la	$17,D_8009B2C8
	addu	$2,$16,$17
	sw	$2,16($sp)
	la	$2,D_8009B340
	li	$18,0x00000100		# 256
	li	$19,0x00000001		# 1
	sb	$0,56($sp)
	sw	$2,20($sp)
	sw	$18,52($sp)
	sw	$18,48($sp)
	sw	$0,44($sp)
	sw	$0,40($sp)
	sw	$0,32($sp)
	sw	$19,36($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80073728
	sw	$3,28($sp)
	.set	macro
	.set	reorder

	addu	$4,$sp,16
	move	$5,$0
	addu	$17,$17,12
	addu	$16,$16,$17
	la	$3,D_8009B358
	sb	$0,56($sp)
	sw	$16,16($sp)
	sw	$3,20($sp)
	sw	$18,52($sp)
	sw	$18,48($sp)
	sw	$0,44($sp)
	sw	$0,40($sp)
	sw	$0,32($sp)
	sw	$19,36($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80073728
	sw	$2,28($sp)
	.set	macro
	.set	reorder

	lw	$31,80($sp)
	lw	$19,76($sp)
	lw	$18,72($sp)
	lw	$17,68($sp)
	lw	$16,64($sp)
	addu	$sp,$sp,88
	j	$31
	.end	func_8005D46C
	.align	2
	.globl	gnd_land_hit_char_tsuba
	.ent	gnd_land_hit_char_tsuba
gnd_land_hit_char_tsuba:
	.frame	$sp,104,$31		# vars= 48, regs= 10/0, args= 16, extra= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	lw	$3,D_800A326C
	subu	$sp,$sp,104
	sw	$16,64($sp)
	move	$16,$5
	sw	$31,100($sp)
	sw	$fp,96($sp)
	sw	$23,92($sp)
	sw	$22,88($sp)
	sw	$21,84($sp)
	sw	$20,80($sp)
	sw	$19,76($sp)
	sw	$18,72($sp)
	sw	$17,68($sp)
	.set	noreorder
	.set	nomacro
	bgez	$3,$L426
	move	$2,$3
	.set	macro
	.set	reorder

	addu	$2,$3,3
$L426:
	sra	$2,$2,2
	sll	$2,$2,2
	subu	$2,$3,$2
	sw	$2,D_800A326C
	.set	noreorder
	.set	nomacro
	blez	$16,$L427
	move	$17,$4
	.set	macro
	.set	reorder

	addu	$16,$16,-1
$L427:
	.set	noreorder
	.set	nomacro
	jal	func_80079154
	move	$19,$0
	.set	macro
	.set	reorder

	lw	$3,D_800A3418
	#nop
	xor	$3,$3,$2
	sll	$2,$3,2
	addu	$2,$2,$3
	sll	$2,$2,2
	subu	$2,$2,$3
	sll	$2,$2,5
	sw	$3,D_800A3418
	.set	noreorder
	.set	nomacro
	jal	func_80079154
	srl	$21,$2,15
	.set	macro
	.set	reorder

	lw	$4,D_800A3418
	lw	$3,D_800A326C
	xor	$4,$4,$2
	sll	$2,$4,3
	subu	$2,$2,$4
	sll	$2,$2,3
	subu	$2,$2,$4
	sll	$2,$2,2
	addu	$3,$3,1
	sll	$3,$3,1
	sw	$4,D_800A3418
	.set	noreorder
	.set	nomacro
	blez	$3,$L428
	srl	$20,$2,15
	.set	macro
	.set	reorder

	li	$18,0x00000100		# 256
	li	$22,0x00000001		# 1
	sll	$2,$16,4
	subu	$2,$2,$16
	sll	$16,$2,2
	la	$23,D_8009B2E0
	addu	$2,$16,$23
	addu	$fp,$2,12
$L429:
	addu	$2,$23,$16
	la	$6,D_8009B388
	sb	$0,56($sp)
	sw	$2,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80079154
	sw	$6,20($sp)
	.set	macro
	.set	reorder

	lw	$3,D_800A3418
	sw	$18,52($sp)
	sw	$18,48($sp)
	xor	$3,$3,$2
	sw	$3,D_800A3418
	.set	noreorder
	.set	nomacro
	jal	func_80079154
	addu	$19,$19,1
	.set	macro
	.set	reorder

	lw	$3,D_800A3418
	#nop
	xor	$3,$3,$2
	sll	$2,$3,1
	addu	$2,$2,$3
	sll	$2,$2,3
	addu	$2,$2,$3
	sll	$2,$2,1
	srl	$2,$2,15
	addu	$2,$2,-25
	addu	$2,$21,$2
	sw	$3,D_800A3418
	.set	noreorder
	.set	nomacro
	jal	func_80079154
	sw	$2,40($sp)
	.set	macro
	.set	reorder

	lw	$3,D_800A3418
	addu	$4,$sp,16
	move	$5,$0
	sw	$0,32($sp)
	sw	$22,36($sp)
	sw	$17,28($sp)
	xor	$3,$3,$2
	sll	$2,$3,1
	addu	$2,$2,$3
	sll	$2,$2,3
	addu	$2,$2,$3
	srl	$2,$2,15
	addu	$2,$2,-12
	addu	$2,$20,$2
	sw	$3,D_800A3418
	.set	noreorder
	.set	nomacro
	jal	func_80073728
	sw	$2,44($sp)
	.set	macro
	.set	reorder

	lw	$3,D_800A3418
	move	$17,$2
	la	$2,D_8009B390
	sb	$0,56($sp)
	sw	$18,52($sp)
	sw	$18,48($sp)
	sw	$2,20($sp)
	andi	$3,$3,0x0001
	sll	$2,$3,1
	addu	$2,$2,$3
	sll	$2,$2,2
	addu	$2,$fp,$2
	.set	noreorder
	.set	nomacro
	jal	func_80079154
	sw	$2,16($sp)
	.set	macro
	.set	reorder

	lw	$3,D_800A3418
	#nop
	xor	$3,$3,$2
	sll	$2,$3,1
	addu	$2,$2,$3
	sll	$2,$2,3
	addu	$2,$2,$3
	sll	$2,$2,2
	srl	$2,$2,15
	addu	$2,$2,-50
	addu	$2,$21,$2
	sw	$3,D_800A3418
	.set	noreorder
	.set	nomacro
	jal	func_80079154
	sw	$2,40($sp)
	.set	macro
	.set	reorder

	lw	$3,D_800A3418
	addu	$4,$sp,16
	move	$5,$0
	sw	$0,32($sp)
	sw	$22,36($sp)
	sw	$17,28($sp)
	xor	$3,$3,$2
	sll	$2,$3,1
	addu	$2,$2,$3
	sll	$2,$2,3
	addu	$2,$2,$3
	sll	$2,$2,1
	srl	$2,$2,15
	addu	$2,$2,-25
	addu	$2,$20,$2
	sw	$3,D_800A3418
	.set	noreorder
	.set	nomacro
	jal	func_80073728
	sw	$2,44($sp)
	.set	macro
	.set	reorder

	lw	$3,D_800A326C
	#nop
	addu	$3,$3,1
	sll	$3,$3,1
	slt	$3,$19,$3
	.set	noreorder
	.set	nomacro
	bne	$3,$0,$L429
	move	$17,$2
	.set	macro
	.set	reorder

$L428:
	lw	$3,D_800A326C
	move	$2,$17
	addu	$3,$3,1
	sw	$3,D_800A326C
	lw	$31,100($sp)
	lw	$fp,96($sp)
	lw	$23,92($sp)
	lw	$22,88($sp)
	lw	$21,84($sp)
	lw	$20,80($sp)
	lw	$19,76($sp)
	lw	$18,72($sp)
	lw	$17,68($sp)
	lw	$16,64($sp)
	addu	$sp,$sp,104
	j	$31
	.end	gnd_land_hit_char_tsuba
	.align	2
	.globl	func_8005D814
	.ent	func_8005D814
func_8005D814:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	j	$31
	move	$2,$0
	.set	macro
	.set	reorder

	.end	func_8005D814
	.align	2
	.globl	func_8005E098
	.ent	func_8005E098
func_8005E098:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	j	$31
	move	$2,$0
	.set	macro
	.set	reorder

	.end	func_8005E098
	.align	2
	.globl	func_8005E51C
	.ent	func_8005E51C
func_8005E51C:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	move	$2,$5
	move	$7,$6
	addu	$5,$4,-1
	li	$4,-1			# 0xffffffff
	.set	noreorder
	.set	nomacro
	jal	func_8005E098
	move	$6,$2
	.set	macro
	.set	reorder

	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_8005E51C
	.align	2
	.globl	func_8005E54C
	.ent	func_8005E54C
func_8005E54C:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	j	$31
	move	$2,$0
	.set	macro
	.set	reorder

	.end	func_8005E54C
	.align	2
	.globl	func_8005F1C8
	.ent	func_8005F1C8
func_8005F1C8:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_8005F1C8
	.align	2
	.globl	func_8005FA98
	.ent	func_8005FA98
func_8005FA98:
	.frame	$sp,80,$31		# vars= 48, regs= 4/0, args= 16, extra= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,80
	sw	$16,64($sp)
	move	$16,$4
	sw	$17,68($sp)
	move	$17,$5
	li	$2,0x00000200		# 512
	sw	$2,48($sp)
	li	$2,0x00000100		# 256
	sw	$2,52($sp)
	sll	$2,$16,1
	addu	$2,$2,$16
	sll	$2,$2,2
	la	$3,D_8009B63C
	addu	$2,$2,$3
	move	$3,$17
	sw	$18,72($sp)
	addu	$18,$17,400
	sw	$2,16($sp)
	li	$2,0x00000001		# 1
	sw	$31,76($sp)
	sb	$0,56($sp)
	sw	$0,44($sp)
	sw	$0,40($sp)
	sw	$0,32($sp)
	.set	noreorder
	.set	nomacro
	beq	$16,$2,$L441
	sw	$6,36($sp)
	.set	macro
	.set	reorder

	slt	$2,$16,2
	beq	$2,$0,$L445
	.set	noreorder
	.set	nomacro
	beq	$16,$0,$L440
	addu	$4,$sp,16
	.set	macro
	.set	reorder

	j	$L447
$L445:
	li	$2,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	beq	$16,$2,$L442
	addu	$4,$sp,16
	.set	macro
	.set	reorder

	j	$L447
$L440:
	la	$2,D_8009B660
	.set	noreorder
	.set	nomacro
	j	$L448
	sw	$2,20($sp)
	.set	macro
	.set	reorder

$L441:
	la	$2,D_8009B670
	.set	noreorder
	.set	nomacro
	j	$L448
	sw	$2,20($sp)
	.set	macro
	.set	reorder

$L442:
	la	$2,D_8009B678
	sw	$2,20($sp)
$L448:
	addu	$4,$sp,16
$L447:
	move	$5,$0
	.set	noreorder
	.set	nomacro
	jal	func_80073728
	sw	$3,28($sp)
	.set	macro
	.set	reorder

	addu	$4,$sp,16
	move	$5,$0
	sll	$3,$16,1
	addu	$3,$3,$16
	sll	$3,$3,2
	la	$6,D_8009B610
	addu	$3,$3,$6
	sw	$3,16($sp)
	la	$3,D_8009B634
	sw	$3,20($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80073728
	sw	$2,28($sp)
	.set	macro
	.set	reorder

	subu	$2,$18,$17
	lw	$31,76($sp)
	lw	$18,72($sp)
	lw	$17,68($sp)
	lw	$16,64($sp)
	addu	$sp,$sp,80
	j	$31
	.end	func_8005FA98
	.align	2
	.globl	func_8005FBC8
	.ent	func_8005FBC8
func_8005FBC8:
	.frame	$sp,48,$31		# vars= 16, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,48
	sw	$17,36($sp)
	move	$17,$5
	addu	$5,$4,51
	li	$4,0x00000002		# 2
	sw	$31,40($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80036EA8
	sw	$16,32($sp)
	.set	macro
	.set	reorder

	move	$16,$2
	move	$4,$16
	.set	noreorder
	.set	nomacro
	jal	replay_camera_Init
	move	$5,$17
	.set	macro
	.set	reorder

	jal	game_FrameLoop
	.set	noreorder
	.set	nomacro
	jal	func_80036F28
	move	$4,$16
	.set	macro
	.set	reorder

	la	$5,D_800A327C
	lwl	$2,3($5)
	lwr	$2,0($5)
	lwl	$3,7($5)
	lwr	$3,4($5)
	swl	$2,19($sp)
	swr	$2,16($sp)
	swl	$3,23($sp)
	swr	$3,20($sp)
	la	$5,D_800A3284
	lwl	$2,3($5)
	lwr	$2,0($5)
	lwl	$3,7($5)
	lwr	$3,4($5)
	swl	$2,27($sp)
	swr	$2,24($sp)
	swl	$3,31($sp)
	swr	$3,28($sp)
	addu	$4,$sp,16
	.set	noreorder
	.set	nomacro
	jal	gpu_LoadImage
	addu	$5,$17,64
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	gpu_DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	addu	$4,$sp,24
	.set	noreorder
	.set	nomacro
	jal	gpu_LoadImage
	addu	$5,$17,20
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	gpu_DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	sw	$0,D_800A3278
	lw	$31,40($sp)
	lw	$17,36($sp)
	lw	$16,32($sp)
	addu	$sp,$sp,48
	j	$31
	.end	func_8005FBC8
	.align	2
	.globl	func_8005FC9C
	.ent	func_8005FC9C
func_8005FC9C:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	j	$31
	move	$2,$0
	.set	macro
	.set	reorder

	.end	func_8005FC9C
	.align	2
	.globl	func_800600C8
	.ent	func_800600C8
func_800600C8:
	.frame	$sp,112,$31		# vars= 56, regs= 7/0, args= 24, extra= 0
	.mask	0x803f0000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,112
	sw	$17,84($sp)
	move	$17,$4
	sw	$18,88($sp)
	move	$18,$5
	sw	$20,96($sp)
	move	$20,$6
	move	$9,$18
	la	$2,D_8009B6F0
	sw	$19,92($sp)
	addu	$19,$18,180
	sw	$21,100($sp)
	addu	$21,$18,192
	sw	$2,24($sp)
	slt	$2,$17,10
	sw	$31,104($sp)
	sw	$16,80($sp)
	sb	$0,64($sp)
	sw	$0,40($sp)
	sw	$0,52($sp)
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L452
	sw	$20,44($sp)
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	$L454
	li	$2,0x00000093		# 147
	.set	macro
	.set	reorder

$L452:
	li	$2,0x000000a3		# 163
$L454:
	addu	$4,$sp,24
	sw	$2,48($sp)
	la	$2,D_8009B758
	sw	$2,28($sp)
	.set	noreorder
	.set	nomacro
	jal	func_8007352C
	sw	$9,32($sp)
	.set	macro
	.set	reorder

	li	$8,0x66660000		# 1717960704
	ori	$8,$8,0x6667
	sll	$3,$17,16
	sra	$6,$3,16
	mult	$6,$8
	move	$9,$2
	sra	$3,$3,31
	move	$16,$0
	mfhi	$10
	#nop
	#nop
	sra	$4,$10,2
	subu	$4,$4,$3
	sll	$5,$4,16
	sra	$7,$5,16
	mult	$7,$8
	la	$2,D_8009B6FC
	sw	$2,24($sp)
	move	$2,$17
	sh	$2,72($sp)
	sh	$2,74($sp)
	sll	$2,$4,2
	addu	$2,$2,$4
	sll	$2,$2,1
	subu	$6,$6,$2
	sra	$5,$5,31
	sh	$6,72($sp)
	mfhi	$10
	#nop
	#nop
	sra	$3,$10,2
	subu	$3,$3,$5
	sll	$2,$3,2
	addu	$2,$2,$3
	sll	$2,$2,1
	subu	$7,$7,$2
	sh	$7,74($sp)
	sll	$2,$16,1
$L460:
	addu	$2,$sp,$2
	lh	$2,72($2)
	la	$3,D_8009B708
	sll	$2,$2,3
	addu	$2,$2,$3
	sw	$2,28($sp)
	slt	$2,$17,10
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L457
	li	$2,0x00000064		# 100
	.set	macro
	.set	reorder

	li	$2,0x00000001		# 1
	subu	$2,$2,$16
	sll	$2,$2,5
	addu	$2,$2,84
$L457:
	addu	$4,$sp,24
	sw	$2,48($sp)
	.set	noreorder
	.set	nomacro
	jal	func_8007352C
	sw	$9,32($sp)
	.set	macro
	.set	reorder

	lh	$3,74($sp)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$3,$0,$L458
	move	$9,$2
	.set	macro
	.set	reorder

	addu	$16,$16,1
	slt	$2,$16,2
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L460
	sll	$2,$16,1
	.set	macro
	.set	reorder

$L458:
	la	$4,D_8009B6F0
	.set	noreorder
	.set	nomacro
	jal	saMotionSet
	move	$5,$0
	.set	macro
	.set	reorder

	move	$4,$19
	li	$5,0x00000001		# 1
	move	$6,$0
	move	$7,$2
	.set	noreorder
	.set	nomacro
	jal	initTexPage
	sw	$0,16($sp)
	.set	macro
	.set	reorder

	lw	$2,D_800A374C
	move	$5,$19
	sll	$4,$20,2
	.set	noreorder
	.set	nomacro
	jal	ot_Link
	addu	$4,$2,$4
	.set	macro
	.set	reorder

	subu	$2,$21,$18
	lw	$31,104($sp)
	lw	$21,100($sp)
	lw	$20,96($sp)
	lw	$19,92($sp)
	lw	$18,88($sp)
	lw	$17,84($sp)
	lw	$16,80($sp)
	addu	$sp,$sp,112
	j	$31
	.end	func_800600C8
	.align	2
	.globl	func_800602AC
	.ent	func_800602AC
func_800602AC:
	.frame	$sp,64,$31		# vars= 32, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,64
	sw	$16,48($sp)
	move	$16,$5
	addu	$5,$4,61
	li	$4,0x00000002		# 2
	sw	$31,56($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80036EA8
	sw	$17,52($sp)
	.set	macro
	.set	reorder

	move	$17,$2
	move	$4,$17
	.set	noreorder
	.set	nomacro
	jal	replay_camera_Init
	move	$5,$16
	.set	macro
	.set	reorder

	jal	game_FrameLoop
	.set	noreorder
	.set	nomacro
	jal	func_80036F28
	move	$4,$17
	.set	macro
	.set	reorder

	lw	$2,0($16)
	lw	$3,4($16)
	addu	$2,$2,$16
	addu	$3,$3,$16
	sw	$2,0($16)
	sw	$3,4($16)
	la	$5,D_800A3294
	lwl	$2,3($5)
	lwr	$2,0($5)
	lwl	$3,7($5)
	lwr	$3,4($5)
	swl	$2,19($sp)
	swr	$2,16($sp)
	swl	$3,23($sp)
	swr	$3,20($sp)
	la	$5,D_800A329C
	lwl	$2,3($5)
	lwr	$2,0($5)
	lwl	$3,7($5)
	lwr	$3,4($5)
	swl	$2,27($sp)
	swr	$2,24($sp)
	swl	$3,31($sp)
	swr	$3,28($sp)
	lw	$17,0($16)
	addu	$4,$sp,16
	.set	noreorder
	.set	nomacro
	jal	gpu_LoadImage
	addu	$5,$17,64
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	gpu_DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	addu	$4,$sp,24
	.set	noreorder
	.set	nomacro
	jal	gpu_LoadImage
	addu	$5,$17,20
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	gpu_DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	la	$5,D_800A32A4
	lwl	$2,3($5)
	lwr	$2,0($5)
	lwl	$3,7($5)
	lwr	$3,4($5)
	swl	$2,35($sp)
	swr	$2,32($sp)
	swl	$3,39($sp)
	swr	$3,36($sp)
	la	$5,D_800A32AC
	lwl	$2,3($5)
	lwr	$2,0($5)
	lwl	$3,7($5)
	lwr	$3,4($5)
	swl	$2,43($sp)
	swr	$2,40($sp)
	swl	$3,47($sp)
	swr	$3,44($sp)
	lw	$16,4($16)
	addu	$4,$sp,32
	.set	noreorder
	.set	nomacro
	jal	gpu_LoadImage
	addu	$5,$16,96
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	gpu_DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	addu	$4,$sp,40
	.set	noreorder
	.set	nomacro
	jal	gpu_LoadImage
	addu	$5,$16,20
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	gpu_DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	lw	$31,56($sp)
	lw	$17,52($sp)
	lw	$16,48($sp)
	addu	$sp,$sp,64
	j	$31
	.end	func_800602AC
	.align	2
	.globl	func_80060414
	.ent	func_80060414
func_80060414:
	.frame	$sp,96,$31		# vars= 48, regs= 5/0, args= 24, extra= 0
	.mask	0x800f0000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,96
	sw	$18,80($sp)
	move	$18,$6
	andi	$3,$4,0x7fff
	la	$2,D_8009B850
	sll	$3,$3,1
	addu	$3,$3,$2
	sw	$31,88($sp)
	sw	$19,84($sp)
	sw	$17,76($sp)
	sw	$16,72($sp)
	sb	$0,64($sp)
	sw	$0,40($sp)
	sw	$18,44($sp)
	lhu	$2,0($3)
	move	$16,$5
	addu	$17,$16,20
	srl	$2,$2,7
	addu	$2,$2,55
	sw	$2,48($sp)
	lhu	$2,0($3)
	addu	$19,$16,44
	andi	$4,$4,0x8000
	move	$3,$16
	andi	$2,$2,0x007f
	addu	$2,$2,42
	.set	noreorder
	.set	nomacro
	beq	$4,$0,$L463
	sw	$2,52($sp)
	.set	macro
	.set	reorder

	la	$2,D_8009B7AC
	.set	noreorder
	.set	nomacro
	j	$L468
	sw	$2,24($sp)
	.set	macro
	.set	reorder

$L463:
	lbu	$2,D_8009BD24
	#nop
	sltu	$2,$2,12
	beq	$2,$0,$L465
	la	$2,D_8009B7B8
	.set	noreorder
	.set	nomacro
	j	$L468
	sw	$2,24($sp)
	.set	macro
	.set	reorder

$L465:
	la	$2,D_8009B7C4
	sw	$2,24($sp)
$L468:
	addu	$4,$sp,24
	la	$2,D_800A328C
	sw	$2,28($sp)
	.set	noreorder
	.set	nomacro
	jal	func_8007352C
	sw	$3,32($sp)
	.set	macro
	.set	reorder

	lw	$4,24($sp)
	.set	noreorder
	.set	nomacro
	jal	saMotionSet
	move	$5,$0
	.set	macro
	.set	reorder

	move	$4,$17
	li	$5,0x00000001		# 1
	move	$6,$0
	move	$7,$2
	.set	noreorder
	.set	nomacro
	jal	initTexPage
	sw	$0,16($sp)
	.set	macro
	.set	reorder

	lw	$2,D_800A374C
	move	$5,$17
	sll	$4,$18,2
	.set	noreorder
	.set	nomacro
	jal	ot_Link
	addu	$4,$2,$4
	.set	macro
	.set	reorder

	subu	$2,$19,$16
	lw	$31,88($sp)
	lw	$19,84($sp)
	lw	$18,80($sp)
	lw	$17,76($sp)
	lw	$16,72($sp)
	addu	$sp,$sp,96
	j	$31
	.end	func_80060414
	.align	2
	.globl	func_80060544
	.ent	func_80060544
func_80060544:
	.frame	$sp,112,$31		# vars= 48, regs= 10/0, args= 24, extra= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,112
	sw	$20,88($sp)
	move	$20,$4
	sw	$23,100($sp)
	move	$23,$5
	sw	$19,84($sp)
	move	$19,$20
	sw	$18,80($sp)
	addu	$18,$20,1260
	sw	$22,96($sp)
	addu	$22,$20,1500
	sw	$fp,104($sp)
	addu	$fp,$20,1524
	sw	$16,72($sp)
	move	$16,$0
	sw	$17,76($sp)
	move	$17,$0
	sw	$21,92($sp)
	li	$21,0x00000003		# 3
	li	$2,0x00000200		# 512
	sw	$2,56($sp)
	li	$2,0x00000100		# 256
	sw	$31,108($sp)
	sb	$0,64($sp)
	sw	$0,40($sp)
	sw	$23,44($sp)
	sw	$2,60($sp)
	sw	$0,52($sp)
	sw	$0,48($sp)
$L470:
	la	$2,D_8009B770
	addu	$2,$17,$2
	sw	$2,24($sp)
	slt	$2,$16,3
	beq	$2,$0,$L473
	bgtz	$16,$L475
	beq	$16,$0,$L477
	j	$L478
$L473:
	.set	noreorder
	.set	nomacro
	beq	$16,$21,$L480
	addu	$4,$sp,24
	.set	macro
	.set	reorder

	j	$L478
$L477:
	la	$2,D_8009B7D8
	.set	noreorder
	.set	nomacro
	j	$L478
	sw	$2,28($sp)
	.set	macro
	.set	reorder

$L475:
	la	$2,D_8009B800
	.set	noreorder
	.set	nomacro
	j	$L478
	sw	$2,28($sp)
	.set	macro
	.set	reorder

$L480:
	move	$5,$0
	la	$2,D_8009B7D0
	sw	$2,28($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80073728
	sw	$18,36($sp)
	.set	macro
	.set	reorder

	move	$18,$2
$L478:
	beq	$16,$21,$L481
	sw	$19,32($sp)
	.set	noreorder
	.set	nomacro
	jal	func_8007352C
	addu	$4,$sp,24
	.set	macro
	.set	reorder

	move	$19,$2
$L481:
	addu	$16,$16,1
	slt	$2,$16,4
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L470
	addu	$17,$17,12
	.set	macro
	.set	reorder

	addu	$4,$sp,24
	la	$2,D_8009B7A0
	sw	$2,24($sp)
	la	$2,D_8009B820
	sw	$2,28($sp)
	.set	noreorder
	.set	nomacro
	jal	func_8007352C
	sw	$19,32($sp)
	.set	macro
	.set	reorder

	move	$19,$2
	move	$18,$0
	la	$17,D_8009B840
	move	$21,$23
	la	$16,D_8009B3B0
	li	$2,0x000000ff		# 255
	sb	$2,65($sp)
	li	$2,0x00000010		# 16
	sb	$2,67($sp)
	sb	$2,66($sp)
	li	$2,0x00000001		# 1
	sb	$2,64($sp)
$L483:
	addu	$4,$sp,24
	sw	$16,24($sp)
	sw	$17,28($sp)
	.set	noreorder
	.set	nomacro
	jal	func_8007352C
	sw	$19,32($sp)
	.set	macro
	.set	reorder

	move	$19,$2
	addu	$17,$17,8
	addu	$18,$18,1
	slt	$2,$18,2
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L483
	addu	$16,$16,12
	.set	macro
	.set	reorder

	lw	$4,24($sp)
	.set	noreorder
	.set	nomacro
	jal	saMotionSet
	move	$5,$0
	.set	macro
	.set	reorder

	move	$4,$22
	li	$5,0x00000001		# 1
	move	$6,$0
	move	$7,$2
	.set	noreorder
	.set	nomacro
	jal	initTexPage
	sw	$0,16($sp)
	.set	macro
	.set	reorder

	lw	$2,D_800A374C
	move	$5,$22
	sll	$4,$21,2
	.set	noreorder
	.set	nomacro
	jal	ot_Link
	addu	$4,$2,$4
	.set	macro
	.set	reorder

	subu	$2,$fp,$20
	lw	$31,108($sp)
	lw	$fp,104($sp)
	lw	$23,100($sp)
	lw	$22,96($sp)
	lw	$21,92($sp)
	lw	$20,88($sp)
	lw	$19,84($sp)
	lw	$18,80($sp)
	lw	$17,76($sp)
	lw	$16,72($sp)
	addu	$sp,$sp,112
	j	$31
	.end	func_80060544
	.align	2
	.globl	func_80060758
	.ent	func_80060758
func_80060758:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	sh	$0,D_800A32B6
	sh	$0,D_800A32B4
	j	$31
	.end	func_80060758
	.align	2
	.globl	func_80060768
	.ent	func_80060768
func_80060768:
	.frame	$sp,56,$31		# vars= 8, regs= 6/0, args= 24, extra= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,56
	sw	$18,40($sp)
	move	$18,$4
	sw	$19,44($sp)
	move	$19,$5
	sw	$16,32($sp)
	move	$16,$6
	sw	$17,36($sp)
	addu	$17,$18,2000
	addu	$4,$sp,24
	addu	$5,$sp,28
	la	$6,D_8009B0C0
	move	$7,$19
	addu	$2,$18,2160
	sw	$31,52($sp)
	sw	$20,48($sp)
	sw	$18,24($sp)
	sw	$2,28($sp)
	.set	noreorder
	.set	nomacro
	jal	func_8006D808
	sw	$16,16($sp)
	.set	macro
	.set	reorder

	sltu	$2,$16,3
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L489
	addu	$20,$18,2760
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	initTile
	move	$4,$17
	.set	macro
	.set	reorder

	li	$2,0x000000ff		# 255
	sb	$2,2004($18)
	li	$2,0x0000006a		# 106
	sh	$2,2008($18)
	sll	$2,$16,1
	addu	$2,$2,$16
	sll	$2,$2,2
	addu	$2,$2,$16
	sll	$2,$2,1
	addu	$2,$2,91
	sb	$0,2005($18)
	sb	$0,2006($18)
	sh	$2,2010($18)
	lhu	$4,D_800A32B4
	li	$5,-2004353024			# 0x88880000
	ori	$5,$5,0x8889
	sll	$3,$4,16
	sra	$3,$3,16
	sll	$2,$3,3
	addu	$2,$2,$3
	sll	$2,$2,3
	subu	$2,$2,$3
	sll	$3,$2,2
	subu	$3,$3,$2
	sll	$3,$3,1
	mult	$3,$5
	addu	$4,$4,1
	li	$2,0x00000002		# 2
	sh	$4,D_800A32B4
	sh	$2,2014($18)
	mfhi	$8
	#nop
	#nop
	addu	$2,$8,$3
	sra	$2,$2,4
	sra	$3,$3,31
	subu	$2,$2,$3
	sh	$2,2012($18)
	lh	$2,D_800A32B4
	#nop
	slt	$2,$2,31
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L490
	li	$2,0x0000001e		# 30
	.set	macro
	.set	reorder

	sh	$2,D_800A32B4
$L490:
	move	$4,$17
	.set	noreorder
	.set	nomacro
	jal	gpu_SetSemiTransp
	move	$5,$0
	.set	macro
	.set	reorder

	lw	$2,D_800A374C
	move	$5,$17
	addu	$17,$18,2016
	sll	$4,$19,2
	.set	noreorder
	.set	nomacro
	jal	ot_Link
	addu	$4,$2,$4
	.set	macro
	.set	reorder

$L489:
	.set	noreorder
	.set	nomacro
	jal	initTile
	move	$4,$17
	.set	macro
	.set	reorder

	li	$2,0x000000ff		# 255
	sb	$2,4($17)
	li	$2,0x0000009e		# 158
	sh	$2,8($17)
	li	$2,0x000000bd		# 189
	sb	$0,5($17)
	sb	$0,6($17)
	sh	$2,10($17)
	lhu	$4,D_800A32B6
	li	$5,-2004353024			# 0x88880000
	ori	$5,$5,0x8889
	sll	$3,$4,16
	sra	$3,$3,16
	sll	$2,$3,2
	addu	$2,$2,$3
	sll	$2,$2,4
	addu	$2,$2,$3
	sll	$2,$2,2
	mult	$2,$5
	addu	$4,$4,1
	li	$3,0x00000002		# 2
	sh	$4,D_800A32B6
	sh	$3,14($17)
	mfhi	$8
	#nop
	#nop
	addu	$3,$8,$2
	sra	$3,$3,4
	sra	$2,$2,31
	subu	$3,$3,$2
	sh	$3,12($17)
	lh	$2,D_800A32B6
	#nop
	slt	$2,$2,31
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L491
	li	$2,0x0000001e		# 30
	.set	macro
	.set	reorder

	sh	$2,D_800A32B6
$L491:
	move	$4,$17
	.set	noreorder
	.set	nomacro
	jal	gpu_SetSemiTransp
	move	$5,$0
	.set	macro
	.set	reorder

	lw	$4,D_800A374C
	move	$5,$17
	addu	$17,$17,16
	sll	$16,$19,2
	.set	noreorder
	.set	nomacro
	jal	ot_Link
	addu	$4,$4,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	initTile
	move	$4,$17
	.set	macro
	.set	reorder

	move	$4,$17
	li	$5,0x00000001		# 1
	li	$2,0x0000003f		# 63
	sh	$2,8($17)
	li	$2,0x0000002d		# 45
	sh	$2,10($17)
	li	$2,0x00000202		# 514
	sh	$2,12($17)
	li	$2,0x0000006c		# 108
	sb	$0,4($17)
	sb	$0,5($17)
	sb	$0,6($17)
	.set	noreorder
	.set	nomacro
	jal	gpu_SetSemiTransp
	sh	$2,14($17)
	.set	macro
	.set	reorder

	lw	$4,D_800A374C
	move	$5,$17
	addu	$17,$17,16
	.set	noreorder
	.set	nomacro
	jal	ot_Link
	addu	$4,$4,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	initTile
	move	$4,$17
	.set	macro
	.set	reorder

	move	$4,$17
	li	$5,0x00000001		# 1
	li	$2,0x00000092		# 146
	sh	$2,8($17)
	li	$2,0x000000aa		# 170
	sh	$2,10($17)
	li	$2,0x0000015c		# 348
	sh	$2,12($17)
	li	$2,0x0000001a		# 26
	sb	$0,4($17)
	sb	$0,5($17)
	sb	$0,6($17)
	.set	noreorder
	.set	nomacro
	jal	gpu_SetSemiTransp
	sh	$2,14($17)
	.set	macro
	.set	reorder

	lw	$4,D_800A374C
	move	$5,$17
	.set	noreorder
	.set	nomacro
	jal	ot_Link
	addu	$4,$4,$16
	.set	macro
	.set	reorder

	sw	$0,16($sp)
	lw	$4,28($sp)
	li	$5,0x00000001		# 1
	move	$6,$0
	.set	noreorder
	.set	nomacro
	jal	initTexPage
	move	$7,$0
	.set	macro
	.set	reorder

	lw	$4,D_800A374C
	lw	$5,28($sp)
	.set	noreorder
	.set	nomacro
	jal	ot_Link
	addu	$4,$4,$16
	.set	macro
	.set	reorder

	lw	$3,28($sp)
	subu	$2,$20,$18
	addu	$3,$3,12
	sw	$3,28($sp)
	lw	$31,52($sp)
	lw	$20,48($sp)
	lw	$19,44($sp)
	lw	$18,40($sp)
	lw	$17,36($sp)
	lw	$16,32($sp)
	addu	$sp,$sp,56
	j	$31
	.end	func_80060768
	.align	2
	.globl	func_80060A68
	.ent	func_80060A68
func_80060A68:
	.frame	$sp,32,$31		# vars= 8, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	lw	$3,D_800A3468
	subu	$sp,$sp,32
	sw	$31,24($sp)
	lhu	$4,0($3)
	la	$2,D_800F10D0
	sll	$6,$4,2
	addu	$6,$6,$2
	sw	$0,0($6)
	lw	$2,12($3)
	lw	$5,12($3)
	lw	$2,0($2)
	#nop
	sw	$2,32($3)
	lw	$2,4($5)
	lw	$5,12($3)
	sw	$2,36($3)
	lw	$2,8($5)
	lw	$5,16($3)
	sw	$2,40($3)
	lhu	$2,0($5)
	#nop
	sh	$2,24($3)
	addu	$2,$3,24
	sw	$2,D_800A3478
	lw	$2,16($3)
	lw	$5,16($3)
	lhu	$2,2($2)
	#nop
	sh	$2,26($3)
	lhu	$5,4($5)
	addu	$2,$3,32
	sw	$2,D_800A347C
	sh	$5,28($3)
	lbu	$2,D_8009BA60($4)
	lw	$3,0($6)
	#nop
	addu	$2,$2,$3
	sll	$2,$2,2
	lw	$2,chractar_use_pset_combo_id_table($2)
	#nop
	jal	$31,$2
	lw	$3,D_800A3468
	#nop
	lw	$3,20($3)
	#nop
	sb	$2,0($3)
	lw	$2,D_800A3468
	#nop
	lw	$2,0($2)
	li	$3,0x00200000		# 2097152
	and	$2,$2,$3
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L493
	li	$2,0x0000000a		# 10
	.set	macro
	.set	reorder

	sw	$2,D_800A32BC
$L493:
	lw	$31,24($sp)
	addu	$sp,$sp,32
	j	$31
	.end	func_80060A68
	.align	2
	.globl	func_80060B70
	.ent	func_80060B70
func_80060B70:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	lw	$3,D_800A3468
	subu	$sp,$sp,24
	sw	$31,16($sp)
	lw	$2,4($3)
	lw	$4,D_800A346C
	lhu	$2,0($2)
	#nop
	sh	$2,0($4)
	lw	$2,4($3)
	#nop
	lhu	$2,2($2)
	#nop
	sh	$2,2($4)
	lw	$2,4($3)
	#nop
	lhu	$2,4($2)
	#nop
	sh	$2,4($4)
	lw	$2,8($3)
	lw	$5,D_800A3470
	lw	$2,0($2)
	#nop
	sw	$2,0($5)
	lw	$2,8($3)
	#nop
	lw	$2,4($2)
	#nop
	sw	$2,4($5)
	lw	$2,8($3)
	lw	$6,D_800A3474
	lw	$2,8($2)
	.set	noreorder
	.set	nomacro
	jal	func_80061FAC
	sw	$2,8($5)
	.set	macro
	.set	reorder

	lw	$2,D_800A3468
	#nop
	lhu	$2,0($2)
	#nop
	lbu	$3,D_8009BA60($2)
	sll	$2,$2,2
	lw	$2,D_800F10D0($2)
	#nop
	addu	$3,$3,$2
	sll	$3,$3,2
	lw	$2,chractar_use_pset_combo_id_table($3)
	#nop
	jal	$31,$2
	lw	$3,D_800A3468
	#nop
	lw	$3,20($3)
	.set	noreorder
	lw	$31,16($sp)
	sb	$2,0($3)
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80060B70
	.align	2
	.globl	saTan1GaugeInit
	.ent	saTan1GaugeInit
saTan1GaugeInit:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	move	$3,$0
	la	$4,D_800F10D0
$L496:
	sw	$0,0($4)
	sb	$0,D_800F1150($3)
	addu	$3,$3,1
	slt	$2,$3,28
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L496
	addu	$4,$4,4
	.set	macro
	.set	reorder

	sh	$0,D_800A345E
	sh	$0,D_800A345C
	sw	$0,D_800A3458
	sw	$0,D_800A3454
	sw	$0,D_800A3450
	sw	$0,D_800A344C
	sw	$0,D_800A3460
	sw	$0,D_800A3444
	sw	$0,D_800A3448
	j	$31
	.end	saTan1GaugeInit
	.align	2
	.globl	func_80060CB8
	.ent	func_80060CB8
func_80060CB8:
	.frame	$sp,40,$31		# vars= 8, regs= 4/0, args= 16, extra= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	sw	$18,32($sp)
	move	$18,$5
	sw	$17,28($sp)
	move	$17,$4
	sw	$31,36($sp)
	.set	noreorder
	.set	nomacro
	jal	game_FrameLoop
	sw	$16,24($sp)
	.set	macro
	.set	reorder

	lw	$2,D_8009BD38
	#nop
	andi	$3,$2,0x000f
	.set	noreorder
	.set	nomacro
	bne	$3,$0,$L501
	li	$2,0x00000003		# 3
	.set	macro
	.set	reorder

	li	$4,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	j	$L509
	li	$5,0x0000003c		# 60
	.set	macro
	.set	reorder

$L501:
	.set	noreorder
	.set	nomacro
	bne	$3,$2,$L503
	li	$2,0x00000002		# 2
	.set	macro
	.set	reorder

	li	$4,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	j	$L509
	li	$5,0x0000002f		# 47
	.set	macro
	.set	reorder

$L503:
	.set	noreorder
	.set	nomacro
	bne	$3,$2,$L505
	li	$2,0x00000005		# 5
	.set	macro
	.set	reorder

	li	$4,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	j	$L509
	li	$5,0x00000030		# 48
	.set	macro
	.set	reorder

$L505:
	bne	$3,$2,$L507
	li	$4,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	j	$L509
	li	$5,0x00000031		# 49
	.set	macro
	.set	reorder

$L507:
	li	$4,0x00000002		# 2
	move	$5,$0
$L509:
	.set	noreorder
	.set	nomacro
	jal	func_80036EA8
	li	$16,0x000001dc		# 476
	.set	macro
	.set	reorder

	move	$4,$2
	.set	noreorder
	.set	nomacro
	jal	replay_camera_Init
	move	$5,$17
	.set	macro
	.set	reorder

	jal	game_FrameLoop
	move	$4,$0
	li	$2,0x00000380		# 896
	sh	$2,16($sp)
	li	$2,0x00000080		# 128
	sh	$0,18($sp)
	sh	$2,20($sp)
	.set	noreorder
	.set	nomacro
	jal	gpu_DrawSync
	sh	$16,22($sp)
	.set	macro
	.set	reorder

	addu	$4,$sp,16
	.set	noreorder
	.set	nomacro
	jal	gpu_LoadImage
	move	$5,$17
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	gpu_DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	li	$5,0x00010000		# 65536
	ori	$5,$5,0xdc00
	addu	$4,$sp,16
	addu	$5,$17,$5
	li	$2,0x00000070		# 112
	sh	$2,20($sp)
	li	$2,0x00000024		# 36
	sh	$16,18($sp)
	.set	noreorder
	.set	nomacro
	jal	gpu_LoadImage
	sh	$2,22($sp)
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	gpu_DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	jal	saTan1GaugeInit
	jal	func_80079154
	.set	noreorder
	.set	nomacro
	jal	func_80079184
	move	$4,$2
	.set	macro
	.set	reorder

	addu	$3,$18,18000
	addu	$2,$3,18000
	sw	$18,D_800A3420
	sw	$3,D_800A3424
	lw	$31,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,40
	j	$31
	.end	func_80060CB8
	.align	2
	.globl	gnd_get_fog
	.ent	gnd_get_fog
gnd_get_fog:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	beq	$4,$0,$L511
	lw	$2,D_800A3424
	j	$L513
$L511:
	lw	$2,D_800A3420
$L513:
	sw	$2,D_800A37D4
	lw	$2,D_800A37D4
	#nop
	sw	$2,D_800A3720
	j	$31
	.end	gnd_get_fog
	.align	2
	.globl	func_80060E38
	.ent	func_80060E38
func_80060E38:
	.frame	$sp,112,$31		# vars= 72, regs= 9/0, args= 0, extra= 0
	.mask	0x40ff0000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,112
	li	$2,0x1f800000		# 528482304
	ori	$2,$2,0x0018
	sw	$2,0($sp)
	li	$2,0x1f800000		# 528482304
	ori	$2,$2,0x0020
	sw	$2,8($sp)
	li	$2,0x1f800000		# 528482304
	ori	$2,$2,0x0030
	sw	$2,16($sp)
	li	$2,0x1f800000		# 528482304
	ori	$2,$2,0x0050
	sw	$2,24($sp)
	li	$2,0x1f800000		# 528482304
	ori	$2,$2,0x0058
	sw	$2,32($sp)
	li	$2,0x1f800000		# 528482304
	ori	$2,$2,0x005c
	sw	$2,40($sp)
	li	$2,0x1f800000		# 528482304
	ori	$2,$2,0x0060
	sw	$2,48($sp)
	li	$2,0x1f800000		# 528482304
	ori	$2,$2,0x0062
	sw	$2,56($sp)
	li	$2,0x1f800000		# 528482304
	ori	$2,$2,0x0064
	sw	$fp,104($sp)
	li	$fp,0x1f800000		# 528482304
	ori	$fp,$fp,0x0066
	li	$25,0x1f800000		# 528482304
	sw	$2,64($sp)
	li	$2,0x1f800000		# 528482304
	sw	$2,D_800A3468
	lw	$2,0($sp)
	ori	$25,$25,0x0068
	li	$24,0x1f800000		# 528482304
	ori	$24,$24,0x006a
	sw	$23,100($sp)
	li	$23,0x1f800000		# 528482304
	ori	$23,$23,0x006c
	sw	$22,96($sp)
	li	$22,0x1f800000		# 528482304
	ori	$22,$22,0x0070
	sw	$21,92($sp)
	li	$21,0x1f800000		# 528482304
	ori	$21,$21,0x0074
	sw	$20,88($sp)
	li	$20,0x1f800000		# 528482304
	ori	$20,$20,0x0080
	sw	$19,84($sp)
	li	$19,0x1f800000		# 528482304
	ori	$19,$19,0x0082
	sw	$18,80($sp)
	li	$18,0x1f800000		# 528482304
	ori	$18,$18,0x0084
	sw	$17,76($sp)
	li	$17,0x1f800000		# 528482304
	ori	$17,$17,0x0088
	sw	$16,72($sp)
	sw	$2,D_800A346C
	lw	$2,8($sp)
	li	$16,0x1f800000		# 528482304
	ori	$16,$16,0x008c
	li	$15,0x1f800000		# 528482304
	sw	$2,D_800A3470
	lw	$2,16($sp)
	ori	$15,$15,0x0090
	li	$14,0x1f800000		# 528482304
	ori	$14,$14,0x0098
	sw	$2,D_800A3474
	lw	$2,24($sp)
	li	$13,0x1f800000		# 528482304
	ori	$13,$13,0x009a
	li	$12,0x1f800000		# 528482304
	sw	$2,D_800A3488
	lw	$2,32($sp)
	ori	$12,$12,0x009c
	li	$11,0x1f800000		# 528482304
	ori	$11,$11,0x009e
	sw	$2,D_800A3490
	lw	$2,40($sp)
	li	$10,0x1f800000		# 528482304
	ori	$10,$10,0x00a0
	li	$9,0x1f800000		# 528482304
	sw	$2,D_800A3494
	lw	$2,48($sp)
	ori	$9,$9,0x00a4
	li	$8,0x1f800000		# 528482304
	ori	$8,$8,0x00a8
	sw	$2,D_800A3498
	lw	$2,56($sp)
	li	$7,0x1f800000		# 528482304
	ori	$7,$7,0x00ac
	li	$6,0x1f800000		# 528482304
	sw	$2,D_800A349C
	lw	$2,64($sp)
	ori	$6,$6,0x00b0
	li	$3,0x1f800000		# 528482304
	ori	$3,$3,0x00b8
	sw	$fp,D_800A34A4
	sw	$25,D_800A34A8
	sw	$24,D_800A34AC
	sw	$23,D_800A34B0
	sw	$22,D_800A34B4
	sw	$21,D_800A34B8
	sw	$20,D_800A34BC
	sw	$19,D_800A34C0
	sw	$18,D_800A34C4
	sw	$17,D_800A34C8
	sw	$16,D_800A34CC
	sw	$15,D_800A34D0
	sw	$14,D_800A34D4
	sw	$13,D_800A34D8
	sw	$12,D_800A34DC
	sw	$11,D_800A34E0
	sw	$10,D_800A34E4
	sw	$9,D_800A34E8
	sw	$8,D_800A3480
	sw	$7,D_800A3484
	sw	$6,D_800A348C
	sw	$3,D_800A34EC
	sw	$4,528482308
	sw	$2,D_800A34A0
	sw	$5,528482312
	lw	$fp,104($sp)
	lw	$23,100($sp)
	lw	$22,96($sp)
	lw	$21,92($sp)
	lw	$20,88($sp)
	lw	$19,84($sp)
	lw	$18,80($sp)
	lw	$17,76($sp)
	lw	$16,72($sp)
	addu	$sp,$sp,112
	j	$31
	.end	func_80060E38
	.align	2
	.globl	func_80061064
	.ent	func_80061064
func_80061064:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	sw	$31,24($sp)
	sw	$17,20($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80060E38
	sw	$16,16($sp)
	.set	macro
	.set	reorder

	move	$16,$0
	la	$17,D_800F1150
$L516:
	lw	$3,D_800A3468
	addu	$2,$16,$17
	sw	$2,20($3)
	lbu	$2,D_800F1150($16)
	#nop
	beq	$2,$0,$L519
	.set	noreorder
	.set	nomacro
	jal	func_80060B70
	sw	$16,0($3)
	.set	macro
	.set	reorder

$L519:
	addu	$16,$16,1
	slt	$2,$16,28
	bne	$2,$0,$L516
	lw	$3,D_800A32BC
	#nop
	slt	$2,$3,2
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L521
	li	$2,0x00000001		# 1
	.set	macro
	.set	reorder

	lw	$5,D_800A3464
	la	$4,D_800F1140
	addu	$2,$3,-1
	sw	$2,D_800A32BC
	jal	func_80041E10
	j	$L522
$L521:
	bne	$3,$2,$L522
	jal	leaf_muki_awase_800421A4
	sw	$0,D_800A32BC
$L522:
	lw	$3,D_800A37D4
	lw	$2,D_800A3720
	#nop
	subu	$3,$3,$2
	sll	$2,$3,1
	addu	$2,$2,$3
	sll	$3,$2,4
	addu	$2,$2,$3
	sll	$3,$2,8
	addu	$2,$2,$3
	sll	$3,$2,16
	addu	$2,$2,$3
	subu	$2,$0,$2
	sra	$5,$2,3
	slt	$2,$5,450
	bne	$2,$0,$L524
	la	$4,D_800158E0
	.set	noreorder
	.set	nomacro
	jal	debug_printf
	addu	$5,$5,-450
	.set	macro
	.set	reorder

$L524:
	lw	$31,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,32
	j	$31
	.end	func_80061064
	.align	2
	.globl	game_Cleanup
	.ent	game_Cleanup
game_Cleanup:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	jal	saTan1GaugeInit
	jal	leaf_muki_awase_800421A4
	sw	$0,D_800A32BC
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	game_Cleanup
	.align	2
	.globl	func_800611A4
	.ent	func_800611A4
func_800611A4:
	.frame	$sp,32,$31		# vars= 8, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	sw	$31,28($sp)
	sw	$16,24($sp)
	lhu	$2,0($5)
	#nop
	sh	$2,16($sp)
	lhu	$2,2($5)
	move	$16,$4
	la	$4,D_800F116C
	sw	$4,D_800A3468
	sh	$2,18($sp)
	lhu	$5,4($5)
	li	$3,0x00210000		# 2162688
	ori	$3,$3,0x001a
	addu	$2,$sp,16
	sw	$2,D_800F117C
	la	$2,D_800F116A
	sw	$16,D_800F1178
	sw	$2,D_800F1180
	sw	$3,0($4)
	.set	noreorder
	.set	nomacro
	jal	func_80060A68
	sh	$5,20($sp)
	.set	macro
	.set	reorder

	lw	$2,0($16)
	#nop
	sw	$2,D_800F1140
	lw	$2,4($16)
	#nop
	sw	$2,D_800F1144
	lw	$2,8($16)
	li	$3,0x00ff0000		# 16711680
	ori	$3,$3,0xffef
	sw	$3,D_800A3464
	sw	$2,D_800F1148
	lw	$31,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,32
	j	$31
	.end	func_800611A4
	.align	2
	.globl	func_80061250
	.ent	func_80061250
func_80061250:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	la	$3,D_800F1159
	sw	$31,20($sp)
	sw	$16,16($sp)
	#.set	volatile
	lbu	$2,0($3)
	#.set	novolatile
	move	$16,$4
	la	$5,D_800F116C
	sw	$5,D_800A3468
	sw	$16,D_800F1178
	beq	$2,$0,$L528
	#.set	volatile
	lbu	$2,1($3)
	#.set	novolatile
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L529
	addu	$4,$3,1
	.set	macro
	.set	reorder

	#.set	volatile
	sb	$0,1($3)
	#.set	novolatile
	#.set	volatile
	sb	$0,0($3)
	#.set	novolatile
$L529:
	#.set	volatile
	lbu	$2,0($3)
	#.set	novolatile
	#nop
	bne	$2,$0,$L531
$L528:
	lw	$2,D_800A3468
	li	$4,0x00210000		# 2162688
	ori	$4,$4,0x0009
	la	$3,D_800F1159
	sw	$3,20($2)
	.set	noreorder
	.set	nomacro
	j	$L532
	sw	$4,0($2)
	.set	macro
	.set	reorder

$L531:
	#.set	volatile
	lbu	$2,1($3)
	#.set	novolatile
	#nop
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L532
	li	$2,0x00210000		# 2162688
	.set	macro
	.set	reorder

	ori	$2,$2,0x000a
	sw	$4,D_800F1180
	sw	$2,0($5)
$L532:
	jal	func_80060A68
	lw	$2,0($16)
	#nop
	sw	$2,D_800F1140
	lw	$2,4($16)
	#nop
	sw	$2,D_800F1144
	lw	$2,8($16)
	li	$3,0x00ff0000		# 16711680
	ori	$3,$3,0x0060
	sw	$3,D_800A3464
	sw	$2,D_800F1148
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80061250
	.align	2
	.globl	func_8006133C
	.ent	func_8006133C
func_8006133C:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$16,16($sp)
	move	$16,$4
	li	$4,0x00210000		# 2162688
	ori	$4,$4,0x0004
	la	$3,D_800F116C
	la	$2,D_800F1154
	sw	$31,20($sp)
	sw	$3,D_800A3468
	sw	$16,D_800F1178
	sw	$2,D_800F1180
	.set	noreorder
	.set	nomacro
	jal	func_80060A68
	sw	$4,0($3)
	.set	macro
	.set	reorder

	lw	$2,0($16)
	#nop
	sw	$2,D_800F1140
	lw	$2,4($16)
	#nop
	sw	$2,D_800F1144
	lw	$3,8($16)
	li	$2,0x00800000		# 8388608
	ori	$2,$2,0x80ff
	sw	$2,D_800A3464
	li	$2,0x00000001		# 1
	sw	$3,D_800F1148
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_8006133C
	.align	2
	.globl	func_800613C8
	.ent	func_800613C8
func_800613C8:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$16,16($sp)
	move	$16,$4
	li	$4,0x00210000		# 2162688
	ori	$4,$4,0x000b
	la	$3,D_800F116C
	la	$2,D_800F115B
	sw	$31,20($sp)
	sw	$3,D_800A3468
	sw	$16,D_800F1178
	sw	$2,D_800F1180
	.set	noreorder
	.set	nomacro
	jal	func_80060A68
	sw	$4,0($3)
	.set	macro
	.set	reorder

	lw	$2,0($16)
	#nop
	sw	$2,D_800F1140
	lw	$2,4($16)
	#nop
	sw	$2,D_800F1144
	lw	$3,8($16)
	li	$2,0x00800000		# 8388608
	ori	$2,$2,0x80ff
	sw	$2,D_800A3464
	li	$2,0x00000010		# 16
	sw	$3,D_800F1148
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_800613C8
	.align	2
	.globl	func_80061454
	.ent	func_80061454
func_80061454:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$16,16($sp)
	move	$16,$4
	li	$4,0x00290000		# 2686976
	ori	$4,$4,0x000b
	la	$3,D_800F116C
	la	$2,D_800F115B
	sw	$31,20($sp)
	sw	$3,D_800A3468
	sw	$16,D_800F1178
	sw	$2,D_800F1180
	.set	noreorder
	.set	nomacro
	jal	func_80060A68
	sw	$4,0($3)
	.set	macro
	.set	reorder

	lw	$2,0($16)
	#nop
	sw	$2,D_800F1140
	lw	$2,4($16)
	#nop
	sw	$2,D_800F1144
	lw	$3,8($16)
	li	$2,0x00800000		# 8388608
	ori	$2,$2,0x80ff
	sw	$2,D_800A3464
	li	$2,0x00000008		# 8
	sw	$3,D_800F1148
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80061454
	.align	2
	.globl	func_800614E0
	.ent	func_800614E0
func_800614E0:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$16,16($sp)
	move	$16,$4
	li	$4,0x00310000		# 3211264
	ori	$4,$4,0x000b
	la	$3,D_800F116C
	la	$2,D_800F115B
	sw	$31,20($sp)
	sw	$3,D_800A3468
	sw	$16,D_800F1178
	sw	$2,D_800F1180
	.set	noreorder
	.set	nomacro
	jal	func_80060A68
	sw	$4,0($3)
	.set	macro
	.set	reorder

	lw	$2,0($16)
	#nop
	sw	$2,D_800F1140
	lw	$2,4($16)
	#nop
	sw	$2,D_800F1144
	lw	$3,8($16)
	li	$2,0x00800000		# 8388608
	ori	$2,$2,0x80ff
	sw	$2,D_800A3464
	li	$2,0x00000005		# 5
	sw	$3,D_800F1148
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_800614E0
	.align	2
	.globl	func_8006156C
	.ent	func_8006156C
func_8006156C:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	la	$3,D_800F1154+1
	sw	$31,20($sp)
	sw	$16,16($sp)
	lbu	$2,0($3)
	move	$16,$4
	la	$5,D_800F116C
	sw	$5,D_800A3468
	sw	$16,D_800F1178
	beq	$2,$0,$L539
	lbu	$2,1($3)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L540
	addu	$4,$3,1
	.set	macro
	.set	reorder

	sb	$0,1($3)
	sb	$0,0($3)
$L540:
	lbu	$2,0($3)
	#nop
	bne	$2,$0,$L542
$L539:
	lw	$2,D_800A3468
	li	$4,0x00210000		# 2162688
	ori	$4,$4,0x0005
	la	$3,D_800F1154+1
	sw	$3,20($2)
	.set	noreorder
	.set	nomacro
	j	$L543
	sw	$4,0($2)
	.set	macro
	.set	reorder

$L542:
	lbu	$2,1($3)
	#nop
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L543
	li	$2,0x00210000		# 2162688
	.set	macro
	.set	reorder

	ori	$2,$2,0x0006
	sw	$4,D_800F1180
	sw	$2,0($5)
$L543:
	jal	func_80060A68
	lw	$2,0($16)
	#nop
	sw	$2,D_800F1140
	lw	$2,4($16)
	#nop
	sw	$2,D_800F1144
	lw	$3,8($16)
	li	$2,0x00ff0000		# 16711680
	ori	$2,$2,0x8080
	sw	$2,D_800A3464
	sw	$3,D_800F1148
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_8006156C
	.align	2
	.globl	func_80061658
	.ent	func_80061658
func_80061658:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$16,16($sp)
	move	$16,$4
	la	$4,D_800F116C
	sw	$31,20($sp)
	sw	$4,D_800A3468
	sw	$16,D_800F1178
	.set	noreorder
	.set	nomacro
	beq	$5,$0,$L547
	li	$2,0x00000001		# 1
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	beq	$5,$2,$L548
	li	$3,0x00210000		# 2162688
	.set	macro
	.set	reorder

	j	$L546
$L547:
	li	$3,0x00210000		# 2162688
	la	$2,D_800F115C
	.set	noreorder
	.set	nomacro
	j	$L551
	ori	$3,$3,0x000c
	.set	macro
	.set	reorder

$L548:
	ori	$3,$3,0x000d
	la	$2,D_800F115C+1
$L551:
	sb	$0,0($2)
	sw	$2,D_800F1180
	sw	$3,0($4)
$L546:
	jal	func_80060A68
	lw	$2,0($16)
	#nop
	sw	$2,D_800F1140
	lw	$2,4($16)
	#nop
	sw	$2,D_800F1144
	lw	$2,8($16)
	li	$3,0x00100000		# 1048576
	ori	$3,$3,0xffff
	sw	$3,D_800A3464
	sw	$2,D_800F1148
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80061658
	.align	2
	.globl	func_80061710
	.ent	func_80061710
func_80061710:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$16,16($sp)
	move	$16,$4
	la	$4,D_800F116C
	sw	$31,20($sp)
	sw	$4,D_800A3468
	sw	$16,D_800F1178
	.set	noreorder
	.set	nomacro
	beq	$5,$0,$L554
	li	$2,0x00000001		# 1
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	beq	$5,$2,$L555
	li	$3,0x00210000		# 2162688
	.set	macro
	.set	reorder

	j	$L553
$L554:
	li	$3,0x00210000		# 2162688
	la	$2,D_800F115C+2
	.set	noreorder
	.set	nomacro
	j	$L558
	ori	$3,$3,0x000e
	.set	macro
	.set	reorder

$L555:
	ori	$3,$3,0x000f
	la	$2,D_800F115C+3
$L558:
	sb	$0,0($2)
	sw	$2,D_800F1180
	sw	$3,0($4)
$L553:
	jal	func_80060A68
	lw	$2,0($16)
	#nop
	sw	$2,D_800F1140
	lw	$2,4($16)
	#nop
	sw	$2,D_800F1144
	lw	$2,8($16)
	li	$3,0x00100000		# 1048576
	ori	$3,$3,0xff10
	sw	$3,D_800A3464
	sw	$2,D_800F1148
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80061710
	.align	2
	.globl	func_800617C8
	.ent	func_800617C8
func_800617C8:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	la	$3,D_800F1160
	sw	$31,20($sp)
	sw	$16,16($sp)
	lbu	$2,0($3)
	move	$16,$4
	la	$5,D_800F116C
	sw	$5,D_800A3468
	sw	$16,D_800F1178
	beq	$2,$0,$L560
	lbu	$2,1($3)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L561
	addu	$4,$3,1
	.set	macro
	.set	reorder

	sb	$0,1($3)
	sb	$0,0($3)
$L561:
	lbu	$2,0($3)
	#nop
	bne	$2,$0,$L563
$L560:
	lw	$2,D_800A3468
	li	$4,0x00210000		# 2162688
	ori	$4,$4,0x0010
	la	$3,D_800F1160
	sw	$3,20($2)
	.set	noreorder
	.set	nomacro
	j	$L564
	sw	$4,0($2)
	.set	macro
	.set	reorder

$L563:
	lbu	$2,1($3)
	#nop
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L564
	li	$2,0x00210000		# 2162688
	.set	macro
	.set	reorder

	ori	$2,$2,0x0011
	sw	$4,D_800F1180
	sw	$2,0($5)
$L564:
	jal	func_80060A68
	lw	$2,0($16)
	#nop
	sw	$2,D_800F1140
	lw	$2,4($16)
	#nop
	sw	$2,D_800F1144
	lw	$3,8($16)
	li	$2,0x00c00000		# 12582912
	ori	$2,$2,0x6013
	sw	$2,D_800A3464
	sw	$3,D_800F1148
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_800617C8
	.align	2
	.globl	func_800618B4
	.ent	func_800618B4
func_800618B4:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	la	$3,D_800F1152
	sw	$31,20($sp)
	sw	$16,16($sp)
	lbu	$2,0($3)
	move	$16,$4
	la	$6,D_800F116C
	sw	$6,D_800A3468
	sw	$16,D_800F1178
	sw	$5,D_800F117C
	beq	$2,$0,$L567
	lbu	$2,1($3)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L568
	addu	$4,$3,1
	.set	macro
	.set	reorder

	sb	$0,1($3)
	sb	$0,0($3)
$L568:
	lbu	$2,0($3)
	#nop
	bne	$2,$0,$L570
$L567:
	lw	$2,D_800A3468
	li	$4,0x00210000		# 2162688
	ori	$4,$4,0x0002
	la	$3,D_800F1152
	sw	$3,20($2)
	.set	noreorder
	.set	nomacro
	j	$L571
	sw	$4,0($2)
	.set	macro
	.set	reorder

$L570:
	lbu	$2,1($3)
	#nop
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L571
	li	$2,0x00210000		# 2162688
	.set	macro
	.set	reorder

	ori	$2,$2,0x0003
	sw	$4,D_800F1180
	sw	$2,0($6)
$L571:
	jal	func_80060A68
	lw	$2,0($16)
	#nop
	sw	$2,D_800F1140
	lw	$2,4($16)
	#nop
	sw	$2,D_800F1144
	lw	$3,8($16)
	li	$2,0x00ff0000		# 16711680
	sw	$2,D_800A3464
	sw	$3,D_800F1148
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_800618B4
	.align	2
	.globl	func_800619A4
	.ent	func_800619A4
func_800619A4:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	li	$5,0x00010000		# 65536
	ori	$5,$5,0x0008
	la	$3,D_800F116C
	la	$2,D_800F1158
	sw	$31,16($sp)
	sw	$3,D_800A3468
	sw	$4,D_800F1178
	sw	$2,D_800F1180
	.set	noreorder
	.set	nomacro
	jal	func_80060A68
	sw	$5,0($3)
	.set	macro
	.set	reorder

	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_800619A4
	.align	2
	.globl	func_800619F0
	.ent	func_800619F0
func_800619F0:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	li	$5,0x00010000		# 65536
	ori	$5,$5,0x0007
	la	$3,D_800F116C
	la	$2,D_800F1154+3
	sw	$31,16($sp)
	sw	$3,D_800A3468
	sw	$4,D_800F1178
	sw	$2,D_800F1180
	.set	noreorder
	.set	nomacro
	jal	func_80060A68
	sw	$5,0($3)
	.set	macro
	.set	reorder

	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_800619F0
	.align	2
	.globl	func_80061A3C
	.ent	func_80061A3C
func_80061A3C:
	.frame	$sp,32,$31		# vars= 8, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	la	$8,D_800F116C
	addu	$2,$sp,16
	sw	$31,24($sp)
	sw	$8,D_800A3468
	sh	$0,20($sp)
	sh	$0,16($sp)
	sh	$5,18($sp)
	sw	$4,D_800F1178
	sw	$2,D_800F117C
	.set	noreorder
	.set	nomacro
	bne	$7,$0,$L576
	li	$3,0x00010000		# 65536
	.set	macro
	.set	reorder

	la	$2,D_800F1150
	sw	$2,D_800F1180
	li	$2,0x00010000		# 65536
	addu	$2,$6,$2
	.set	noreorder
	.set	nomacro
	j	$L577
	sw	$2,0($8)
	.set	macro
	.set	reorder

$L576:
	ori	$3,$3,0x0001
	la	$2,D_800F1151
	addu	$3,$6,$3
	sw	$2,D_800F1180
	sw	$3,0($8)
$L577:
	jal	func_80060A68
	lw	$31,24($sp)
	addu	$sp,$sp,32
	j	$31
	.end	func_80061A3C
	.align	2
	.globl	func_80061ACC
	.ent	func_80061ACC
func_80061ACC:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	sw	$16,16($sp)
	la	$16,D_800F1164
	sw	$31,24($sp)
	sw	$17,20($sp)
	lbu	$2,0($16)
	move	$17,$4
	la	$4,D_800F116C
	sw	$4,D_800A3468
	sw	$17,D_800F1178
	sw	$5,D_800F117C
	beq	$2,$0,$L579
	lbu	$2,1($16)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L580
	addu	$3,$16,1
	.set	macro
	.set	reorder

	sb	$0,1($16)
	sb	$0,0($16)
$L580:
	lbu	$2,0($16)
	#nop
	bne	$2,$0,$L582
$L579:
	lw	$2,D_800A3468
	li	$3,0x00210000		# 2162688
	ori	$3,$3,0x0014
	la	$16,D_800F1164
	sw	$16,20($2)
	.set	noreorder
	.set	nomacro
	jal	func_80060A68
	sw	$3,0($2)
	.set	macro
	.set	reorder

	lw	$2,D_800A3468
	li	$3,0x00010000		# 65536
	ori	$3,$3,0x0007
	addu	$16,$16,-13
	sw	$16,20($2)
	.set	noreorder
	.set	nomacro
	j	$L583
	sw	$3,0($2)
	.set	macro
	.set	reorder

$L582:
	lbu	$2,1($16)
	#nop
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L583
	li	$2,0x00210000		# 2162688
	.set	macro
	.set	reorder

	ori	$2,$2,0x0015
	sw	$3,D_800F1180
	.set	noreorder
	.set	nomacro
	jal	func_80060A68
	sw	$2,0($4)
	.set	macro
	.set	reorder

	lw	$3,D_800A3468
	li	$4,0x00010000		# 65536
	ori	$4,$4,0x0007
	addu	$2,$16,-13
	sw	$2,20($3)
	sw	$4,0($3)
$L583:
	jal	func_80060A68
	lw	$2,0($17)
	#nop
	sw	$2,D_800F1140
	lw	$2,4($17)
	#nop
	sw	$2,D_800F1144
	lw	$3,8($17)
	li	$2,0x00ff0000		# 16711680
	ori	$2,$2,0x8080
	sw	$2,D_800A3464
	sw	$3,D_800F1148
	lw	$31,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,32
	j	$31
	.end	func_80061ACC
	.align	2
	.globl	func_80061C00
	.ent	func_80061C00
func_80061C00:
	.frame	$sp,104,$31		# vars= 72, regs= 4/0, args= 16, extra= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,104
	sw	$18,96($sp)
	move	$18,$4
	move	$3,$5
	sw	$17,92($sp)
	move	$17,$6
	la	$2,D_800F116C
	sw	$2,D_800A3468
	li	$2,0x00000001		# 1
	sw	$31,100($sp)
	.set	noreorder
	.set	nomacro
	beq	$17,$2,$L586
	sw	$16,88($sp)
	.set	macro
	.set	reorder

	move	$17,$0
$L586:
	addu	$4,$sp,24
	addu	$16,$sp,48
	move	$5,$16
	li	$2,-2560			# 0xfffff600
	sh	$2,18($sp)
	li	$2,0x00000a00		# 2560
	sh	$0,16($sp)
	sh	$2,20($sp)
	sw	$0,40($sp)
	sw	$0,36($sp)
	sw	$0,32($sp)
	sh	$3,26($sp)
	sh	$0,28($sp)
	.set	noreorder
	.set	nomacro
	jal	motutil_GetWalkDir
	sh	$0,24($sp)
	.set	macro
	.set	reorder

	move	$4,$16
	sw	$0,76($sp)
	sw	$0,72($sp)
	.set	noreorder
	.set	nomacro
	jal	gte_SetRotMatrix
	sw	$0,68($sp)
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	gte_SetTransVector
	move	$4,$16
	.set	macro
	.set	reorder

	addu	$4,$sp,16
	addu	$5,$sp,32
	.set	noreorder
	.set	nomacro
	jal	func_8007F2AC
	addu	$6,$sp,80
	.set	macro
	.set	reorder

	lw	$2,32($sp)
	lw	$3,36($sp)
	lw	$4,40($sp)
	lw	$5,D_800A3468
	sh	$2,16($sp)
	addu	$2,$sp,16
	sh	$3,18($sp)
	la	$3,D_800F1164+2
	sh	$4,20($sp)
	sw	$18,12($5)
	sw	$2,16($5)
	lbu	$2,0($3)
	#nop
	beq	$2,$0,$L587
	lbu	$2,1($3)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L588
	addu	$4,$3,1
	.set	macro
	.set	reorder

	sb	$0,1($3)
	sb	$0,0($3)
$L588:
	lbu	$2,0($3)
	#nop
	bne	$2,$0,$L590
$L587:
	lw	$2,D_800A3468
	li	$4,0x00010000		# 65536
	ori	$4,$4,0x0016
	la	$3,D_800F1164+2
	sw	$3,20($2)
	sw	$4,0($2)
	sh	$17,D_800A34F0
	j	$L591
$L590:
	lbu	$2,1($3)
	#nop
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L591
	li	$2,0x00010000		# 65536
	.set	macro
	.set	reorder

	ori	$2,$2,0x0017
	sw	$4,20($5)
	sw	$2,0($5)
	sh	$17,D_800A34F2
$L591:
	jal	func_80060A68
	lw	$31,100($sp)
	lw	$18,96($sp)
	lw	$17,92($sp)
	lw	$16,88($sp)
	addu	$sp,$sp,104
	j	$31
	.end	func_80061C00
	.align	2
	.globl	func_80061D74
	.ent	func_80061D74
func_80061D74:
	.frame	$sp,104,$31		# vars= 72, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,104
	sw	$17,92($sp)
	move	$17,$4
	addu	$4,$sp,24
	sw	$16,88($sp)
	addu	$16,$sp,48
	sh	$5,26($sp)
	move	$5,$16
	la	$2,D_800F116C
	sw	$2,D_800A3468
	li	$2,-2560			# 0xfffff600
	sh	$2,18($sp)
	li	$2,0x00000a00		# 2560
	sw	$31,96($sp)
	sh	$0,16($sp)
	sh	$2,20($sp)
	sw	$0,40($sp)
	sw	$0,36($sp)
	sw	$0,32($sp)
	sh	$0,28($sp)
	.set	noreorder
	.set	nomacro
	jal	motutil_GetWalkDir
	sh	$0,24($sp)
	.set	macro
	.set	reorder

	move	$4,$16
	sw	$0,76($sp)
	sw	$0,72($sp)
	.set	noreorder
	.set	nomacro
	jal	gte_SetRotMatrix
	sw	$0,68($sp)
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	gte_SetTransVector
	move	$4,$16
	.set	macro
	.set	reorder

	addu	$4,$sp,16
	addu	$5,$sp,32
	.set	noreorder
	.set	nomacro
	jal	func_8007F2AC
	addu	$6,$sp,80
	.set	macro
	.set	reorder

	lw	$2,32($sp)
	lw	$3,36($sp)
	lw	$4,40($sp)
	lw	$5,D_800A3468
	sh	$2,16($sp)
	addu	$2,$sp,16
	sh	$3,18($sp)
	la	$3,D_800F1168
	sh	$4,20($sp)
	sw	$17,12($5)
	sw	$2,16($5)
	lbu	$2,0($3)
	#nop
	beq	$2,$0,$L594
	lbu	$2,1($3)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L595
	addu	$4,$3,1
	.set	macro
	.set	reorder

	sb	$0,1($3)
	sb	$0,0($3)
$L595:
	lbu	$2,0($3)
	#nop
	bne	$2,$0,$L597
$L594:
	lw	$2,D_800A3468
	li	$4,0x00010000		# 65536
	ori	$4,$4,0x0018
	la	$3,D_800F1168
	sw	$3,20($2)
	.set	noreorder
	.set	nomacro
	j	$L598
	sw	$4,0($2)
	.set	macro
	.set	reorder

$L597:
	lbu	$2,1($3)
	#nop
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L598
	li	$2,0x00010000		# 65536
	.set	macro
	.set	reorder

	ori	$2,$2,0x0019
	sw	$4,20($5)
	sw	$2,0($5)
$L598:
	jal	func_80060A68
	lw	$31,96($sp)
	lw	$17,92($sp)
	lw	$16,88($sp)
	addu	$sp,$sp,104
	j	$31
	.end	func_80061D74
	.align	2
	.globl	func_80061EC0
	.ent	func_80061EC0
func_80061EC0:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	la	$3,D_800F1160+2
	sw	$31,20($sp)
	sw	$16,16($sp)
	lbu	$2,0($3)
	move	$16,$4
	la	$5,D_800F116C
	sw	$5,D_800A3468
	sw	$16,D_800F1178
	beq	$2,$0,$L601
	lbu	$2,1($3)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L602
	addu	$4,$3,1
	.set	macro
	.set	reorder

	sb	$0,1($3)
	sb	$0,0($3)
$L602:
	lbu	$2,0($3)
	#nop
	bne	$2,$0,$L604
$L601:
	lw	$2,D_800A3468
	li	$4,0x00210000		# 2162688
	ori	$4,$4,0x0012
	la	$3,D_800F1160+2
	sw	$3,20($2)
	.set	noreorder
	.set	nomacro
	j	$L605
	sw	$4,0($2)
	.set	macro
	.set	reorder

$L604:
	lbu	$2,1($3)
	#nop
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L605
	li	$2,0x00210000		# 2162688
	.set	macro
	.set	reorder

	ori	$2,$2,0x0013
	sw	$4,D_800F1180
	sw	$2,0($5)
$L605:
	jal	func_80060A68
	lw	$2,0($16)
	#nop
	sw	$2,D_800F1140
	lw	$2,4($16)
	#nop
	sw	$2,D_800F1144
	lw	$3,8($16)
	li	$2,0x00ff0000		# 16711680
	ori	$2,$2,0x00ff
	sw	$2,D_800A3464
	sw	$3,D_800F1148
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80061EC0
	.align	2
	.globl	func_80061FAC
	.ent	func_80061FAC
func_80061FAC:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	lw	$3,D_800A34EC
	subu	$sp,$sp,24
	sw	$31,20($sp)
	sw	$16,16($sp)
	lhu	$2,0($4)
	#nop
	sh	$2,0($3)
	lhu	$2,2($4)
	#nop
	sh	$2,2($3)
	lhu	$2,4($4)
	move	$16,$6
	move	$5,$16
	move	$4,$3
	.set	noreorder
	.set	nomacro
	jal	motutil_GetWalkDir
	sh	$2,4($4)
	.set	macro
	.set	reorder

	move	$4,$16
	la	$5,D_8009BB74
	sw	$0,28($16)
	sw	$0,24($16)
	.set	noreorder
	.set	nomacro
	jal	func_8007E8DC
	sw	$0,20($16)
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	gte_SetRotMatrix
	move	$4,$16
	.set	macro
	.set	reorder

	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80061FAC
	.align	2
	.globl	func_80062020
	.ent	func_80062020
func_80062020:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$2,0($4)
	sw	$0,D_800A32B8
	andi	$2,$2,0x0001
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L610
	move	$5,$0
	.set	macro
	.set	reorder

	move	$3,$0
$L611:
	lw	$2,0($4)
	#nop
	sw	$2,D_800F1198($3)
	lw	$2,4($4)
	#nop
	sw	$2,D_800F119C($3)
	lw	$2,8($4)
	addu	$4,$4,12
	sw	$2,D_800F11A0($3)
	lw	$2,0($4)
	addu	$5,$5,1
	andi	$2,$2,0x0001
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L611
	addu	$3,$3,12
	.set	macro
	.set	reorder

$L610:
	sll	$3,$5,1
	addu	$3,$3,$5
	sll	$3,$3,2
	la	$2,D_800F1198
	addu	$2,$3,$2
	sw	$0,8($2)
	sw	$0,4($2)
	sw	$0,D_800F1198($3)
	j	$31
	.end	func_80062020
	.align	2
	.globl	func_800620B8
	.ent	func_800620B8
func_800620B8:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_800620B8
	.align	2
	.globl	func_8006288C
	.ent	func_8006288C
func_8006288C:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	move	$4,$0
	la	$8,D_800F0C04
	move	$5,$0
	lw	$6,D_800A347C
	lw	$7,D_800A3478
	move	$3,$0
	li	$11,0x00000001		# 1
	li	$2,0x00000001		# 1
	sw	$2,D_800F1138
$L617:
	lw	$10,D_800A3460
	sll	$9,$11,$4
	and	$2,$10,$9
	bne	$2,$0,$L618
	lw	$2,0($6)
	#nop
	sw	$2,D_800F0FB8($3)
	lw	$2,4($6)
	#nop
	sw	$2,D_800F0FBC($3)
	lw	$2,8($6)
	#nop
	sw	$2,D_800F0FC0($3)
	lhu	$2,0($7)
	#nop
	sh	$2,D_800F10A0($5)
	lhu	$2,2($7)
	#nop
	sh	$2,D_800F10A2($5)
	lhu	$3,4($7)
	or	$2,$10,$9
	sw	$2,D_800A3460
	sh	$3,D_800F10A4($5)
	.set	noreorder
	.set	nomacro
	j	$L619
	sh	$0,0($8)
	.set	macro
	.set	reorder

$L618:
	addu	$8,$8,2
	addu	$5,$5,8
	addu	$4,$4,1
	slt	$2,$4,6
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L617
	addu	$3,$3,12
	.set	macro
	.set	reorder

$L619:
	.set	noreorder
	.set	nomacro
	j	$31
	li	$2,0x00000001		# 1
	.set	macro
	.set	reorder

	.end	func_8006288C
	.align	2
	.globl	func_8006295C
	.ent	func_8006295C
func_8006295C:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_8006295C
	.align	2
	.globl	func_80062FEC
	.ent	func_80062FEC
func_80062FEC:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	li	$2,0x00000001		# 1
	sw	$2,D_800F10F0
	move	$6,$0
	li	$5,0x00000001		# 1
$L623:
	lw	$4,D_800A3448
	sll	$3,$5,$6
	and	$2,$4,$3
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L626
	or	$2,$4,$3
	.set	macro
	.set	reorder

	sw	$2,D_800A3448
	.set	noreorder
	.set	nomacro
	j	$L634
	sll	$5,$6,1
	.set	macro
	.set	reorder

$L626:
	addu	$6,$6,1
	slt	$2,$6,12
	bne	$2,$0,$L623
	sll	$5,$6,1
$L634:
	lw	$4,D_800A347C
	#nop
	lw	$3,0($4)
	addu	$2,$5,$6
	sll	$2,$2,2
	sw	$3,D_800F0E38($2)
	lw	$3,4($4)
	#nop
	sw	$3,D_800F0E3C($2)
	lw	$3,8($4)
	#nop
	sw	$3,D_800F0E40($2)
	sh	$0,D_800F0BEC($5)
	.set	noreorder
	.set	nomacro
	j	$31
	li	$2,0x00000001		# 1
	.set	macro
	.set	reorder

	.end	func_80062FEC
	.align	2
	.globl	func_80063084
	.ent	func_80063084
func_80063084:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_80063084
	.align	2
	.globl	func_80063AF0
	.ent	func_80063AF0
func_80063AF0:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	lw	$3,D_800A3468
	subu	$sp,$sp,24
	li	$2,0x00000001		# 1
	sw	$31,16($sp)
	sw	$2,D_800F10D0
	lw	$2,0($3)
	#nop
	sra	$2,$2,17
	andi	$2,$2,0x0003
	sh	$2,D_800A345C
	.set	noreorder
	.set	nomacro
	jal	func_80063BD0
	move	$4,$0
	.set	macro
	.set	reorder

	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80063AF0
	.align	2
	.globl	func_80063B34
	.ent	func_80063B34
func_80063B34:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	lw	$3,D_800A3468
	subu	$sp,$sp,24
	li	$2,0x00000001		# 1
	sw	$31,16($sp)
	sw	$2,D_800F10D4
	lw	$2,0($3)
	#nop
	sra	$2,$2,17
	andi	$2,$2,0x0003
	sh	$2,D_800A345E
	.set	noreorder
	.set	nomacro
	jal	func_80063BD0
	li	$4,0x00000001		# 1
	.set	macro
	.set	reorder

	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80063B34
	.align	2
	.globl	func_80063B78
	.ent	func_80063B78
func_80063B78:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	lw	$3,D_800A3480
	lh	$2,D_800A345C
	subu	$sp,$sp,24
	move	$4,$0
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80063E10
	sw	$2,0($3)
	.set	macro
	.set	reorder

	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80063B78
	.align	2
	.globl	func_80063BA4
	.ent	func_80063BA4
func_80063BA4:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	lw	$3,D_800A3480
	lh	$2,D_800A345E
	subu	$sp,$sp,24
	li	$4,0x00000001		# 1
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80063E10
	sw	$2,0($3)
	.set	macro
	.set	reorder

	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80063BA4
	.align	2
	.globl	func_80063BD0
	.ent	func_80063BD0
func_80063BD0:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	j	$31
	move	$2,$0
	.set	macro
	.set	reorder

	.end	func_80063BD0
	.align	2
	.globl	func_80063E10
	.ent	func_80063E10
func_80063E10:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	j	$31
	move	$2,$0
	.set	macro
	.set	reorder

	.end	func_80063E10
	.align	2
	.globl	func_800644FC
	.ent	func_800644FC
func_800644FC:
	.frame	$sp,48,$31		# vars= 8, regs= 6/0, args= 16, extra= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,48
	sw	$18,32($sp)
	move	$18,$4
	sw	$31,44($sp)
	sw	$20,40($sp)
	sw	$19,36($sp)
	sw	$17,28($sp)
	sw	$16,24($sp)
 #APP
 #NO_APP
	lw	$2,0($18)
	#nop
	.set	noreorder
	.set	nomacro
	blez	$2,$L643
	sll	$2,$6,2
	.set	macro
	.set	reorder

	la	$3,D_800A3454
	addu	$20,$2,$3
	addu	$2,$6,$2
	sll	$19,$2,4
	move	$17,$5
	move	$16,$0
$L644:
	lw	$3,0($20)
	li	$2,0x00000001		# 1
	sll	$2,$2,$16
	and	$3,$3,$2
	beq	$3,$0,$L647
	la	$4,D_800F1000
 #APP
 #NO_APP
	addu	$4,$4,$19
	sll	$2,$16,3
	addu	$4,$4,$2
	.set	noreorder
	.set	nomacro
	jal	motutil_GetWalkDir
	move	$5,$17
	.set	macro
	.set	reorder

$L647:
	lw	$2,0($18)
	addu	$16,$16,1
	slt	$2,$16,$2
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L644
	addu	$17,$17,32
	.set	macro
	.set	reorder

$L643:
	lw	$31,44($sp)
	lw	$20,40($sp)
	lw	$19,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,48
	j	$31
	.end	func_800644FC
	.align	2
	.globl	func_800645B0
	.ent	func_800645B0
func_800645B0:
	.frame	$sp,40,$31		# vars= 0, regs= 5/0, args= 16, extra= 0
	.mask	0x800f0000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	sw	$19,28($sp)
	move	$19,$0
	li	$2,0x00000001		# 1
	sw	$31,32($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	sw	$16,16($sp)
	sw	$2,D_800F10EC
$L650:
	move	$4,$0
	addu	$16,$19,$4
$L665:
	lw	$2,D_800A3444
	li	$3,0x00000001		# 1
	sll	$18,$3,$16
	and	$2,$2,$18
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L654
	addu	$4,$4,1
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_80079154
	sll	$17,$16,1
	.set	macro
	.set	reorder

	lw	$3,D_800A347C
	#nop
	lw	$3,0($3)
	addu	$16,$17,$16
	sll	$16,$16,2
	andi	$2,$2,0x00ff
	addu	$3,$3,$2
	addu	$3,$3,-127
	sw	$3,D_800F0D78($16)
	.set	noreorder
	.set	nomacro
	jal	func_80079154
	addu	$19,$19,4
	.set	macro
	.set	reorder

	lw	$3,D_800A347C
	#nop
	lw	$3,4($3)
	andi	$2,$2,0x00ff
	addu	$3,$3,$2
	addu	$3,$3,-127
	sw	$3,D_800F0D7C($16)
	jal	func_80079154
	lw	$3,D_800A347C
	#nop
	lw	$3,8($3)
	andi	$2,$2,0x00ff
	addu	$3,$3,$2
	addu	$3,$3,-127
	sw	$3,videoDec($16)
	jal	func_80079154
	lw	$3,D_800A3444
	andi	$2,$2,0x0007
	sh	$2,D_800F0BCC($17)
	or	$3,$3,$18
	sw	$3,D_800A3444
	.set	noreorder
	.set	nomacro
	j	$L664
	slt	$2,$19,15
	.set	macro
	.set	reorder

$L654:
	slt	$2,$4,4
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L665
	addu	$16,$19,$4
	.set	macro
	.set	reorder

	addu	$19,$19,4
	slt	$2,$19,15
$L664:
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L650
	li	$2,0x00000001		# 1
	.set	macro
	.set	reorder

	lw	$31,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,40
	j	$31
	.end	func_800645B0
	.align	2
	.globl	func_800646E8
	.ent	func_800646E8
func_800646E8:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_800646E8
	.align	2
	.globl	func_80064E90
	.ent	func_80064E90
func_80064E90:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$3,D_800A347C
	#nop
	lw	$2,0($3)
	#nop
	sw	$2,D_800F0CA0
	lw	$2,4($3)
	#nop
	sw	$2,D_800F0CA4
	lw	$3,8($3)
	li	$2,0x00000001		# 1
	sw	$2,D_800F10E0
	sh	$0,D_800F0BA8
	sw	$3,D_800F0CA8
	j	$31
	.end	func_80064E90
	.align	2
	.globl	func_80064ED8
	.ent	func_80064ED8
func_80064ED8:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$3,D_800A347C
	#nop
	lw	$2,0($3)
	#nop
	sw	$2,D_800F0CAC
	lw	$2,4($3)
	#nop
	sw	$2,D_800F0CB0
	lw	$3,8($3)
	li	$2,0x00000001		# 1
	sw	$2,D_800F10E4
	sh	$0,D_800F0BAA
	sw	$3,D_800F0CB4
	j	$31
	.end	func_80064ED8
	.align	2
	.globl	func_80064F20
	.ent	func_80064F20
func_80064F20:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$3,D_800A347C
	#nop
	lw	$2,0($3)
	#nop
	sw	$2,D_800F0CB8
	lw	$2,4($3)
	#nop
	sw	$2,D_800F0CBC
	lw	$3,8($3)
	li	$2,0x00000001		# 1
	sw	$2,D_800F10E8
	sh	$0,D_800F0BAC
	sw	$3,D_800F0CC0
	j	$31
	.end	func_80064F20
	.align	2
	.globl	func_80064F68
	.ent	func_80064F68
func_80064F68:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$3,D_800A347C
	#nop
	lw	$2,0($3)
	#nop
	sw	$2,D_800F0CC4
	lw	$2,4($3)
	#nop
	sw	$2,D_800F0CC8
	lw	$3,8($3)
	li	$2,0x00000001		# 1
	sw	$2,D_800F10F4
	li	$2,0x00000040		# 64
	sh	$2,D_800F0BAE
	sw	$3,D_800F0CCC
	.set	noreorder
	.set	nomacro
	j	$31
	li	$2,0x00000001		# 1
	.set	macro
	.set	reorder

	.end	func_80064F68
	.align	2
	.globl	func_80064FB4
	.ent	func_80064FB4
func_80064FB4:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$3,D_800A347C
	#nop
	lw	$2,0($3)
	#nop
	sw	$2,D_800F0CD0
	lw	$2,4($3)
	#nop
	sw	$2,D_800F0CD4
	lw	$3,8($3)
	li	$2,0x00000001		# 1
	sw	$2,D_800F10F8
	li	$2,0x00000040		# 64
	sh	$2,D_800F0BB0
	sw	$3,D_800F0CD8
	.set	noreorder
	.set	nomacro
	j	$31
	li	$2,0x00000001		# 1
	.set	macro
	.set	reorder

	.end	func_80064FB4
	.align	2
	.globl	func_80065000
	.ent	func_80065000
func_80065000:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$3,D_800A347C
	lw	$4,D_800A3468
	lw	$2,0($3)
	#nop
	sw	$2,D_800F0CDC
	lw	$2,4($3)
	#nop
	sw	$2,D_800F0CE0
	lw	$3,8($3)
	li	$2,0x00000001		# 1
	sw	$2,D_800F10FC
	sh	$0,D_800F0BB2
	sw	$3,D_800F0CE4
	lw	$2,0($4)
	#nop
	sra	$2,$2,19
	andi	$2,$2,0x0003
	sh	$2,D_800A3440
	.set	noreorder
	.set	nomacro
	j	$31
	li	$2,0x00000001		# 1
	.set	macro
	.set	reorder

	.end	func_80065000
	.align	2
	.globl	func_8006505C
	.ent	func_8006505C
func_8006505C:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$3,D_800A347C
	#nop
	lw	$2,0($3)
	#nop
	sw	$2,D_800F0CE8
	lw	$2,4($3)
	#nop
	sw	$2,D_800F0CEC
	lw	$3,8($3)
	li	$2,0x00000001		# 1
	sw	$2,D_800F1100
	sh	$0,D_800F0BB4
	sw	$3,D_800F0CF0
	j	$31
	.end	func_8006505C
	.align	2
	.globl	func_800650A4
	.ent	func_800650A4
func_800650A4:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$3,D_800A347C
	#nop
	lw	$2,0($3)
	#nop
	sw	$2,D_800F0CF4
	lw	$2,4($3)
	#nop
	sw	$2,D_800F0CF8
	lw	$3,8($3)
	li	$2,0x00000001		# 1
	sw	$2,D_800F1104
	sh	$0,D_800F0BB6
	sw	$3,D_800F0CFC
	j	$31
	.end	func_800650A4
	.align	2
	.globl	func_800650EC
	.ent	func_800650EC
func_800650EC:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$3,D_800A347C
	#nop
	lw	$2,0($3)
	#nop
	sw	$2,D_800F0D18
	lw	$2,4($3)
	#nop
	sw	$2,D_800F0D1C
	lw	$3,8($3)
	li	$2,0x00000001		# 1
	sw	$2,D_800F1108
	sh	$0,D_800F0BBC
	sw	$3,D_800F0D20
	j	$31
	.end	func_800650EC
	.align	2
	.globl	func_80065134
	.ent	func_80065134
func_80065134:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$3,D_800A347C
	#nop
	lw	$2,0($3)
	#nop
	sw	$2,D_800F0D24
	lw	$2,4($3)
	#nop
	sw	$2,D_800F0D28
	lw	$3,8($3)
	li	$2,0x00000001		# 1
	sw	$2,D_800F110C
	sh	$0,D_800F0BBE
	sw	$3,D_800F0D2C
	j	$31
	.end	func_80065134
	.align	2
	.globl	func_8006517C
	.ent	func_8006517C
func_8006517C:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$3,D_800A347C
	#nop
	lw	$2,0($3)
	#nop
	sw	$2,D_800F0D30
	lw	$2,4($3)
	#nop
	sw	$2,D_800F0D34
	lw	$2,8($3)
	sh	$0,D_800F0BC0
	sw	$2,D_800F0D38
	lw	$2,0($3)
	#nop
	sw	$2,D_800F0D48
	lw	$2,4($3)
	#nop
	sw	$2,D_800F0D4C
	lw	$3,8($3)
	li	$2,0x00000001		# 1
	sw	$2,D_800F1110
	sh	$0,D_800F0BC4
	sw	$3,D_800F0D50
	j	$31
	.end	func_8006517C
	.align	2
	.globl	func_800651F0
	.ent	func_800651F0
func_800651F0:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$3,D_800A347C
	#nop
	#.set	volatile
	lw	$2,0($3)
	#.set	novolatile
	#nop
	sw	$2,D_800F0D3C
	#.set	volatile
	lw	$2,4($3)
	#.set	novolatile
	#nop
	sw	$2,D_800F0D40
	#.set	volatile
	lw	$2,8($3)
	#.set	novolatile
	sh	$0,D_800F0BC2
	sw	$2,D_800F0D44
	#.set	volatile
	lw	$2,0($3)
	#.set	novolatile
	#nop
	sw	$2,D_800F0D54
	#.set	volatile
	lw	$2,4($3)
	#.set	novolatile
	#.set	volatile
	lw	$3,8($3)
	#.set	novolatile
	li	$4,0x00000001		# 1
	sw	$4,D_800F1114
	sh	$0,D_800F0BC6
	sw	$2,D_800F0D58
	sw	$3,D_800F0D5C
	j	$31
	.end	func_800651F0
	.align	2
	.globl	func_80065264
	.ent	func_80065264
func_80065264:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$3,D_800A347C
	#nop
	lw	$2,0($3)
	#nop
	sw	$2,D_800F0D60
	lw	$2,4($3)
	#nop
	sw	$2,D_800F0D64
	lw	$3,8($3)
	li	$2,0x00000001		# 1
	sw	$2,D_800F1118
	sh	$0,D_800F0BC8
	sw	$3,D_800F0D68
	j	$31
	.end	func_80065264
	.align	2
	.globl	func_800652AC
	.ent	func_800652AC
func_800652AC:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$3,D_800A347C
	#nop
	lw	$2,0($3)
	#nop
	sw	$2,D_800F0D6C
	lw	$2,4($3)
	#nop
	sw	$2,D_800F0D70
	lw	$3,8($3)
	li	$2,0x00000001		# 1
	sw	$2,D_800F111C
	sh	$0,D_800F0BCA
	sw	$3,D_800F0D74
	j	$31
	.end	func_800652AC
	.align	2
	.globl	func_800652F4
	.ent	func_800652F4
func_800652F4:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	motion_SetExMotion
	move	$4,$0
	.set	macro
	.set	reorder

	la	$4,D_800F0BA8
	lhu	$3,0($4)
	#nop
	addu	$3,$3,511
	sh	$3,0($4)
	sll	$3,$3,16
	sra	$3,$3,16
	slt	$3,$3,4097
	.set	noreorder
	.set	nomacro
	bne	$3,$0,$L682
	andi	$2,$2,0x00ff
	.set	macro
	.set	reorder

	move	$2,$0
$L682:
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_800652F4
	.align	2
	.globl	func_80065344
	.ent	func_80065344
func_80065344:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	motion_SetExMotion
	li	$4,0x00000001		# 1
	.set	macro
	.set	reorder

	la	$4,D_800F0BAA
	lhu	$3,0($4)
	#nop
	addu	$3,$3,454
	sh	$3,0($4)
	sll	$3,$3,16
	sra	$3,$3,16
	slt	$3,$3,4552
	.set	noreorder
	.set	nomacro
	bne	$3,$0,$L685
	andi	$2,$2,0x00ff
	.set	macro
	.set	reorder

	move	$2,$0
$L685:
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80065344
	.align	2
	.globl	func_80065394
	.ent	func_80065394
func_80065394:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	motion_SetExMotion
	li	$4,0x00000002		# 2
	.set	macro
	.set	reorder

	la	$4,D_800F0BAC
	lhu	$3,0($4)
	#nop
	addu	$3,$3,454
	sh	$3,0($4)
	sll	$3,$3,16
	sra	$3,$3,16
	slt	$3,$3,4552
	.set	noreorder
	.set	nomacro
	bne	$3,$0,$L688
	andi	$2,$2,0x00ff
	.set	macro
	.set	reorder

	move	$2,$0
$L688:
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80065394
	.align	2
	.globl	func_800653E4
	.ent	func_800653E4
func_800653E4:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	motion_SetExMotion
	li	$4,0x00000003		# 3
	.set	macro
	.set	reorder

	la	$4,D_800F0BAE
	lhu	$3,0($4)
	#nop
	addu	$3,$3,25
	sh	$3,0($4)
	sll	$3,$3,16
	sra	$3,$3,16
	slt	$3,$3,201
	.set	noreorder
	.set	nomacro
	bne	$3,$0,$L691
	andi	$2,$2,0x00ff
	.set	macro
	.set	reorder

	move	$2,$0
$L691:
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_800653E4
	.align	2
	.globl	func_80065434
	.ent	func_80065434
func_80065434:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	motion_SetExMotion
	li	$4,0x00000004		# 4
	.set	macro
	.set	reorder

	la	$4,D_800F0BB0
	lhu	$3,0($4)
	#nop
	addu	$3,$3,25
	sh	$3,0($4)
	sll	$3,$3,16
	sra	$3,$3,16
	slt	$3,$3,201
	.set	noreorder
	.set	nomacro
	bne	$3,$0,$L694
	andi	$2,$2,0x00ff
	.set	macro
	.set	reorder

	move	$2,$0
$L694:
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80065434
	.align	2
	.globl	func_80065484
	.ent	func_80065484
func_80065484:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	lw	$3,D_800A3484
	lh	$2,D_800A3440
	subu	$sp,$sp,24
	li	$4,0x00000005		# 5
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	motion_SetExMotion
	sw	$2,0($3)
	.set	macro
	.set	reorder

	lw	$3,D_800A3484
	#nop
	lw	$3,0($3)
	move	$4,$2
	li	$2,0x00000001		# 1
	beq	$3,$2,$L699
	beq	$3,$0,$L698
	li	$2,0x00000002		# 2
	beq	$3,$2,$L700
	j	$L697
$L698:
	la	$3,D_800F0BB2
	lhu	$2,0($3)
	.set	noreorder
	.set	nomacro
	j	$L705
	addu	$2,$2,511
	.set	macro
	.set	reorder

$L699:
	la	$3,D_800F0BB2
	lhu	$2,0($3)
	.set	noreorder
	.set	nomacro
	j	$L705
	addu	$2,$2,1022
	.set	macro
	.set	reorder

$L700:
	la	$3,D_800F0BB2
	lhu	$2,0($3)
	#nop
	addu	$2,$2,1533
$L705:
	sh	$2,0($3)
$L697:
	lh	$2,D_800F0BB2
	#nop
	slt	$2,$2,8193
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L703
	andi	$2,$4,0x00ff
	.set	macro
	.set	reorder

	move	$2,$0
$L703:
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80065484
	.align	2
	.globl	func_80065540
	.ent	func_80065540
func_80065540:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	motion_SetExMotion
	li	$4,0x00000006		# 6
	.set	macro
	.set	reorder

	la	$4,D_800F0BB4
	lhu	$3,0($4)
	#nop
	addu	$3,$3,50
	sh	$3,0($4)
	sll	$3,$3,16
	sra	$3,$3,16
	slt	$3,$3,256
	.set	noreorder
	.set	nomacro
	bne	$3,$0,$L707
	andi	$2,$2,0x00ff
	.set	macro
	.set	reorder

	move	$2,$0
$L707:
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80065540
	.align	2
	.globl	func_80065590
	.ent	func_80065590
func_80065590:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	motion_SetExMotion
	li	$4,0x00000007		# 7
	.set	macro
	.set	reorder

	la	$4,D_800F0BB6
	lhu	$3,0($4)
	#nop
	addu	$3,$3,50
	sh	$3,0($4)
	sll	$3,$3,16
	sra	$3,$3,16
	slt	$3,$3,256
	.set	noreorder
	.set	nomacro
	bne	$3,$0,$L710
	andi	$2,$2,0x00ff
	.set	macro
	.set	reorder

	move	$2,$0
$L710:
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80065590
	.align	2
	.globl	func_800655E0
	.ent	func_800655E0
func_800655E0:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	motion_SetExMotion
	li	$4,0x0000000a		# 10
	.set	macro
	.set	reorder

	la	$4,D_800F0BBC
	lhu	$3,0($4)
	#nop
	addu	$3,$3,50
	sh	$3,0($4)
	sll	$3,$3,16
	sra	$3,$3,16
	slt	$3,$3,256
	.set	noreorder
	.set	nomacro
	bne	$3,$0,$L713
	andi	$2,$2,0x00ff
	.set	macro
	.set	reorder

	move	$2,$0
$L713:
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_800655E0
	.align	2
	.globl	func_80065630
	.ent	func_80065630
func_80065630:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	motion_SetExMotion
	li	$4,0x0000000b		# 11
	.set	macro
	.set	reorder

	la	$4,D_800F0BBE
	lhu	$3,0($4)
	#nop
	addu	$3,$3,50
	sh	$3,0($4)
	sll	$3,$3,16
	sra	$3,$3,16
	slt	$3,$3,256
	.set	noreorder
	.set	nomacro
	bne	$3,$0,$L716
	andi	$2,$2,0x00ff
	.set	macro
	.set	reorder

	move	$2,$0
$L716:
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80065630
	.align	2
	.globl	func_80065680
	.ent	func_80065680
func_80065680:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	motion_SetExMotion
	li	$4,0x0000000c		# 12
	.set	macro
	.set	reorder

	la	$3,D_800F0BC0
	lhu	$2,0($3)
	li	$4,0x0000000e		# 14
	addu	$2,$2,1
	.set	noreorder
	.set	nomacro
	jal	motion_SetExMotion
	sh	$2,0($3)
	.set	macro
	.set	reorder

	lhu	$3,D_800F0BC4
	#nop
	addu	$3,$3,1
	sh	$3,D_800F0BC4
	sll	$3,$3,16
	sra	$3,$3,16
	slt	$3,$3,11
	.set	noreorder
	.set	nomacro
	bne	$3,$0,$L719
	andi	$2,$2,0x00ff
	.set	macro
	.set	reorder

	move	$2,$0
$L719:
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80065680
	.align	2
	.globl	func_800656EC
	.ent	func_800656EC
func_800656EC:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	li	$4,0x0000000d		# 13
	sw	$31,20($sp)
	.set	noreorder
	.set	nomacro
	jal	motion_SetExMotion
	sw	$16,16($sp)
	.set	macro
	.set	reorder

	la	$16,D_800F0BC2
	lhu	$2,0($16)
	li	$4,0x0000000f		# 15
	addu	$2,$2,1
	.set	noreorder
	.set	nomacro
	jal	motion_SetExMotion
	sh	$2,0($16)
	.set	macro
	.set	reorder

	lhu	$3,D_800F0BC6
	lh	$4,0($16)
	addu	$3,$3,1
	slt	$4,$4,11
	sh	$3,D_800F0BC6
	.set	noreorder
	.set	nomacro
	bne	$4,$0,$L722
	andi	$2,$2,0x00ff
	.set	macro
	.set	reorder

	move	$2,$0
$L722:
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_800656EC
	.align	2
	.globl	func_80065760
	.ent	func_80065760
func_80065760:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	motion_SetExMotion
	li	$4,0x00000010		# 16
	.set	macro
	.set	reorder

	la	$4,D_800F0BC8
	lhu	$3,0($4)
	#nop
	addu	$3,$3,454
	sh	$3,0($4)
	sll	$3,$3,16
	sra	$3,$3,16
	slt	$3,$3,4552
	.set	noreorder
	.set	nomacro
	bne	$3,$0,$L725
	andi	$2,$2,0x00ff
	.set	macro
	.set	reorder

	move	$2,$0
$L725:
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80065760
	.align	2
	.globl	func_800657B0
	.ent	func_800657B0
func_800657B0:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	motion_SetExMotion
	li	$4,0x00000011		# 17
	.set	macro
	.set	reorder

	la	$4,D_800F0BCA
	lhu	$3,0($4)
	#nop
	addu	$3,$3,454
	sh	$3,0($4)
	sll	$3,$3,16
	sra	$3,$3,16
	slt	$3,$3,4552
	.set	noreorder
	.set	nomacro
	bne	$3,$0,$L728
	andi	$2,$2,0x00ff
	.set	macro
	.set	reorder

	move	$2,$0
$L728:
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_800657B0
	.align	2
	.globl	motion_SetExMotion
	.ent	motion_SetExMotion
motion_SetExMotion:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	j	$31
	move	$2,$0
	.set	macro
	.set	reorder

	.end	motion_SetExMotion
	.align	2
	.globl	func_80066EC0
	.ent	func_80066EC0
func_80066EC0:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	move	$4,$0
	move	$5,$0
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80067200
	move	$6,$0
	.set	macro
	.set	reorder

	li	$3,0x00000001		# 1
	sw	$3,D_800F10D8
	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80066EC0
	.align	2
	.globl	func_80066EF4
	.ent	func_80066EF4
func_80066EF4:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	move	$4,$0
	move	$5,$0
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80067200
	li	$6,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$3,0x00000002		# 2
	sw	$3,D_800F10D8
	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80066EF4
	.align	2
	.globl	func_80066F28
	.ent	func_80066F28
func_80066F28:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	li	$4,0x00000001		# 1
	li	$5,0x00000001		# 1
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80067200
	move	$6,$0
	.set	macro
	.set	reorder

	li	$3,0x00000001		# 1
	sw	$3,D_800F10DC
	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80066F28
	.align	2
	.globl	func_80066F5C
	.ent	func_80066F5C
func_80066F5C:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	li	$4,0x00000001		# 1
	li	$5,0x00000001		# 1
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80067200
	li	$6,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$3,0x00000002		# 2
	sw	$3,D_800F10DC
	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80066F5C
	.align	2
	.globl	func_80066F90
	.ent	func_80066F90
func_80066F90:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	li	$4,0x00000002		# 2
	li	$5,0x00000001		# 1
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80067200
	move	$6,$0
	.set	macro
	.set	reorder

	li	$3,0x00000001		# 1
	sw	$3,D_800F1120
	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80066F90
	.align	2
	.globl	func_80066FC4
	.ent	func_80066FC4
func_80066FC4:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	li	$4,0x00000002		# 2
	li	$5,0x00000001		# 1
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80067200
	li	$6,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$3,0x00000002		# 2
	sw	$3,D_800F1120
	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80066FC4
	.align	2
	.globl	func_80066FF8
	.ent	func_80066FF8
func_80066FF8:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	li	$4,0x00000003		# 3
	move	$5,$0
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80067200
	move	$6,$0
	.set	macro
	.set	reorder

	li	$3,0x00000001		# 1
	sw	$3,D_800F1124
	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80066FF8
	.align	2
	.globl	func_8006702C
	.ent	func_8006702C
func_8006702C:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	li	$4,0x00000003		# 3
	move	$5,$0
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80067200
	li	$6,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$3,0x00000002		# 2
	sw	$3,D_800F1124
	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_8006702C
	.align	2
	.globl	func_80067060
	.ent	func_80067060
func_80067060:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	li	$4,0x00000004		# 4
	li	$5,0x00000002		# 2
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80067200
	move	$6,$0
	.set	macro
	.set	reorder

	li	$3,0x00000001		# 1
	sw	$3,D_800F1128
	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80067060
	.align	2
	.globl	func_80067094
	.ent	func_80067094
func_80067094:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	li	$4,0x00000004		# 4
	li	$5,0x00000002		# 2
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80067200
	li	$6,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$3,0x00000002		# 2
	sw	$3,D_800F1128
	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80067094
	.align	2
	.globl	func_800670C8
	.ent	func_800670C8
func_800670C8:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	li	$4,0x00000005		# 5
	li	$5,0x00000003		# 3
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80067200
	move	$6,$0
	.set	macro
	.set	reorder

	li	$3,0x00000001		# 1
	sw	$3,D_800F112C
	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_800670C8
	.align	2
	.globl	func_800670FC
	.ent	func_800670FC
func_800670FC:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	li	$4,0x00000005		# 5
	li	$5,0x00000003		# 3
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80067200
	li	$6,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$3,0x00000002		# 2
	sw	$3,D_800F112C
	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_800670FC
	.align	2
	.globl	func_80067130
	.ent	func_80067130
func_80067130:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	li	$4,0x00000006		# 6
	li	$5,0x00000003		# 3
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80067200
	move	$6,$0
	.set	macro
	.set	reorder

	li	$3,0x00000001		# 1
	sw	$3,D_800F1130
	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80067130
	.align	2
	.globl	func_80067164
	.ent	func_80067164
func_80067164:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	li	$4,0x00000006		# 6
	li	$5,0x00000003		# 3
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80067200
	li	$6,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$3,0x00000002		# 2
	sw	$3,D_800F1130
	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80067164
	.align	2
	.globl	func_80067198
	.ent	func_80067198
func_80067198:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	li	$4,0x00000007		# 7
	li	$5,0x00000002		# 2
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80067200
	move	$6,$0
	.set	macro
	.set	reorder

	li	$3,0x00000001		# 1
	sw	$3,D_800F1134
	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80067198
	.align	2
	.globl	func_800671CC
	.ent	func_800671CC
func_800671CC:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	li	$4,0x00000007		# 7
	li	$5,0x00000002		# 2
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80067200
	li	$6,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$3,0x00000002		# 2
	sw	$3,D_800F1134
	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_800671CC
	.align	2
	.globl	func_80067200
	.ent	func_80067200
func_80067200:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	j	$31
	move	$2,$0
	.set	macro
	.set	reorder

	.end	func_80067200
	.align	2
	.globl	func_800676C8
	.ent	func_800676C8
func_800676C8:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	move	$4,$0
	.set	noreorder
	.set	nomacro
	jal	func_800678A8
	move	$5,$0
	.set	macro
	.set	reorder

	move	$4,$0
	.set	noreorder
	.set	nomacro
	jal	func_80067D14
	move	$5,$0
	.set	macro
	.set	reorder

	move	$4,$0
	.set	noreorder
	.set	nomacro
	jal	func_80068D88
	move	$5,$0
	.set	macro
	.set	reorder

	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_800676C8
	.align	2
	.globl	func_80067704
	.ent	func_80067704
func_80067704:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	li	$4,0x00000001		# 1
	.set	noreorder
	.set	nomacro
	jal	func_800678A8
	li	$5,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$4,0x00000001		# 1
	.set	noreorder
	.set	nomacro
	jal	func_80067D14
	li	$5,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$4,0x00000001		# 1
	.set	noreorder
	.set	nomacro
	jal	func_80068D88
	li	$5,0x00000001		# 1
	.set	macro
	.set	reorder

	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80067704
	.align	2
	.globl	func_80067740
	.ent	func_80067740
func_80067740:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	li	$4,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	jal	func_800678A8
	li	$5,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$4,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	jal	func_80067D14
	li	$5,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$4,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	jal	func_80068D88
	li	$5,0x00000001		# 1
	.set	macro
	.set	reorder

	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80067740
	.align	2
	.globl	func_8006777C
	.ent	func_8006777C
func_8006777C:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	li	$4,0x00000003		# 3
	.set	noreorder
	.set	nomacro
	jal	func_800678A8
	move	$5,$0
	.set	macro
	.set	reorder

	li	$4,0x00000003		# 3
	.set	noreorder
	.set	nomacro
	jal	func_80067D14
	move	$5,$0
	.set	macro
	.set	reorder

	li	$4,0x00000003		# 3
	.set	noreorder
	.set	nomacro
	jal	func_80068D88
	move	$5,$0
	.set	macro
	.set	reorder

	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_8006777C
	.align	2
	.globl	func_800677B8
	.ent	func_800677B8
func_800677B8:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	li	$4,0x00000004		# 4
	.set	noreorder
	.set	nomacro
	jal	func_800678A8
	li	$5,0x00000002		# 2
	.set	macro
	.set	reorder

	li	$4,0x00000004		# 4
	.set	noreorder
	.set	nomacro
	jal	func_80067D14
	li	$5,0x00000002		# 2
	.set	macro
	.set	reorder

	li	$4,0x00000004		# 4
	.set	noreorder
	.set	nomacro
	jal	func_80068D88
	li	$5,0x00000002		# 2
	.set	macro
	.set	reorder

	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_800677B8
	.align	2
	.globl	func_800677F4
	.ent	func_800677F4
func_800677F4:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	li	$4,0x00000005		# 5
	.set	noreorder
	.set	nomacro
	jal	func_800678A8
	li	$5,0x00000003		# 3
	.set	macro
	.set	reorder

	li	$4,0x00000005		# 5
	.set	noreorder
	.set	nomacro
	jal	func_80067D14
	li	$5,0x00000003		# 3
	.set	macro
	.set	reorder

	li	$4,0x00000005		# 5
	.set	noreorder
	.set	nomacro
	jal	func_80068D88
	li	$5,0x00000003		# 3
	.set	macro
	.set	reorder

	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_800677F4
	.align	2
	.globl	func_80067830
	.ent	func_80067830
func_80067830:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	li	$4,0x00000006		# 6
	.set	noreorder
	.set	nomacro
	jal	func_800678A8
	li	$5,0x00000003		# 3
	.set	macro
	.set	reorder

	li	$4,0x00000006		# 6
	.set	noreorder
	.set	nomacro
	jal	func_80067D14
	li	$5,0x00000003		# 3
	.set	macro
	.set	reorder

	li	$4,0x00000006		# 6
	.set	noreorder
	.set	nomacro
	jal	func_80068D88
	li	$5,0x00000003		# 3
	.set	macro
	.set	reorder

	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80067830
	.align	2
	.globl	func_8006786C
	.ent	func_8006786C
func_8006786C:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	li	$4,0x00000007		# 7
	.set	noreorder
	.set	nomacro
	jal	func_800678A8
	li	$5,0x00000002		# 2
	.set	macro
	.set	reorder

	li	$4,0x00000007		# 7
	.set	noreorder
	.set	nomacro
	jal	func_80067D14
	li	$5,0x00000002		# 2
	.set	macro
	.set	reorder

	li	$4,0x00000007		# 7
	.set	noreorder
	.set	nomacro
	jal	func_80068D88
	li	$5,0x00000002		# 2
	.set	macro
	.set	reorder

	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_8006786C
	.align	2
	.globl	func_800678A8
	.ent	func_800678A8
func_800678A8:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	j	$31
	move	$2,$0
	.set	macro
	.set	reorder

	.end	func_800678A8
	.align	2
	.globl	func_80067D14
	.ent	func_80067D14
func_80067D14:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	j	$31
	move	$2,$0
	.set	macro
	.set	reorder

	.end	func_80067D14
	.align	2
	.globl	func_80068D88
	.ent	func_80068D88
func_80068D88:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$4,D_800A34EC
	lw	$7,D_800A37D4
	addu	$2,$4,428
	sw	$2,D_800A3724
	lw	$5,128($4)
	addu	$8,$4,110
	addu	$10,$4,124
	addu	$6,$4,128
	subu	$3,$5,$7
	sll	$2,$3,1
	addu	$2,$2,$3
	sll	$3,$2,4
	addu	$2,$2,$3
	sll	$3,$2,8
	addu	$2,$2,$3
	sll	$3,$2,16
	addu	$2,$2,$3
	subu	$2,$0,$2
	sra	$2,$2,3
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L759
	addu	$12,$4,140
	.set	macro
	.set	reorder

	sw	$7,128($4)
 #APP
 #NO_APP
	lw	$2,128($4)
	sw	$5,124($4)
 #APP
 #NO_APP
	lw	$3,124($4)
	li	$11,0x00000001		# 1
	sltu	$2,$2,$3
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L760
	sh	$0,110($4)
	.set	macro
	.set	reorder

	li	$9,-16777216			# 0xff000000
	li	$7,0x00ff0000		# 16711680
	ori	$7,$7,0xffff
$L761:
	lh	$2,0($8)
	#nop
	sll	$2,$2,1
	addu	$2,$2,$12
	lhu	$2,0($2)
	lw	$4,D_800A374C
	sll	$2,$2,2
	addu	$4,$4,$2
	sw	$4,D_800A34E4
	lw	$5,0($6)
	#nop
	sw	$5,D_800A34E8
	lw	$3,0($5)
	lw	$2,0($4)
	and	$3,$3,$9
	and	$2,$2,$7
	or	$3,$3,$2
	sw	$3,0($5)
	lw	$4,D_800A34E4
	lw	$3,D_800A34E8
	lw	$2,0($4)
	and	$3,$3,$7
	and	$2,$2,$9
	or	$3,$3,$2
	sw	$3,0($4)
	lw	$2,0($6)
	#nop
	addu	$2,$2,40
	sw	$2,0($6)
	lhu	$2,0($8)
	#nop
	addu	$2,$2,1
	sh	$2,0($8)
	lw	$2,0($6)
	lw	$3,0($10)
	#nop
	sltu	$2,$2,$3
	bne	$2,$0,$L761
$L760:
	lw	$2,0($10)
	#nop
	sw	$2,D_800A37D4
	j	$L765
$L759:
	move	$11,$0
$L765:
	.set	noreorder
	.set	nomacro
	j	$31
	move	$2,$11
	.set	macro
	.set	reorder

	.end	func_80068D88
	.align	2
	.globl	func_80068ECC
	.ent	func_80068ECC
func_80068ECC:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	la	$5,D_8009BC04
	lw	$2,0($5)
	li	$3,-2			# 0xfffffffe
	and	$2,$2,$3
	andi	$3,$4,0x0001
	or	$2,$2,$3
	li	$3,-3			# 0xfffffffd
	and	$2,$2,$3
	andi	$3,$4,0x0002
	or	$2,$2,$3
	li	$3,-5			# 0xfffffffb
	and	$2,$2,$3
	andi	$3,$4,0x0004
	or	$2,$2,$3
 #APP
 #NO_APP
	li	$3,-9			# 0xfffffff7
	and	$2,$2,$3
	srl	$3,$4,1
	andi	$3,$3,0x0008
	or	$2,$2,$3
 #APP
 #NO_APP
	li	$3,-17			# 0xffffffef
	and	$2,$2,$3
	srl	$3,$4,1
	andi	$3,$3,0x0010
	or	$2,$2,$3
 #APP
 #NO_APP
	li	$3,-33			# 0xffffffdf
	and	$2,$2,$3
	srl	$3,$4,1
	andi	$3,$3,0x0020
	or	$2,$2,$3
	li	$3,-65			# 0xffffffbf
	and	$2,$2,$3
	sll	$3,$4,3
	andi	$3,$3,0x0040
	or	$2,$2,$3
	li	$3,-129			# 0xffffff7f
	and	$2,$2,$3
	andi	$4,$4,0x0080
	or	$2,$2,$4
	.set	noreorder
	.set	nomacro
	j	$31
	sw	$2,0($5)
	.set	macro
	.set	reorder

	.end	func_80068ECC
	.align	2
	.globl	func_80068F70
	.ent	func_80068F70
func_80068F70:
	.frame	$sp,40,$31		# vars= 8, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	sw	$16,24($sp)
	move	$16,$4
	sw	$17,28($sp)
	sw	$16,D_800A3500
	sw	$16,D_800A351C
	addu	$16,$16,88
	sw	$31,32($sp)
	sw	$16,D_800A3500
	.set	noreorder
	.set	nomacro
	jal	snd_StopAll
	move	$17,$5
	.set	macro
	.set	reorder

	lw	$5,D_800A3500
	.set	noreorder
	.set	nomacro
	jal	func_8006E950
	li	$4,0x00000002		# 2
	.set	macro
	.set	reorder

	lw	$4,D_800A3500
	#nop
	sw	$4,D_800A372C
	jal	efc_rob_Close
	lw	$5,D_800A351C
	move	$4,$2
	sw	$4,D_800A3500
	jal	func_8006E49C
	lw	$5,D_800A34F8
	lw	$3,D_8009BC04
	sw	$16,36($2)
	sw	$2,D_800A3500
	sw	$2,D_800A34FC
	addu	$2,$2,52
	sw	$2,D_800A3500
	li	$2,-16			# 0xfffffff0
	and	$5,$5,$2
	andi	$2,$3,0x0001
	sw	$5,D_800A34F8
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L782
	li	$2,0x00000005		# 5
	.set	macro
	.set	reorder

	li	$4,-16			# 0xfffffff0
	move	$6,$3
$L769:
	lw	$5,D_800A34F8
	#nop
	andi	$3,$5,0x000f
	slt	$2,$3,7
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L772
	addu	$2,$3,1
	.set	macro
	.set	reorder

	and	$2,$5,$4
	sw	$2,D_800A34F8
	.set	noreorder
	.set	nomacro
	j	$L782
	li	$2,0x00000005		# 5
	.set	macro
	.set	reorder

$L772:
	and	$3,$5,$4
	andi	$2,$2,0x000f
	or	$5,$3,$2
	sw	$5,D_800A34F8
	andi	$5,$5,0x000f
	srl	$5,$6,$5
	andi	$5,$5,0x0001
	.set	noreorder
	.set	nomacro
	beq	$5,$0,$L769
	li	$2,0x00000005		# 5
	.set	macro
	.set	reorder

$L782:
	lw	$3,D_800A34FC
	sw	$17,D_800A3524
	sw	$0,D_800A3518
	sh	$0,D_800A3528
	sh	$2,42($3)
	sh	$2,40($3)
	lw	$5,D_800A34F8
	li	$2,-7169			# 0xffffe3ff
	sh	$0,D_800A3512
	sh	$0,D_800A3510
	sh	$0,D_800A350E
	sh	$0,D_800A350C
	and	$5,$5,$2
	ori	$5,$5,0x1000
	sw	$5,D_800A34F8
	sh	$0,18($3)
	sh	$0,16($3)
	sh	$0,14($3)
	sh	$0,12($3)
	la	$6,D_800A32C0
	lwl	$2,3($6)
	lwr	$2,0($6)
	lwl	$3,7($6)
	lwr	$3,4($6)
	swl	$2,19($sp)
	swr	$2,16($sp)
	swl	$3,23($sp)
	swr	$3,20($sp)
	.set	noreorder
	.set	nomacro
	jal	gpu_DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	addu	$4,$sp,16
	li	$5,0x000003c0		# 960
	.set	noreorder
	.set	nomacro
	jal	func_8007B6C8
	li	$6,0x000001fe		# 510
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	gpu_DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	lw	$2,D_800A3524
	#nop
	lw	$3,32($2)
	lw	$4,D_800A34FC
	li	$2,0x00000001		# 1
	andi	$3,$3,0x0001
	sb	$3,48($4)
	lw	$31,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,40
	j	$31
	.end	func_80068F70
	.align	2
	.globl	func_80069120
	.ent	func_80069120
func_80069120:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	lw	$2,D_800A3524
	lw	$3,D_800A34FC
	subu	$sp,$sp,24
	sw	$31,20($sp)
	sw	$16,16($sp)
	lw	$2,32($2)
	lbu	$3,48($3)
	andi	$2,$2,0x0001
	.set	noreorder
	.set	nomacro
	beq	$3,$2,$L784
	move	$16,$4
	.set	macro
	.set	reorder

	lw	$4,D_800A372C
	jal	func_8006E8CC
$L784:
	lw	$2,D_800A3524
	#nop
	lw	$2,32($2)
	lw	$3,D_800A34FC
	andi	$2,$2,0x0001
	sb	$2,48($3)
	sll	$2,$16,1
	addu	$2,$2,$16
	lw	$3,D_800A351C
	sll	$2,$2,2
	subu	$2,$2,$16
	sll	$2,$2,2
	addu	$2,$3,$2
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80069120
	.align	2
	.globl	efc_rob_Close
	.ent	efc_rob_Close
efc_rob_Close:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, extra= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	sw	$18,24($sp)
	move	$18,$4
	sw	$17,20($sp)
	move	$17,$0
	sw	$16,16($sp)
	addu	$16,$18,20
	sw	$31,28($sp)
$L786:
	lw	$5,0($16)
	move	$4,$18
	addu	$16,$16,4
	.set	noreorder
	.set	nomacro
	jal	func_8006920C
	addu	$17,$17,1
	.set	macro
	.set	reorder

	slt	$2,$17,12
	bne	$2,$0,$L786
	lw	$4,0($18)
	lw	$6,4($18)
	.set	noreorder
	.set	nomacro
	jal	tslGlobalMemFree_8005C2A8
	li	$5,0x00000001		# 1
	.set	macro
	.set	reorder

	lw	$2,4($18)
	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,32
	j	$31
	.end	efc_rob_Close
	.align	2
	.globl	func_8006920C
	.ent	func_8006920C
func_8006920C:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$2,0($5)
	#nop
	beq	$2,$0,$L790
	li	$3,-1			# 0xffffffff
$L794:
	lw	$2,0($5)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$3,$L795
	addu	$2,$2,$4
	.set	macro
	.set	reorder

	sw	$2,0($5)
$L795:
	addu	$5,$5,4
	lw	$2,0($5)
	#nop
	bne	$2,$0,$L794
$L790:
	j	$31
	.end	func_8006920C
	.align	2
	.globl	func_80069250
	.ent	func_80069250
func_80069250:
	.frame	$sp,64,$31		# vars= 40, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,64
	sw	$16,56($sp)
	move	$16,$5
	la	$5,D_800A3518
	sw	$31,60($sp)
	sw	$0,D_800A3514
	.set	noreorder
	.set	nomacro
	jal	func_8006E390
	addu	$4,$sp,16
	.set	macro
	.set	reorder

	addu	$4,$sp,16
	.set	noreorder
	.set	nomacro
	jal	func_80069E18
	move	$5,$0
	.set	macro
	.set	reorder

	li	$2,0x00400000		# 4194304
	ori	$2,$2,0x0040
	and	$16,$16,$2
	.set	noreorder
	.set	nomacro
	bne	$16,$0,$L798
	li	$4,0x00000001		# 1
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	$L799
	move	$2,$0
	.set	macro
	.set	reorder

$L798:
	li	$5,0x0000007f		# 127
	.set	noreorder
	.set	nomacro
	jal	func_8005C650
	li	$6,0x0000007f		# 127
	.set	macro
	.set	reorder

	li	$2,0x00000001		# 1
$L799:
	lw	$31,60($sp)
	lw	$16,56($sp)
	addu	$sp,$sp,64
	j	$31
	.end	func_80069250
	.align	2
	.globl	func_800692C0
	.ent	func_800692C0
func_800692C0:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	move	$14,$4
	move	$10,$0
	move	$11,$0
	sll	$5,$5,4
	li	$15,0x00000001		# 1
	move	$13,$0
	move	$9,$0
	la	$12,D_800A32D0
$L804:
	sll	$4,$11,2
	lw	$2,0($12)
	lw	$3,D_800A32C8($4)
	lh	$4,0($6)
	addu	$7,$7,$13
	sll	$8,$2,$5
	.set	noreorder
	.set	nomacro
	bne	$4,$0,$L807
	sll	$3,$3,$5
	.set	macro
	.set	reorder

	lw	$4,0($14)
	#nop
	and	$2,$4,$3
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L808
	and	$2,$4,$8
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	$L811
	sh	$15,0($7)
	.set	macro
	.set	reorder

$L808:
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L811
	li	$2,-1			# 0xffffffff
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	$L811
	sh	$2,0($7)
	.set	macro
	.set	reorder

$L807:
	lw	$4,0($14)
	#nop
	and	$2,$4,$3
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L812
	li	$2,0x00000006		# 6
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	$L813
	sh	$2,0($6)
	.set	macro
	.set	reorder

$L812:
	and	$2,$4,$8
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L813
	li	$2,-6			# 0xfffffffa
	.set	macro
	.set	reorder

	sh	$2,0($7)
$L813:
	lh	$3,0($6)
	#nop
	slt	$2,$3,6
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L815
	slt	$2,$3,-5
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	$L820
	sll	$2,$15,$9
	.set	macro
	.set	reorder

$L815:
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L811
	li	$2,0x00000002		# 2
	.set	macro
	.set	reorder

	sll	$2,$2,$9
$L820:
	addu	$10,$10,$2
	sh	$0,0($7)
	sh	$0,0($6)
$L811:
	addu	$13,$13,2
	lhu	$2,0($6)
	lhu	$3,0($7)
	addu	$9,$9,16
	addu	$12,$12,4
	addu	$11,$11,1
	addu	$2,$2,$3
	sh	$2,0($6)
	slt	$2,$11,2
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L804
	addu	$6,$6,2
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	$31
	move	$2,$10
	.set	macro
	.set	reorder

	.end	func_800692C0
	.align	2
	.globl	func_800693CC
	.ent	func_800693CC
func_800693CC:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	j	$31
	move	$2,$0
	.set	macro
	.set	reorder

	.end	func_800693CC
	.align	2
	.globl	func_80069898
	.ent	func_80069898
func_80069898:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, extra= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	sw	$20,32($sp)
	move	$20,$4
	sw	$31,36($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	sw	$16,16($sp)
	lw	$16,24($20)
	move	$17,$5
	move	$19,$6
	.set	noreorder
	.set	nomacro
	jal	initTile
	move	$4,$16
	.set	macro
	.set	reorder

	li	$2,0x000000ff		# 255
	li	$18,0x00000080		# 128
	sb	$2,4($16)
	sb	$2,5($16)
	sb	$2,6($16)
	sb	$18,4($16)
	sb	$18,5($16)
	sb	$18,6($16)
	lhu	$2,0($17)
	#nop
	sh	$2,8($16)
	lhu	$2,2($17)
	#nop
	sh	$2,10($16)
	lhu	$2,4($17)
	#nop
	sh	$2,12($16)
	lhu	$2,6($17)
	move	$4,$16
	move	$5,$0
	.set	noreorder
	.set	nomacro
	jal	gpu_SetSemiTransp
	sh	$2,14($16)
	.set	macro
	.set	reorder

	lw	$4,D_800A374C
	move	$5,$16
	addu	$16,$16,16
	sll	$19,$19,2
	.set	noreorder
	.set	nomacro
	jal	ot_Link
	addu	$4,$4,$19
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	initTile
	move	$4,$16
	.set	macro
	.set	reorder

	sb	$18,4($16)
	sb	$18,5($16)
	sb	$18,6($16)
	lhu	$2,0($17)
	#nop
	sh	$2,8($16)
	lhu	$2,2($17)
	#nop
	addu	$2,$2,-1
	sh	$2,10($16)
	lhu	$2,4($17)
	#nop
	sh	$2,12($16)
	lhu	$2,6($17)
	move	$4,$16
	li	$5,0x00000001		# 1
	.set	noreorder
	.set	nomacro
	jal	gpu_SetSemiTransp
	sh	$2,14($16)
	.set	macro
	.set	reorder

	lw	$4,D_800A374C
	move	$5,$16
	addu	$16,$16,16
	.set	noreorder
	.set	nomacro
	jal	ot_Link
	addu	$4,$4,$19
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	initTile
	move	$4,$16
	.set	macro
	.set	reorder

	li	$2,0x00000040		# 64
	sb	$2,4($16)
	sb	$2,5($16)
	sb	$2,6($16)
	lhu	$2,0($17)
	#nop
	sh	$2,8($16)
	lhu	$2,2($17)
	#nop
	addu	$2,$2,-2
	sh	$2,10($16)
	lhu	$2,4($17)
	#nop
	sh	$2,12($16)
	lhu	$2,6($17)
	move	$4,$16
	li	$5,0x00000001		# 1
	.set	noreorder
	.set	nomacro
	jal	gpu_SetSemiTransp
	sh	$2,14($16)
	.set	macro
	.set	reorder

	lw	$4,D_800A374C
	move	$5,$16
	addu	$16,$16,16
	.set	noreorder
	.set	nomacro
	jal	ot_Link
	addu	$4,$4,$19
	.set	macro
	.set	reorder

	sw	$16,24($20)
	lw	$31,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,40
	j	$31
	.end	func_80069898
	.align	2
	.globl	func_80069A30
	.ent	func_80069A30
func_80069A30:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$16,16($sp)
	sw	$31,20($sp)
	.set	noreorder
	.set	nomacro
	jal	saTan2GaugeInit_80077D00
	move	$16,$4
	.set	macro
	.set	reorder

	lw	$2,32($2)
	#nop
	andi	$2,$2,0x0001
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L824
	li	$2,0x00000022		# 34
	.set	macro
	.set	reorder

	sb	$2,4($16)
	.set	noreorder
	.set	nomacro
	j	$L825
	sb	$2,5($16)
	.set	macro
	.set	reorder

$L824:
	li	$2,0x0000004c		# 76
	sb	$2,4($16)
	sb	$2,5($16)
	li	$2,0x0000006c		# 108
$L825:
	sb	$2,6($16)
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80069A30
	.align	2
	.globl	func_80069A8C
	.ent	func_80069A8C
func_80069A8C:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$16,16($sp)
	sw	$31,20($sp)
	.set	noreorder
	.set	nomacro
	jal	saTan2GaugeInit_80077D00
	move	$16,$4
	.set	macro
	.set	reorder

	lw	$2,32($2)
	#nop
	andi	$2,$2,0x0001
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L827
	li	$2,0x00000008		# 8
	.set	macro
	.set	reorder

	sb	$2,4($16)
	.set	noreorder
	.set	nomacro
	j	$L828
	sb	$2,5($16)
	.set	macro
	.set	reorder

$L827:
	li	$2,0x00000031		# 49
	sb	$0,4($16)
	sb	$0,5($16)
$L828:
	sb	$2,6($16)
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80069A8C
	.align	2
	.globl	func_80069AE4
	.ent	func_80069AE4
func_80069AE4:
	.frame	$sp,96,$31		# vars= 48, regs= 6/0, args= 24, extra= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,96
	sw	$20,88($sp)
	move	$20,$4
	sw	$31,92($sp)
	sw	$19,84($sp)
	sw	$18,80($sp)
	sw	$17,76($sp)
	sw	$16,72($sp)
	lw	$19,24($20)
	li	$2,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	bne	$5,$2,$L830
	li	$2,0x00000001		# 1
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	initTile
	move	$4,$19
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_80069A30
	move	$4,$19
	.set	macro
	.set	reorder

	move	$4,$19
	li	$5,0x00000001		# 1
	li	$2,0x0000004e		# 78
	li	$18,0x00000030		# 48
	li	$17,0x000000cc		# 204
	li	$16,0x000000b0		# 176
	sh	$2,8($19)
	sh	$18,10($19)
	sh	$17,12($19)
	.set	noreorder
	.set	nomacro
	jal	gpu_SetSemiTransp
	sh	$16,14($19)
	.set	macro
	.set	reorder

	lw	$4,D_800A374C
	move	$5,$19
	addu	$19,$19,16
	.set	noreorder
	.set	nomacro
	jal	ot_Link
	addu	$4,$4,68
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	initTile
	move	$4,$19
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_80069A30
	move	$4,$19
	.set	macro
	.set	reorder

	move	$4,$19
	li	$5,0x00000001		# 1
	li	$2,0x00000166		# 358
	sh	$2,8($19)
	sh	$18,10($19)
	sh	$17,12($19)
	.set	noreorder
	.set	nomacro
	j	$L838
	sh	$16,14($19)
	.set	macro
	.set	reorder

$L830:
	bne	$5,$2,$L832
	.set	noreorder
	.set	nomacro
	jal	initTile
	move	$4,$19
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_80069A30
	move	$4,$19
	.set	macro
	.set	reorder

	move	$4,$19
	li	$5,0x00000001		# 1
	li	$2,0x0000003f		# 63
	sh	$2,8($19)
	li	$2,0x00000030		# 48
	sh	$2,10($19)
	li	$2,0x00000202		# 514
	sh	$2,12($19)
	.set	noreorder
	.set	nomacro
	j	$L839
	li	$2,0x000000b0		# 176
	.set	macro
	.set	reorder

$L832:
	.set	noreorder
	.set	nomacro
	jal	initTile
	move	$4,$19
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_80069A30
	move	$4,$19
	.set	macro
	.set	reorder

	move	$4,$19
	li	$5,0x00000001		# 1
	li	$2,0x00000130		# 304
	sh	$2,8($19)
	li	$2,0x0000003a		# 58
	sh	$2,10($19)
	li	$2,0x00000126		# 294
	sh	$2,12($19)
	li	$2,0x000000ab		# 171
$L839:
	sh	$2,14($19)
$L838:
	.set	noreorder
	.set	nomacro
	jal	gpu_SetSemiTransp
	move	$17,$0
	.set	macro
	.set	reorder

	lw	$4,D_800A374C
	move	$5,$19
	addu	$19,$19,16
	.set	noreorder
	.set	nomacro
	jal	ot_Link
	addu	$4,$4,68
	.set	macro
	.set	reorder

	li	$2,0x00000012		# 18
	sw	$19,24($20)
	sw	$2,44($sp)
	sb	$0,64($sp)
	sw	$0,40($sp)
	lw	$2,4($20)
	#nop
	lw	$18,52($2)
	sw	$0,48($sp)
	sw	$0,52($sp)
	move	$16,$18
$L834:
	lw	$2,0($16)
	#nop
	sw	$2,24($sp)
	addu	$2,$2,12
	sw	$2,28($sp)
	lw	$2,20($20)
	addu	$4,$sp,24
	addu	$16,$16,4
	addu	$17,$17,1
	.set	noreorder
	.set	nomacro
	jal	func_8007352C
	sw	$2,32($sp)
	.set	macro
	.set	reorder

	sw	$2,20($20)
	slt	$2,$17,3
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L834
	move	$5,$0
	.set	macro
	.set	reorder

	lw	$4,0($18)
	.set	noreorder
	.set	nomacro
	jal	saMotionSet
	sw	$4,24($sp)
	.set	macro
	.set	reorder

	sw	$0,16($sp)
	lw	$4,28($20)
	li	$5,0x00000001		# 1
	move	$6,$0
	.set	noreorder
	.set	nomacro
	jal	initTexPage
	move	$7,$2
	.set	macro
	.set	reorder

	lw	$4,D_800A374C
	lw	$5,28($20)
	.set	noreorder
	.set	nomacro
	jal	ot_Link
	addu	$4,$4,72
	.set	macro
	.set	reorder

	lw	$16,12($20)
	lw	$2,28($20)
	move	$4,$16
	addu	$2,$2,12
	.set	noreorder
	.set	nomacro
	jal	initPolyF4
	sw	$2,28($20)
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_80069A8C
	move	$4,$16
	.set	macro
	.set	reorder

	move	$4,$16
	move	$5,$0
	li	$2,0x000000b9		# 185
	li	$19,0x00000122		# 290
	li	$18,0x000000ef		# 239
	sh	$0,8($16)
	sh	$2,10($16)
	sh	$19,12($16)
	sh	$0,14($16)
	sh	$0,16($16)
	sh	$18,18($16)
	sh	$19,20($16)
	.set	noreorder
	.set	nomacro
	jal	gpu_SetSemiTransp
	sh	$18,22($16)
	.set	macro
	.set	reorder

	lw	$4,D_800A374C
	move	$5,$16
	addu	$16,$16,24
	.set	noreorder
	.set	nomacro
	jal	ot_Link
	addu	$4,$4,76
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	initPolyF4
	move	$4,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_80069A8C
	move	$4,$16
	.set	macro
	.set	reorder

	move	$4,$16
	move	$5,$0
	li	$17,0x0000015e		# 350
	li	$2,0x0000027f		# 639
	sh	$2,12($16)
	sh	$2,20($16)
	li	$2,0x00000036		# 54
	sh	$17,8($16)
	sh	$0,10($16)
	sh	$0,14($16)
	sh	$17,16($16)
	sh	$18,18($16)
	.set	noreorder
	.set	nomacro
	jal	gpu_SetSemiTransp
	sh	$2,22($16)
	.set	macro
	.set	reorder

	lw	$4,D_800A374C
	move	$5,$16
	addu	$16,$16,24
	.set	noreorder
	.set	nomacro
	jal	ot_Link
	addu	$4,$4,76
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	initPolyF4
	move	$4,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_80069A8C
	move	$4,$16
	.set	macro
	.set	reorder

	move	$4,$16
	move	$5,$0
	sh	$19,8($16)
	sh	$0,10($16)
	sh	$17,12($16)
	sh	$0,14($16)
	sh	$19,16($16)
	sh	$18,18($16)
	sh	$17,20($16)
	.set	noreorder
	.set	nomacro
	jal	gpu_SetSemiTransp
	sh	$18,22($16)
	.set	macro
	.set	reorder

	lw	$4,D_800A374C
	move	$5,$16
	addu	$16,$16,24
	.set	noreorder
	.set	nomacro
	jal	ot_Link
	addu	$4,$4,76
	.set	macro
	.set	reorder

	sw	$16,12($20)
	lw	$31,92($sp)
	lw	$20,88($sp)
	lw	$19,84($sp)
	lw	$18,80($sp)
	lw	$17,76($sp)
	lw	$16,72($sp)
	addu	$sp,$sp,96
	j	$31
	.end	func_80069AE4
	.align	2
	.globl	func_80069E18
	.ent	func_80069E18
func_80069E18:
	.frame	$sp,88,$31		# vars= 48, regs= 3/0, args= 24, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,88
	sw	$17,76($sp)
	move	$17,$4
	sw	$31,80($sp)
	sw	$16,72($sp)
	lw	$16,24($17)
	.set	noreorder
	.set	nomacro
	jal	initTile
	move	$4,$16
	.set	macro
	.set	reorder

	move	$4,$16
	move	$5,$0
	li	$2,0x000000ff		# 255
	sb	$2,4($16)
	sb	$2,5($16)
	sb	$2,6($16)
	li	$2,0x00000280		# 640
	sh	$2,12($16)
	li	$2,0x000000f0		# 240
	sh	$0,8($16)
	sh	$0,10($16)
	.set	noreorder
	.set	nomacro
	jal	gpu_SetSemiTransp
	sh	$2,14($16)
	.set	macro
	.set	reorder

	lw	$4,D_800A374C
	move	$5,$16
	.set	noreorder
	.set	nomacro
	jal	ot_Link
	addu	$4,$4,80
	.set	macro
	.set	reorder

	lw	$2,4($17)
	addu	$16,$16,16
	sw	$16,24($17)
	lw	$16,20($2)
	li	$2,0x00000010		# 16
	sw	$2,44($sp)
	sw	$0,40($sp)
	sw	$0,48($sp)
	sw	$0,52($sp)
	sb	$0,64($sp)
	lw	$4,0($16)
	move	$5,$0
	.set	noreorder
	.set	nomacro
	jal	saMotionSet
	sw	$4,24($sp)
	.set	macro
	.set	reorder

	sw	$0,16($sp)
	lw	$4,28($17)
	li	$5,0x00000001		# 1
	move	$6,$0
	.set	noreorder
	.set	nomacro
	jal	initTexPage
	move	$7,$2
	.set	macro
	.set	reorder

	lw	$4,D_800A374C
	lw	$5,28($17)
	.set	noreorder
	.set	nomacro
	jal	ot_Link
	addu	$4,$4,68
	.set	macro
	.set	reorder

	lw	$2,28($17)
	#nop
	addu	$2,$2,12
	sw	$2,28($17)
	lw	$2,24($sp)
	#nop
	addu	$3,$2,12
	sw	$3,28($sp)
	lw	$2,20($17)
	addu	$4,$sp,24
	.set	noreorder
	.set	nomacro
	jal	func_8007352C
	sw	$2,32($sp)
	.set	macro
	.set	reorder

	sw	$2,20($17)
	lw	$2,4($16)
	#nop
	addu	$3,$2,12
	sw	$2,24($sp)
	sw	$3,28($sp)
	lw	$2,20($17)
	addu	$4,$sp,24
	.set	noreorder
	.set	nomacro
	jal	func_8007352C
	sw	$2,32($sp)
	.set	macro
	.set	reorder

	sw	$2,20($17)
	lw	$2,8($16)
	#nop
	addu	$3,$2,12
	sw	$2,24($sp)
	sw	$3,28($sp)
	lw	$2,20($17)
	addu	$4,$sp,24
	.set	noreorder
	.set	nomacro
	jal	func_8007352C
	sw	$2,32($sp)
	.set	macro
	.set	reorder

	sw	$2,20($17)
	lw	$31,80($sp)
	lw	$17,76($sp)
	lw	$16,72($sp)
	addu	$sp,$sp,88
	j	$31
	.end	func_80069E18
	.align	2
	.globl	func_80069F80
	.ent	func_80069F80
func_80069F80:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_80069F80
	.align	2
	.globl	func_8006A1A0
	.ent	func_8006A1A0
func_8006A1A0:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_8006A1A0
	.align	2
	.globl	func_8006A3CC
	.ent	func_8006A3CC
func_8006A3CC:
	.frame	$sp,40,$31		# vars= 0, regs= 3/0, args= 24, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	sw	$17,28($sp)
	move	$17,$4
	sw	$31,32($sp)
	sw	$16,24($sp)
	lw	$2,4($17)
	#nop
	lw	$2,28($2)
	#nop
	lw	$2,16($2)
	move	$16,$5
	sw	$2,0($16)
	lw	$3,0($16)
	sw	$0,24($16)
	sw	$0,28($16)
	sb	$0,40($16)
	sw	$0,16($16)
	li	$2,0x00000001		# 1
	sw	$2,20($16)
	addu	$3,$3,12
	sw	$3,4($16)
	lw	$2,20($17)
	move	$4,$16
	.set	noreorder
	.set	nomacro
	jal	func_8007352C
	sw	$2,8($16)
	.set	macro
	.set	reorder

	sw	$2,20($17)
	lw	$4,0($16)
	.set	noreorder
	.set	nomacro
	jal	saMotionSet
	move	$5,$0
	.set	macro
	.set	reorder

	sw	$0,16($sp)
	lw	$4,28($17)
	li	$5,0x00000001		# 1
	move	$6,$0
	.set	noreorder
	.set	nomacro
	jal	initTexPage
	move	$7,$2
	.set	macro
	.set	reorder

	lw	$4,D_800A374C
	lw	$5,28($17)
	.set	noreorder
	.set	nomacro
	jal	ot_Link
	addu	$4,$4,4
	.set	macro
	.set	reorder

	lw	$2,28($17)
	#nop
	addu	$2,$2,12
	sw	$2,28($17)
	lw	$31,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,40
	j	$31
	.end	func_8006A3CC
	.align	2
	.globl	func_8006A494
	.ent	func_8006A494
func_8006A494:
	.frame	$sp,40,$31		# vars= 0, regs= 3/0, args= 24, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	sw	$17,28($sp)
	move	$17,$4
	sw	$31,32($sp)
	sw	$16,24($sp)
	lw	$2,4($17)
	#nop
	lw	$2,28($2)
	#nop
	lw	$2,36($2)
	move	$16,$5
	sw	$2,0($16)
	lw	$3,0($16)
	sw	$0,24($16)
	sw	$0,28($16)
	sb	$0,40($16)
	sw	$0,16($16)
	li	$2,0x00000001		# 1
	sw	$2,20($16)
	li	$2,0x00000100		# 256
	sw	$2,32($16)
	sw	$2,36($16)
	addu	$3,$3,12
	sw	$3,4($16)
	lw	$2,8($17)
	move	$4,$16
	move	$5,$0
	.set	noreorder
	.set	nomacro
	jal	func_80073728
	sw	$2,12($16)
	.set	macro
	.set	reorder

	sw	$2,8($17)
	lw	$4,0($16)
	.set	noreorder
	.set	nomacro
	jal	saMotionSet
	move	$5,$0
	.set	macro
	.set	reorder

	sw	$0,16($sp)
	lw	$4,28($17)
	li	$5,0x00000001		# 1
	move	$6,$0
	.set	noreorder
	.set	nomacro
	jal	initTexPage
	move	$7,$2
	.set	macro
	.set	reorder

	lw	$4,D_800A374C
	lw	$5,28($17)
	.set	noreorder
	.set	nomacro
	jal	ot_Link
	addu	$4,$4,4
	.set	macro
	.set	reorder

	lw	$2,28($17)
	#nop
	addu	$2,$2,12
	sw	$2,28($17)
	lw	$31,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,40
	j	$31
	.end	func_8006A494
	.align	2
	.globl	saTan3GaugeMain_8006A564
	.ent	saTan3GaugeMain_8006A564
saTan3GaugeMain_8006A564:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	saTan3GaugeMain_8006A564
	.align	2
	.globl	func_8006A880
	.ent	func_8006A880
func_8006A880:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_8006A880
	.align	2
	.globl	func_8006B120
	.ent	func_8006B120
func_8006B120:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_8006B120
	.align	2
	.globl	func_8006B578
	.ent	func_8006B578
func_8006B578:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_8006B578
	.align	2
	.globl	func_8006B898
	.ent	func_8006B898
func_8006B898:
	.frame	$sp,64,$31		# vars= 40, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,64
	sw	$5,68($sp)
	lw	$2,D_800A3514
	lw	$3,D_800A36AC
	sw	$4,64($sp)
	addu	$4,$sp,16
	la	$5,D_800A3518
	sw	$31,60($sp)
	sw	$16,56($sp)
	addu	$2,$2,1
	andi	$3,$3,0x0001
	sll	$16,$3,7
	addu	$16,$16,$3
	sll	$16,$16,3
	addu	$16,$16,$3
	sll	$16,$16,4
	sw	$2,D_800A3514
	la	$2,g_disp_fb_base
	.set	noreorder
	.set	nomacro
	jal	func_8006E390
	addu	$16,$16,$2
	.set	macro
	.set	reorder

	addu	$4,$sp,16
	li	$5,0x00000001		# 1
	.set	noreorder
	.set	nomacro
	jal	func_80069AE4
	move	$6,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_8006B120
	addu	$4,$sp,16
	.set	macro
	.set	reorder

	addu	$4,$sp,64
	.set	noreorder
	.set	nomacro
	jal	func_8006B578
	addu	$5,$sp,68
	.set	macro
	.set	reorder

	lw	$31,60($sp)
	lw	$16,56($sp)
	addu	$sp,$sp,64
	j	$31
	.end	func_8006B898
	.align	2
	.globl	func_8006B92C
	.ent	func_8006B92C
func_8006B92C:
	.frame	$sp,40,$31		# vars= 8, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	lw	$6,D_800A34FC
	subu	$sp,$sp,40
	sw	$17,28($sp)
	move	$17,$5
	sw	$16,24($sp)
	move	$16,$0
	sw	$31,32($sp)
	lw	$3,0($17)
	addu	$4,$sp,16
	move	$5,$0
	la	$7,D_800A350C
	addu	$6,$6,12
	andi	$2,$3,0xffff
	srl	$3,$3,16
	or	$2,$2,$3
	.set	noreorder
	.set	nomacro
	jal	func_800692C0
	sw	$2,16($sp)
	.set	macro
	.set	reorder

	sra	$3,$2,16
	li	$2,0x00000001		# 1
	.set	noreorder
	.set	nomacro
	beq	$3,$2,$L852
	li	$2,0x00000002		# 2
	.set	macro
	.set	reorder

	beq	$3,$2,$L855
	j	$L851
$L852:
	lw	$4,D_800A34F8
	li	$2,0x00004000		# 16384
	andi	$3,$4,0xe000
	.set	noreorder
	.set	nomacro
	bne	$3,$2,$L853
	li	$3,-65536			# 0xffff0000
	.set	macro
	.set	reorder

	li	$2,-65536			# 0xffff0000
	ori	$2,$2,0x1fff
	and	$2,$4,$2
	sw	$2,D_800A34F8
	.set	noreorder
	.set	nomacro
	j	$L872
	move	$4,$0
	.set	macro
	.set	reorder

$L853:
	ori	$3,$3,0x1fff
	and	$3,$4,$3
	srl	$2,$4,13
	andi	$2,$2,0x0007
	.set	noreorder
	.set	nomacro
	j	$L871
	addu	$2,$2,1
	.set	macro
	.set	reorder

$L855:
	lw	$4,D_800A34F8
	#nop
	andi	$2,$4,0xe000
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L856
	li	$3,-65536			# 0xffff0000
	.set	macro
	.set	reorder

	li	$2,-65536			# 0xffff0000
	ori	$2,$2,0x1fff
	and	$2,$4,$2
	ori	$2,$2,0x4000
	sw	$2,D_800A34F8
	.set	noreorder
	.set	nomacro
	j	$L872
	move	$4,$0
	.set	macro
	.set	reorder

$L856:
	ori	$3,$3,0x1fff
	and	$3,$4,$3
	srl	$2,$4,13
	andi	$2,$2,0x0007
	addu	$2,$2,-1
$L871:
	andi	$2,$2,0x0007
	sll	$2,$2,13
	or	$3,$3,$2
	sw	$3,D_800A34F8
	move	$4,$0
$L872:
	li	$5,0x0000007f		# 127
	.set	noreorder
	.set	nomacro
	jal	func_8005C650
	li	$6,0x0000007f		# 127
	.set	macro
	.set	reorder

$L851:
	lw	$2,D_800A34F8
	#nop
	srl	$2,$2,13
	andi	$3,$2,0x0007
	li	$2,0x00000001		# 1
	.set	noreorder
	.set	nomacro
	beq	$3,$2,$L863
	slt	$2,$3,2
	.set	macro
	.set	reorder

	beq	$2,$0,$L869
	.set	noreorder
	.set	nomacro
	beq	$3,$0,$L861
	li	$3,0x00400000		# 4194304
	.set	macro
	.set	reorder

	j	$L860
$L869:
	li	$2,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	beq	$3,$2,$L865
	li	$3,0x00400000		# 4194304
	.set	macro
	.set	reorder

	j	$L860
$L861:
	lw	$2,0($17)
	ori	$3,$3,0x0040
	and	$2,$2,$3
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L860
	li	$4,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$5,0x0000007f		# 127
	.set	noreorder
	.set	nomacro
	jal	func_8005C650
	li	$6,0x0000007f		# 127
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	$L860
	li	$16,0x00000002		# 2
	.set	macro
	.set	reorder

$L863:
	lw	$2,0($17)
	li	$3,0x00400000		# 4194304
	ori	$3,$3,0x0040
	and	$2,$2,$3
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L860
	li	$4,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$5,0x0000007f		# 127
	.set	noreorder
	.set	nomacro
	jal	func_8005C650
	li	$6,0x0000007f		# 127
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	$L860
	li	$16,0x00000003		# 3
	.set	macro
	.set	reorder

$L865:
	lw	$2,0($17)
	ori	$3,$3,0x0040
	and	$2,$2,$3
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L860
	li	$4,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$5,0x0000007f		# 127
	.set	noreorder
	.set	nomacro
	jal	func_8005C650
	li	$6,0x0000007f		# 127
	.set	macro
	.set	reorder

	lw	$2,D_800A34F8
	li	$16,0x00000001		# 1
	li	$3,-7169			# 0xffffe3ff
	and	$3,$2,$3
	srl	$2,$2,10
	andi	$2,$2,0x0007
	addu	$2,$2,1
	andi	$2,$2,0x0007
	sll	$2,$2,10
	or	$3,$3,$2
	sw	$3,D_800A34F8
$L860:
	lw	$2,0($17)
	li	$3,0x00100000		# 1048576
	ori	$3,$3,0x0010
	and	$2,$2,$3
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L870
	li	$4,0x00000002		# 2
	.set	macro
	.set	reorder

	li	$5,0x0000007f		# 127
	.set	noreorder
	.set	nomacro
	jal	func_8005C650
	li	$6,0x0000007f		# 127
	.set	macro
	.set	reorder

	li	$16,0x00000001		# 1
$L870:
	move	$2,$16
	lw	$31,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,40
	j	$31
	.end	func_8006B92C
	.align	2
	.globl	func_8006BB68
	.ent	func_8006BB68
func_8006BB68:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_8006BB68
 #APP
	.set	noat
.set	noreorder
.set noat
.set noreorder
glabel func_8006BD28
    addiu  $sp, $sp, -88
    sw     $s4, 64($sp)
    addu   $s4, $a0, $zero
    sw     $s5, 68($sp)
    addu   $s5, $a1, $zero
    sw     $s1, 52($sp)
    addu   $s1, $a2, $zero
    sw     $s6, 72($sp)
    addu   $s6, $a3, $zero
    sw     $s3, 60($sp)
    addu   $s3, $zero, $zero
    lw     $v0, D_800A34FC
    sll    $t0, $s4, 3
    sw     $ra, 84($sp)
    sw     $fp, 80($sp)
    sw     $s7, 76($sp)
    sw     $s2, 56($sp)
    sw     $s0, 48($sp)
    sw     $t0, 32($sp)
    lw     $v0, 36($v0)
    addiu  $s7, $zero, 18
    lw     $v0, 32($v0)
    addiu  $fp, $zero, 8
    sw     $v0, 24($sp)
    addiu  $v0, $zero, 48
    sb     $v0, 43($s1)
    sb     $v0, 42($s1)
    sb     $v0, 41($s1)
.L_func_8006BD28_outer:
    lw     $t0, 24($sp)
    sll    $v0, $s3, 2
    addu   $v0, $v0, $t0
    lw     $t0, 32($sp)
    nop
    addu   $v0, $t0, $v0
    lw     $v1, 0($v0)
    addiu  $v0, $zero, -1
    beq    $v1, $v0, .L_func_8006BD28_end
     sw    $v1, 0($s1)
    bne    $s4, $s7, .L_func_8006BD28_skip_n3
     addiu $s2, $zero, 1
    addiu  $s2, $zero, 3
.L_func_8006BD28_skip_n3:
    beqz   $s2, .L_func_8006BD28_post_inner
     addu  $s0, $zero, $zero
.L_func_8006BD28_inner:
    sw     $zero, 24($s1)
    sw     $s5, 28($s1)
    bne    $s4, $s7, .L_func_8006BD28_byte28_zero
     sw    $fp, 20($s1)
    beq    $s0, $s6, .L_func_8006BD28_byte28_zero
     addiu $v0, $zero, 2
    bne    $s0, $v0, .L_func_8006BD28_byte28_one
     addiu $v0, $zero, 1
.L_func_8006BD28_byte28_zero:
    j      .L_func_8006BD28_after_byte28
     sb    $zero, 40($s1)
.L_func_8006BD28_byte28_one:
    sb     $v0, 40($s1)
.L_func_8006BD28_after_byte28:
    addu   $a0, $s1, $zero
    sll    $a1, $s0, 3
    lw     $v1, D_800A36E4
    lw     $v0, 0($s1)
    addiu  $s0, $s0, 1
    sw     $zero, 16($s1)
    addiu  $v0, $v0, 12
    addu   $v0, $v0, $a1
    sw     $v1, 8($s1)
    jal    func_8007352C
     sw    $v0, 4($s1)
    sw     $v0, D_800A36E4
    slt    $v0, $s0, $s2
    bnez   $v0, .L_func_8006BD28_inner
     nop
.L_func_8006BD28_post_inner:
    lw     $a0, 0($s1)
    jal    saMotionSet
     addu  $a1, $zero, $zero
    addiu  $a1, $zero, 1
    addu   $a2, $zero, $zero
    lw     $a0, D_800A36E0
    addu   $a3, $v0, $zero
    jal    initTexPage
     sw    $zero, 16($sp)
    lui    $a0, %hi(D_800A374C)
    lw     $a0, %lo(D_800A374C)($a0)
    lw     $a1, D_800A36E0
    jal    ot_Link
     addiu $a0, $a0, 32
    lw     $v0, D_800A36E0
    addiu  $s3, $s3, 1
    addiu  $v0, $v0, 12
    sw     $v0, D_800A36E0
    slti   $v0, $s3, 2
    bnez   $v0, .L_func_8006BD28_outer
     nop
.L_func_8006BD28_end:
    lw     $ra, 84($sp)
    lw     $fp, 80($sp)
    lw     $s7, 76($sp)
    lw     $s6, 72($sp)
    lw     $s5, 68($sp)
    lw     $s4, 64($sp)
    lw     $s3, 60($sp)
    lw     $s2, 56($sp)
    lw     $s1, 52($sp)
    lw     $s0, 48($sp)
    addiu  $sp, $sp, 88
    jr     $ra
     nop
.set	reorder
.set	at
.set reorder
.set at

 #NO_APP
	.align	2
	.globl	func_8006BEC4
	.ent	func_8006BEC4
func_8006BEC4:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_8006BEC4
	.align	2
	.globl	func_8006C168
	.ent	func_8006C168
func_8006C168:
	.frame	$sp,112,$31		# vars= 88, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,112
	sw	$5,116($sp)
	lw	$2,D_800A3514
	lw	$3,D_800A36AC
	sw	$4,112($sp)
	addu	$4,$sp,16
	la	$5,D_800A3518
	sw	$31,108($sp)
	sw	$16,104($sp)
	addu	$2,$2,1
	andi	$3,$3,0x0001
	sll	$16,$3,7
	addu	$16,$16,$3
	sll	$16,$16,3
	addu	$16,$16,$3
	sll	$16,$16,4
	sw	$2,D_800A3514
	la	$2,g_disp_fb_base
	.set	noreorder
	.set	nomacro
	jal	func_8006E390
	addu	$16,$16,$2
	.set	macro
	.set	reorder

	addu	$4,$sp,16
	li	$5,0x00000001		# 1
	.set	noreorder
	.set	nomacro
	jal	func_80069AE4
	move	$6,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_8006BB68
	addu	$4,$sp,16
	.set	macro
	.set	reorder

	addu	$4,$sp,112
	.set	noreorder
	.set	nomacro
	jal	func_8006B92C
	addu	$5,$sp,116
	.set	macro
	.set	reorder

	lw	$31,108($sp)
	lw	$16,104($sp)
	addu	$sp,$sp,112
	j	$31
	.end	func_8006C168
	.align	2
	.globl	saTan2InfoInit_8006C1FC
	.ent	saTan2InfoInit_8006C1FC
saTan2InfoInit_8006C1FC:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	jal	func_8006C168
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	saTan2InfoInit_8006C1FC
	.align	2
	.globl	saTan4GaugeMain
	.ent	saTan4GaugeMain
saTan4GaugeMain:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	saTan4GaugeMain
	.align	2
	.globl	func_8006CBD4
	.ent	func_8006CBD4
func_8006CBD4:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	sll	$6,$4,4
	li	$2,0x00000010		# 16
	sll	$2,$2,$6
	and	$2,$5,$2
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L879
	li	$2,0x00000040		# 64
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	$L880
	li	$7,0x00000001		# 1
	.set	macro
	.set	reorder

$L879:
	sll	$2,$2,$6
	and	$2,$5,$2
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L881
	li	$2,0x00000080		# 128
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	$L880
	li	$7,0x00000002		# 2
	.set	macro
	.set	reorder

$L881:
	sll	$2,$2,$6
	and	$2,$5,$2
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L883
	li	$2,0x00000020		# 32
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	$L880
	li	$7,0x00000003		# 3
	.set	macro
	.set	reorder

$L883:
	sll	$2,$2,$6
	and	$2,$5,$2
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L894
	move	$5,$0
	.set	macro
	.set	reorder

	move	$7,$0
$L880:
	move	$5,$0
$L894:
	sll	$8,$4,1
	li	$2,0x00000001		# 1
	sll	$2,$2,$7
	sll	$3,$4,2
	sll	$4,$2,$3
	nor	$6,$0,$4
$L889:
	lw	$2,D_800A34FC
	#nop
	addu	$2,$8,$2
	lh	$3,40($2)
	sll	$2,$5,16
	sra	$2,$2,16
	bne	$2,$3,$L890
	lw	$3,D_800A3524
	#nop
	addu	$3,$3,$2
	lbu	$2,23($3)
	.set	noreorder
	.set	nomacro
	j	$L893
	or	$2,$2,$4
	.set	macro
	.set	reorder

$L890:
	lw	$3,D_800A3524
	#nop
	addu	$3,$3,$2
	lbu	$2,23($3)
	#nop
	and	$2,$2,$6
$L893:
	sb	$2,23($3)
	addu	$2,$5,1
	move	$5,$2
	sll	$2,$2,16
	sra	$2,$2,16
	slt	$2,$2,3
	bne	$2,$0,$L889
	j	$31
	.end	func_8006CBD4
	.align	2
	.globl	func_8006CCC8
	.ent	func_8006CCC8
func_8006CCC8:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_8006CCC8
	.align	2
	.globl	func_8006CFBC
	.ent	func_8006CFBC
func_8006CFBC:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	j	$31
	move	$2,$0
	.set	macro
	.set	reorder

	.end	func_8006CFBC
	.align	2
	.globl	cpu_reset_dir
	.ent	cpu_reset_dir
cpu_reset_dir:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$3,D_800A34FC
	li	$2,0x00000005		# 5
	sh	$2,42($3)
	.set	noreorder
	.set	nomacro
	j	$31
	sh	$2,40($3)
	.set	macro
	.set	reorder

	.end	cpu_reset_dir
	.align	2
	.globl	func_8006D338
	.ent	func_8006D338
func_8006D338:
	.frame	$sp,112,$31		# vars= 88, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,112
	sw	$5,116($sp)
	lw	$2,D_800A3514
	lw	$3,D_800A36AC
	sw	$4,112($sp)
	addu	$4,$sp,16
	la	$5,D_800A3518
	sw	$31,108($sp)
	sw	$16,104($sp)
	addu	$2,$2,1
	andi	$3,$3,0x0001
	sll	$16,$3,7
	addu	$16,$16,$3
	sll	$16,$16,3
	addu	$16,$16,$3
	sll	$16,$16,4
	sw	$2,D_800A3514
	la	$2,g_disp_fb_base
	.set	noreorder
	.set	nomacro
	jal	func_8006E390
	addu	$16,$16,$2
	.set	macro
	.set	reorder

	addu	$4,$sp,16
	li	$5,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	jal	func_80069AE4
	move	$6,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	saTan4GaugeMain
	addu	$4,$sp,16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_8006CFBC
	addu	$4,$sp,16
	.set	macro
	.set	reorder

	addu	$4,$sp,112
	addu	$5,$sp,116
	sll	$2,$2,16
	.set	noreorder
	.set	nomacro
	jal	func_8006CCC8
	sra	$6,$2,16
	.set	macro
	.set	reorder

	lw	$31,108($sp)
	lw	$16,104($sp)
	addu	$sp,$sp,112
	j	$31
	.end	func_8006D338
	.align	2
	.globl	func_8006D3DC
	.ent	func_8006D3DC
func_8006D3DC:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_8006D3DC
	.align	2
	.globl	func_8006D5D4
	.ent	func_8006D5D4
func_8006D5D4:
	.frame	$sp,40,$31		# vars= 8, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	sw	$16,24($sp)
	move	$16,$5
	sw	$17,28($sp)
	move	$17,$0
	addu	$4,$sp,16
	move	$5,$0
	lw	$6,D_800A34FC
	andi	$2,$16,0xffff
	srl	$3,$16,16
	or	$2,$2,$3
	la	$7,D_800A350C
	sw	$31,32($sp)
	sw	$2,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_800692C0
	addu	$6,$6,12
	.set	macro
	.set	reorder

	sra	$3,$2,16
	li	$2,0x00000001		# 1
	.set	noreorder
	.set	nomacro
	bne	$3,$2,$L901
	move	$4,$0
	.set	macro
	.set	reorder

	lhu	$2,D_800A3528
	li	$5,0x0000007f		# 127
	li	$6,0x0000007f		# 127
	.set	noreorder
	.set	nomacro
	j	$L910
	addu	$2,$2,1
	.set	macro
	.set	reorder

$L901:
	li	$2,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	bne	$3,$2,$L902
	li	$5,0x0000007f		# 127
	.set	macro
	.set	reorder

	lhu	$2,D_800A3528
	li	$6,0x0000007f		# 127
	addu	$2,$2,-1
$L910:
	sh	$2,D_800A3528
	jal	func_8005C650
$L902:
	lh	$2,D_800A3528
	#nop
	.set	noreorder
	.set	nomacro
	bgez	$2,$L904
	li	$2,0x00000002		# 2
	.set	macro
	.set	reorder

	sh	$2,D_800A3528
$L904:
	lhu	$3,D_800A3528
	li	$2,0x55550000		# 1431633920
	ori	$2,$2,0x5556
	sll	$3,$3,16
	sra	$4,$3,16
	mult	$4,$2
	li	$5,0x00100000		# 1048576
	ori	$5,$5,0x0010
	and	$5,$16,$5
	sra	$3,$3,31
	mfhi	$8
	#nop
	#nop
	subu	$3,$8,$3
	sll	$2,$3,1
	addu	$2,$2,$3
	subu	$4,$4,$2
	sh	$4,D_800A3528
	.set	noreorder
	.set	nomacro
	beq	$5,$0,$L905
	li	$4,0x00000002		# 2
	.set	macro
	.set	reorder

	li	$5,0x0000007f		# 127
	.set	noreorder
	.set	nomacro
	jal	func_8005C650
	li	$6,0x0000007f		# 127
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	$L906
	li	$17,-1			# 0xffffffff
	.set	macro
	.set	reorder

$L905:
	li	$2,0x00400000		# 4194304
	ori	$2,$2,0x0040
	and	$2,$16,$2
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L906
	li	$4,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$5,0x0000007f		# 127
	.set	noreorder
	.set	nomacro
	jal	func_8005C650
	li	$6,0x0000007f		# 127
	.set	macro
	.set	reorder

	lh	$5,D_800A3528
	li	$2,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	bne	$5,$2,$L908
	li	$2,-196608			# 0xfffd0000
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	$L906
	li	$17,-1			# 0xffffffff
	.set	macro
	.set	reorder

$L908:
	lw	$4,D_800A3524
	#nop
	lw	$3,20($4)
	ori	$2,$2,0xffff
	li	$17,0x00000001		# 1
	and	$3,$3,$2
	andi	$2,$5,0x0001
	sll	$2,$2,17
	or	$3,$3,$2
	sw	$3,20($4)
$L906:
	move	$2,$17
	lw	$31,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,40
	j	$31
	.end	func_8006D5D4
	.align	2
	.globl	func_8006D74C
	.ent	func_8006D74C
func_8006D74C:
	.frame	$sp,120,$31		# vars= 88, regs= 4/0, args= 16, extra= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	lw	$2,D_800A3514
	lw	$3,D_800A36AC
	subu	$sp,$sp,120
	sw	$17,108($sp)
	move	$17,$4
	sw	$18,112($sp)
	move	$18,$5
	addu	$4,$sp,16
	la	$5,D_800A3518
	sw	$31,116($sp)
	sw	$16,104($sp)
	addu	$2,$2,1
	andi	$3,$3,0x0001
	sll	$16,$3,7
	addu	$16,$16,$3
	sll	$16,$16,3
	addu	$16,$16,$3
	sll	$16,$16,4
	sw	$2,D_800A3514
	la	$2,D_800F7438
	.set	noreorder
	.set	nomacro
	jal	func_8006E390
	addu	$16,$16,$2
	.set	macro
	.set	reorder

	addu	$4,$sp,16
	li	$5,0x00000001		# 1
	.set	noreorder
	.set	nomacro
	jal	func_80069AE4
	move	$6,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_8006D3DC
	addu	$4,$sp,16
	.set	macro
	.set	reorder

	move	$4,$17
	.set	noreorder
	.set	nomacro
	jal	func_8006D5D4
	move	$5,$18
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_8005C6D0
	move	$16,$2
	.set	macro
	.set	reorder

	move	$2,$16
	lw	$31,116($sp)
	lw	$18,112($sp)
	lw	$17,108($sp)
	lw	$16,104($sp)
	addu	$sp,$sp,120
	j	$31
	.end	func_8006D74C
	.align	2
	.globl	func_8006D7FC
	.ent	func_8006D7FC
func_8006D7FC:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	sw	$0,D_800A352C
	.set	noreorder
	.set	nomacro
	j	$31
	li	$2,0x00000001		# 1
	.set	macro
	.set	reorder

	.end	func_8006D7FC
	.align	2
	.globl	func_8006D808
	.ent	func_8006D808
func_8006D808:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_8006D808
	.align	2
	.globl	func_8006DD94
	.ent	func_8006DD94
func_8006DD94:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_8006DD94
	.align	2
	.globl	func_8006DF68
	.ent	func_8006DF68
func_8006DF68:
	.frame	$sp,40,$31		# vars= 8, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	sw	$16,24($sp)
	move	$16,$5
	sw	$17,28($sp)
	move	$17,$0
	addu	$4,$sp,16
	move	$5,$0
	lw	$6,D_800A34FC
	andi	$2,$16,0xffff
	srl	$3,$16,16
	or	$2,$2,$3
	la	$7,D_800A350C
	sw	$31,32($sp)
	sw	$2,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_800692C0
	addu	$6,$6,12
	.set	macro
	.set	reorder

	sra	$2,$2,16
	andi	$2,$2,0x00ff
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L916
	move	$4,$0
	.set	macro
	.set	reorder

	lw	$2,D_800A352C
	li	$5,0x0000007f		# 127
	addu	$2,$2,1
	sw	$2,D_800A352C
	.set	noreorder
	.set	nomacro
	jal	func_8005C650
	li	$6,0x0000007f		# 127
	.set	macro
	.set	reorder

$L916:
	lw	$2,D_800A352C
	li	$3,0x00100000		# 1048576
	ori	$3,$3,0x0010
	and	$3,$16,$3
	andi	$2,$2,0x0001
	sw	$2,D_800A352C
	.set	noreorder
	.set	nomacro
	beq	$3,$0,$L917
	li	$4,0x00000002		# 2
	.set	macro
	.set	reorder

	li	$17,-1			# 0xffffffff
	li	$5,0x0000007f		# 127
	.set	noreorder
	.set	nomacro
	jal	func_8005C650
	li	$6,0x0000007f		# 127
	.set	macro
	.set	reorder

	j	$L918
$L917:
	li	$2,0x00400000		# 4194304
	ori	$2,$2,0x0040
	and	$2,$16,$2
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L918
	li	$4,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$5,0x0000007f		# 127
	.set	noreorder
	.set	nomacro
	jal	func_8005C650
	li	$6,0x0000007f		# 127
	.set	macro
	.set	reorder

	lw	$2,D_800A352C
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L918
	li	$17,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$17,-1			# 0xffffffff
$L918:
	jal	func_8005C6D0
	move	$2,$17
	lw	$31,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,40
	j	$31
	.end	func_8006DF68
	.align	2
	.globl	func_8006E068
	.ent	func_8006E068
func_8006E068:
	.frame	$sp,120,$31		# vars= 88, regs= 4/0, args= 16, extra= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	lw	$2,D_800A3514
	lw	$3,D_800A36AC
	subu	$sp,$sp,120
	sw	$17,108($sp)
	move	$17,$4
	sw	$18,112($sp)
	move	$18,$5
	addu	$4,$sp,16
	la	$5,D_800A3518
	sw	$31,116($sp)
	sw	$16,104($sp)
	addu	$2,$2,1
	andi	$3,$3,0x0001
	sll	$16,$3,7
	addu	$16,$16,$3
	sll	$16,$16,3
	addu	$16,$16,$3
	sll	$16,$16,4
	sw	$2,D_800A3514
	la	$2,g_disp_fb_base
	.set	noreorder
	.set	nomacro
	jal	func_8006E390
	addu	$16,$16,$2
	.set	macro
	.set	reorder

	addu	$4,$sp,16
	li	$5,0x00000001		# 1
	.set	noreorder
	.set	nomacro
	jal	func_80069AE4
	move	$6,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_8006DD94
	addu	$4,$sp,16
	.set	macro
	.set	reorder

	move	$4,$17
	.set	noreorder
	.set	nomacro
	jal	func_8006DF68
	move	$5,$18
	.set	macro
	.set	reorder

	lw	$31,116($sp)
	lw	$18,112($sp)
	lw	$17,108($sp)
	lw	$16,104($sp)
	addu	$sp,$sp,120
	j	$31
	.end	func_8006E068
	.align	2
	.globl	func_8006E10C
	.ent	func_8006E10C
func_8006E10C:
	.frame	$sp,56,$31		# vars= 8, regs= 5/0, args= 24, extra= 0
	.mask	0x800f0000,-8
	.fmask	0x00000000,0
	lw	$2,D_800A3524
	subu	$sp,$sp,56
	sw	$31,48($sp)
	sw	$19,44($sp)
	sw	$18,40($sp)
	sw	$17,36($sp)
	sw	$16,32($sp)
	la	$6,D_800A32D8
	lwl	$3,3($6)
	lwr	$3,0($6)
	lwl	$4,7($6)
	lwr	$4,4($6)
	swl	$3,27($sp)
	swr	$3,24($sp)
	swl	$4,31($sp)
	swr	$4,28($sp)
	lw	$2,32($2)
	lw	$19,D_800A3500
	andi	$2,$2,0x0001
	beq	$2,$0,$L924
	li	$4,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	j	$L925
	li	$5,0x00000060		# 96
	.set	macro
	.set	reorder

$L924:
	li	$4,0x00000002		# 2
	li	$5,0x00000007		# 7
$L925:
	.set	noreorder
	.set	nomacro
	jal	func_80036EA8
	li	$17,0x000000f0		# 240
	.set	macro
	.set	reorder

	lw	$5,D_800A3500
	move	$16,$2
	.set	noreorder
	.set	nomacro
	jal	replay_camera_Init
	move	$4,$16
	.set	macro
	.set	reorder

	jal	game_FrameLoop
	.set	noreorder
	.set	nomacro
	jal	func_80036F28
	move	$4,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	gpu_SetDispMask
	move	$4,$0
	.set	macro
	.set	reorder

	la	$16,D_800F7438
	move	$4,$16
	move	$5,$0
	move	$6,$0
	li	$7,0x00000280		# 640
	.set	noreorder
	.set	nomacro
	jal	gpu_InitDrawEnv
	sw	$17,16($sp)
	.set	macro
	.set	reorder

	addu	$4,$16,16528
	move	$5,$0
	li	$6,0x000000f0		# 240
	li	$7,0x00000280		# 640
	.set	noreorder
	.set	nomacro
	jal	gpu_InitDrawEnv
	sw	$17,16($sp)
	.set	macro
	.set	reorder

	addu	$4,$16,92
	move	$5,$0
	li	$6,0x000000f0		# 240
	li	$7,0x00000280		# 640
	.set	noreorder
	.set	nomacro
	jal	gpu_InitDispEnv
	sw	$17,16($sp)
	.set	macro
	.set	reorder

	addu	$18,$16,16620
	move	$4,$18
	move	$5,$0
	move	$6,$0
	li	$7,0x00000280		# 640
	.set	noreorder
	.set	nomacro
	jal	gpu_InitDispEnv
	sw	$17,16($sp)
	.set	macro
	.set	reorder

	sb	$0,D_800F74A4
	sb	$0,D_800FB534
	sb	$0,D_800F74A5
	sb	$0,D_800FB535
	.set	noreorder
	.set	nomacro
	jal	gpu_DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	addu	$4,$sp,24
	move	$5,$0
	move	$6,$0
	.set	noreorder
	.set	nomacro
	jal	func_8007B4D0
	move	$7,$0
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	gpu_DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	addu	$4,$sp,24
	.set	noreorder
	.set	nomacro
	jal	gpu_LoadImage
	addu	$5,$19,20
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	gpu_DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_8007B9B0
	move	$4,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_8007BC08
	move	$4,$18
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	gpu_SetDispMask
	li	$4,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$2,0x00000001		# 1
	lw	$31,48($sp)
	lw	$19,44($sp)
	lw	$18,40($sp)
	lw	$17,36($sp)
	lw	$16,32($sp)
	addu	$sp,$sp,56
	j	$31
	.end	func_8006E10C
	.align	2
	.globl	func_8006E2A8
	.ent	func_8006E2A8
func_8006E2A8:
	.frame	$sp,32,$31		# vars= 8, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	move	$4,$0
	sw	$31,28($sp)
	.set	noreorder
	.set	nomacro
	jal	gpu_SetDispMask
	sw	$16,24($sp)
	.set	macro
	.set	reorder

	lw	$2,D_800A3518
	la	$16,D_800F7438
	andi	$2,$2,0x0001
	sll	$4,$2,7
	addu	$4,$4,$2
	sll	$4,$4,3
	addu	$4,$4,$2
	sll	$4,$4,4
	.set	noreorder
	.set	nomacro
	jal	func_8007B9B0
	addu	$4,$4,$16
	.set	macro
	.set	reorder

	lw	$2,D_800A3518
	addu	$16,$16,92
	andi	$2,$2,0x0001
	sll	$4,$2,7
	addu	$4,$4,$2
	sll	$4,$4,3
	addu	$4,$4,$2
	sll	$4,$4,4
	.set	noreorder
	.set	nomacro
	jal	func_8007BC08
	addu	$4,$4,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	gpu_DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	la	$5,D_800A32E0
	lwl	$2,3($5)
	lwr	$2,0($5)
	lwl	$3,7($5)
	lwr	$3,4($5)
	swl	$2,19($sp)
	swr	$2,16($sp)
	swl	$3,23($sp)
	swr	$3,20($sp)
	addu	$4,$sp,16
	move	$5,$0
	move	$6,$0
	.set	noreorder
	.set	nomacro
	jal	func_8007B4D0
	move	$7,$0
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	gpu_DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	li	$4,0x00000001		# 1
	move	$5,$0
	move	$6,$0
	.set	noreorder
	.set	nomacro
	jal	disp_SetFramebufferMode
	move	$7,$0
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	gpu_SetDispMask
	li	$4,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$2,0x00000001		# 1
	lw	$31,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,32
	j	$31
	.end	func_8006E2A8
	.align	2
	.globl	func_8006E390
	.ent	func_8006E390
func_8006E390:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$16,16($sp)
	move	$16,$4
	sw	$31,20($sp)
	lw	$4,0($5)
	#nop
	addu	$4,$4,1
	sw	$4,0($5)
	.set	noreorder
	.set	nomacro
	jal	func_80069120
	andi	$4,$4,0x0001
	.set	macro
	.set	reorder

	lw	$3,D_800A34FC
	#nop
	lw	$3,36($3)
	#nop
	sw	$3,4($16)
	lw	$3,4($2)
	#nop
	sw	$3,12($16)
	lw	$3,0($2)
	#nop
	sw	$3,8($16)
	lw	$3,8($2)
	#nop
	sw	$3,16($16)
	lw	$3,16($2)
	#nop
	sw	$3,20($16)
	lw	$3,12($2)
	#nop
	sw	$3,24($16)
	lw	$3,20($2)
	#nop
	sw	$3,28($16)
	lw	$3,24($2)
	#nop
	sw	$3,32($16)
	lw	$3,28($2)
	sw	$2,D_800A3520
	sw	$3,36($16)
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_8006E390
	.align	2
	.globl	func_8006E440
	.ent	func_8006E440
func_8006E440:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$3,0($4)
	li	$2,-1			# 0xffffffff
	.set	noreorder
	.set	nomacro
	beq	$3,$2,$L928
	move	$5,$4
	.set	macro
	.set	reorder

	li	$3,-1			# 0xffffffff
	lw	$2,0($4)
	#nop
	addu	$2,$2,$5
$L934:
	sw	$2,0($4)
	addu	$4,$4,4
	lw	$2,0($4)
	#nop
	.set	noreorder
	.set	nomacro
	bne	$2,$3,$L934
	addu	$2,$2,$5
	.set	macro
	.set	reorder

$L928:
	j	$31
	.end	func_8006E440
	.align	2
	.globl	saMotionSet
	.ent	saMotionSet
saMotionSet:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lbu	$2,0($4)
	lbu	$3,1($4)
	andi	$2,$2,0xfe1f
	sll	$3,$3,7
	addu	$2,$2,$3
	.set	noreorder
	.set	nomacro
	j	$31
	addu	$2,$2,$5
	.set	macro
	.set	reorder

	.end	saMotionSet
	.align	2
	.globl	func_8006E49C
	.ent	func_8006E49C
func_8006E49C:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	li	$3,0x00009c40		# 40000
	sw	$4,0($5)
	addu	$4,$4,$3
	addu	$2,$4,24000
	sw	$2,8($5)
	addu	$2,$4,25080
	sw	$4,4($5)
	addu	$4,$4,26680
	sw	$2,12($5)
	addu	$2,$4,7000
	sw	$2,20($5)
	addu	$2,$4,7600
	sw	$2,24($5)
	addu	$2,$4,7720
	sw	$2,28($5)
	addu	$2,$4,7840
	sw	$4,16($5)
	addu	$4,$4,8112
	sw	$4,44($5)
	addu	$4,$4,$3
	sw	$2,32($5)
	addu	$2,$4,24000
	sw	$2,52($5)
	addu	$2,$4,25080
	sw	$4,48($5)
	addu	$4,$4,26680
	sw	$2,56($5)
	addu	$2,$4,7000
	sw	$2,64($5)
	addu	$2,$4,7600
	sw	$2,68($5)
	addu	$2,$4,7720
	sw	$2,72($5)
	addu	$2,$4,7840
	sw	$2,76($5)
	addu	$2,$4,8112
	.set	noreorder
	.set	nomacro
	j	$31
	sw	$4,60($5)
	.set	macro
	.set	reorder

	.end	func_8006E49C
	.align	2
	.globl	func_8006E534
	.ent	func_8006E534
func_8006E534:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_8006E534
	.align	2
	.globl	func_8006E8AC
	.ent	func_8006E8AC
func_8006E8AC:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	sll	$2,$4,1
	addu	$2,$2,$4
	lw	$3,D_800A35AC
	sll	$2,$2,2
	subu	$2,$2,$4
	sll	$2,$2,2
	.set	noreorder
	.set	nomacro
	j	$31
	addu	$2,$3,$2
	.set	macro
	.set	reorder

	.end	func_8006E8AC
	.align	2
	.globl	func_8006E8CC
	.ent	func_8006E8CC
func_8006E8CC:
	.frame	$sp,32,$31		# vars= 8, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	sw	$16,24($sp)
	sw	$31,28($sp)
	.set	noreorder
	.set	nomacro
	jal	saTan2GaugeInit_80077D00
	move	$16,$4
	.set	macro
	.set	reorder

	lw	$2,32($2)
	#nop
	andi	$2,$2,0x0001
	beq	$2,$0,$L940
	lw	$16,16($16)
	.set	noreorder
	.set	nomacro
	j	$L942
	move	$4,$0
	.set	macro
	.set	reorder

$L940:
	lw	$16,12($16)
	move	$4,$0
$L942:
	li	$2,0x000001e0		# 480
	sh	$2,18($sp)
	li	$2,0x00000280		# 640
	sh	$2,20($sp)
	li	$2,0x00000020		# 32
	sh	$0,16($sp)
	.set	noreorder
	.set	nomacro
	jal	gpu_DrawSync
	sh	$2,22($sp)
	.set	macro
	.set	reorder

	addu	$4,$sp,16
	.set	noreorder
	.set	nomacro
	jal	gpu_LoadImage
	move	$5,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	gpu_DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	lw	$31,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,32
	j	$31
	.end	func_8006E8CC
	.align	2
	.globl	func_8006E950
	.ent	func_8006E950
func_8006E950:
	.frame	$sp,48,$31		# vars= 8, regs= 5/0, args= 16, extra= 0
	.mask	0x800f0000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,48
	sw	$16,24($sp)
	move	$16,$4
	sw	$17,28($sp)
	move	$17,$5
	sw	$31,40($sp)
	sw	$19,36($sp)
	.set	noreorder
	.set	nomacro
	jal	game_FrameLoop
	sw	$18,32($sp)
	.set	macro
	.set	reorder

	li	$4,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	jal	func_80036EA8
	move	$5,$16
	.set	macro
	.set	reorder

	move	$4,$2
	.set	noreorder
	.set	nomacro
	jal	replay_camera_Init
	move	$5,$17
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	game_FrameLoop
	li	$18,0x00000280		# 640
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_8006E440
	move	$4,$17
	.set	macro
	.set	reorder

	lw	$19,8($17)
	move	$4,$0
	li	$2,0x00000180		# 384
	li	$16,0x000001dc		# 476
	sh	$18,16($sp)
	sh	$0,18($sp)
	sh	$2,20($sp)
	.set	noreorder
	.set	nomacro
	jal	gpu_DrawSync
	sh	$16,22($sp)
	.set	macro
	.set	reorder

	addu	$4,$sp,16
	.set	noreorder
	.set	nomacro
	jal	gpu_LoadImage
	move	$5,$19
	.set	macro
	.set	reorder

	move	$4,$0
	li	$2,0x00000170		# 368
	sh	$2,20($sp)
	li	$2,0x00000024		# 36
	sh	$18,16($sp)
	sh	$16,18($sp)
	.set	noreorder
	.set	nomacro
	jal	gpu_DrawSync
	sh	$2,22($sp)
	.set	macro
	.set	reorder

	li	$5,0x00050000		# 327680
	ori	$5,$5,0x9400
	addu	$4,$sp,16
	.set	noreorder
	.set	nomacro
	jal	gpu_LoadImage
	addu	$5,$19,$5
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_8006E8CC
	move	$4,$17
	.set	macro
	.set	reorder

	lw	$31,40($sp)
	lw	$19,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,48
	j	$31
	.end	func_8006E950
	.align	2
	.globl	efc_buki_ZanzouClose
	.ent	efc_buki_ZanzouClose
efc_buki_ZanzouClose:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$16,16($sp)
	move	$16,$4
	sw	$31,20($sp)
	lw	$5,84($16)
	jal	func_8006920C
	lw	$5,88($16)
	.set	noreorder
	.set	nomacro
	jal	func_8006920C
	move	$4,$16
	.set	macro
	.set	reorder

	lw	$5,92($16)
	.set	noreorder
	.set	nomacro
	jal	func_8006920C
	move	$4,$16
	.set	macro
	.set	reorder

	lw	$5,96($16)
	.set	noreorder
	.set	nomacro
	jal	func_8006920C
	move	$4,$16
	.set	macro
	.set	reorder

	lw	$5,100($16)
	.set	noreorder
	.set	nomacro
	jal	func_8006920C
	move	$4,$16
	.set	macro
	.set	reorder

	lw	$5,104($16)
	.set	noreorder
	.set	nomacro
	jal	func_8006920C
	move	$4,$16
	.set	macro
	.set	reorder

	lw	$5,108($16)
	.set	noreorder
	.set	nomacro
	jal	func_8006920C
	move	$4,$16
	.set	macro
	.set	reorder

	lw	$5,112($16)
	.set	noreorder
	.set	nomacro
	jal	func_8006920C
	move	$4,$16
	.set	macro
	.set	reorder

	lw	$5,116($16)
	.set	noreorder
	.set	nomacro
	jal	func_8006920C
	move	$4,$16
	.set	macro
	.set	reorder

	lw	$4,0($16)
	lw	$6,4($16)
	.set	noreorder
	.set	nomacro
	jal	tslGlobalMemFree_8005C2A8
	li	$5,0x00000001		# 1
	.set	macro
	.set	reorder

	lw	$2,4($16)
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	efc_buki_ZanzouClose
	.align	2
	.globl	func_8006EACC
	.ent	func_8006EACC
func_8006EACC:
	.frame	$sp,64,$31		# vars= 40, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	lw	$3,D_800A36AC
	sw	$4,D_800A3548
	lw	$4,D_800A35BC
	subu	$sp,$sp,64
	sw	$31,56($sp)
	sw	$5,D_800A354C
	andi	$3,$3,0x0001
	sll	$2,$3,7
	addu	$2,$2,$3
	sll	$2,$2,3
	addu	$2,$2,$3
	sll	$2,$2,4
	la	$3,D_800F7438
	addu	$2,$2,$3
	sw	$2,D_800A35C0
	li	$2,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	bne	$4,$2,$L946
	andi	$2,$5,0xffff
	.set	macro
	.set	reorder

	sw	$2,D_800A354C
$L946:
	jal	func_8006EC0C
	lw	$5,D_800A35C4
	#nop
	lw	$3,12($5)
	lw	$2,8($5)
	addu	$3,$3,1
	andi	$4,$3,0x0001
	addu	$2,$2,1
	sw	$2,8($5)
	.set	noreorder
	.set	nomacro
	jal	func_8006E8AC
	sw	$3,12($5)
	.set	macro
	.set	reorder

	lw	$3,D_800A35A8
	#nop
	sw	$3,16($sp)
	lw	$3,0($2)
	#nop
	sw	$3,20($sp)
	lw	$3,8($2)
	#nop
	sw	$3,28($sp)
	lw	$3,16($2)
	#nop
	sw	$3,32($sp)
	lw	$3,12($2)
	#nop
	sw	$3,36($sp)
	lw	$3,20($2)
	#nop
	sw	$3,40($sp)
	lw	$3,24($2)
	#nop
	sw	$3,44($sp)
	lw	$3,28($2)
	#nop
	sw	$3,48($sp)
	lw	$4,32($2)
	lhu	$3,D_800A3580
	sw	$2,D_800A35A4
	addu	$3,$3,-2
	sltu	$3,$3,2
	.set	noreorder
	.set	nomacro
	bne	$3,$0,$L947
	sw	$4,52($sp)
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_8006F528
	addu	$4,$sp,16
	.set	macro
	.set	reorder

$L947:
	lh	$2,D_800A3580
	#nop
	sll	$2,$2,2
	lw	$2,D_8009BC1C($2)
	#nop
	.set	noreorder
	.set	nomacro
	jal	$31,$2
	addu	$4,$sp,16
	.set	macro
	.set	reorder

	lw	$2,D_800A35A0
	lw	$31,56($sp)
	addu	$sp,$sp,64
	j	$31
	.end	func_8006EACC
	.align	2
	.globl	func_8006EC0C
	.ent	func_8006EC0C
func_8006EC0C:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	lbu	$3,D_800A3578
	subu	$sp,$sp,24
	li	$2,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	beq	$3,$2,$L950
	sw	$31,16($sp)
	.set	macro
	.set	reorder

	slt	$2,$3,3
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L951
	li	$2,0x00000001		# 1
	.set	macro
	.set	reorder

	beq	$3,$2,$L953
	j	$L954
$L951:
	li	$2,0x00000003		# 3
	.set	noreorder
	.set	nomacro
	beq	$3,$2,$L953
	li	$2,0x00000004		# 4
	.set	macro
	.set	reorder

	beq	$3,$2,$L950
	j	$L954
$L953:
	lhu	$2,D_800A3570
	#nop
	addu	$2,$2,32
	sh	$2,D_800A3570
	sll	$2,$2,16
	sra	$2,$2,16
	slt	$2,$2,488
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L954
	li	$3,0x000001e8		# 488
	.set	macro
	.set	reorder

	lhu	$2,D_800A3584
	lhu	$4,D_800A3578
	sh	$3,D_800A3570
	sh	$2,D_800A3580
	srl	$2,$4,8
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L954
	addu	$2,$4,1
	.set	macro
	.set	reorder

	sh	$2,D_800A3578
	j	$L954
$L950:
	lh	$3,D_800A3570
	li	$2,0x000001e8		# 488
	.set	noreorder
	.set	nomacro
	bne	$3,$2,$L959
	li	$4,0x00000005		# 5
	.set	macro
	.set	reorder

	li	$5,0x0000007f		# 127
	.set	noreorder
	.set	nomacro
	jal	func_8005C650
	li	$6,0x0000007f		# 127
	.set	macro
	.set	reorder

$L959:
	lhu	$2,D_800A3570
	#nop
	addu	$2,$2,-32
	sh	$2,D_800A3570
	sll	$2,$2,16
	bgtz	$2,$L954
	sh	$0,D_800A3570
	sh	$0,D_800A3578
$L954:
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_8006EC0C
	.align	2
	.globl	func_8006ECF4
	.ent	func_8006ECF4
func_8006ECF4:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_8006ECF4
	.align	2
	.globl	func_8006F038
	.ent	func_8006F038
func_8006F038:
	.frame	$sp,40,$31		# vars= 0, regs= 3/0, args= 24, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	sw	$17,28($sp)
	move	$17,$4
	sw	$31,32($sp)
	sw	$16,24($sp)
	lw	$16,20($17)
	.set	noreorder
	.set	nomacro
	jal	initTile
	move	$4,$16
	.set	macro
	.set	reorder

	lhu	$2,D_800A3550
	sh	$0,8($16)
	sh	$0,10($16)
	sb	$2,4($16)
	lhu	$3,D_800A3550
	li	$2,0x00000280		# 640
	sh	$2,12($16)
	sb	$3,5($16)
	lhu	$3,D_800A3550
	move	$4,$16
	li	$5,0x00000001		# 1
	li	$2,0x000000f0		# 240
	sh	$2,14($16)
	.set	noreorder
	.set	nomacro
	jal	gpu_SetSemiTransp
	sb	$3,6($16)
	.set	macro
	.set	reorder

	lw	$4,D_800A374C
	move	$5,$16
	.set	noreorder
	.set	nomacro
	jal	ot_Link
	addu	$16,$16,16
	.set	macro
	.set	reorder

	sw	$16,20($17)
	sw	$0,16($sp)
	lw	$4,24($17)
	li	$5,0x00000001		# 1
	move	$6,$0
	.set	noreorder
	.set	nomacro
	jal	initTexPage
	li	$7,0x00000040		# 64
	.set	macro
	.set	reorder

	lw	$4,D_800A374C
	lw	$5,24($17)
	jal	ot_Link
	lw	$2,24($17)
	#nop
	addu	$2,$2,12
	sw	$2,24($17)
	lw	$31,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,40
	j	$31
	.end	func_8006F038
	.align	2
	.globl	func_8006F100
	.ent	func_8006F100
func_8006F100:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_8006F100
	.align	2
	.globl	func_8006F528
	.ent	func_8006F528
func_8006F528:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_8006F528
	.align	2
	.globl	func_8006F97C
	.ent	func_8006F97C
func_8006F97C:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_8006F97C
	.align	2
	.globl	replay_camera_attack
	.ent	replay_camera_attack
replay_camera_attack:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	replay_camera_attack
	.align	2
	.globl	func_80070C70
	.ent	func_80070C70
func_80070C70:
	.frame	$sp,104,$31		# vars= 56, regs= 6/0, args= 24, extra= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	lw	$3,D_800A35A8
	subu	$sp,$sp,104
	li	$2,0x00000100		# 256
	sw	$31,100($sp)
	sw	$20,96($sp)
	sw	$19,92($sp)
	sw	$18,88($sp)
	sw	$17,84($sp)
	sw	$16,80($sp)
	sw	$0,40($sp)
	sw	$0,48($sp)
	sw	$0,52($sp)
	sw	$2,56($sp)
	sw	$2,60($sp)
	sb	$0,64($sp)
	lw	$19,100($3)
	sw	$0,52($sp)
	sw	$0,48($sp)
	lw	$2,4($19)
	move	$16,$4
	move	$17,$0
	li	$20,0x00000060		# 96
	sw	$2,24($sp)
	addu	$2,$2,12
	sw	$2,28($sp)
 #APP
	addiu $2,$0,1
 #NO_APP
	sw	$2,44($sp)
	lw	$2,16($16)
	addu	$4,$sp,24
	.set	noreorder
	.set	nomacro
	jal	func_8007352C
	sw	$2,32($sp)
	.set	macro
	.set	reorder

	sw	$2,16($16)
	lw	$4,24($sp)
	.set	noreorder
	.set	nomacro
	jal	saMotionSet
	li	$5,0x00000060		# 96
	.set	macro
	.set	reorder

	sw	$0,16($sp)
	lw	$4,24($16)
	li	$5,0x00000001		# 1
	move	$6,$0
	.set	noreorder
	.set	nomacro
	jal	initTexPage
	move	$7,$2
	.set	macro
	.set	reorder

	lw	$4,D_800A374C
	lw	$5,24($16)
	.set	noreorder
	.set	nomacro
	jal	ot_Link
	addu	$4,$4,4
	.set	macro
	.set	reorder

	lw	$2,24($16)
	move	$4,$16
	addu	$5,$sp,72
	li	$6,0x00000001		# 1
	addu	$2,$2,12
	sw	$2,24($16)
	li	$2,0x000000e7		# 231
	sh	$2,76($sp)
	li	$2,0x000000cc		# 204
	sh	$2,72($sp)
	li	$2,0x00000025		# 37
	sh	$2,74($sp)
	li	$2,0x00000001		# 1
	.set	noreorder
	.set	nomacro
	jal	func_80069898
	sh	$2,78($sp)
	.set	macro
	.set	reorder

	lw	$2,0($19)
	li	$18,0x0000000a		# 10
	sw	$2,24($sp)
	addu	$2,$2,72
	sw	$2,28($sp)
	sll	$2,$17,6
$L981:
	sw	$2,48($sp)
	sw	$18,44($sp)
	lw	$2,16($16)
	addu	$4,$sp,24
	.set	noreorder
	.set	nomacro
	jal	func_8007352C
	sw	$2,32($sp)
	.set	macro
	.set	reorder

	sw	$2,16($16)
	lw	$2,24($sp)
	addu	$17,$17,1
	addu	$2,$2,12
	sw	$2,24($sp)
	slt	$2,$17,6
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L981
	sll	$2,$17,6
	.set	macro
	.set	reorder

	lw	$4,0($19)
	move	$5,$20
	.set	noreorder
	.set	nomacro
	jal	saMotionSet
	sw	$4,24($sp)
	.set	macro
	.set	reorder

	sw	$0,16($sp)
	lw	$4,24($16)
	li	$5,0x00000001		# 1
	move	$6,$0
	.set	noreorder
	.set	nomacro
	jal	initTexPage
	move	$7,$2
	.set	macro
	.set	reorder

	lw	$4,D_800A374C
	lw	$5,24($16)
	.set	noreorder
	.set	nomacro
	jal	ot_Link
	addu	$4,$4,40
	.set	macro
	.set	reorder

	lw	$2,24($16)
	#nop
	addu	$2,$2,12
	sw	$2,24($16)
	lw	$2,D_800A35B0
	lh	$4,D_800A3558
	lw	$3,8($19)
	move	$17,$0
	addu	$2,$2,1
	addu	$2,$2,$4
	.set	noreorder
	.set	nomacro
	blez	$2,$L972
	sw	$3,24($sp)
	.set	macro
	.set	reorder

	li	$18,0x00000050		# 80
	move	$19,$0
$L973:
	lbu	$2,D_800A3560($19)
 #APP
	addiu $3,$0,5
	addiu $4,$0,16
	addiu $6,$0,2
	la $5,D_800A3590
 #NO_APP
	#nop
	andi	$2,$2,0x00ff
	beq	$2,$3,$L976
	.set	noreorder
	.set	nomacro
	beq	$2,$4,$L976
	sll	$2,$17,2
	.set	macro
	.set	reorder

	lw	$4,24($sp)
	addu	$2,$2,$5
	lh	$5,D_800A3558
	lw	$3,D_800A35B0
	addu	$4,$4,12
	sw	$4,28($sp)
	lh	$2,0($2)
	addu	$3,$3,$5
	sll	$2,$2,4
	addu	$4,$4,$2
	.set	noreorder
	.set	nomacro
	bne	$3,$0,$L978
	sw	$4,28($sp)
	.set	macro
	.set	reorder

	lw	$2,D_800A35BC
	#nop
	bne	$2,$6,$L977
$L978:
	.set	noreorder
	.set	nomacro
	j	$L979
	sw	$18,48($sp)
	.set	macro
	.set	reorder

$L977:
 #APP
	addiu $2,$0,261
 #NO_APP
	sw	$2,48($sp)
$L979:
 #APP
	addiu $2,$0,1
 #NO_APP
	sw	$2,44($sp)
	lw	$2,16($16)
	addu	$4,$sp,24
	.set	noreorder
	.set	nomacro
	jal	func_8007352C
	sw	$2,32($sp)
	.set	macro
	.set	reorder

	sw	$2,16($16)
$L976:
	addu	$18,$18,364
	lw	$2,D_800A35B0
	lh	$3,D_800A3558
	addu	$17,$17,1
	addu	$2,$2,1
	addu	$2,$2,$3
	slt	$2,$17,$2
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L973
	addu	$19,$19,3
	.set	macro
	.set	reorder

$L972:
	lw	$4,24($sp)
	.set	noreorder
	.set	nomacro
	jal	saMotionSet
	move	$5,$20
	.set	macro
	.set	reorder

	sw	$0,16($sp)
	lw	$4,24($16)
	li	$5,0x00000001		# 1
	move	$6,$0
	.set	noreorder
	.set	nomacro
	jal	initTexPage
	move	$7,$2
	.set	macro
	.set	reorder

	lw	$4,D_800A374C
	lw	$5,24($16)
	.set	noreorder
	.set	nomacro
	jal	ot_Link
	addu	$4,$4,4
	.set	macro
	.set	reorder

	lw	$2,24($16)
	move	$4,$16
	addu	$5,$sp,24
	addu	$2,$2,12
	.set	noreorder
	.set	nomacro
	jal	motion_ShiftControl
	sw	$2,24($16)
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_8006ECF4
	move	$4,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_80072E10
	move	$4,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	saTan3GaugeMain_80073200
	move	$4,$16
	.set	macro
	.set	reorder

	lw	$31,100($sp)
	lw	$20,96($sp)
	lw	$19,92($sp)
	lw	$18,88($sp)
	lw	$17,84($sp)
	lw	$16,80($sp)
	addu	$sp,$sp,104
	j	$31
	.end	func_80070C70
	.align	2
	.globl	motion_ShiftControl
	.ent	motion_ShiftControl
motion_ShiftControl:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	motion_ShiftControl
	.align	2
	.globl	func_80071C20
	.ent	func_80071C20
func_80071C20:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lbu	$2,D_800A3561
	#nop
	lbu	$2,D_8009BC7C($2)
	#nop
	andi	$2,$2,0x0002
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L984
	li	$3,0x00000003		# 3
	.set	macro
	.set	reorder

	li	$3,0x00000009		# 9
$L984:
	.set	noreorder
	.set	nomacro
	j	$31
	move	$2,$3
	.set	macro
	.set	reorder

	.end	func_80071C20
	.align	2
	.globl	func_80071C4C
	.ent	func_80071C4C
func_80071C4C:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_80071C4C
	.align	2
	.globl	func_80072084
	.ent	func_80072084
func_80072084:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	lw	$2,D_800A35A8
	subu	$sp,$sp,24
	sw	$31,16($sp)
	lw	$5,104($2)
	.set	noreorder
	.set	nomacro
	jal	func_800720FC
	move	$6,$0
	.set	macro
	.set	reorder

	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80072084
	.align	2
	.globl	func_800720AC
	.ent	func_800720AC
func_800720AC:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	lw	$2,D_800A35A8
	subu	$sp,$sp,24
	sw	$31,16($sp)
	lw	$5,108($2)
	.set	noreorder
	.set	nomacro
	jal	func_800720FC
	li	$6,0x00000001		# 1
	.set	macro
	.set	reorder

	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_800720AC
	.align	2
	.globl	func_800720D4
	.ent	func_800720D4
func_800720D4:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	lw	$2,D_800A35A8
	subu	$sp,$sp,24
	sw	$31,16($sp)
	lw	$5,112($2)
	.set	noreorder
	.set	nomacro
	jal	func_800720FC
	li	$6,0x00000002		# 2
	.set	macro
	.set	reorder

	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_800720D4
	.align	2
	.globl	func_800720FC
	.ent	func_800720FC
func_800720FC:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_800720FC
	.align	2
	.globl	func_80072BC4
	.ent	func_80072BC4
func_80072BC4:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	sw	$16,16($sp)
	move	$16,$4
	sw	$17,20($sp)
	move	$17,$5
	sw	$31,24($sp)
	.set	noreorder
	.set	nomacro
	jal	initPolyG4
	move	$4,$17
	.set	macro
	.set	reorder

	move	$4,$17
	.set	noreorder
	.set	nomacro
	jal	gpu_SetSemiTransp
	move	$5,$0
	.set	macro
	.set	reorder

	slt	$16,$16,4
	.set	noreorder
	.set	nomacro
	beq	$16,$0,$L991
	li	$3,0x000000fc		# 252
	.set	macro
	.set	reorder

	li	$2,0x00000082		# 130
	sb	$0,4($17)
	sb	$0,5($17)
	sb	$0,6($17)
	sb	$3,12($17)
	sb	$2,13($17)
	sb	$0,14($17)
	sb	$3,20($17)
	sb	$2,21($17)
	sb	$0,22($17)
	lw	$2,D_800A35C4
	#nop
	lw	$2,8($2)
	#nop
	andi	$2,$2,0x0004
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L992
	li	$2,0x000000c3		# 195
	.set	macro
	.set	reorder

	sb	$2,29($17)
	.set	noreorder
	.set	nomacro
	j	$L993
	li	$2,0x0000001e		# 30
	.set	macro
	.set	reorder

$L992:
	sb	$2,29($17)
	li	$2,0x00000050		# 80
$L993:
	sb	$3,28($17)
	.set	noreorder
	.set	nomacro
	j	$L994
	sb	$2,30($17)
	.set	macro
	.set	reorder

$L991:
	li	$3,0x00000040		# 64
	li	$4,0x00000080		# 128
	li	$2,0x00000050		# 80
	sb	$2,20($17)
	li	$2,0x000000a0		# 160
	sb	$2,21($17)
	li	$2,0x00000010		# 16
	sb	$0,4($17)
	sb	$0,5($17)
	sb	$0,6($17)
	sb	$3,12($17)
	sb	$0,13($17)
	sb	$4,14($17)
	sb	$3,22($17)
	sb	$2,28($17)
	sb	$3,29($17)
	sb	$4,30($17)
$L994:
	lw	$4,D_800A374C
	move	$5,$17
	.set	noreorder
	.set	nomacro
	jal	ot_Link
	addu	$4,$4,96
	.set	macro
	.set	reorder

	addu	$2,$17,36
	lw	$31,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,32
	j	$31
	.end	func_80072BC4
	.align	2
	.globl	func_80072CD4
	.ent	func_80072CD4
func_80072CD4:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	sw	$16,16($sp)
	move	$16,$4
	sw	$17,20($sp)
	move	$17,$5
	sw	$31,24($sp)
	.set	noreorder
	.set	nomacro
	jal	initPolyG4
	move	$4,$17
	.set	macro
	.set	reorder

	move	$4,$17
	.set	noreorder
	.set	nomacro
	jal	gpu_SetSemiTransp
	move	$5,$0
	.set	macro
	.set	reorder

	slt	$16,$16,4
	.set	noreorder
	.set	nomacro
	beq	$16,$0,$L996
	li	$2,0x00000010		# 16
	.set	macro
	.set	reorder

	lw	$2,D_800A35C4
	#nop
	lw	$2,8($2)
	#nop
	andi	$2,$2,0x0004
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L997
	li	$3,0x00000046		# 70
	.set	macro
	.set	reorder

	li	$2,0x000000c3		# 195
	sb	$2,5($17)
	li	$2,0x0000001e		# 30
	sb	$2,6($17)
	li	$2,0x000000c8		# 200
	sb	$2,13($17)
	.set	noreorder
	.set	nomacro
	j	$L1002
	li	$3,0x00000032		# 50
	.set	macro
	.set	reorder

$L997:
	li	$2,0x000000c3		# 195
	sb	$2,5($17)
	li	$2,0x00000050		# 80
	sb	$2,6($17)
	li	$2,0x000000dc		# 220
	sb	$2,13($17)
$L1002:
	li	$2,0x000000fc		# 252
	sb	$2,12($17)
	sb	$3,14($17)
	sb	$2,20($17)
	li	$2,0x000000fc		# 252
	sb	$2,4($17)
	li	$2,0x00000082		# 130
	sb	$2,21($17)
	li	$2,0x00000032		# 50
	sb	$2,28($17)
	li	$2,0x00000028		# 40
	sb	$2,29($17)
	li	$2,0x0000000a		# 10
	sb	$0,22($17)
	.set	noreorder
	.set	nomacro
	j	$L1007
	sb	$2,30($17)
	.set	macro
	.set	reorder

$L996:
	li	$3,0x00000030		# 48
	li	$4,0x00000060		# 96
	sb	$2,4($17)
	li	$2,0x00000040		# 64
	sb	$2,14($17)
	li	$2,0x00000018		# 24
	sb	$3,5($17)
	sb	$4,6($17)
	sb	$0,13($17)
	sb	$3,20($17)
	sb	$0,21($17)
	sb	$4,22($17)
	sb	$2,12($17)
	sb	$0,28($17)
	sb	$0,29($17)
	sb	$0,30($17)
$L1007:
	lw	$4,D_800A374C
	move	$5,$17
	.set	noreorder
	.set	nomacro
	jal	ot_Link
	addu	$4,$4,96
	.set	macro
	.set	reorder

	addu	$2,$17,36
	lw	$31,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,32
	j	$31
	.end	func_80072CD4
	.align	2
	.globl	func_80072E10
	.ent	func_80072E10
func_80072E10:
	.frame	$sp,48,$31		# vars= 0, regs= 7/0, args= 16, extra= 0
	.mask	0x803f0000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,48
	sw	$21,36($sp)
	move	$21,$4
	sw	$31,40($sp)
	sw	$20,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80073060
	sw	$16,16($sp)
	.set	macro
	.set	reorder

	lh	$4,D_800A3580
	lw	$2,12($21)
	li	$20,0x00000050		# 80
	li	$18,0x00000032		# 50
	li	$17,0x00000052		# 82
	li	$16,0x00000140		# 320
	move	$5,$2
	sh	$20,8($5)
	sh	$18,10($5)
	sh	$20,16($5)
	sh	$17,18($5)
	sh	$16,24($5)
	sh	$18,26($5)
	sh	$16,32($5)
	.set	noreorder
	.set	nomacro
	jal	func_80072BC4
	sh	$17,34($5)
	.set	macro
	.set	reorder

	lh	$4,D_800A3580
	move	$5,$2
	li	$19,0x00000231		# 561
	sh	$19,8($5)
	sh	$18,10($5)
	sh	$19,16($5)
	sh	$17,18($5)
	sh	$16,24($5)
	sh	$18,26($5)
	sh	$16,32($5)
	.set	noreorder
	.set	nomacro
	jal	func_80072BC4
	sh	$17,34($5)
	.set	macro
	.set	reorder

	lh	$4,D_800A3580
	move	$5,$2
	li	$18,0x00000071		# 113
	sh	$16,8($5)
	sh	$17,10($5)
	sh	$16,16($5)
	sh	$18,18($5)
	sh	$20,24($5)
	sh	$17,26($5)
	sh	$20,32($5)
	.set	noreorder
	.set	nomacro
	jal	func_80072CD4
	sh	$18,34($5)
	.set	macro
	.set	reorder

	lh	$4,D_800A3580
	move	$5,$2
	sh	$16,8($5)
	sh	$17,10($5)
	sh	$16,16($5)
	sh	$18,18($5)
	sh	$19,24($5)
	sh	$17,26($5)
	sh	$19,32($5)
	.set	noreorder
	.set	nomacro
	jal	func_80072CD4
	sh	$18,34($5)
	.set	macro
	.set	reorder

	sw	$2,12($21)
	lw	$31,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,48
	j	$31
	.end	func_80072E10
	.align	2
	.globl	func_80072F30
	.ent	func_80072F30
func_80072F30:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	sw	$16,16($sp)
	move	$16,$4
	sw	$17,20($sp)
	move	$17,$5
	sw	$31,24($sp)
	.set	noreorder
	.set	nomacro
	jal	initTile
	move	$4,$17
	.set	macro
	.set	reorder

	slt	$16,$16,4
	.set	noreorder
	.set	nomacro
	beq	$16,$0,$L1014
	li	$5,0x00000001		# 1
	.set	macro
	.set	reorder

	move	$4,$17
	li	$2,0x0000009e		# 158
	sb	$2,4($17)
	li	$2,0x00000064		# 100
	sb	$2,5($17)
	.set	noreorder
	.set	nomacro
	j	$L1016
	sb	$0,6($17)
	.set	macro
	.set	reorder

$L1014:
	move	$4,$17
	move	$5,$0
	li	$2,0x00000028		# 40
	sb	$2,4($17)
	sb	$2,5($17)
	li	$2,0x00000018		# 24
	sb	$2,6($17)
$L1016:
	jal	gpu_SetSemiTransp
	lw	$4,D_800A374C
	move	$5,$17
	.set	noreorder
	.set	nomacro
	jal	ot_Link
	addu	$4,$4,92
	.set	macro
	.set	reorder

	addu	$2,$17,16
	lw	$31,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,32
	j	$31
	.end	func_80072F30
	.align	2
	.globl	func_80072FCC
	.ent	func_80072FCC
func_80072FCC:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$16,16($sp)
	move	$16,$5
	sw	$31,20($sp)
	.set	noreorder
	.set	nomacro
	jal	initTile
	move	$4,$16
	.set	macro
	.set	reorder

	lh	$2,D_800A3580
	#nop
	slt	$2,$2,4
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L1018
	li	$5,0x00000001		# 1
	.set	macro
	.set	reorder

	move	$4,$16
	li	$2,0x00000046		# 70
	sb	$2,4($16)
	li	$2,0x00000024		# 36
	sb	$2,5($16)
	li	$2,0x0000000a		# 10
	.set	noreorder
	.set	nomacro
	j	$L1020
	sb	$2,6($16)
	.set	macro
	.set	reorder

$L1018:
	move	$4,$16
	move	$5,$0
	sb	$0,4($16)
	sb	$0,5($16)
	sb	$0,6($16)
$L1020:
	jal	gpu_SetSemiTransp
	lw	$4,D_800A374C
	move	$5,$16
	.set	noreorder
	.set	nomacro
	jal	ot_Link
	addu	$4,$4,92
	.set	macro
	.set	reorder

	addu	$2,$16,16
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80072FCC
	.align	2
	.globl	func_80073060
	.ent	func_80073060
func_80073060:
	.frame	$sp,56,$31		# vars= 0, regs= 10/0, args= 16, extra= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,56
	sw	$22,40($sp)
	move	$22,$4
	sw	$31,52($sp)
	sw	$fp,48($sp)
	sw	$23,44($sp)
	sw	$21,36($sp)
	sw	$20,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	sw	$16,16($sp)
	lw	$5,20($22)
	li	$19,0x0000006f		# 111
	li	$18,0x00000032		# 50
	li	$17,0x00000002		# 2
	li	$16,0x0000003f		# 63
$L1022:
	lh	$4,D_800A3580
	sh	$19,8($5)
	addu	$19,$19,32
	sh	$18,10($5)
	sh	$17,12($5)
	.set	noreorder
	.set	nomacro
	jal	func_80072F30
	sh	$16,14($5)
	.set	macro
	.set	reorder

	move	$5,$2
	slt	$2,$19,528
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L1022
	move	$20,$0
	.set	macro
	.set	reorder

	li	$19,0x0000006a		# 106
	lh	$4,D_800A3580
	li	$fp,0x00000005		# 5
	li	$17,0x00000051		# 81
	li	$2,0x00000041		# 65
	li	$16,0x000001e0		# 480
	li	$18,0x00000001		# 1
	sh	$17,8($5)
	sh	$2,10($5)
	sh	$16,12($5)
	.set	noreorder
	.set	nomacro
	jal	func_80072F30
	sh	$18,14($5)
	.set	macro
	.set	reorder

	lh	$4,D_800A3580
	li	$23,0x00000032		# 50
	move	$5,$2
	li	$2,0x00000061		# 97
	sh	$17,8($5)
	sh	$2,10($5)
	sh	$16,12($5)
	.set	noreorder
	.set	nomacro
	jal	func_80072F30
	sh	$18,14($5)
	.set	macro
	.set	reorder

	lh	$4,D_800A3580
	li	$21,0x0000003f		# 63
	move	$5,$2
	li	$2,0x00000050		# 80
	sh	$2,10($5)
	li	$2,0x00000002		# 2
	sh	$17,8($5)
	sh	$16,12($5)
	.set	noreorder
	.set	nomacro
	jal	func_80072F30
	sh	$2,14($5)
	.set	macro
	.set	reorder

	move	$5,$2
$L1030:
	sh	$19,8($5)
	lh	$4,D_800A3580
	addu	$19,$19,33
	subu	$2,$fp,$20
	addu	$20,$20,1
	sh	$23,10($5)
	sh	$2,12($5)
	.set	noreorder
	.set	nomacro
	jal	func_80072FCC
	sh	$21,14($5)
	.set	macro
	.set	reorder

	move	$5,$2
	slt	$2,$20,5
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L1030
	li	$17,0x00000032		# 50
	.set	macro
	.set	reorder

	move	$20,$0
	li	$19,0x00000211		# 529
	li	$18,0x00000005		# 5
	li	$16,0x0000003f		# 63
$L1035:
	sh	$19,8($5)
	lh	$4,D_800A3580
	addu	$19,$19,-32
	subu	$2,$18,$20
	addu	$20,$20,1
	sh	$2,12($5)
	sh	$17,10($5)
	.set	noreorder
	.set	nomacro
	jal	func_80072FCC
	sh	$16,14($5)
	.set	macro
	.set	reorder

	move	$5,$2
	slt	$2,$20,5
	bne	$2,$0,$L1035
	sw	$5,20($22)
	lw	$31,52($sp)
	lw	$fp,48($sp)
	lw	$23,44($sp)
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,56
	j	$31
	.end	func_80073060
	.align	2
	.globl	saTan3GaugeMain_80073200
	.ent	saTan3GaugeMain_80073200
saTan3GaugeMain_80073200:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	saTan3GaugeMain_80073200
	.align	2
	.globl	func_8007352C
	.ent	func_8007352C
func_8007352C:
	.frame	$sp,56,$31		# vars= 0, regs= 10/0, args= 16, extra= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,56
	sw	$20,32($sp)
	move	$20,$4
	sw	$31,52($sp)
	sw	$fp,48($sp)
	sw	$23,44($sp)
	sw	$22,40($sp)
	sw	$21,36($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	sw	$16,16($sp)
	lw	$22,0($20)
	#nop
	lhu	$4,4($22)
	lhu	$5,6($22)
	lw	$21,8($20)
	jal	gpu_CalcClut
	lbu	$3,2($22)
	#nop
	addu	$3,$3,-1
	.set	noreorder
	.set	nomacro
	bltz	$3,$L1043
	andi	$fp,$2,0xffff
	.set	macro
	.set	reorder

	move	$23,$3
	addu	$19,$21,6
$L1044:
	lw	$3,4($20)
	sll	$2,$23,16
	sra	$2,$2,13
	lw	$5,24($20)
	addu	$16,$3,$2
	lh	$7,0($16)
	lh	$6,2($16)
	lw	$3,28($20)
	lbu	$2,6($16)
	lbu	$4,7($16)
	addu	$17,$7,$5
	addu	$18,$6,$3
	addu	$2,$17,$2
	.set	noreorder
	.set	nomacro
	blez	$2,$L1046
	addu	$4,$18,$4
	.set	macro
	.set	reorder

	slt	$2,$17,640
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L1048
	addu	$3,$23,-1
	.set	macro
	.set	reorder

	slt	$2,$18,240
	beq	$2,$0,$L1048
	.set	noreorder
	.set	nomacro
	blez	$4,$L1055
	sll	$2,$3,16
	.set	macro
	.set	reorder

	move	$4,$21
	.set	noreorder
	.set	nomacro
	jal	initSprt
	move	$5,$7
	.set	macro
	.set	reorder

	sh	$fp,8($19)
	sh	$17,2($19)
	sh	$18,4($19)
	lbu	$2,4($16)
	lbu	$3,8($22)
	#nop
	addu	$2,$2,$3
	sb	$2,6($19)
	lbu	$2,5($16)
	lbu	$3,10($22)
	#nop
	addu	$2,$2,$3
	sb	$2,7($19)
	lbu	$2,6($16)
	#nop
	sh	$2,10($19)
	lbu	$2,7($16)
	#nop
	sh	$2,12($19)
	lbu	$2,40($20)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L1051
	move	$4,$21
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	gpu_SetRawTexture
	move	$5,$0
	.set	macro
	.set	reorder

	lbu	$2,41($20)
	#nop
	sb	$2,-2($19)
	lbu	$2,42($20)
	#nop
	sb	$2,-1($19)
	lbu	$2,43($20)
	.set	noreorder
	.set	nomacro
	j	$L1052
	sb	$2,0($19)
	.set	macro
	.set	reorder

$L1051:
	.set	noreorder
	.set	nomacro
	jal	gpu_SetRawTexture
	li	$5,0x00000001		# 1
	.set	macro
	.set	reorder

$L1052:
	lw	$5,16($20)
	.set	noreorder
	.set	nomacro
	jal	gpu_SetSemiTransp
	move	$4,$21
	.set	macro
	.set	reorder

	lw	$2,20($20)
	#nop
	sltu	$2,$2,4102
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L1053
	move	$5,$21
	.set	macro
	.set	reorder

	li	$2,0x00000001		# 1
	la	$4,D_800159A0
	.set	noreorder
	.set	nomacro
	jal	DispSleepMenuTex
	sw	$2,20($20)
	.set	macro
	.set	reorder

 #APP
	move $5, $21
 #NO_APP
$L1053:
	lw	$4,20($20)
	lw	$2,D_800A374C
	addu	$19,$19,20
	addu	$21,$21,20
	sll	$4,$4,2
	.set	noreorder
	.set	nomacro
	jal	ot_Link
	addu	$4,$2,$4
	.set	macro
	.set	reorder

$L1046:
	addu	$3,$23,-1
$L1048:
	sll	$2,$3,16
$L1055:
	.set	noreorder
	.set	nomacro
	bgez	$2,$L1044
	move	$23,$3
	.set	macro
	.set	reorder

$L1043:
	move	$2,$21
	lw	$31,52($sp)
	lw	$fp,48($sp)
	lw	$23,44($sp)
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,56
	j	$31
	.end	func_8007352C
	.align	2
	.globl	func_80073728
	.ent	func_80073728
func_80073728:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	j	$31
	move	$2,$0
	.set	macro
	.set	reorder

	.end	func_80073728
	.align	2
	.globl	func_80073C78
	.ent	func_80073C78
func_80073C78:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_80073C78
	.align	2
	.globl	func_80074220
	.ent	func_80074220
func_80074220:
	.frame	$sp,96,$31		# vars= 48, regs= 6/0, args= 24, extra= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,96
	sw	$20,88($sp)
	move	$20,$4
	sw	$31,92($sp)
	sw	$19,84($sp)
	sw	$18,80($sp)
	sw	$17,76($sp)
	.set	noreorder
	.set	nomacro
	bne	$5,$0,$L1060
	sw	$16,72($sp)
	.set	macro
	.set	reorder

	lw	$16,20($20)
	.set	noreorder
	.set	nomacro
	jal	initTile
	move	$4,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_80069A30
	move	$4,$16
	.set	macro
	.set	reorder

	move	$4,$16
	li	$5,0x00000001		# 1
	li	$2,0x0000003f		# 63
	sh	$2,8($16)
	li	$2,0x00000030		# 48
	sh	$2,10($16)
	li	$2,0x00000202		# 514
	sh	$2,12($16)
	li	$2,0x000000b0		# 176
	.set	noreorder
	.set	nomacro
	jal	gpu_SetSemiTransp
	sh	$2,14($16)
	.set	macro
	.set	reorder

	lw	$4,D_800A374C
	move	$5,$16
	addu	$16,$16,16
	.set	noreorder
	.set	nomacro
	jal	ot_Link
	addu	$4,$4,120
	.set	macro
	.set	reorder

	sw	$16,20($20)
$L1060:
	li	$2,0x0000001f		# 31
	sw	$2,44($sp)
	sb	$0,64($sp)
	sw	$0,40($sp)
	lw	$2,0($20)
	#nop
	lw	$18,56($2)
	move	$17,$0
	sw	$0,48($sp)
	sw	$0,52($sp)
	move	$16,$18
$L1061:
	lw	$2,0($16)
	#nop
	sw	$2,24($sp)
	addu	$2,$2,12
	sw	$2,28($sp)
	lw	$2,16($20)
	addu	$4,$sp,24
	addu	$16,$16,4
	addu	$17,$17,1
	.set	noreorder
	.set	nomacro
	jal	func_8007352C
	sw	$2,32($sp)
	.set	macro
	.set	reorder

	sw	$2,16($20)
	slt	$2,$17,3
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L1061
	move	$5,$0
	.set	macro
	.set	reorder

	lw	$4,0($18)
	.set	noreorder
	.set	nomacro
	jal	saMotionSet
	sw	$4,24($sp)
	.set	macro
	.set	reorder

	sw	$0,16($sp)
	lw	$4,24($20)
	li	$5,0x00000001		# 1
	move	$6,$0
	.set	noreorder
	.set	nomacro
	jal	initTexPage
	move	$7,$2
	.set	macro
	.set	reorder

	lw	$4,D_800A374C
	lw	$5,24($20)
	.set	noreorder
	.set	nomacro
	jal	ot_Link
	addu	$4,$4,124
	.set	macro
	.set	reorder

	lw	$16,8($20)
	lw	$2,24($20)
	move	$4,$16
	addu	$2,$2,12
	.set	noreorder
	.set	nomacro
	jal	initPolyF4
	sw	$2,24($20)
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_80069A8C
	move	$4,$16
	.set	macro
	.set	reorder

	move	$4,$16
	move	$5,$0
	li	$2,0x000000b9		# 185
	li	$19,0x00000122		# 290
	li	$18,0x000000ef		# 239
	sh	$0,8($16)
	sh	$2,10($16)
	sh	$19,12($16)
	sh	$0,14($16)
	sh	$0,16($16)
	sh	$18,18($16)
	sh	$19,20($16)
	.set	noreorder
	.set	nomacro
	jal	gpu_SetSemiTransp
	sh	$18,22($16)
	.set	macro
	.set	reorder

	lw	$4,D_800A374C
	move	$5,$16
	addu	$16,$16,24
	.set	noreorder
	.set	nomacro
	jal	ot_Link
	addu	$4,$4,128
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	initPolyF4
	move	$4,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_80069A8C
	move	$4,$16
	.set	macro
	.set	reorder

	move	$4,$16
	move	$5,$0
	li	$17,0x0000015e		# 350
	li	$2,0x0000027f		# 639
	sh	$2,12($16)
	sh	$2,20($16)
	li	$2,0x00000036		# 54
	sh	$17,8($16)
	sh	$0,10($16)
	sh	$0,14($16)
	sh	$17,16($16)
	sh	$18,18($16)
	.set	noreorder
	.set	nomacro
	jal	gpu_SetSemiTransp
	sh	$2,22($16)
	.set	macro
	.set	reorder

	lw	$4,D_800A374C
	move	$5,$16
	addu	$16,$16,24
	.set	noreorder
	.set	nomacro
	jal	ot_Link
	addu	$4,$4,128
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	initPolyF4
	move	$4,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_80069A8C
	move	$4,$16
	.set	macro
	.set	reorder

	move	$4,$16
	move	$5,$0
	sh	$19,8($16)
	sh	$0,10($16)
	sh	$17,12($16)
	sh	$0,14($16)
	sh	$19,16($16)
	sh	$18,18($16)
	sh	$17,20($16)
	.set	noreorder
	.set	nomacro
	jal	gpu_SetSemiTransp
	sh	$18,22($16)
	.set	macro
	.set	reorder

	lw	$4,D_800A374C
	move	$5,$16
	addu	$16,$16,24
	.set	noreorder
	.set	nomacro
	jal	ot_Link
	addu	$4,$4,128
	.set	macro
	.set	reorder

	sw	$16,8($20)
	lw	$31,92($sp)
	lw	$20,88($sp)
	lw	$19,84($sp)
	lw	$18,80($sp)
	lw	$17,76($sp)
	lw	$16,72($sp)
	addu	$sp,$sp,96
	j	$31
	.end	func_80074220
	.align	2
	.globl	func_80074488
	.ent	func_80074488
func_80074488:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_80074488
	.align	2
	.globl	func_800747D8
	.ent	func_800747D8
func_800747D8:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_800747D8
	.align	2
	.globl	func_80074B18
	.ent	func_80074B18
func_80074B18:
	.frame	$sp,96,$31		# vars= 40, regs= 10/0, args= 16, extra= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,96
	li	$3,0x00000005		# 5
	sw	$31,92($sp)
	sw	$fp,88($sp)
	sw	$23,84($sp)
	sw	$22,80($sp)
	sw	$21,76($sp)
	sw	$20,72($sp)
	sw	$19,68($sp)
	sw	$18,64($sp)
	sw	$17,60($sp)
	sw	$16,56($sp)
	sw	$4,16($sp)
	sw	$5,24($sp)
	.set	noreorder
	.set	nomacro
	beq	$6,$0,$L1068
	sw	$6,32($sp)
	.set	macro
	.set	reorder

	li	$3,0x00000008		# 8
$L1068:
	lw	$4,D_800A36A0
	lw	$7,16($sp)
	lbu	$2,101($4)
	lw	$19,20($7)
	addu	$2,$2,3
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L1069
	sltu	$7,$0,$3
	.set	macro
	.set	reorder

	sw	$3,40($sp)
	sw	$7,48($sp)
	lw	$7,24($sp)
	move	$21,$0
	sll	$22,$7,4
	subu	$22,$22,$7
	sll	$22,$22,4
$L1070:
	lw	$2,4($4)
	lw	$7,48($sp)
	lw	$18,60($2)
	.set	noreorder
	.set	nomacro
	beq	$7,$0,$L1073
	move	$20,$0
	.set	macro
	.set	reorder

	sra	$3,$21,16
	sll	$2,$3,4
	addu	$23,$2,$3
	sll	$fp,$23,1
	addu	$17,$18,2
	addu	$16,$19,10
$L1074:
	.set	noreorder
	.set	nomacro
	jal	initTile
	move	$4,$19
	.set	macro
	.set	reorder

	lbu	$2,6($17)
	#nop
	sb	$2,-6($16)
	lbu	$2,7($17)
	#nop
	sb	$2,-5($16)
	lbu	$2,8($17)
	#nop
	sb	$2,-4($16)
	lhu	$2,2($17)
	#nop
	sh	$2,2($16)
	lhu	$2,4($17)
	move	$4,$19
	move	$5,$0
	.set	noreorder
	.set	nomacro
	jal	gpu_SetSemiTransp
	sh	$2,4($16)
	.set	macro
	.set	reorder

	lw	$7,32($sp)
	#nop
	beq	$7,$0,$L1077
	lhu	$2,0($18)
	#nop
	addu	$2,$2,$22
	sh	$2,-2($16)
	lhu	$2,0($17)
	#nop
	addu	$2,$2,$fp
	.set	noreorder
	.set	nomacro
	j	$L1078
	addu	$2,$2,43
	.set	macro
	.set	reorder

$L1077:
	lhu	$2,0($18)
	#nop
	addu	$2,$2,$22
	sh	$2,-2($16)
	lhu	$2,0($17)
	#nop
	addu	$2,$2,$23
	addu	$2,$2,124
$L1078:
	sh	$2,0($16)
	lw	$7,24($sp)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$7,$0,$L1079
	li	$4,0x0000000b		# 11
	.set	macro
	.set	reorder

	li	$4,0x00000015		# 21
$L1079:
	addu	$16,$16,16
	move	$5,$19
	addu	$19,$19,16
	lw	$2,D_800A374C
	addu	$17,$17,12
	addu	$18,$18,12
	sll	$4,$4,2
	.set	noreorder
	.set	nomacro
	jal	ot_Link
	addu	$4,$2,$4
	.set	macro
	.set	reorder

	lw	$7,40($sp)
	addu	$20,$20,1
	sll	$2,$20,16
	sra	$2,$2,16
	slt	$2,$2,$7
	bne	$2,$0,$L1074
$L1073:
	lw	$4,D_800A36A0
	#nop
	lbu	$2,101($4)
	li	$3,0x00010000		# 65536
	addu	$21,$21,$3
	sra	$3,$21,16
	addu	$2,$2,3
	slt	$3,$3,$2
	bne	$3,$0,$L1070
$L1069:
	lw	$7,16($sp)
	#nop
	sw	$19,20($7)
	lw	$31,92($sp)
	lw	$fp,88($sp)
	lw	$23,84($sp)
	lw	$22,80($sp)
	lw	$21,76($sp)
	lw	$20,72($sp)
	lw	$19,68($sp)
	lw	$18,64($sp)
	lw	$17,60($sp)
	lw	$16,56($sp)
	addu	$sp,$sp,96
	j	$31
	.end	func_80074B18
	.align	2
	.globl	func_80074D2C
	.ent	func_80074D2C
func_80074D2C:
	.frame	$sp,88,$31		# vars= 48, regs= 3/0, args= 24, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,88
	sw	$16,72($sp)
	move	$16,$4
	sw	$31,80($sp)
	sw	$17,76($sp)
	sw	$0,40($sp)
	sb	$0,64($sp)
	lw	$2,0($16)
	#nop
	lw	$2,28($2)
	li	$17,0x0000000c		# 12
	sll	$6,$6,16
	sra	$6,$6,14
	addu	$6,$6,$2
	lw	$3,0($6)
	sll	$2,$5,4
	subu	$2,$2,$5
	sll	$2,$2,4
	sw	$2,48($sp)
	sw	$0,52($sp)
	sw	$3,24($sp)
	addu	$3,$3,12
	.set	noreorder
	.set	nomacro
	beq	$5,$0,$L1084
	sw	$3,28($sp)
	.set	macro
	.set	reorder

	li	$17,0x00000016		# 22
$L1084:
	sw	$17,44($sp)
	lw	$2,16($16)
	addu	$4,$sp,24
	.set	noreorder
	.set	nomacro
	jal	func_8007352C
	sw	$2,32($sp)
	.set	macro
	.set	reorder

	sw	$2,16($16)
	lw	$4,24($sp)
	.set	noreorder
	.set	nomacro
	jal	saMotionSet
	move	$5,$0
	.set	macro
	.set	reorder

	sw	$0,16($sp)
	lw	$4,24($16)
	li	$5,0x00000001		# 1
	move	$6,$0
	.set	noreorder
	.set	nomacro
	jal	initTexPage
	move	$7,$2
	.set	macro
	.set	reorder

	lw	$2,D_800A374C
	lw	$5,24($16)
	sll	$4,$17,2
	.set	noreorder
	.set	nomacro
	jal	ot_Link
	addu	$4,$2,$4
	.set	macro
	.set	reorder

	lw	$2,24($16)
	#nop
	addu	$2,$2,12
	sw	$2,24($16)
	lw	$31,80($sp)
	lw	$17,76($sp)
	lw	$16,72($sp)
	addu	$sp,$sp,88
	j	$31
	.end	func_80074D2C
	.align	2
	.globl	func_80074E08
	.ent	func_80074E08
func_80074E08:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_80074E08
	.align	2
	.globl	func_8007526C
	.ent	func_8007526C
func_8007526C:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	move	$6,$0
	lw	$4,D_800A36A0
	li	$7,0x000000c8		# 200
$L1087:
	lbu	$3,16($4)
	li	$2,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	beq	$3,$2,$L1097
	slt	$2,$3,3
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L1103
	li	$2,0x00000001		# 1
	.set	macro
	.set	reorder

	beq	$3,$2,$L1091
	.set	noreorder
	.set	nomacro
	j	$L1106
	addu	$6,$6,1
	.set	macro
	.set	reorder

$L1103:
	li	$2,0x00000003		# 3
	.set	noreorder
	.set	nomacro
	beq	$3,$2,$L1094
	li	$2,0x00000004		# 4
	.set	macro
	.set	reorder

	beq	$3,$2,$L1099
	.set	noreorder
	.set	nomacro
	j	$L1106
	addu	$6,$6,1
	.set	macro
	.set	reorder

$L1091:
	lhu	$3,8($4)
	lhu	$2,12($4)
	addu	$3,$3,10
	addu	$2,$2,10
	sh	$2,12($4)
	sll	$2,$2,16
	sra	$2,$2,16
	slt	$2,$2,200
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L1090
	sh	$3,8($4)
	.set	macro
	.set	reorder

	lhu	$3,16($4)
	#nop
	srl	$2,$3,8
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L1093
	addu	$2,$3,1
	.set	macro
	.set	reorder

	sh	$2,16($4)
$L1093:
	lhu	$2,24($4)
	lhu	$3,56($4)
	sh	$0,8($4)
	sh	$7,12($4)
	sh	$2,20($4)
	.set	noreorder
	.set	nomacro
	j	$L1090
	sh	$3,60($4)
	.set	macro
	.set	reorder

$L1094:
	lhu	$2,12($4)
	#nop
	addu	$2,$2,10
	sh	$2,12($4)
	sll	$2,$2,16
	sra	$2,$2,16
	slt	$2,$2,200
	bne	$2,$0,$L1090
	lhu	$2,24($4)
	lhu	$3,56($4)
	lhu	$5,16($4)
	sh	$7,8($4)
	sh	$7,12($4)
	sh	$2,20($4)
	srl	$2,$5,8
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L1090
	sh	$3,60($4)
	.set	macro
	.set	reorder

	addu	$2,$5,1
	.set	noreorder
	.set	nomacro
	j	$L1090
	sh	$2,16($4)
	.set	macro
	.set	reorder

$L1097:
	lhu	$2,12($4)
	#nop
	addu	$2,$2,-10
	sh	$2,12($4)
	sll	$2,$2,16
	bgtz	$2,$L1090
	.set	noreorder
	.set	nomacro
	j	$L1107
	sh	$0,8($4)
	.set	macro
	.set	reorder

$L1099:
	lhu	$2,8($4)
	lhu	$3,12($4)
	addu	$2,$2,-10
	addu	$3,$3,-10
	sh	$3,12($4)
	sll	$3,$3,16
	.set	noreorder
	.set	nomacro
	bgtz	$3,$L1090
	sh	$2,8($4)
	.set	macro
	.set	reorder

	sh	$0,8($4)
$L1107:
	sh	$0,12($4)
	sh	$0,16($4)
$L1090:
	addu	$6,$6,1
$L1106:
	slt	$2,$6,2
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L1087
	addu	$4,$4,2
	.set	macro
	.set	reorder

	j	$31
	.end	func_8007526C
	.align	2
	.globl	saTan1GaugeMain
	.ent	saTan1GaugeMain
saTan1GaugeMain:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	saTan1GaugeMain
	.align	2
	.globl	func_80075670
	.ent	func_80075670
func_80075670:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	lw	$7,D_800A36A0
	subu	$sp,$sp,24
	sw	$31,20($sp)
	sw	$16,16($sp)
	sw	$4,24($sp)
	lw	$2,16($7)
	#nop
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L1109
	move	$16,$5
	.set	macro
	.set	reorder

	addu	$4,$sp,24
	sll	$2,$16,2
	addu	$6,$2,64
	addu	$6,$7,$6
	la	$7,D_800A35D0
	.set	noreorder
	.set	nomacro
	jal	func_800692C0
	addu	$7,$2,$7
	.set	macro
	.set	reorder

	sra	$2,$2,16
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L1111
	move	$4,$0
	.set	macro
	.set	reorder

	lw	$3,D_800A36A0
	#nop
	sh	$0,52($3)
	addu	$3,$3,$16
	lbu	$2,104($3)
	#nop
	addu	$2,$2,1
	sb	$2,104($3)
	lw	$7,D_800A36A0
	#nop
	addu	$3,$7,$16
	lbu	$2,104($3)
	li	$5,0x0000007f		# 127
	li	$6,0x0000007f		# 127
	andi	$2,$2,0x0001
	.set	noreorder
	.set	nomacro
	jal	func_8005C650
	sb	$2,104($3)
	.set	macro
	.set	reorder

$L1111:
	lw	$7,D_800A36A0
	#nop
	addu	$2,$7,$16
	lbu	$3,104($2)
	sll	$2,$16,1
	addu	$2,$2,$7
	sh	$3,60($2)
	lw	$4,24($sp)
	sll	$3,$16,4
	li	$2,0x00000040		# 64
	sll	$2,$2,$3
	and	$2,$4,$2
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L1112
	li	$6,0x00000001		# 1
	.set	macro
	.set	reorder

	move	$4,$0
	li	$5,0x00000002		# 2
$L1116:
	sll	$2,$4,16
	addu	$3,$4,1
	move	$4,$3
	sra	$2,$2,15
	addu	$2,$2,$7
	sll	$3,$3,16
	sra	$3,$3,16
	slt	$3,$3,2
	sh	$0,56($2)
	sh	$6,16($2)
	.set	noreorder
	.set	nomacro
	bne	$3,$0,$L1116
	sh	$5,24($2)
	.set	macro
	.set	reorder

	lw	$7,D_800A36A0
	li	$4,0x00000001		# 1
	li	$5,0x0000007f		# 127
	li	$6,0x0000007f		# 127
	addu	$2,$7,$16
	lbu	$3,104($2)
	addu	$2,$16,1
	andi	$2,$2,0x0001
	addu	$2,$7,$2
	addu	$3,$3,1
	andi	$3,$3,0x0001
	.set	noreorder
	.set	nomacro
	j	$L1128
	sb	$3,104($2)
	.set	macro
	.set	reorder

$L1112:
	li	$2,0x00000010		# 16
	sll	$2,$2,$3
	and	$2,$4,$2
	beq	$2,$0,$L1109
	.set	noreorder
	.set	nomacro
	bne	$16,$0,$L1120
	addu	$2,$7,20
	.set	macro
	.set	reorder

	addu	$2,$7,22
$L1120:
	lh	$3,0($2)
	li	$2,0x00000001		# 1
	.set	noreorder
	.set	nomacro
	bne	$3,$2,$L1121
	li	$4,0x00000004		# 4
	.set	macro
	.set	reorder

	move	$4,$0
	li	$5,0x00000003		# 3
$L1125:
	sll	$2,$4,16
	addu	$3,$4,1
	move	$4,$3
	sra	$2,$2,15
	addu	$2,$2,$7
	sll	$3,$3,16
	sra	$3,$3,16
	slt	$3,$3,2
	sh	$0,56($2)
	sh	$5,16($2)
	.set	noreorder
	.set	nomacro
	bne	$3,$0,$L1125
	sh	$0,24($2)
	.set	macro
	.set	reorder

	li	$4,0x00000002		# 2
$L1121:
	li	$5,0x0000007f		# 127
	li	$6,0x0000007f		# 127
$L1128:
	jal	func_8005C650
$L1109:
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80075670
	.align	2
	.globl	func_80075830
	.ent	func_80075830
func_80075830:
	.frame	$sp,80,$31		# vars= 48, regs= 4/0, args= 16, extra= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	lw	$2,D_800A36A0
	subu	$sp,$sp,80
	sw	$18,72($sp)
	move	$18,$4
	sw	$31,76($sp)
	sw	$17,68($sp)
	sw	$16,64($sp)
	sw	$7,32($sp)
	lhu	$4,52($2)
	move	$16,$5
	move	$17,$6
	andi	$4,$4,0x001f
	sll	$4,$4,7
	.set	noreorder
	.set	nomacro
	jal	math_Sin
	addu	$4,$4,511
	.set	macro
	.set	reorder

	sll	$3,$2,1
	addu	$3,$3,$2
	sll	$3,$3,4
	sra	$3,$3,12
	addu	$3,$3,-64
	sb	$3,59($sp)
	sb	$3,58($sp)
	sb	$3,57($sp)
	lw	$2,0($18)
	#nop
	lw	$2,20($2)
	#nop
	lw	$2,84($2)
	#nop
	sw	$2,16($sp)
	addu	$2,$2,12
	sw	$2,20($sp)
	slt	$2,$16,10
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L1131
	li	$2,0x66660000		# 1717960704
	.set	macro
	.set	reorder

	ori	$2,$2,0x6667
	mult	$16,$2
	sra	$2,$16,31
	mfhi	$8
	#nop
	#nop
	sra	$3,$8,1
	subu	$3,$3,$2
	move	$5,$3
	sll	$2,$3,2
	addu	$2,$2,$3
	.set	noreorder
	.set	nomacro
	j	$L1132
	subu	$6,$16,$2
	.set	macro
	.set	reorder

$L1131:
	ori	$2,$2,0x6667
	addu	$4,$16,-10
	mult	$4,$2
	sra	$2,$4,31
	mfhi	$8
	#nop
	#nop
	sra	$3,$8,1
	subu	$3,$3,$2
	move	$5,$3
	sll	$2,$3,2
	addu	$2,$2,$3
	subu	$6,$4,$2
$L1132:
	lw	$3,D_800A36A0
	sll	$2,$17,1
	addu	$4,$2,$3
	lh	$3,28($4)
	sll	$2,$5,16
	sra	$2,$2,16
	.set	noreorder
	.set	nomacro
	bne	$3,$2,$L1133
	sll	$2,$6,16
	.set	macro
	.set	reorder

	lh	$3,32($4)
	sra	$2,$2,16
	.set	noreorder
	.set	nomacro
	bne	$3,$2,$L1133
	li	$2,0x00000001		# 1
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	$L1134
	sb	$2,56($sp)
	.set	macro
	.set	reorder

$L1133:
	sb	$0,56($sp)
$L1134:
	sll	$4,$17,4
	subu	$4,$4,$17
	sll	$4,$4,4
	sll	$3,$5,16
	sra	$3,$3,16
	sll	$2,$3,1
	addu	$2,$2,$3
	sll	$2,$2,3
	addu	$2,$2,$3
	sll	$2,$2,2
	addu	$4,$4,$2
	sll	$2,$6,16
	sra	$2,$2,12
	sw	$4,40($sp)
	.set	noreorder
	.set	nomacro
	beq	$17,$0,$L1135
	sw	$2,44($sp)
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	$L1137
	li	$2,0x00000013		# 19
	.set	macro
	.set	reorder

$L1135:
	li	$2,0x00000009		# 9
$L1137:
	sw	$2,36($sp)
	lw	$2,16($18)
	addu	$4,$sp,16
	.set	noreorder
	.set	nomacro
	jal	func_8007352C
	sw	$2,24($sp)
	.set	macro
	.set	reorder

	sw	$2,16($18)
	lw	$31,76($sp)
	lw	$18,72($sp)
	lw	$17,68($sp)
	lw	$16,64($sp)
	addu	$sp,$sp,80
	j	$31
	.end	func_80075830
	.align	2
	.globl	func_800759D0
	.ent	func_800759D0
func_800759D0:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_800759D0
	.align	2
	.globl	func_80075F80
	.ent	func_80075F80
func_80075F80:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_80075F80
	.align	2
	.globl	func_8007636C
	.ent	func_8007636C
func_8007636C:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_8007636C
	.align	2
	.globl	func_800768DC
	.ent	func_800768DC
func_800768DC:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_800768DC
	.align	2
	.globl	func_80076D74
	.ent	func_80076D74
func_80076D74:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_80076D74
	.align	2
	.globl	func_80076FF8
	.ent	func_80076FF8
func_80076FF8:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$16,16($sp)
	move	$16,$4
	sw	$31,20($sp)
	lw	$5,20($16)
	jal	func_8006920C
	lw	$5,24($16)
	.set	noreorder
	.set	nomacro
	jal	func_8006920C
	move	$4,$16
	.set	macro
	.set	reorder

	lw	$5,28($16)
	.set	noreorder
	.set	nomacro
	jal	func_8006920C
	move	$4,$16
	.set	macro
	.set	reorder

	lw	$5,32($16)
	.set	noreorder
	.set	nomacro
	jal	func_8006920C
	move	$4,$16
	.set	macro
	.set	reorder

	lw	$5,36($16)
	.set	noreorder
	.set	nomacro
	jal	func_8006920C
	move	$4,$16
	.set	macro
	.set	reorder

	lw	$5,40($16)
	.set	noreorder
	.set	nomacro
	jal	func_8006920C
	move	$4,$16
	.set	macro
	.set	reorder

	lw	$5,44($16)
	.set	noreorder
	.set	nomacro
	jal	func_8006920C
	move	$4,$16
	.set	macro
	.set	reorder

	lw	$5,48($16)
	.set	noreorder
	.set	nomacro
	jal	func_8006920C
	move	$4,$16
	.set	macro
	.set	reorder

	lw	$5,52($16)
	.set	noreorder
	.set	nomacro
	jal	func_8006920C
	move	$4,$16
	.set	macro
	.set	reorder

	lw	$5,56($16)
	.set	noreorder
	.set	nomacro
	jal	func_8006920C
	move	$4,$16
	.set	macro
	.set	reorder

	lw	$2,4($16)
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80076FF8
	.align	2
	.globl	func_80077098
	.ent	func_80077098
func_80077098:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	sll	$2,$4,1
	addu	$2,$2,$4
	lw	$3,D_800A35D8
	sll	$2,$2,2
	subu	$2,$2,$4
	sll	$2,$2,2
	.set	noreorder
	.set	nomacro
	j	$31
	addu	$2,$3,$2
	.set	macro
	.set	reorder

	.end	func_80077098
	.align	2
	.globl	func_800770B8
	.ent	func_800770B8
func_800770B8:
	.frame	$sp,64,$31		# vars= 24, regs= 5/0, args= 16, extra= 0
	.mask	0x800f0000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,64
	sw	$19,52($sp)
	move	$19,$5
	sw	$18,48($sp)
	move	$18,$6
	sw	$16,40($sp)
	move	$16,$4
	sw	$17,44($sp)
	addu	$17,$16,88
	sw	$31,56($sp)
 #APP
 #NO_APP
	lw	$4,D_800A374C
	li	$5,0x00001008		# 4104
	sh	$0,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_8007B844
	sh	$0,18($sp)
	.set	macro
	.set	reorder

	sw	$16,D_800A35D8
	jal	snd_StopAll
	li	$4,0x00000006		# 6
	.set	noreorder
	.set	nomacro
	jal	func_8006E950
	move	$5,$17
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_80076FF8
	move	$4,$17
	.set	macro
	.set	reorder

	lw	$5,D_800A35D8
	.set	noreorder
	.set	nomacro
	jal	func_8006E49C
	move	$4,$2
	.set	macro
	.set	reorder

	move	$3,$17
	move	$17,$2
	move	$8,$0
	move	$6,$0
	li	$10,-1			# 0xffffffff
	li	$9,0x00000001		# 1
	addu	$11,$sp,16
	sw	$17,D_800A36A0
	sw	$3,4($17)
	sw	$0,48($17)
	sh	$0,52($17)
$L1146:
	lw	$5,D_800A36A0
	sll	$4,$8,16
	sra	$4,$4,16
	sll	$2,$4,1
	sll	$3,$4,2
	addu	$2,$2,$5
	sh	$0,16($2)
	sh	$0,8($2)
	sh	$0,12($2)
	sh	$0,20($2)
	sh	$0,60($2)
	la	$2,D_800A35D0
	addu	$2,$3,$2
	sh	$0,2($2)
	sh	$0,0($2)
	addu	$2,$3,$5
	addu	$5,$5,$4
	sh	$0,66($2)
	sh	$0,64($2)
	sb	$8,104($5)
	lw	$2,D_800A36A0
	addu	$3,$3,$4
	sll	$3,$3,1
	addu	$2,$2,$3
	addu	$7,$2,106
	addu	$5,$2,126
$L1149:
	sll	$2,$6,16
	addu	$4,$6,1
	move	$6,$4
	sra	$2,$2,15
	addu	$3,$2,$7
	addu	$2,$2,$5
	sll	$4,$4,16
	sra	$4,$4,16
	slt	$4,$4,5
	sh	$10,0($3)
	.set	noreorder
	.set	nomacro
	bne	$4,$0,$L1149
	sh	$0,0($2)
	.set	macro
	.set	reorder

	move	$6,$0
	sll	$3,$8,16
	sra	$3,$3,16
	lw	$4,D_800A36A0
	sll	$2,$3,2
	addu	$2,$2,$3
	sll	$7,$2,1
	sll	$3,$3,1
	addu	$5,$3,$11
	li	$2,0x00000005		# 5
	addu	$3,$3,$4
	sh	$0,92($3)
	sh	$2,96($3)
	addu	$2,$6,$7
$L1163:
	sll	$2,$2,16
	sra	$3,$2,16
	lbu	$2,D_8009BCE4($3)
	#nop
	andi	$4,$2,0x00f2
	sll	$2,$9,$3
	and	$2,$18,$2
	sb	$4,D_8009BCE4($3)
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L1156
	ori	$2,$4,0x0001
	.set	macro
	.set	reorder

	sb	$2,D_8009BCE4($3)
	lhu	$2,0($5)
	#nop
	addu	$2,$2,1
	sh	$2,0($5)
$L1156:
	addu	$2,$6,1
	move	$6,$2
	sll	$2,$2,16
	sra	$2,$2,16
	slt	$2,$2,10
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L1163
	addu	$2,$6,$7
	.set	macro
	.set	reorder

	addu	$2,$8,1
	move	$8,$2
	sll	$2,$2,16
	sra	$2,$2,16
	slt	$2,$2,2
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L1146
	move	$6,$0
	.set	macro
	.set	reorder

	lw	$4,D_800A36A0
	#nop
	sw	$0,32($4)
	sw	$0,28($4)
	lh	$2,16($sp)
	lh	$3,18($sp)
	move	$6,$2
	slt	$2,$2,$3
	.set	noreorder
	.set	nomacro
	beq	$2,$0,$L1159
	move	$5,$3
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	$L1162
	addu	$2,$6,-3
	.set	macro
	.set	reorder

$L1159:
	addu	$2,$5,-3
$L1162:
	sb	$2,100($4)
	lw	$3,D_800A36A0
	#nop
	lbu	$2,100($3)
	#nop
	sltu	$2,$2,3
	.set	noreorder
	.set	nomacro
	bne	$2,$0,$L1161
	li	$2,0x00000002		# 2
	.set	macro
	.set	reorder

	sb	$2,100($3)
$L1161:
	lw	$4,D_800A36A0
	#nop
	sw	$19,0($4)
	sb	$0,101($4)
	lw	$4,D_800A36A0
	li	$2,0x00000001		# 1
	sb	$2,103($4)
	lw	$4,D_800A36A0
	#nop
	lbu	$2,103($4)
	#nop
	sll	$2,$2,1
	lbu	$2,D_8009BD21($2)
	li	$16,0x00000001		# 1
	sb	$2,102($4)
	sb	$16,D_800A35DC
	lw	$31,56($sp)
	lw	$19,52($sp)
	lw	$18,48($sp)
	lw	$17,44($sp)
	lw	$16,40($sp)
	addu	$sp,$sp,64
	j	$31
	.end	func_800770B8
	.align	2
	.globl	func_80077374
	.ent	func_80077374
func_80077374:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_80077374
	.align	2
	.globl	func_80077724
	.ent	func_80077724
func_80077724:
	.frame	$sp,64,$31		# vars= 40, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	lw	$3,D_800A36AC
	lw	$7,D_800A36A0
	subu	$sp,$sp,64
	sw	$16,56($sp)
	move	$16,$5
	sw	$31,60($sp)
	andi	$3,$3,0x0001
	sll	$2,$3,7
	addu	$2,$2,$3
	sll	$2,$2,3
	addu	$2,$2,$3
	lw	$5,48($7)
	lhu	$6,52($7)
	sll	$2,$2,4
	la	$3,D_800F7438
	addu	$2,$2,$3
	sw	$2,36($7)
	addu	$5,$5,1
	andi	$4,$5,0x0001
	addu	$6,$6,1
	sh	$6,52($7)
	.set	noreorder
	.set	nomacro
	jal	func_80077098
	sw	$5,48($7)
	.set	macro
	.set	reorder

	lw	$3,D_800A36A0
	#nop
	lw	$4,4($3)
	sw	$2,44($3)
	sw	$4,16($sp)
	lw	$3,0($2)
	#nop
	sw	$3,20($sp)
	lw	$3,4($2)
	#nop
	sw	$3,24($sp)
	lw	$3,8($2)
	#nop
	sw	$3,28($sp)
	lw	$3,16($2)
	#nop
	sw	$3,32($sp)
	lw	$3,12($2)
	#nop
	sw	$3,36($sp)
	lw	$3,20($2)
	#nop
	sw	$3,40($sp)
	lw	$3,24($2)
	#nop
	sw	$3,44($sp)
	lw	$3,28($2)
	#nop
	sw	$3,48($sp)
	lw	$2,32($2)
	addu	$5,$sp,16
	move	$4,$16
	.set	noreorder
	.set	nomacro
	jal	func_80077374
	sw	$2,52($sp)
	.set	macro
	.set	reorder

	lw	$31,60($sp)
	lw	$16,56($sp)
	addu	$sp,$sp,64
	j	$31
	.end	func_80077724
	.align	2
	.globl	func_80077820
	.ent	func_80077820
func_80077820:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	la	$5,D_8009BD24
	sw	$31,16($sp)
	jal	func_80068F70
	li	$4,0x00000001		# 1
	move	$5,$0
	move	$6,$0
	.set	noreorder
	.set	nomacro
	jal	disp_SetFramebufferMode
	move	$7,$0
	.set	macro
	.set	reorder

	sw	$0,D_800A35E4
	.set	noreorder
	lw	$31,16($sp)
	li	$2,0x00000001		# 1
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80077820
	.align	2
	.globl	func_80077860
	.ent	func_80077860
func_80077860:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	jal	func_80069250
	li	$3,0x00000001		# 1
	.set	noreorder
	.set	nomacro
	bne	$2,$3,$L1169
	move	$2,$0
	.set	macro
	.set	reorder

	sw	$0,D_800A35E4
	li	$2,0x00000001		# 1
$L1169:
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80077860
	.align	2
	.globl	func_80077894
	.ent	func_80077894
func_80077894:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$16,16($sp)
	sw	$31,20($sp)
	.set	noreorder
	.set	nomacro
	jal	func_800693CC
	move	$16,$0
	.set	macro
	.set	reorder

	move	$5,$2
	.set	noreorder
	.set	nomacro
	bltz	$5,$L1171
	li	$2,-16			# 0xfffffff0
	.set	macro
	.set	reorder

	la	$4,D_8009BD38
	lw	$3,0($4)
	li	$16,0x00000001		# 1
	sw	$0,D_800A35E4
	and	$3,$3,$2
	andi	$2,$5,0x000f
	or	$3,$3,$2
	.set	noreorder
	.set	nomacro
	j	$L1172
	sw	$3,0($4)
	.set	macro
	.set	reorder

$L1171:
	li	$2,-2			# 0xfffffffe
	.set	noreorder
	.set	nomacro
	bne	$5,$2,$L1174
	move	$2,$16
	.set	macro
	.set	reorder

	li	$16,-1			# 0xffffffff
$L1172:
	move	$2,$16
$L1174:
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80077894
	.align	2
	.globl	func_80077904
	.ent	func_80077904
func_80077904:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$2,D_8009BD38
	sw	$0,D_800A35E4
	andi	$2,$2,0x000f
	sll	$2,$2,1
	lbu	$3,D_8009BD59($2)
	#nop
	sw	$3,D_800A35E0
	lbu	$2,D_8009BD58($2)
	j	$31
	.end	func_80077904
	.align	2
	.globl	func_80077940
	.ent	func_80077940
func_80077940:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	li	$2,0x003f0000		# 4128768
	ori	$2,$2,0xf000
	andi	$3,$4,0x03ff
	and	$2,$4,$2
	srl	$2,$2,2
	addu	$3,$3,$2
	li	$2,0x01000000		# 16777216
	and	$2,$4,$2
	srl	$2,$2,4
	addu	$3,$3,$2
	li	$2,0x04000000		# 67108864
	and	$4,$4,$2
	srl	$4,$4,5
	addu	$3,$3,$4
	sw	$3,D_800A35E8
	j	$31
	.end	func_80077940
	.align	2
	.globl	func_80077984
	.ent	func_80077984
func_80077984:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	lw	$5,D_800A35E0
	lw	$7,D_800A35E8
	subu	$sp,$sp,24
	la	$6,D_8009BD24
	sw	$31,16($sp)
	jal	func_8006E534
	li	$4,0x00000001		# 1
	move	$5,$0
	move	$6,$0
	.set	noreorder
	.set	nomacro
	jal	disp_SetFramebufferMode
	move	$7,$0
	.set	macro
	.set	reorder

	.set	noreorder
	lw	$31,16($sp)
	li	$2,0x00000001		# 1
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80077984
	.align	2
	.globl	func_800779C8
	.ent	func_800779C8
func_800779C8:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,20($sp)
	.set	noreorder
	.set	nomacro
	jal	func_8006EACC
	sw	$16,16($sp)
	.set	macro
	.set	reorder

	move	$16,$2
	.set	noreorder
	.set	nomacro
	beq	$16,$0,$L1180
	move	$2,$16
	.set	macro
	.set	reorder

	jal	func_8005B6FC
	move	$2,$16
$L1180:
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_800779C8
	.align	2
	.globl	saTanMainDispGnd_80077A04
	.ent	saTanMainDispGnd_80077A04
saTanMainDispGnd_80077A04:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	sw	$0,D_800A35E4
	jal	func_8006D74C
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	saTanMainDispGnd_80077A04
	.align	2
	.globl	func_80077A28
	.ent	func_80077A28
func_80077A28:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	li	$4,0x00000001		# 1
	move	$5,$0
	move	$6,$0
	sw	$31,16($sp)
	sw	$0,D_800A35E4
	.set	noreorder
	.set	nomacro
	jal	disp_SetFramebufferMode
	move	$7,$0
	.set	macro
	.set	reorder

	jal	func_8006D7FC
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80077A28
	.align	2
	.globl	saTan2InfoInit_80077A60
	.ent	saTan2InfoInit_80077A60
saTan2InfoInit_80077A60:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	jal	func_8006E068
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	saTan2InfoInit_80077A60
	.align	2
	.globl	func_80077A80
	.ent	func_80077A80
func_80077A80:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	lw	$6,D_800A35E8
	subu	$sp,$sp,24
	la	$5,D_8009BD24
	sw	$31,16($sp)
	jal	func_800770B8
	li	$4,0x00000001		# 1
	move	$5,$0
	move	$6,$0
	.set	noreorder
	.set	nomacro
	jal	disp_SetFramebufferMode
	move	$7,$0
	.set	macro
	.set	reorder

	.set	noreorder
	lw	$31,16($sp)
	li	$2,0x00000001		# 1
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80077A80
	.align	2
	.globl	saTan2InfoInit_80077AC0
	.ent	saTan2InfoInit_80077AC0
saTan2InfoInit_80077AC0:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	jal	func_80077724
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	saTan2InfoInit_80077AC0
	.align	2
	.globl	func_80077AE0
	.ent	func_80077AE0
func_80077AE0:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	jal	func_8006E10C
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80077AE0
	.align	2
	.globl	func_80077B00
	.ent	func_80077B00
func_80077B00:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	jal	func_8006E2A8
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80077B00
	.align	2
	.globl	saTan2GaugeInit_80077B20
	.ent	saTan2GaugeInit_80077B20
saTan2GaugeInit_80077B20:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	li	$2,0x00000001		# 1
	sw	$2,D_800A35E4
	j	$31
	.end	saTan2GaugeInit_80077B20
