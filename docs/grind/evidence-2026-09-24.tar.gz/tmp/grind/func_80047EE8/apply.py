import io
p='src/text1b.c'
src=io.open(p,encoding='utf-8',newline='').read()
cand=io.open('memory/grind/func_80047EE8/candidate.c',encoding='utf-8',newline='').read()
body=cand[cand.index('void func_80047EE8('):]
if not body.endswith('\n'): body+='\n'
old='INCLUDE_ASM("asm/funcs", func_80047EE8);\n'
assert src.count(old)==1, src.count(old)
src=src.replace(old, body)
io.open(p,'w',encoding='utf-8',newline='').write(src)
print('applied, body lines', body.count('\n'))
