# func_800307D0 (cpu_check_tubazeri_2) — live-chassis residual, s11 (labelled s8), 2026-08-25

Body measured: memory/grind/func_800307D0/rejected/floor1-named-pointer-head-score1.c
(the s2-s7 reviewer-PASSed, ban-free, named-base-pointer form), applied to
src/code6cac_b.c:1159 in place of INCLUDE_ASM.

sandbox func_800307D0 --disable all:
  {"score": 1, "target_insns": 76, "build_insns": 76, "scorable": true,
   "rules_dropped": 0, "cheat_asm_stripped": 48}

Instruction-level residual (objdump of tmp/sandbox/func_800307D0/code6cac_b.o
vs asm/funcs/func_800307D0.s), the ONLY difference in 76/76 insns:

  build   18c0:  02029021  addu  s2, s0, v0      <- base-first
  target  80030834: 21905000  addu  $s2, $v0, $s0 <- index-first

Surrounding context is byte-identical on both sides, including the duplicated
`sll v0, s1, 1` on the two join paths (.L80030830 / .L80030834) and the
following `lh s3, 0x332(s2)`.

Conclusion: on the CURRENT chassis (2026-08-25) the honest, ban-free floor is
exactly 1 and the residual is exactly the idx25 commutative-operand-order
instruction that s2-s10 identified. Nothing about the chassis has moved.
