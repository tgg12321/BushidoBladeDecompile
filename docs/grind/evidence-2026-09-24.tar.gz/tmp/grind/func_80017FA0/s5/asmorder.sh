#!/bin/bash
cd "/mnt/c/Users/Trenton/Desktop/Bushido Blade 2 Decompile"
cat > /tmp/t1.s <<'ASM'
D_1F800000 = 0x1F800000
.text
.globl t
t:
sw $2, 0x1F800064($5)
sw $2, D_1F800000+0x64($5)
lw $2, 0x1F800064($5)
ASM
mipsel-linux-gnu-as -march=r3000 -mtune=r3000 -no-pad-sections -O1 -G0 -o /tmp/t1.o /tmp/t1.s
mipsel-linux-gnu-objdump -d /tmp/t1.o | tail -14
