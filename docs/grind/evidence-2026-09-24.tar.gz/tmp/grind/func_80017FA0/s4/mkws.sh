#!/bin/bash
set -e
cd "/mnt/c/Users/Trenton/Desktop/Bushido Blade 2 Decompile"
WS=tmp/perm_17fa0
mkdir -p $WS

# base.c = preprocessed full TU (correct codegen context), candidate applied to src
mipsel-linux-gnu-cpp -Iinclude -undef -Wall -lang-c -fno-builtin \
  -Dmips -D__GNUC__=2 -D__OPTIMIZE__ -D__mips__ -D__mips -Dpsx -D__psx__ -D__psx \
  -D_PSYQ -D__EXTENSIONS__ -D_MIPSEL -D_LANGUAGE_C -DLANGUAGE_C \
  src/code6cac.c > $WS/base.pre.c
# pycparser fix: GameObj is used in two prototypes but never declared in this TU
# (cc1 recovers; pycparser does not). A forward typedef is codegen-neutral.
{ echo 'typedef struct GameObj GameObj;'; cat $WS/base.pre.c; } > $WS/base.c

cat > $WS/settings.toml <<'EOF'
func_name = "func_80017FA0"
compiler_type = "gcc"

[weight_overrides]
perm_inline = 0.0
EOF

cat > $WS/compile.sh <<'EOF'
#!/bin/bash
set -e
cd "/mnt/c/Users/Trenton/Desktop/Bushido Blade 2 Decompile"
IN="$1"
OUT="$3"
TMPS=$(mktemp /tmp/f17faXXXXXX.s)
trap "rm -f $TMPS $TMPS.fn.s" EXIT
tools/gcc-2.7.2/build/cc1 -O2 -G0 -funsigned-char -quiet -mcpu=3000 \
    -mips1 -mno-abicalls -fno-builtin -w -mel "$IN" -o /dev/stdout 2>/dev/null \
  | python3 tools/prologue_fix.py \
  | python3 tools/maspsx/maspsx.py --expand-div --aspsx-version=2.34 \
      --sdata-syms=sdata_syms.txt --sdata-funcs=sdata_funcs.txt \
      --sdata-exclude=sdata_exclude.txt --expand-lb \
      --expand-lb-funcs=expand_lb_funcs.txt --multu-funcs=multu_funcs.txt \
      --expand-dest-funcs=expand_dest_funcs.txt \
      --label-nop-funcs=maspsx_label_nop_funcs.txt \
  | python3 tools/multu_pad.py --funcs multu_pad_funcs.txt > "$TMPS"
awk '
/^[ \t]*\.ent[ \t]+func_80017FA0$/ {p=1}
p {print}
p && /^[ \t]*\.end[ \t]+func_80017FA0$/ {exit}
' "$TMPS" > "$TMPS.fn.s"
{ echo "D_1F800004 = 0x1F800004"; cat "$TMPS.fn.s"; } \
  | mipsel-linux-gnu-as -Iinclude -march=r3000 -mtune=r3000 \
      -no-pad-sections -O1 -G0 -o "$OUT"
EOF
chmod +x $WS/compile.sh

sed 's/^.set gp=64$//' tools/decomp-permuter/prelude.inc > $WS/prelude_r3k.inc
{ cat $WS/prelude_r3k.inc; echo "D_1F800004 = 0x1F800004"; cat asm/funcs/func_80017FA0.s; } > $WS/target.s
mipsel-linux-gnu-as -Iinclude -march=r3000 -mtune=r3000 -no-pad-sections \
  -O1 -G0 -o $WS/target.o $WS/target.s

bash $WS/compile.sh $WS/base.c -o $WS/base.o
echo "=== base vs target insn counts ==="
for f in $WS/base.o $WS/target.o; do
  echo -n "$f: "
  mipsel-linux-gnu-objdump -d "$f" | awk '/<func_80017FA0>:/{p=1;next} /^[0-9a-f]+ </{p=0} p' | grep -c '\t'
done
