import sys,re
D="tmp/grind/func_80060A68/s10/"
def norm(l):
    l=l.strip().replace('$','')
    l=re.sub(r'-?0x[0-9a-fA-F]+',lambda m:str(int(m.group(0),16)),l)
    l=re.sub(r'\s+',' ',l).replace(', ',',')
    return l
tgt=[norm(l) for l in open(D+"target.txt") if l.strip()]
cur=[norm(l) for l in open(D+sys.argv[1]+".dis") if l.strip()]
for i in range(max(len(tgt),len(cur))):
    a=tgt[i] if i<len(tgt) else '---'
    b=cur[i] if i<len(cur) else '---'
    if a!=b: print(f"{i+1:3d}  T:{a:36s} C:{b}")
print("len tgt",len(tgt),"cur",len(cur))
