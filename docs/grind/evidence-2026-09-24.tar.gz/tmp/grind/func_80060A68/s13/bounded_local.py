"""s13 bounded local-alloc inverse driver.

tools/ra_solver/inverse.py's LocalBackend.atoms() builds ALLOC_ORDER atoms with
`for perm in itertools.permutations(base)` and only then tests `len(base) <= 6`
INSIDE the loop -- with 25 quantities in func_80060A68's block 0 that is 25!
iterations, which is the "100% CPU, never finishes depth 1" tool wall recorded in
the 2026-08-30 campaign note.  This driver reuses the SAME backend (same forward
model, same _alloc, same _pri) and simply generates the atom list without the
permutation class, so depth 1 and depth 2 terminate.
"""
import sys, json, itertools, time
sys.path.insert(0, "tools/ra_solver")
import inverse as I

B = I.LocalBackend("tmp/ra_solver_work/text1b.local.json",
                   "func_80060A68", 0,
                   sugg="tmp/ra_solver_work/text1b.sugg.json")
GOAL = {8: 4}
base = B.baseline()
print("baseline :", {k: I.rname(v) for k, v in sorted(base.items())})
print("dump     :", {k: I.rname(v) for k, v in sorted(B.dump.items())})
print("goal     : qty8 ->", I.rname(4))
print("pri      :", {k: B._pri(v) for k, v in sorted(B.state.items())})
print("order    :", sorted(B.state, key=lambda k: (-B._pri(B.state[k]), k)))

atoms = [a for a in _atoms(B, GOAL)] if False else None
# regenerate atoms minus ALLOC_ORDER
out = []
for q in sorted(B.state):
    e = B.state[q]
    for d in (1, 2, 3, 4):
        out.append(I.Atom(I.L.REFS_UP, f"qty {q}: refs {e['refs']}->{e['refs']+d}",
                          I.COST[I.L.REFS_UP]+d-1, ("qty", (q, "refs", e["refs"]+d))))
    for d in (-1, -2):
        if e["refs"]+d >= 1:
            out.append(I.Atom(I.L.REFS_DOWN, f"qty {q}: refs {e['refs']}->{e['refs']+d}",
                              I.COST[I.L.REFS_DOWN], ("qty", (q, "refs", e["refs"]+d))))
    for nb in range(e["birth"]+1, e["death"]):
        out.append(I.Atom(I.L.LIVE_SHRINK, f"qty {q}: born later ({e['birth']}->{nb})",
                          I.COST[I.L.LIVE_SHRINK], ("qty", (q, "birth", nb))))
    for nd in range(e["birth"]+1, e["death"]):
        out.append(I.Atom(I.L.LIVE_SHRINK, f"qty {q}: dies earlier ({e['death']}->{nd})",
                          I.COST[I.L.LIVE_SHRINK], ("qty", (q, "death", nd))))
    for d in (1, 2, 4):
        out.append(I.Atom(I.L.LIVE_EXTEND, f"qty {q}: dies later ({e['death']}->{e['death']+d})",
                          I.COST[I.L.LIVE_EXTEND], ("qty", (q, "death", e["death"]+d))))
        if e["birth"]-d >= 0:
            out.append(I.Atom(I.L.LIVE_EXTEND, f"qty {q}: born earlier ({e['birth']}->{e['birth']-d})",
                              I.COST[I.L.LIVE_EXTEND], ("qty", (q, "birth", e["birth"]-d))))
lo = min(e["birth"] for e in B.state.values())
hi = max(e["death"] for e in B.state.values())
for reg in (2, 3, 4, 5):
    if reg in I.FIXED: continue
    out.append(I.Atom(I.L.HARDREG_LIVE, f"hard {I.rname(reg)} live across [{lo},{hi})",
                      I.COST[I.L.HARDREG_LIVE], ("hard", (reg, lo, hi))))
nxt = max(B.state)+100
for pr_refs, span in ((2, 2), (4, 4), (2, hi-lo)):
    e = {"refs": pr_refs, "birth": lo, "death": min(lo+span, hi), "size": 1}
    out.append(I.Atom(I.L.EXTRA_QTY, f"one more temp: refs={pr_refs} span=[{e['birth']},{e['death']})",
                      I.COST[I.L.EXTRA_QTY], ("extra", (nxt, dict(e)))))
    nxt += 1
print("atom space:", len(out), "over", len(set(a.cls for a in out)), "classes "
      "(ALLOC_ORDER class deliberately omitted -- see docstring)")

def matches(a): return a is not None and all(a.get(k) == v for k, v in GOAL.items())

for depth in (1, 2):
    t = time.time()
    hits = []
    for combo in itertools.combinations(out, depth):
        if matches(B.run(list(combo))):
            hits.append(combo)
    print(f"depth {depth}: {len(hits)} hit(s) in {time.time()-t:.1f}s")
    seen = set()
    for c in hits[:40]:
        k = " AND ".join(a.desc for a in c)
        if k in seen: continue
        seen.add(k)
        print("   ", k)
    if hits:
        break
