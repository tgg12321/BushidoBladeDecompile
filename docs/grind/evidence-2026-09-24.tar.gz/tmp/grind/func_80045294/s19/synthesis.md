# s19 SYNTHESIS — func_80045294 (saTan0Init)

Floor: 2 (unchanged since s1). Residual: 2-insn sched2 ordering of `sll $3,$18,4` vs `sw $16,16($sp) ; move $16,$18` in the prologue cluster. All 83 insns present; RA byte-identical to target.

## The merged attack — one problem statement, four pass-level dead-ends

Reaching target's `sw ; move16 ; sll` cluster requires **INSN_LUID(sll) > INSN_LUID(move16)** at both sched1 and sched2 ready-list evaluation (s3, s15, s16). This is equivalent to placing `v1 = a0<<4` at a source LUID that emits an ashift whose INSN is later than the (set i a0) move16. Any such C-source lever hand-derivation can reach triggers one of four pass-level failure modes, each proven at pass output:

1. **cse.c BB-scoped operand substitution** (s7, s15, root cause of the H1 / decl-init-decouple / inner-block-defer-v1 / late-v1-assign-with-s4-inline / i-with-i-as-shift-operand family). Whenever `(set new_pseudo a0_pseudo)` precedes `(ashift a0_pseudo K)` in the same basic block, cse rewrites the ashift's operand to new_pseudo. a0's live-range collapses from insn 4→22 to insn 4→15; reg_n_refs drops; global_alloc demotes it 2 slots in the queue → $21 instead of $18 → target RA rotates → score jumps to 11.

2. **local_alloc/global_alloc pool split with no coalescer** (s6, root cause of the cse-fold-anon-shift / late-v1-assign-with-s4-inline / combined-decl-v1-s4 family). Any C spelling with two tree-level `a0<<4` subexpressions where one is block-0-scoped (dies in prologue) and one is loop-carried produces two pseudos in separate allocation pools. combine.c cannot substitute across multi-use pseudos (mem-address prevents fold into insn 18). GCC 2.7.2 has NO cross-pass coalescer (added in GCC 3+). Extra copy insn survives → 84 insns → score=2 but +1 length.

3. **Both scheduling passes commit by the same LUID mechanism** (s16). sched1 already emits sll-before-move16 by the same rank_for_schedule INSN_LUID tiebreak that sched2 uses; reload preserves LUIDs. No scheduler-only flag (`-fno-schedule-insns[2]`) can decouple.

4. **No pure-C CFG-splitter defeats cse's BB view** (s10, s11). do-while(0) collapses in jump.c BEFORE cse runs; `({ expr; })` collapses in c-parse.y BEFORE RTL creation. saTan0Init has no natural semantic conditional between `i=a0` and `v1=a0<<4` (both are direct inits, no bounds check applies). Owner-sanctioned do-while(0) exception (2026-07-06) offered no relief.

## Enumerated dead axes (18 sessions)

**Hand-derivation (s1–s16, s18)** — all measured dead: init-order permutations (v1 vs i, sum position, {i,s4,count,s5} free cluster), guard form (`while` vs `if/do-while`), s5 hoist position, split-init on s5, decl/init decouple, inner-block scoping, alias intermediate (`s32 aa=a0;`), arithmetic-form (signed/unsigned/ptrdiff), destination-type (s32/u32), declarator packing, CFG-splitter attempts (do-while(0), stmt-expr), operand-order swap on s5.

**Rederive (s8, s9, s17, s18)** — EIGHT independent sub-axes all converge on the H1 shape (KILLED) or NEUTRAL free axes: (1) m2c mips-gcc-c, (2) m2c mipsel-gcc-c + mips-ido-c, (3) Kengo source + debug + globals metadata, (4) decomp.me local corpus shingle-search (top sim 0.127), (5) BB2 sibling shape (four saTan* siblings all single-target loops, no accumulator), (6) m2c --gotos-only, (7) m2c mwcc dialect, (8) m2c mipsee + no-stack-spill + deterministic-vars.

**Directed permuter (s13, s14)** — score-60 plateau confirmed across ~6000 iters on both chassis: full-TU (2524-line cpp-expanded) + minimal-base (63-line hand-authored), each with PERM_LINESWAP over the 6-decl cluster + PERM_GENERAL on `a0<<4` and `s4+a1`.

**Random-mode permuter (s13)** — full-TU chassis, 17773 iters / 668s, unbounded PERM_RANDOMIZE (no region annotation = whole-function surface), plateau=60. Only novel finds were equivalent-basin free axis (sum/v1 swap) and a broken-UB false-match.

## The residual frontier — one narrow axis, then OWNER-ESCALATION

The single genuinely un-measured chassis-lever is **minimal-base chassis + random-mode (no directed annotations)**. s13's random-mode was on the full-TU chassis; s14's minimal-base chassis was only measured with directed PERM_LINESWAP + PERM_GENERAL. The minimal-base chassis has ~40x fewer AST nodes → pycparser randomizer's per-iteration mutation depth is unconstrained by irrelevant top-level decls, and the compile pipeline runs at the same 6-9 iter/s rate. This is a **subtly-different search**, not obviously stronger than s13 (indeed, likely weaker in reach), but it is the last chassis-mutation-mode combination not empirically banked. A single fresh-seed campaign to natural iteration limit closes it.

If minimal-base + random-mode also plateaus at 60, every sanctioned axis is measured dead: hand-derivation (s1–s18), rederive (s8/s9/s17/s18), directed permuter (s13/s14), random permuter on both chassis (s13 + s20). OWNER-ESCALATION becomes ripe. The escalation entry writes itself: LUID axis proved coupled to cse.c substitution AND to reg_n_refs collapse; both scheduling passes commit via same tiebreak; no pure-C CFG-splitter defeats cse's BB view; permuter random + directed both plateau on both chassis.

## Reset frontier for s20 (ladder pass)

1. **PRIMARY (permuter modality) — minimal-base + random-mode.** Reuse s14's `perm_min/` chassis (63-line base.c, empty PROLOGUE_CONFIG). Strip PERM_LINESWAP + PERM_GENERAL annotations to make it unannotated random-mode (unbounded PERM_RANDOMIZE region per decomp-permuter/src/randomizer.py:172 fallback). Launch via `tools/permuter_campaign.py launch --label s20-min-random-fresh1 -j 4 --stop-on-zero`, harvest at natural iter limit (~5000 iters). If sub-60 find: apply to src/text1a_c.c, re-sandbox, save as candidate.c. If plateau=60: bank as final sanctioned axis measured dead.

2. **SECONDARY (owner-escalation prep, if #1 plateaus) — draft escalation entry.** Cite: s7/s15 cse.c substitution (a) coupling, s15/s16 sched1+sched2 LUID mechanism (b), s10/s11 no-pure-C-CFG-splitter, s6 no-coalescer for two-tree branch, s8/s9/s17/s18 eight-sub-axis rederive kill, s13/s14 directed permuter plateau, s20 random permuter plateau on both chassis. Owner ruling options: authorize as canonical-inline-asm-scoped-region for the 2-insn cluster only, OR accept score=2 as pure-C-COMPLETED with a documented exception. Do NOT emit owner-gated in s20 without the s20 measurement banked.

3. **DEPRIORITIZED — cross-chassis PERM_RANDOMIZE experiments.** Regional-scoped PERM_RANDOMIZE (e.g. wrapping only the decl block) is provably a SUBSET of s13's unbounded region search (randomizer picks `random.choice(regions)` per iter; scoping narrows the choice set). Not worth measuring separately.
