# 0 "src/text1a_c.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/mipsel-linux-gnu/include/stdc-predef.h" 1 3
# 0 "<command-line>" 2
# 1 "src/text1a_c.c"
# 1 "include/common.h" 1




typedef unsigned char u8;
typedef signed char s8;
typedef unsigned short u16;
typedef signed short s16;
typedef unsigned int u32;
typedef signed int s32;
typedef unsigned long long u64;
typedef signed long long s64;

typedef volatile u8 vu8;
typedef volatile s8 vs8;
typedef volatile u16 vu16;
typedef volatile s16 vs16;
typedef volatile u32 vu32;
typedef volatile s32 vs32;
# 2 "src/text1a_c.c" 2

# 1 "include/include_asm.h" 1
# 27 "include/include_asm.h"
__asm__(".include \"include/macro.inc\"\n");
# 4 "src/text1a_c.c" 2
# 1 "include/sound.h" 1





# 1 "include/common.h" 1
# 7 "include/sound.h" 2


extern s32 g_snd_bgm_id;
extern s32 g_snd_se_id;
extern s32 g_snd_volume;


extern void spu_SetVolume(s32, s32, s32);
# 5 "src/text1a_c.c" 2
# 1 "include/game.h" 1
# 9 "include/game.h"
extern u8 SpecialCam;
extern u8 g_disp_enable;
extern u8 g_disp_fade;
extern s16 g_game_mirror_mode;
extern s16 g_game_p2_ctrl;
extern s32 g_game_timer;
extern s16 g_stage_id;
extern s16 g_stage_variant;
# 6 "src/text1a_c.c" 2
# 1 "include/code6cac.h" 1
# 9 "include/code6cac.h"
extern s16 StatusUpBuf;
extern u8 cpu_practice_honmokuroku_data_tbl;
extern u8 g_module_type_tbl;
extern s32 menuDat;
extern s16 single_dojo_yaburi_char_id_tbl;


extern s32 D_800100A4;
extern s32 D_800109C8;
extern u8 D_8008D518;
extern u8 D_8008D538;
extern u8 D_8008D55C;
extern u8 D_8008D578;
extern u16 D_8008D59E;
extern u8 D_8008D864;
extern s32 D_8008D86C;
extern s32 D_8008D88C;
extern u8 D_8008D9EC;
extern u8 D_8008DA08;
extern s16 D_8008DA50;
extern s16 D_8008DA94;
extern s16 D_8008DAD8;
extern u8 D_8008DB1C;
extern s16 D_8008E194;
extern s16 D_8008E19E;
extern u8 D_8008E1A1;
extern u8 D_8008E338;
extern u16 D_8008E3C0;
extern u8 D_8008E5A8;
extern u8 D_8008E5CC;
extern u8 D_8008E748;
extern u8 D_8008E75C;
extern u8 D_8008EA44;
extern u8 D_8008EA45;
extern s16 D_8008EAC0;
extern s16 D_8008EB04;
extern s16 D_8008EB06;
extern s16 D_8008EB08;
extern s16 D_8008EB0A;
extern s16 D_8008EB0C;
extern s32 D_8008EB10;
extern s32 D_8008EB14;
extern s32 D_8008EB18;
extern u8 D_8008EB1C;
extern u8 D_8008EB38;
extern s16 D_8008EB54;
extern u8 D_8008EB6C;
extern u8 D_8008EB80;
extern u8 D_8008EB8E;
extern u16 D_8008EBA0;
extern s32 D_8008EBCC;
extern s32 D_8008EBE0;
extern u8 D_8008EBF4;
extern u8 D_8008EBFC;
extern u8 D_8008EBFD;
extern u8 D_8008EC30;
extern u32 D_8008EC38;
extern s16 D_8008F12C;
extern u8 D_8008F13C;
extern u8 D_8008F19C;
extern u8 D_8008F19D;
extern u8 D_8008F1A8;
extern u8 D_8008F204;
extern u8 D_800900EC;
extern u8 D_8009016C;
extern u32 D_80090178;
extern u32 D_800905F8;
extern s32 D_80090600;
extern s32 D_80090604;
extern s16 D_80090608;
extern s16 D_800906A4;
extern s32 D_800948C0;
extern u16 D_80094C68;
extern s16 D_800A310C;
extern s32 D_800A3134;
extern s32 D_800A3140;
extern u8 D_800A31DA;
extern u32 D_800A3220;
extern u8 D_800A3670;
extern u8 D_800A3671;
extern s16 D_800A367A;
extern s16 D_800A367C;
extern u8 D_800A3680;
extern s32 D_800A368C;
extern u8 D_800A3690;
extern s32 D_800A369C;
extern s16 D_800A36A4;
extern s32 D_800A36AC;
extern s32 D_800A36B4;
extern u8 D_800A36B9;
extern u8 D_800A36BA;
extern u8 D_800A36BB;
extern s16 D_800A36C2;
extern s32 D_800A36C4;
extern s16 D_800A36C6;
extern u8 D_800A36C8;
extern u16 D_800A36CA;
extern u8 D_800A36CC;
extern s16 D_800A36D2;
extern s32 D_800A36D4;
extern s32 D_800A36D8;
extern u8 D_800A36E8;
extern u8 D_800A36F0;
extern u8 D_800A36F1;
extern u8 D_800A36F2;
extern u8 D_800A36F4;
extern s16 D_800A36F6;
extern u8 D_800A36F9;
extern u8 D_800A36FA;
extern s16 D_800A36FC;
extern u8 D_800A3712;
extern u8 D_800A3713;
extern u8 D_800A3719;
extern u8 D_800A371A;
extern u8 D_800A371B;
extern s32 D_800A371C;
extern u8 D_800A3728;
extern s8 D_800A3748;
extern s16 D_800A3756;
extern u8 D_800A3758;
extern u8 D_800A3764;
extern u8 D_800A3769;
extern u8 D_800A376A;
extern u8 D_800A376B;
extern u8 D_800A376C;
extern s16 D_800A376E;
extern s32 D_800A3778;
extern u8 D_800A377B;
extern u8 D_800A3781;
extern u8 D_800A3783;
extern s32 D_800A3784;
extern u8 D_800A3788;
extern s32 D_800A3794;
extern u8 D_800A37A0;
extern s32 D_800A37A4;
extern u8 D_800A37B0;
extern u8 D_800A37B4;
extern u8 D_800A37B5;
extern u8 D_800A37B6;
extern s32 D_800A37B8;
extern u8 D_800A37BC;
extern s32 D_800A37C0;
extern u8 D_800A37C6;
extern u8 D_800A37D2;
extern u8 D_800A37D3;
extern u8 D_800A37E0;
extern u8 D_800A37E1;
extern s16 D_800A37E8;
extern s16 D_800A37EA;
extern s16 D_800A37EC;
extern u8 D_800A37F8;
extern u8 D_800A3804;
extern s32 D_800A380C;
extern u8 D_800A3816;
extern u8 D_800A3817;
extern s16 D_800A381C;
extern u8 D_800A381E;
extern s32 D_800A3820;
extern s16 D_800A3824;
extern u8 D_800A382D;
extern s16 D_800A382E;
extern s32 D_800A3830;
extern s16 D_800A3834;
extern u8 D_800A3836;
extern s32 D_800A3844;
extern s32 D_800A3858;
extern u8 *D_800A385C;
extern s32 D_800A3860;
extern s32 D_800A3864;
extern u8 D_800A3874;
extern s16 D_800A3876;
extern s32 D_800A3878;
extern s32 D_800A387C;
extern u8 D_800A3880;
extern s32 D_800A3888;
extern s32 D_800A388C;
extern u8 D_800A3898;
extern u8 D_800A3899;
extern u8 D_800A389A;
extern u8 D_800A389B;
extern u16 D_800A389C;
extern s32 D_800A38A0;
extern u8 D_800A38A4;
extern s16 D_800A38A8;
extern u8 D_800A38AA;
extern u8 D_800A38AB;
extern s16 D_800A38AE;
extern u8 D_800A38B0;
extern u8 D_800A38B8;
extern s16 D_800A38BA;
extern u8 D_800A38C0;
extern u8 D_800A38C1;
extern u16 D_800A38C6;
extern u8 D_800A38D4;
extern s16 D_800A38DC;
extern u8 D_800A38DE;
extern u8 D_800A38DF;
extern u8 D_800A38E0;
extern u8 D_800A38E1;
extern u8 D_800A38E2;
extern s32 D_800A38E4;
extern u8 D_800A38E8;
extern u8 D_800A38E9;
extern u8 D_800A38EC;
extern u8 D_800A38ED;
extern u8 D_800A38EE;
extern s32 D_800A38F0;
extern s32 D_800A38F4;
extern u8 D_800A38F8;
extern u8 D_800A3906;
extern u8 D_800A3907;
extern u8 D_800A390C;
extern u8 D_800A390D;
extern s8 D_800A390E;
extern u8 D_800A390F;
extern s16 D_800A3910;
extern u8 D_800A3912;
extern u8 D_800A3913;
extern u8 D_800A3914;
extern u8 D_800A3915;
extern u8 D_800A3918;
extern u8 D_800A391E;
extern u8 D_800A391F;
extern u8 D_800A3920;
extern u8 D_800A3928;
extern u8 D_800A3929;
extern s32 D_800A3D40;
extern s32 D_800F5328;
extern s32 D_800F532C;
extern s32 D_800F5330;
extern s16 D_800F5344;
extern u8 D_800F5347;
extern s16 D_800F5358;
extern s16 D_800F535A;
extern s16 D_800F535C;
extern s16 D_800F5360;
extern s16 D_800F5362;
extern s16 D_800F5364;
extern u8 D_800F5368;
extern u8 D_800F65F9;
extern s32 D_800F6608;
extern s32 D_800F660C;
extern s32 D_800F6610;
extern s16 D_800F6618;
extern s16 D_800F661A;
extern s16 D_800F661C;
extern s32 D_800F6620;
extern u8 D_800F6626;
extern u8 D_800F6627;
extern s16 D_800F6638;
extern s16 D_800F663A;
extern s16 D_800F663C;
extern s16 D_800F6640;
extern s16 D_800F6642;
extern s16 D_800F6644;
extern s16 D_800F68E0;
extern s32 D_800FF584;
extern s32 D_800FF5A4;
extern s32 D_800FF5A8;
extern s32 D_800FF5C8;
extern s32 D_800FF5CC;
extern s32 D_800FF5D0;
extern s16 D_800FF5D8;
extern s16 D_800FF5DA;
extern s16 D_800FF5DC;
extern s32 D_800FF5E0;
extern u8 D_80101BF0;
extern s16 D_80101E00;
extern u8 D_80101E59;
extern s32 D_80101E5C;
extern s16 D_80101E60;
extern s16 D_80101E62;
extern s16 D_80101E64;
extern s16 D_80101E66;
extern s16 D_80101E68;
extern s16 D_80101E6A;
extern s32 D_80101E6C;
extern s32 D_80101E78;
extern s32 D_80101E7C;
extern s32 D_80101E80;
extern s32 D_80101E84;
extern s32 D_80101E88;
extern s32 D_80101E8C;
extern u8 D_80101E90;
extern s32 D_80101E94;
extern s16 D_80101E98;
extern s16 D_80101E9A;
extern s16 D_80101E9C;
extern u16 D_80101E9E;
extern s32 D_80101EA0;
extern s32 D_80101EA4;
extern u8 D_80101EC8;
extern s16 D_80101ECE;
extern s16 D_80101ED2;
extern s16 D_80101EDA;
extern s16 D_80101EDC;
extern s16 D_80101EE8;
extern s32 D_80101F04;
extern s16 D_80101F08;
extern s16 D_80101F10;
extern s16 D_80101F12;
extern s16 D_80101F14;
extern s16 D_80101F26;
extern s16 D_80101F42;
extern s16 D_80101F4C;
extern s16 D_80101F4E;
extern s16 D_80101F5E;
extern u8 D_80101F75;
extern u8 D_80101F79;
extern u8 D_80101F7A;
extern u8 D_80101F7B;
extern s32 D_80101F80;
extern s32 D_80101F84;
extern s32 D_80101F88;
extern s32 D_80101FA0;
extern s32 D_80101FA4;
extern s32 D_80101FA8;
extern s32 D_80101FB0;
extern s32 D_80101FB4;
extern s32 D_80101FB8;
extern s32 D_80101FBC;
extern s32 D_80101FC0;
extern s32 D_80101FC4;
extern s32 D_80101FCC;
extern s32 D_80101FD0;
extern s32 D_80101FD4;
extern s32 D_80101FDC;
extern s32 D_80101FE0;
extern s32 D_80101FE4;
extern s32 D_80101FEC;
extern s32 D_80101FF0;
extern s32 D_80101FF4;
extern s32 D_80101FFC;
extern s32 D_80102000;
extern s32 D_80102004;
extern s32 D_8010200C;
extern s32 D_80102010;
extern s16 D_80102014;
extern s16 D_80102016;
extern s16 D_80102018;
extern s16 D_8010201A;
extern s32 D_8010203C;
extern s32 D_80102040;
extern s32 D_80102044;
extern s32 D_80102054;
extern s32 D_80102058;
extern s32 D_8010205C;
extern s32 D_801020D8;
extern s32 D_801020DC;
extern s32 D_801020E0;
extern s32 D_801020E4;
extern s32 D_801020E8;
extern s32 D_801020EC;
extern s32 D_801020FC;
extern s32 D_80102100;
extern s32 D_80102104;
extern s32 D_80102108;
extern s32 D_8010210C;
extern s32 D_80102110;
extern s16 D_8010214E;
extern s32 D_80102154;
extern s16 D_801021E2;
extern u8 D_80102216;
extern s16 D_8010231A;
extern u16 D_80102322;
extern s16 D_80102326;
extern s16 D_80102334;
extern s32 D_80102350;
extern s16 D_8010235C;
extern s16 D_80102372;
extern u16 D_8010237E;
extern s16 D_8010238E;
extern s16 D_801023AA;
extern u8 D_801023C1;
extern u8 D_801023C5;
extern s32 D_801023EC;
extern s32 D_801023F4;
extern s32 D_80102408;
extern s32 D_80102410;
extern s32 D_80102448;
extern s32 D_80102450;
extern s16 D_80102462;
extern s16 D_801024DE;
extern s16 D_8010259A;
extern s32 D_801025A0;
extern s16 D_8010262E;
extern s32 D_80102760;
extern s32 D_80102764;
extern s32 D_80102768;
extern s32 D_80102770;
extern s16 D_80102778;
extern s16 D_8010277A;
extern u8 D_8010277C;
extern u8 D_8010277E;
extern u8 D_80102780;
extern u8 D_80102782;
extern u8 D_80102783;
extern u8 D_80102784;
extern u8 D_80102785;
extern u8 D_80102786;
extern u8 D_80102787;
extern s16 D_80102788;
extern s16 D_8010278A;
extern s16 D_8010278C;
extern s16 D_8010278E;
extern s32 D_80102790;
extern u8 D_80102795;
extern s32 D_80102798;
extern s32 D_8010279C;
extern s32 D_801027B0;
extern s32 D_801027B4;
extern s32 D_801027B8;
extern s32 D_801027BC;
extern s32 D_801027C0;
extern s32 D_801027D4;
extern u8 D_80104E88;
extern s32 MotDataBaseAddress;
extern u8 D_80106A70;
extern u8 D_80106A71;
extern u8 D_80106A72;
extern s16 D_80106A7A;
extern u8 D_80106A80;
extern u8 D_80106A82;
extern u8 D_801077AF;
extern u8 D_801077B0;
extern u8 D_801077BA;
extern s32 D_80107850;
extern s32 D_80107854;
extern s32 D_80107858;


extern void DispPracticeMenuTex_A(u8 *, u8 *, u8 *, s32, s32, s32);
extern void DispSleepMenuTex(s32, s32, s32, s32);
extern void func_80021A98(s32, u8 *, s32);
extern void func_80022580(s32, s32, s32, s32, s32);
extern s32 func_80036EA8(s32, s32);
extern void func_8003A728(s32);
extern void func_8003AE5C(s32);
extern void func_8003DE14(s32 *, s32);
extern void game_SetControllerPorts(s32);
extern void gnd_init_80041688(s32, s32);
extern void func_80048BA4(s32, s32, s32);
extern void func_800493E4(s32);
extern void func_800494D4(s32, s32);
extern void func_80049584(s32);
extern s32 func_8005B8B8(s32);
extern void func_8005C6D0(void);
extern void bios_Exec(s32 *, s32, s32 *);
extern s32 bios_FormatDevice_B(s32 *);
extern void func_80079A30(s32 *, s32, s32, s32);
extern void gpu_SetMode(s32);
extern void gpu_SetDispMask(s32);
extern void gpu_DrawSync(s32);
extern void func_8007FF7C(void);
extern void func_80080148(void);
extern void cdrom_SetDebugLevel(s32);
extern void cdrom_SetCallbackB(s32);
extern void func_80080390(s32, s32);
extern void func_800826CC(s32);
extern s32 func_800827D0(s32, s32);
extern void func_80085448(s32, s32, s32);
extern s32 func_8008C464(s32, s32, s32);
extern s32 motion_SetMotion(void);
extern void replay_camera_get_attack_number(s32, s32, s32, s32);
extern void special_camera_Exec(void);
# 7 "src/text1a_c.c" 2



extern s16 D_800EED10[];
extern s32 D_800EED1C[];
extern s32 D_800EED18;
extern s32 D_800EED14;
extern s32 D_800EED00[];
extern s32 D_800A33AC;
extern s32 D_800A33A0;
extern s32 D_800A33A4;
extern s32 D_800A33A8;
extern u8 D_800A9D10;
extern void func_80049E1C(void);
extern void InitFadePanel(void);
extern void func_80044098(s16);
extern void func_80044010(s32 *, s16);
extern s32 D_800A3240;
extern s32 D_800A3398;
extern s32 D_800A3244;
extern s16 D_800963EE;
extern void md_game_check_mode(s32 *, s32);
extern void func_80054410(s32 *);
extern s32 func_800457A0(s32);
extern void func_80041430(s32, s32);
extern s32 func_8004019C(s32 *, s32);


extern s32 D_800A378C;
extern s32 D_800A3234;
extern s32 D_800A3378;
extern u8 D_800A9830;
extern u8 D_800A9920;
extern u16 D_80094AF4;
extern u8 D_80094B48[];
extern u8 D_80094D40[];
extern void initLoadImage(s32, s16 *, s32, s32);


extern s32 func_800486FC(s32 *);
extern s32 g_anim_func_table[];
extern s16 D_800F62E0;

void rob_life_ctrl_2(s32 *hsv, s32 *rgb) {
    s32 h = hsv[0];
    s32 s = hsv[1];
    s32 v = hsv[2];
    s32 i, f, p, q, t;
    s32 r, g, b;

    if (func_800486FC(hsv)) {
        s = 0;
    }
    if (s == 0) {
        r = v;
        g = v;
        b = v;
        goto out;
    }
    if (h == 0x1000) {
        h = 0;
    }
    p = v * (0x1000 - s);
    p = p >> 12;
    h = h * 6;
    f = h & 0xFFF;
    i = h >> 12;
    q = (v * (0x1000 - ((s * f) >> 12))) >> 12;
    t = (v * (0x1000 - ((s * (0x1000 - f)) >> 12))) >> 12;

    if ((u32)i >= 6U) goto out;
    switch (i) {
    case 0: r = v; g = t; b = p; goto out;
    case 1: r = q; g = v; b = p; goto out;
    case 2: r = p; g = v; b = t; goto out;
    case 3: r = p; g = q; b = v; goto out;
    case 4: r = t; g = p; b = v; goto out;
    case 5: r = v; g = p; b = q; goto out;
    }
out:
    rgb[0] = r;
    rgb[1] = g;
    rgb[2] = b;
}





void mot_data_set(s32 *a0, s32 *a1) {
    s32 r, g, b;
    s32 max_val, min_val;
    s32 chroma;
    s32 sat;
    s32 hue;
    s32 dR, dG, dB;
    s32 val;

    r = a0[0];
    g = a0[1];
    b = a0[2];


    if (r >= g) {
        if (r >= b) {
            max_val = r;
        } else {
            max_val = b;
        }
    } else {
        if (g >= b) {
            max_val = g;
        } else {
            max_val = b;
        }
    }


    if (g >= r) {
        if (b >= r) {
            min_val = r;
        } else {
            min_val = b;
        }
    } else {
        if (b >= g) {
            min_val = g;
        } else {
            min_val = b;
        }
    }

    chroma = max_val - min_val;

    val = max_val;

    if (val != 0) {
        sat = (chroma << 12) / val;
    } else {
        sat = 0;
    }

    if (sat != 0) {
        dR = ((max_val - r) << 12) / chroma;
        dG = ((max_val - g) << 12) / chroma;
        dB = ((max_val - b) << 12) / chroma;

        if (r == max_val) {
            hue = dB - dG;
        } else if (g == max_val) {
            s32 tmp = dB - 0x2000;
            hue = dR - tmp;
        } else if (b == max_val) {
            s32 tmp = dR - 0x4000;
            hue = dG - tmp;
        }

        hue /= 6;

        if (hue < 0) {
            hue += 0x1000;
        }
    } else {
        hue = 0;
    }

    a1[0] = hue;
    a1[1] = sat;
    a1[2] = val;
}

extern s16 D_800F6650;
void func_8004283C(s32 a0) {
    if (a0) {
        D_800F6650 = 1;
    } else {
        D_800F6650 = 0;
    }
}
extern s16 D_800F6650;
s32 rob_ScaleMarioInit(void) {
    return D_800F6650;
}
extern s16 Judge[];
void _SelectSection(u16 *a0, s16 *a1) {
    s32 angA, angB;
    s16 sinA, sinB, sinC;
    s16 cosB, cosC;
    s32 negSinAxsinB_12;
    s32 prod_sinC, cosB_cosC;
    s32 sinAxcosB;
    s32 sinAxcosB_12;
    s32 cosA_negSinC;
    s32 prod2_sinC, sinB_cosC;
    s32 sinAxsinB;
    s32 sinAxsinB_12;
    s32 sinAxsinB_12_cosC;
    s32 cosB_sinC;
    s32 negSinA_cosB;
    s32 cosA_cosC;
    s32 negSinAxcosB_12;
    s32 negSinAxcosB_12_cosC;
    s32 cosA_negSinB;
    s32 cosA_cosB;
    s32 sinB_sinC;
    s32 cosA;
    register s32 angC asm("$3");

    angA = a0[0];
    angB = a0[1];

    sinA = Judge[angA & 0xFFF];
    sinB = Judge[angB & 0xFFF];

    angC = a0[2];
    sinC = Judge[angC & 0xFFF];

    negSinAxsinB_12 = (sinA * -sinB) >> 12;

    prod_sinC = negSinAxsinB_12 * sinC;

    cosB = Judge[((s16)angB + 0x400) & 0xFFF];
    cosC = Judge[((s16)angC + 0x400) & 0xFFF];

    cosB_cosC = cosB * cosC;

    sinAxcosB = sinA * cosB;

    cosA = (s16)*(volatile u16 *)(&Judge[((s16)angA + 0x400) & 0xFFF]);

    cosA_negSinC = cosA * -sinC;

    sinAxcosB_12 = sinAxcosB >> 12;
    prod2_sinC = sinAxcosB_12 * sinC;

    sinAxsinB = sinA * sinB;
    sinB_cosC = sinB * cosC;

    sinAxsinB_12 = sinAxsinB >> 12;
    sinAxsinB_12_cosC = sinAxsinB_12 * cosC;

    cosB_sinC = cosB * sinC;

    negSinA_cosB = -sinA * cosB;

    cosA_cosC = cosA * cosC;

    negSinAxcosB_12 = negSinA_cosB >> 12;
    negSinAxcosB_12_cosC = negSinAxcosB_12 * cosC;

    cosA_negSinB = cosA * -sinB;

    cosA_cosB = cosA * cosB;

    a1[7] = sinA;
    a1[1] = cosA_negSinC >> 12;
    a1[4] = cosA_cosC >> 12;
    a1[6] = cosA_negSinB >> 12;
    a1[8] = cosA_cosB >> 12;
    a1[0] = (prod_sinC + cosB_cosC) >> 12;
    a1[2] = (prod2_sinC + sinB_cosC) >> 12;
    a1[3] = (sinAxsinB_12_cosC + cosB_sinC) >> 12;

    sinB_sinC = sinB * sinC;
    a1[5] = (negSinAxcosB_12_cosC + sinB_sinC) >> 12;
}
extern s16 Judge[];
void replay_camera_rob_back_loose3(u16 *a0, s16 *a1) {
    s32 angA, angB;
    s16 sinA, sinB, sinC;
    s16 cosB, cosC;
    s32 sinAxsinB_12;
    s32 prod_sinC, prod_cosC;
    s32 cosB_cosC, cosB_negsinC;
    s32 cosA_sinB, cosA_sinC, cosA_cosC, cosA_cosB;
    s32 sinAxcosB;
    s32 sinAxcosB_12;
    s32 scb_sinC, neg_sinB_cosC;
    s32 scb_cosC;
    s32 sinB_sinC;
    s32 cosA;
    register s32 angC asm("$3");

    angA = a0[0];
    angB = a0[1];

    sinA = Judge[angA & 0xFFF];
    sinB = Judge[angB & 0xFFF];

    angC = a0[2];
    sinC = Judge[angC & 0xFFF];

    sinAxsinB_12 = (sinA * sinB) >> 12;

    prod_sinC = sinAxsinB_12 * sinC;

    cosB = Judge[((s16)angB + 0x400) & 0xFFF];
    cosC = Judge[((s16)angC + 0x400) & 0xFFF];

    cosB_cosC = cosB * cosC;
    prod_cosC = sinAxsinB_12 * cosC;

    cosA = (s16)*(volatile u16 *)(&Judge[((s16)angA + 0x400) & 0xFFF]);

    cosB_negsinC = cosB * -sinC;

    cosA_sinB = cosA * sinB;
    cosA_sinC = cosA * sinC;

    sinAxcosB = sinA * cosB;
    cosA_cosC = cosA * cosC;

    sinAxcosB_12 = sinAxcosB >> 12;

    scb_sinC = sinAxcosB_12 * sinC;
    neg_sinB_cosC = -sinB * cosC;

    scb_cosC = sinAxcosB_12 * cosC;

    cosA_cosB = cosA * cosB;

    a1[5] = -sinA;
    a1[2] = cosA_sinB >> 12;
    a1[3] = cosA_sinC >> 12;
    a1[4] = cosA_cosC >> 12;
    a1[8] = cosA_cosB >> 12;
    a1[0] = (prod_sinC + cosB_cosC) >> 12;
    a1[1] = (prod_cosC + cosB_negsinC) >> 12;
    a1[6] = (scb_sinC + neg_sinB_cosC) >> 12;

    sinB_sinC = sinB * sinC;
    a1[7] = (scb_cosC + sinB_sinC) >> 12;
}
extern s16 Judge[];
void hirahira_w_ctrl_2(u16 *a0, s16 *a1) {
    s32 angB, angC;
    s16 cosB, cosC;
    s32 cosB_cosC, cosB_negsinC;
    s32 angA;
    s16 sinB;
    s16 sinA;
    s16 sinC;
    s32 sab;
    s32 sab12;
    s32 sab12_cosC, sab12_negsinC;
    s32 cosA;
    s32 cosA_sinC, cosA_cosC;
    s32 cosA_negsinB;
    s32 negsinA_cosB;
    s32 cab12, cab12_cosC;
    s32 cosA_sinB;
    s32 sinA_sinC;
    s32 csb12_sinC;
    s32 cosA_cosB;
    s32 sinA_cosC;

    angB = a0[1];
    angC = a0[2];

    sinB = Judge[angB & 0xFFF];
    sinC = Judge[angC & 0xFFF];
    angA = a0[0];
    sinA = Judge[angA & 0xFFF];

    cosB = Judge[((s16)angB + 0x400) & 0xFFF];
    cosC = Judge[((s16)angC + 0x400) & 0xFFF];

    cosB_cosC = cosB * cosC;

    sab = sinA * sinB;

    cosB_negsinC = cosB * -sinC;
    sab12 = sab >> 12;

    sab12_cosC = sab12 * cosC;

    cosA = (s16)*(volatile u16 *)(&Judge[((s16)angA + 0x400) & 0xFFF]);

    cosA_sinC = cosA * sinC;
    sab12_negsinC = sab12 * -sinC;
    cosA_cosC = cosA * cosC;
    cosA_negsinB = cosA * -sinB;
    negsinA_cosB = -sinA * cosB;

    cab12 = cosA_negsinB >> 12;
    cab12_cosC = cab12 * cosC;

    cosA_sinB = cosA * sinB;
    sinA_sinC = sinA * sinC;

    csb12_sinC = (cosA_sinB >> 12) * sinC;

    cosA_cosB = cosA * cosB;

    a1[2] = sinB;
    a1[0] = cosB_cosC >> 12;
    a1[1] = cosB_negsinC >> 12;
    a1[5] = negsinA_cosB >> 12;

    sinA_cosC = sinA * cosC;

    a1[8] = cosA_cosB >> 12;
    a1[3] = (sab12_cosC + cosA_sinC) >> 12;
    a1[4] = (sab12_negsinC + cosA_cosC) >> 12;
    a1[6] = (cab12_cosC + sinA_sinC) >> 12;
    a1[7] = (csb12_sinC + sinA_cosC) >> 12;
}

extern void func_8004A348(s16 *, s32 *);
extern void func_80042874(void);
extern void func_80042A88(void);
extern void hirahira_w_ctrl_2();
extern s32 D_800F66A8;
extern s32 D_800F66B0;
extern s32 D_800F66B4;
void func_80042E90(void) {
    g_anim_func_table[0] = (s32)func_8004A348;
    D_800F66A8 = (s32)func_80042874;
    D_800F66B0 = (s32)func_80042A88;
    D_800F66B4 = (s32)hirahira_w_ctrl_2;
}
void func_80042ED8(u16 *a0) {




    u16 t, x, y, z;
    y = a0[1];
    x = a0[2];
    z = a0[5];
    t = a0[6];
    a0[2] = t;
    a0[6] = x;
    t = a0[3];
    a0[1] = t;
    a0[3] = y;
    t = a0[7];
    a0[5] = t;
    a0[7] = z;
}
extern s16 Judge[];
void func_80042F10(s32 *a0, s32 *a1, s32 a2) {
    s16 sin_val, cos_val;
    s32 x, y;
    s32 sin_x, cos_x, sin_y, cos_y;
    sin_val = Judge[(a2 + 0x400) & 0xFFF];
    x = *a0;
    cos_val = Judge[a2 & 0xFFF];
    y = *a1;
    sin_x = sin_val * x;
    cos_x = cos_val * x;
    sin_y = sin_val * y;
    cos_y = cos_val * y;
    *a1 = (cos_x + sin_y) >> 12;
    *a0 = (sin_x - cos_y) >> 12;
}
extern s32 *func_8007ED6C(s32 *, s16 *, s32 *);
extern s16 single_game_getEnemyCharId(s32, s32);
extern s32 math_Cos(s32);
extern s32 math_Sin(s32);
extern void func_8007EB4C(s32 *, s32 *);
void func_80042FA0(s32 *a0, s16 *a1) {
    s16 rot[3];
    s32 result[4];
    s32 sp28[8];
    s16 angle1;
    s32 cos_val, sin_val;
    s16 neg_angle2;
    s32 combined;

    rot[0] = 0;
    rot[1] = 0;
    rot[2] = 0x1000;
    func_8007ED6C(a0, rot, result);

    angle1 = single_game_getEnemyCharId(result[0], result[2]);

    cos_val = math_Cos((s16)angle1);
    sin_val = math_Sin((s16)angle1);

    combined = (cos_val * result[2] + sin_val * result[0]) >> 12;
    neg_angle2 = -single_game_getEnemyCharId(result[1], combined);

    rot[0] = -neg_angle2;
    rot[1] = -angle1;
    rot[2] = 0;
    hirahira_w_ctrl_2(rot, sp28);

    func_8007EB4C(sp28, a0);

    rot[0] = 0;
    rot[1] = 0x1000;
    rot[2] = 0;
    func_8007ED6C(sp28, rot, result);

    {
        s16 angle3;
        angle3 = single_game_getEnemyCharId(result[0], result[1]);
        a1[0] = neg_angle2;
        a1[1] = angle1;
        a1[2] = -angle3;
    }
}

typedef struct { s32 f0, f1, f2, f3, f4, f5, f6, f7; } StructCopy32_800430E4;
extern void func_8004DDB4(s32, s32, s32, s32);
extern s32 D_800FF610;
extern s32 D_800951D8;
extern s32 D_80095280;
extern s32 D_80095328;
extern s32 D_800A3828;
void func_800430E4(s32 arg0, s32 arg1, s16 arg2, u8 *arg3) {
    s32 *dst = (s32 *)0x1F8003A0;
    s32 t0;

    t0 = *(s32 *)0x1F800008;
    *(s32 *)0x1F800008 = 3 - t0;

    *(StructCopy32_800430E4 *)dst = *(StructCopy32_800430E4 *)&D_800FF610;

    D_800A3828 = (s32)(&D_800F62E0 + arg2 * 48);

    *(s16 *)0x1F8003A6 = *(s16 *)0x1F8003A6 >> 1;
    *(s16 *)0x1F8003A8 = *(s16 *)0x1F8003A8 >> 1;
    *(s16 *)0x1F8003AA = *(s16 *)0x1F8003AA >> 1;
    *(s32 *)0x1F8003B8 = *(s32 *)0x1F8003B8 >> 1;

    if (arg3[1] & 1) {
        *(s32 *)0x1F80001C = (s32)&D_80095280;
    } else {
        *(s32 *)0x1F80001C = (s32)&D_800951D8;
    }

    func_8004DDB4(arg0, arg1, (s32)dst, t0);

    *(s32 *)0x1F80001C = (s32)&D_80095328;
}

s32 func_80043244(s32 a0) {
    s32 ret;
    if (a0 > 0x16A09) {
        ret = 3;
    } else if (a0 > (s32)0xB500) {
        ret = 2;
    } else {
        ret = a0 >= 0x5A01;
    }
    return ret;
}
s32 func_80043278(s32 a0) {
    s32 mask = (s32)0xFFFFF000;
    volatile s32 *sp = (volatile s32 *)0x1F800000;
    s32 v0 = a0 >> sp[2];
    s32 a0_new = v0 >> 11;
    v0 = (v0 & 0x7FF) | mask;
    v0 = v0 >> a0_new;
    return v0 & 0xFFF;
}
extern s32 *D_80103608[];
extern u16 D_80103658[];
extern void func_80043454(s32, s16, s16, s16);
void videoDecCreate(s16 arg0, s16 arg1, s16 arg2, s16 arg3, s32 arg4) {
    u16 arg4_lo = *(u16 *)&arg4;
    s32 idx = arg0;
    u16 *cnt_base = D_80103658;
    u16 *countPtr;
    s16 i;

    countPtr = &cnt_base[idx];
    i = 0;
    if (*countPtr == 0) goto done;
    {
        s32 **base_addr = D_80103608;
        s32 **basePtr = &base_addr[idx];
        u16 *cntPtr = countPtr;



    loop:
        *(s32 *)0x1F800000 = (*basePtr)[(s16)i];
        func_80043454((s16)arg1, (s16)arg2, (s16)arg3, (s16)arg4_lo);
        i++;
        if ((s16)i < *cntPtr) goto loop;
    }
    done:
    ;
}
void func_80043398(s16 a0, s16 a1, s16 a2, s16 a3, s16 a4) {
    videoDecCreate(a0, (s16)(a1 << 6), (s16)(a2 << 8), (s16)(a3 << 6), (s16)(a4 << 8));
}
void func_800433E4(s16 arg0, s16 arg1, s16 arg2, s16 arg3, s16 arg4, s16 arg5) {
    *(s32 *)0x1F800000 = D_80103608[arg0][arg1];
    func_80043454(arg2, arg3, arg4, arg5);
}
void func_80043454(s32 a0, s16 a1, s16 a2, s16 a3) {
    (void)a0;
    (void)a1;
    (void)a2;
    (void)a3;
}
s32 func_80043BD0(u8 *a0, s32 a1, s32 a2, s32 a3, s32 a4)
{
  register unsigned int t1 asm("$9");
  register s32 t0 asm("$8");
  register s32 v0 asm("$2");
  register unsigned int v1 asm("$3");

  a1 = (a1 << 16) >> 22;
  v0 = (a2 << 16) >> 24;
  a3 = (a3 << 16) >> 20;
  t1 = *((u16 *) (a0 + 0x16));
  t0 = (t1 & 0xF) + a1;
  t0 &= 0xF;
  v1 = (t1 >> 4) & 1;
  v1 += v0;
  v1 &= 1;
  t1 &= 0xFFE0;
  v1 <<= 4;
  t1 |= v1;
  v0 = *((u8 *) (a0 + 0xD));
  t0 |= t1;
  *((u16 *) (a0 + 0x16)) = t0;
  {
    register s32 la1 asm("$5");
    __asm__ __volatile__("lw\t$5, 16($29)" : "=r"(la1) : "r"(t0));
    a1 = la1;
  }
  v1 = *((u8 *) (a0 + 0x1D));
  v0 += a2;
  *((u8 *) (a0 + 0xD)) = v0;
  v0 = *((u8 *) (a0 + 0x15));
  v1 += a2;
  *((u8 *) (a0 + 0x1D)) = v1;
  v1 = *((u16 *) (a0 + 0xE));
  v0 += a2;
  *((u8 *) (a0 + 0x15)) = v0;
  __asm__ __volatile__("");
  a3 += v1 & 0x3F;
  a3 &= 0x3F;
  a1 += (v1 >> 6) & 0x1FF;
  a1 &= 0x1FF;
  v1 &= 0x8000;
  a1 <<= 6;
  v1 |= a1;
  a3 |= v1;
  *((u16 *) (a0 + 0xE)) = a3;
}
s32 func_80043C7C(u8 *a0, s32 a1, s32 a2, s32 a3, s32 a4)
{
  register unsigned int t1 asm("$9");
  register s32 t0 asm("$8");
  register s32 v0 asm("$2");
  register unsigned int v1 asm("$3");

  a1 = (a1 << 16) >> 22;
  v0 = (a2 << 16) >> 24;
  a3 = (a3 << 16) >> 20;
  t1 = *((u16 *) (a0 + 0x16));
  t0 = (t1 & 0xF) + a1;
  t0 &= 0xF;
  v1 = (t1 >> 4) & 1;
  v1 += v0;
  v1 &= 1;
  t1 &= 0xFFE0;
  v1 <<= 4;
  t1 |= v1;
  t0 |= t1;
  *((u16 *) (a0 + 0x16)) = t0;
  {
    register s32 la1 asm("$5");
    __asm__ __volatile__("lw\t$5, 16($29)" : "=r"(la1) : "r"(t0));
    a1 = la1;
  }
  v1 = *((u8 *) (a0 + 0x15));
  v0 = *((u8 *) (a0 + 0xD));
  v1 += a2;
  *((u8 *) (a0 + 0x15)) = v1;
  v1 = *((u8 *) (a0 + 0x25));
  v0 += a2;
  *((u8 *) (a0 + 0xD)) = v0;
  v0 = *((u8 *) (a0 + 0x1D));
  v1 += a2;
  *((u8 *) (a0 + 0x25)) = v1;
  v1 = *((u16 *) (a0 + 0xE));
  v0 += a2;
  *((u8 *) (a0 + 0x1D)) = v0;
  a3 += v1 & 0x3F;
  a3 &= 0x3F;
  a1 += (v1 >> 6) & 0x1FF;
  a1 &= 0x1FF;
  v1 &= 0x8000;
  a1 <<= 6;
  v1 |= a1;
  a3 |= v1;
  *((u16 *) (a0 + 0xE)) = a3;
}
s32 func_80043D34(u8 *a0, s32 a1, s32 a2, s32 a3, s32 a4)
{
  register unsigned int t1 asm("$9");
  register s32 t0 asm("$8");
  register s32 v0 asm("$2");
  register unsigned int v1 asm("$3");

  a1 = (a1 << 16) >> 22;
  v0 = (a2 << 16) >> 24;
  a3 = (a3 << 16) >> 20;
  t1 = *((u16 *) (a0 + 0x1A));
  t0 = (t1 & 0xF) + a1;
  t0 &= 0xF;
  v1 = (t1 >> 4) & 1;
  v1 += v0;
  v1 &= 1;
  t1 &= 0xFFE0;
  v1 <<= 4;
  t1 |= v1;
  v0 = *((u8 *) (a0 + 0xD));
  t0 |= t1;
  *((u16 *) (a0 + 0x1A)) = t0;
  {
    register s32 la1 asm("$5");
    __asm__ __volatile__("lw\t$5, 16($29)" : "=r"(la1) : "r"(t0));
    a1 = la1;
  }
  v1 = *((u8 *) (a0 + 0x25));
  v0 += a2;
  *((u8 *) (a0 + 0xD)) = v0;
  v0 = *((u8 *) (a0 + 0x19));
  v1 += a2;
  *((u8 *) (a0 + 0x25)) = v1;
  v1 = *((u16 *) (a0 + 0xE));
  v0 += a2;
  *((u8 *) (a0 + 0x19)) = v0;
  __asm__ __volatile__("");
  a3 += v1 & 0x3F;
  a3 &= 0x3F;
  a1 += (v1 >> 6) & 0x1FF;
  a1 &= 0x1FF;
  v1 &= 0x8000;
  a1 <<= 6;
  v1 |= a1;
  a3 |= v1;
  *((u16 *) (a0 + 0xE)) = a3;
}
s32 func_80043DE0(u8 *a0, s32 a1, s32 a2, s32 a3, s32 a4)
{
  register unsigned int t1 asm("$9");
  register s32 t0 asm("$8");
  register s32 v0 asm("$2");
  register unsigned int v1 asm("$3");

  a1 = (a1 << 16) >> 22;
  v0 = (a2 << 16) >> 24;
  a3 = (a3 << 16) >> 20;
  t1 = *((u16 *) (a0 + 0x1A));
  t0 = (t1 & 0xF) + a1;
  t0 &= 0xF;
  v1 = (t1 >> 4) & 1;
  v1 += v0;
  v1 &= 1;
  t1 &= 0xFFE0;
  v1 <<= 4;
  t1 |= v1;
  t0 |= t1;
  *((u16 *) (a0 + 0x1A)) = t0;
  {
    register s32 la1 asm("$5");
    __asm__ __volatile__("lw\t$5, 16($29)" : "=r"(la1) : "r"(t0));
    a1 = la1;
  }
  v1 = *((u8 *) (a0 + 0x19));
  v0 = *((u8 *) (a0 + 0xD));
  v1 += a2;
  *((u8 *) (a0 + 0x19)) = v1;
  v1 = *((u8 *) (a0 + 0x31));
  v0 += a2;
  *((u8 *) (a0 + 0xD)) = v0;
  v0 = *((u8 *) (a0 + 0x25));
  v1 += a2;
  *((u8 *) (a0 + 0x31)) = v1;
  v1 = *((u16 *) (a0 + 0xE));
  v0 += a2;
  *((u8 *) (a0 + 0x25)) = v0;
  a3 += v1 & 0x3F;
  a3 &= 0x3F;
  a1 += (v1 >> 6) & 0x1FF;
  a1 &= 0x1FF;
  v1 &= 0x8000;
  a1 <<= 6;
  v1 |= a1;
  a3 |= v1;
  *((u16 *) (a0 + 0xE)) = a3;
}
void func_80043E98(s16 *a0, s16 a1, s16 a2, s16 a3, s16 a4) {
    s16 r1;
    r1 = func_80043F80(a0[0], a1, a2);
    a0[0] = r1;
    a0[2] = func_80043FCC(a0[2], a3, a4);
}
extern s16 func_80043F80(s16, s16, s16);
extern s16 func_80043FCC(s16, s16, s32);
void func_80043F0C(s16 *a0, s16 a1, s16 a2, s16 a3, s16 a4) {
    s16 r1;
    r1 = func_80043F80(a0[3], a1, a2);
    a0[3] = r1;
    a0[1] = func_80043FCC(a0[1], a3, a4);
}
s16 func_80043F80(s16 a0, s16 a1, s16 a2) {
    s32 low = (a0 & 0xF) + (a1 >> 6);
    s32 mid;
    low &= 0xF;
    mid = ((a0 >> 4) & 1) + (a2 >> 8);
    mid &= 1;
    return (s16)(low | ((a0 & ~0x1F) | (mid << 4)));
}
s16 func_80043FCC(s16 a0, s16 a1, s32 a2) {
    s32 low = (a1 >> 4) + (a0 & 0x3F);
    s32 mid;
    low &= 0x3F;
    mid = (a2 + (((u32)(a0 << 17)) >> 23)) & 0x1FF;
    return (s16)(low | ((a0 & (s16)0x8000) | (mid << 6)));
}
__asm__(
    ".set\tnoat\n"
    ".set\tnoreorder\n"
    ".set noat\n"
    ".set noreorder\n"
    "glabel func_80044010\n"
    "    addu       $a2, $a0, $zero\n"
    "    sll        $a1, $a1, 16\n"
    "    lw         $v1, 0($a0)\n"
    "    sra        $a1, $a1, 16\n"
    "    ori        $v0, $v1, 0x8000\n"
    "    andi       $v0, $v0, 0xFFFF\n"
    "    sw         $v0, 0($a0)\n"
    "    addiu      $a0, $a0, 4\n"
    "    sll        $v0, $a1, 2\n"
    "    sll        $a1, $a1, 1\n"
    "    lui        $at, %hi(D_80103608)\n"
    "    addu       $at, $at, $v0\n"
    "    sw         $a0, %lo(D_80103608)($at)\n"
    "    andi       $v0, $v1, 0x7FFF\n"
    "    lui        $at, %hi(D_80103658)\n"
    "    addu       $at, $at, $a1\n"
    "    sh         $v0, %lo(D_80103658)($at)\n"
    "    addu       $v0, $v1, $zero\n"
    "    andi       $v1, $v1, 0x8000\n"
    "    bnez       $v1, .L_func_80044010_end\n"
    "     addiu     $sp, $sp, -8\n"
    "    andi       $v1, $v0, 0xFFFF\n"
    "    blez       $v1, .L_func_80044010_end\n"
    "     addu      $a1, $zero, $zero\n"
    "  .L_func_80044010_loop:\n"
    "    lw         $v0, 0($a0)\n"
    "    addiu      $a1, $a1, 1\n"
    "    addu       $v0, $v0, $a2\n"
    "    sw         $v0, 0($a0)\n"
    "    slt        $v0, $a1, $v1\n"
    "    bnez       $v0, .L_func_80044010_loop\n"
    "     addiu     $a0, $a0, 4\n"
    "  .L_func_80044010_end:\n"
    "    addiu      $sp, $sp, 8\n"
    "    jr         $ra\n"
    "     nop\n"
    ".set\treorder\n"
    ".set\tat\n"
    ".set reorder\n"
    ".set at\n"
);
void func_80044098(s16 a0) {
    register s32 *v1 asm("v1");
    register s32 a4 asm("a0");
    s32 *a6;

    v1 = D_80103608[a0];
    a4 = *(v1 - 1);
    a6 = v1 - 1;
    if (a4 & 0x8000) {
        a4 = a4 & 0x7FFF;
        *(v1 - 1) = a4;
        a4 = a4 - 1;
        if (a4 != -1) {
            do {
                *v1 -= (s32)a6;
                v1++;
                a4--;
            } while (a4 != -1);
        }
    }
}
void func_80044100(s32 a0, s32 a1) {
    s32 *ptr = D_80103608[a0];
    s32 count = D_80103658[a0];
    D_80103608[a0] = (ptr = ptr + (a1 / 4));
    count--;
    if (count != -1) {
        do {
            *ptr += a1;
            ptr++;
            count--;
        } while (count != -1);
    }
}
extern void func_800520B8(s32, s32, s32);
s32 func_80044170(s32 *a0, ...) {
    s32 *base;
    s32 old_first;
    s32 count;
    s32 *slots;
    s32 *varptr;
    s32 dest;
    s32 entry;
    s32 size;

    base = a0;
    old_first = *base;
    count = *(s32 *)((s32)&a0 + 4);
    a0 = base + 1;
    *base = count;
    slots = a0;
    dest = (s32)base + *slots;
    count--;
    varptr = (s32 *)((s32)&a0 + 8);
    if (count != -1) {
        do {
            s32 *tbl;
            s32 cur_off;

            varptr++;
            entry = *(varptr - 1);
            if (entry >= old_first) {
                InitFadePanel();
            }
            count--;
            tbl = (s32 *)((entry * 4) + (s32)a0);
            cur_off = *tbl;
            size = *(tbl + 1);
            *slots = dest - (s32)base;
            slots++;
            size = size - cur_off;
            func_800520B8((s32)base + cur_off, dest, size);
            size = (s32)(((u32)size >> 2) * 4);
            dest += size;
        } while (count != -1);
    }
    *slots = dest - (s32)base;
    return dest;
}
extern void func_800520B8(s32, s32, s32);
s32 hirahira_w_frie(s32 *base, s16 *offsets) {
    s32 *b = base;






    s32 *slots = b + 1;
    s32 count = 0;
    s32 *dest = (s32 *)((s32)b + b[1]);
    s32 v1;
    s32 *walker;
    s32 size;
    s32 cur_off;
    s32 ret;

    v1 = *offsets;
    offsets++;
    if (v1 == -2) {
        ret = (s32)dest;
        goto done;
    }

    {
    s32 stop = -2;
    walker = slots;
    do {
        if (v1 >= 0) {
            size = walker[1];
            cur_off = walker[0];
            *slots = (s32)dest - (s32)b;
            slots++;
            count++;
            size = size - cur_off;
            func_800520B8((s32)b + cur_off, (s32)dest, size);
            size = (u32)size >> 2;
            size = size << 2;
            dest = (s32 *)((s32)dest + size);
        }
        walker++;
        v1 = *offsets;
        offsets++;
    } while (v1 != stop);
    }
    ret = (s32)dest;

done:
    v1 = ret - (s32)b;
    *b = count;
    *slots = v1;
    return ret;
}

extern void func_800520B8(s32, s32, s32);
s32 calc_fc_frame(s32 src_base, s32 *dest_arr, s16 *frame_offsets) {
    s16 *fp;
    s16 *scan;
    s32 *orig_dest;
    s32 *dest;
    s32 val;
    s32 data_ptr;
    s32 sentinel;
    s32 count;
    s32 *src_ptr;
    s32 start;
    s32 size;

    fp = frame_offsets;
    orig_dest = dest_arr;
    count = 0;
    scan = fp + 1;
    dest = dest_arr;

    val = *fp;
    if (val != -2) {
        do {
            if (val >= 0) {
                count++;
            }
            val = *scan;
            scan++;
        } while (val != -2);
    }

    *dest = count;
    dest++;
    src_base += 4;
    data_ptr = (s32)orig_dest + (count + 2) * 4;

    val = *fp;
    if (val != -2) {
        fp++;
        sentinel = -2;
        src_ptr = (s32 *)src_base;
        do {
            if (val >= 0) {
                size = src_ptr[1];
                start = *src_ptr;
                *dest = data_ptr - (s32)orig_dest;
                dest++;
                size = size - start;
                func_800520B8(src_base + start, data_ptr, size);
                size = ((u32)size >> 2) << 2;
                data_ptr += size;
            }
            src_ptr++;
            val = *fp;
            fp++;
        } while (val != sentinel);
    }

    *dest = data_ptr - (s32)orig_dest;
    return data_ptr;
}
extern s16 D_8010367E;
void func_80044498(void) {
    s32 i = 0x13;
    s16 *p = &D_8010367E;
    for (; i >= 0; i--) {
        *p-- = 0;
    }
}
extern s32 D_800A378C;
void saTanMainDispGnd_800444BC(void) {
    func_80044504(D_800A378C);
}
void leaf_muki_awase_800444E0(void) {
    func_80044504(D_800A378C);
}
extern s32 D_800A3678;
extern s32 D_80101BD0;
extern s32 D_800A3708;
extern s32 D_800A370C;
extern s32 D_800FF610;
extern s16 D_80095328;
extern s32 D_80102C00;
extern void func_80042874(s32 *, s32 *);
extern void func_8007EB4C(s32 *, s32 *);
extern void calc_fc_frame_8007EC5C(s32 *, s32 *);
extern void func_8007E4DC(s32 *, s32 *, s32 *);
extern void camera_InitMatrix(void);
extern s32 func_8003E2C8(void);
extern s32 game_GetPlayerCount(void);
extern s32 game_GetPause(void);
extern void func_8004A4E0(void);
extern void game_SetPause(s32);
void func_80044504(s32 a0) {
    s32 *s0 = &D_80101BD0;
    func_80042874(&D_800A3678, s0);
    func_8007EB4C(s0, (s32 *)(D_800A3708 + 0x18));
    calc_fc_frame_8007EC5C((s32 *)(D_800A370C + 0x18), s0);
    func_8007E4DC((s32 *)(D_800A370C + 0x18), (s32 *)(D_800A3708 + 0x18), &D_800FF610);
    if (D_800A36AC & 1) {
        *(s32 *)0x1F800014 = -1;
    } else {
        *(s32 *)0x1F800014 = 0;
    }
    camera_InitMatrix();
    *(s32 *)0x1F80001C = (s32)&D_80095328;
    *(s32 *)0x1F80000C = a0;
    {
        s32 v1;
        if (g_game_timer & 8) {
            v1 = func_8003E2C8();
        } else {
            v1 = 0x7FFFFFFF;
        }
        *(s32 *)0x1F800010 = v1;
    }
    {
        s32 v0 = game_GetPlayerCount();
        if (v0 != 0) {
            v0 = 0xBE;
        } else {
            v0 = game_GetPause();
            if (v0 != 0) {
                v0 = 0x182;
            } else {
                v0 = 0xBE;
            }
        }
        *(s32 *)0x1F800018 = v0;
    }
    func_8004A4E0();
    game_SetPause(1);
    D_800A3820 = (s32)&D_80102C00;
}
extern void InitFadePanel(void);
void func_80044650(void) {
    InitFadePanel();
}
extern s16 D_800A9CF8;
extern s32 D_800A9D00;
extern s32 D_800A9D04;
extern s16 D_800A9CFA;
extern s16 D_800A9CFC;
extern s16 D_800A9CFE;
extern s32 stage_GetId(void);
s32 func_80044670(s16 *a0, s16 a1, s32 a2) {
    s32 v0;



    do { } while (0);
    D_800A9CF8 = a1;
    v0 = *(u16 *)a0;
    a0++;
    D_800A9D00 = (s32)a0;
    D_800A9D04 = a2;
    D_800A9CFA = v0;
    v0 = stage_GetId();
    D_800A9CFC = v0;
    switch ((s16)v0) {
    case 7:
        D_800A9CFE = 0x11;
        break;
    case 4:
        D_800A9CFE = 2;
        break;
    case 0x12:
        D_800A9CFE = 0xA;
        break;
    }
    {
        s32 val = D_800A9CFE;
        return a2 + val * 104;
    }
}
extern s32 game_GetCharData(void);
extern s32 D_800A9D08;
void func_8004473C(void)
{
  extern s8 *D_800A9D04;
  register s32 temp_v0 asm("v0");
  s32 temp_v0_2;
  register s32 var_a2 asm("a2");
  s8 *var_a1;
  register s8 *var_v1 asm("v1");
  register void *var_a0 asm("a0");
  s8 *var_a3;
  register s32 const4 asm("t1");
  register s32 constneg1 asm("t0");
  s32 _sp_pad[2];
  __asm__ volatile("" : "=m"(_sp_pad[0]));
  temp_v0 = game_GetCharData();
  var_a2 = 0;
  var_a1 = D_800A9D04;
  *((s32 *) (((s8 *) &D_800A9D08) + 0)) = temp_v0;
  if (D_800A9CFE > 0)
  {
    var_a3 = ((s8 *) &D_800A9D08) - 0x10;
    const4 = 4;
    constneg1 = -1;
    var_a0 = (void *)(temp_v0 + 0x34);
    var_v1 = var_a1 + 0x58;
    do
    {
      *var_a1 = 0;
      *(s8 *)(var_v1 - 0x57) = 0;
      *(s16 *)(var_v1 - 0x56) = 0;
      *(u16 *)(var_v1 - 0x54) = *(u16 *)(var_a3 + 0);
      *(s16 *)(var_v1 - 0x50) = 0;
      *(s32 *)(var_v1 - 0x4C) = 0;
      *(s16 *)(var_v1 - 0x4E) = const4;
      *(s16 *)(var_v1 - 0x48) = 0;
      *(s16 *)(var_v1 - 0x46) = 0;
      *(s16 *)(var_v1 - 0x44) = 0;
      *(s32 *)(var_v1 - 0xC) = *(s32 *)((s8 *)var_a0 - 8);
      var_a1 += 0x68;
      *(s32 *)(var_v1 - 8) = *(s32 *)((s8 *)var_a0 - 4);
      var_a2 += 1;
      temp_v0_2 = *(s32 *)((s8 *)var_a0 + 0);
      var_a0 = (s8 *)var_a0 + 0x68;
      *(s16 *)(var_v1 - 0x52) = 0;
      *(s32 *)(var_v1 + 0) = constneg1;
      *(s32 *)(var_v1 - 4) = temp_v0_2;
      var_v1 += 0x68;
    }
    while (var_a2 < *(s16 *)(var_a3 + 6));
  }
}
extern void func_800417D0(s32 *);
void efc_rob_set_type_flash(void) {
    s16 local[3];
    s16 sp18[10];
    s32 pad[4];
    register s32 i asm("s4");
    register s8 *obj asm("s2");
    s32 frame;
    s32 angle;
    s16 *scan;
    s16 *base_ptr;
    s32 type;
    s16 cos_val, sin_val;
    s32 fade;
    s32 anim_offset;
    s16 *judge_base;

    obj = *(s8 **)(&D_800A9D04);
    if (D_800A9CFE <= 0) return;

    base_ptr = (s16 *)((s8 *)&D_800A9D04 - 0xA);
    judge_base = Judge;
    anim_offset = 0;
    i = 0;
    do {
        frame = *(s32 *)(obj + 0x58);
        if (frame >= 0) {
            if (frame < *base_ptr) {
                local[0] = 0;
                angle = *(s32 *)(obj + 0x5C);
                local[2] = 0;
                scan = (s16 *)(*(s32 *)((s8 *)base_ptr + 6) + frame * 12);
                local[1] = (s16)angle;
                func_8004A348(local, (s32 *)sp18);
                local[0] = *(u16 *)scan; scan++;
                local[1] = *(u16 *)scan; scan++;
                local[2] = *(u16 *)scan; scan++;
                *(s16 *)(obj + 0x10) = *(u16 *)scan; scan++;
                *(s16 *)(obj + 0x12) = *(u16 *)scan;
                *(s16 *)(obj + 0x14) = *(u16 *)(scan + 1);
                *(s16 *)(obj + 0x6) = 0;
                func_800417D0((s32 *)obj);
                calc_fc_frame_8007EC5C((s32 *)sp18, (s32 *)(obj + 0x18));

                cos_val = judge_base[(angle + 0x400) & 0xFFF];

                {
                    s32 cz, sz, cx, sx;
                    cz = cos_val * local[2];
                    angle &= 0xFFF;
                    sin_val = judge_base[angle];
                    sz = sin_val * local[2];
                    cx = cos_val * local[0];
                    sx = sin_val * local[0];

                    *(s32 *)(obj + 0x2C) += (sz + cx) >> 12;
                    *(s32 *)(obj + 0x30) += local[1];
                    *(s32 *)(obj + 0x34) += (cz - sx) >> 12;
                }

                frame++;
                if (frame >= *base_ptr) {
                    *(s16 *)(obj + 0x60) = 0x1000;
                }
                *(s32 *)(obj + 0x58) = frame;

                type = *(s16 *)((s8 *)base_ptr + 2);
                if (type == 0x12) {
                    s8 *saved_obj = obj;
                    s32 idx;
                    obj = (s8 *)(*(s32 *)((s8 *)base_ptr + 0xE) + anim_offset);
                    idx = (frame - 1) + *base_ptr;
                    scan = (s16 *)(D_800A9D00 + idx * 12);
                    local[0] = *(u16 *)scan; scan++;
                    local[1] = *(u16 *)scan; scan++;
                    local[2] = *(u16 *)scan; scan++;
                    *(s16 *)(obj + 0x10) = *(u16 *)scan; scan++;
                    *(s16 *)(obj + 0x12) = *(u16 *)scan;
                    *(s16 *)(obj + 0x14) = *(u16 *)(scan + 1);
                    *(s16 *)(obj + 0x6) = 0;
                    func_800417D0((s32 *)obj);

                    *(s32 *)(obj + 0x2C) += local[0];
                    *(s32 *)(obj + 0x30) += local[1];
                    *(s32 *)(obj + 0x34) += local[2];
                    obj = saved_obj;
                    goto append_list;
                }
            } else {
                fade = *(s16 *)(obj + 0x60) - 0x40;
                if (fade < 0) {
                    fade = 0;
                }
                if (fade == 0 && *(s16 *)((s8 *)base_ptr + 2) != 4) {
                    *(s32 *)(obj + 0x58) = -2;
                }
                *(s16 *)(obj + 0x60) = (s16)fade;
            }
append_list:
            {
                s32 *list = (s32 *)D_800A3820;
                D_800A3820 = (s32)(list + 1);
                *list = (s32)obj;
            }
        }
        obj += 0x68;
        i++;
        anim_offset += 0x68;
    } while (i < D_800A9CFE);
}

extern s32 D_800F66A0[];
typedef void (*FuncPtr44B30)(s16 *, s16 *);
typedef struct { s32 f0, f1, f2; } Vec3_44B30;

void func_80044B30(s32 a0, s32 a1) {
    s8 *p;
    s16 stage;

    if (a0 >= D_800A9CFE) return;

    p = (s8 *)(D_800A9D04 + a0 * 0x68);
    if (*(s32 *)(p + 0x58) != -1) return;

    stage = D_800A9CFC;
    if (stage == 4) goto case4;
    if (stage == 0x12) goto set_zero;
    goto do_store;

case4:
    if (a0 == 0) {
        a1 = 0x800;
    }
    if (a0 != 1) {
        goto do_store;
    }
set_zero:
    a1 = 0;

do_store:
    *(s32 *)(p + 0x5C) = a1;
    *(s32 *)(p + 0x58) = 0;
    p = (s8 *)(D_800A9D08 + a0 * 0x68);
    *(s16 *)(p + 0x2) = 1;
    {
        u16 cf8 = D_800A9CF8;
        s32 idx = *(s16 *)(p + 0x8);
        *(s16 *)(p + 0x12) = (s16)a1;
        *(s8 *)(p + 0x0) = 0;
        *(s32 *)(p + 0xC) = 0;
        *(s16 *)(p + 0x10) = 0;
        *(s16 *)(p + 0x14) = 0;
        *(s16 *)(p + 0x6) = 1;
        *(u16 *)(p + 0x4) = cf8;
        ((FuncPtr44B30)D_800F66A0[idx])((s16 *)(p + 0x10), (s16 *)(p + 0x18));
    }
    if (D_800A9CFC == 0x12) {
        *(Vec3_44B30 *)(p + 0x4C) = *(Vec3_44B30 *)(p + 0x2C);
    }
}
extern s16 D_800A9CF8;
extern s32 D_800A9D04;
extern s32 D_800A9D00;
extern void func_80044100(s32, s32);
void func_80044C70(s32 a0) {
    func_80044100((s32)D_800A9CF8, a0);
    D_800A9D04 += a0;
    D_800A9D00 += a0;
}
extern s32 math_Sin(s32);
extern s32 math_Cos(s32);
void func_80044CCC(s16 *a0, s16 *a1, s32 a2, s32 a3) {
    s32 sp18[3];
    s32 sp28[3];
    s16 angle;
    s32 radius;
    s32 v0;

    sp18[1] = a0[0];
    angle = a0[1];
    radius = a0[2];
    sp18[0] = (math_Sin(angle) * radius) >> 12;
    v0 = math_Cos(angle);
    sp18[1] = -sp18[1];
    sp18[2] = (v0 * radius) >> 12;
    sp18[2] = -sp18[2];

    sp28[1] = a1[0];
    angle = a1[1];
    radius = a1[2];
    sp28[0] = (math_Sin(angle) * radius) >> 12;
    v0 = math_Cos(angle);
    sp28[1] = -sp28[1];
    sp28[2] = (v0 * radius) >> 12;
    sp28[2] = -sp28[2];

    func_8007E1AC(sp18, sp28, 0x1000 - a2, a2, a3);
}
extern void func_8007E1AC(s32 *, s32 *, s32, s32, s32);
void func_80044DE4(s16 *a0, s16 *a1, s32 a2, s32 a3) {
    s32 sp18[3];
    s32 sp28[3];
    sp18[0] = a0[0];
    a0++;
    sp18[1] = -a0[0];
    sp18[2] = -a0[1];
    sp28[0] = a1[0];
    a1++;
    sp28[1] = -a1[0];
    sp28[2] = -a1[1];
    func_8007E1AC(sp18, sp28, 0x1000 - a2, a2, a3);
}
s32 func_80044E64(void) {
    return 0x25;
}
s32 func_80044E6C(void) {
    return 0x26;
}
extern void game_FrameLoop(void);
extern void special_camera_check_pos_outside_ground_80036E34(s32, s32, s32, s32);

typedef struct { s16 start_sector; s16 length_sectors; } NdataInfEntry;
extern NdataInfEntry D_800963EC[];

void func_80044E74(s32 a0, s32 a1) {
    game_FrameLoop();
    special_camera_check_pos_outside_ground_80036E34(0, a1, D_800963EC[a0].start_sector, D_800963EC[a0].length_sectors);
    game_FrameLoop();
}
void func_80044ED8(s32 a0, s32 a1) {
    if (a0 >= 0x1F) {
        a0 -= 0x1B;
    }
    if (!func_800450F4(a0, a1)) {
        func_80044E74(a0, a1);
    }
}
extern void func_80044E74(s32, s32);
extern s32 func_800450F4(s32, s32);
extern void func_80044E74(s32, s32);
void func_80044F30(s32 a0, s32 a1) {
    func_80044E74(a0 + 0x27, a1);
}
void func_80044F50(s32 a0, s32 a1, s32 a2) {
    if (!a0) {
        func_80044E74(a1 + 0x83, a2);
    } else {
        func_80044E74(a1 + 0x10C, a2);
    }
}
void saTan2InfoInit_80044F80(s32 a0, s32 a1) {
    func_80044E74(a0 + 0x4D, a1);
}
extern s32 D_800A3240;
extern char D_8001528C[];
s32 func_80044FA0(s32 a0, s32 a1) {
    s32 v0;
    s32 s0;

    s0 = a1 - (s32)func_80045814();
    if (s0 < 0) {
        goto set_from_table;
    }
    v0 = func_80045808();
    if (s0 >= v0) {
        goto set_from_table;
    }
    if (D_800A3240 != 0) {
        s0 = (s32)*(s16 *)((u8 *)&D_800963EE + a0 * 4) << 11;
    } else {
        s0 = 0;
    }
    v0 = func_800457DC();
    if (v0 < s0) {
        debug_printf(D_8001528C, a0, s0 - v0);
        while (1) {
            func_800164F8();
        }
    }
    goto do_return;
set_from_table:
    s0 = (s32)*(s16 *)((u8 *)&D_800963EE + a0 * 4) << 11;
do_return:
    func_80044E74(a0, a1);
    return s0;
}
extern s16 D_800963EE;
extern s32 func_800457DC(void);
s32 func_80045080(s32 a0) {
    s32 val = (s32)*(s16 *)((u8 *)&D_800963EE + a0 * 4) << 11;
    return func_800457DC() - val;
}
void seq_Start(s32 a0, s32 a1) {
    func_80044E74(a0 + 0x25, a1);
    D_800A3398 = a1;
    D_800A3244 = 1;
}
extern s16 D_800973EC[];
s32 func_800450F4(s32 a0, s32 a1) {
    s32 *a2_ptr;
    s32 v1;
    s32 *v0_ptr;
    if (D_800A3244 == 0) {
        return 0;
    }
    a0 -= 0x1E;
    if ((u32)a0 >= 7) {
        return 0;
    }
    a0 = D_800973EC[a0];
    if (a0 == -1) {
        return 0;
    }
    a2_ptr = (s32 *)D_800A3398;
    if (*a2_ptr != 5) {
        D_800A3244 = 0;
        return 0;
    }
    v0_ptr = (s32 *)(a0 * 4 + (s32)a2_ptr + 4);
    v1 = *v0_ptr;
    {
        s32 a0_new = (s32)a2_ptr + (((u32)v1 >> 2) << 2);
        s32 a2_val = v0_ptr[1] - v1;
        func_800520B8(a0_new, a1, a2_val);
    }
    return 1;
}
extern s32 D_800A3244;
void seq_Reset(void) {
    D_800A3244 = 0;
}
s32 seq_GetState(void) {
    return D_800A3244;
}
void func_800451A0(void) {
    special_camera_check_pos_outside_ground_80036E34(1, (s32)D_800963EC, 0, 2);
}
void func_800451D0(void) {
    s32 v1 = -1;
    s32 v0 = 0x90;
L_loop:
    *(s16 *)((u8 *)D_800EED10 + v0) = v1;
    v0 -= 0x10;
    if (v0 >= 0) goto L_loop;
    D_800A33A0 = (s32)&D_800A9D10;
    D_800A33A4 = 0x45000;
    D_800A33AC = 0;
    D_800A33A8 = 0;
    func_80049E1C();
}
void saTan5TakeGetPos_80045230(s32 a0) {
    s32 v1;
    if (!a0) {
        a0 = D_800A33A0;
    }
    a0 -= (s32)&D_800A9D10;
    v1 = a0;
    if (a0 < D_800A33A8) {
        v1 = D_800A33A8;
    }
    D_800A33A8 = v1;
    if (a0 > 0x44FFF) {
        InitFadePanel();
    }
}
void func_80045294(s32 a0, s32 a1) {
    s32 sum = 0;
    s32 v1 = a0 << 4;
    s32 s4 = *(s32 *)((u8 *)&D_800EED14 + v1);
    s32 i = a0;
    s32 count = D_800A33AC;
    s32 s5 = s4 + a1;

    if (i < count) {
        do {
            s32 val = *(s32 *)((u8 *)&D_800EED18 + v1);
            v1 += 0x10;
            i += 1;
            sum += val;
        } while (i < count);
    }

    if (sum != 0) {
        s32 *ptr;
        s32 idx;

        gpu_DrawSync(0);
        func_800520B8(s4, s5, sum);

        i = a0;
        if (i < D_800A33AC) {
            v1 = i << 4;
            ptr = (s32 *)((u8 *)&D_800EED14 + v1);
            idx = v1;
            do {
                *ptr += a1;
                {
                    void (*fn)(s16, s32) = (void (*)(s16, s32)) *(s32 *)((u8 *)&D_800EED1C + idx);
                    if (fn != 0) {
                        fn(*(s16 *)((u8 *)&D_800EED10 + idx), a1);
                    }
                }
                ptr = (s32 *)((u8 *)ptr + 0x10);
                idx += 0x10;
                i += 1;
            } while (i < D_800A33AC);
        }
    }

    D_800A33A0 += a1;
    D_800A33A4 -= a1;
}
void func_800453E0(s32 a0) {
    s32 s0 = 0;
    s32 s1;
    s32 *s2;
    s32 *s3;
    s32 v1;
    s32 t0;
    volatile s32 sp_pad;
    s32 v0;

    v0 = D_800A33AC;
    if (v0 <= 0) goto L_exit;

    s2 = D_800EED00;
    s3 = s2 + 4;
    v1 = 0;

L_search:
    v0 = *(s16 *)((u8 *)D_800EED10 + v1);
    if (v0 != a0) goto L_not_found;

    s1 = s0 + 1;
    saTan0Init(s1, -(*(s32 *)((u8 *)&D_800EED18 + v1)));

    {
        s32 v1b = D_800A33AC;
        s32 v0b = v1b - 1;
        if (s0 >= v0b) goto L_clear;
        t0 = s1;
        if (t0 >= v1b) goto L_clear;

        {
            s32 *a3p = t0 * 4 + s2;
            s32 *a2p = t0 * 4 + s3;
L_copy:
            {
                s32 w0 = a2p[0];
                s32 w1 = a2p[1];
                s32 w2 = a2p[2];
                s32 w3 = a2p[3];
                a3p[0] = w0;
                a3p[1] = w1;
                a3p[2] = w2;
                a3p[3] = w3;
                a3p += 4;
                v0 = D_800A33AC;
                t0++;
                a2p += 4;
                if (t0 < v0) goto L_copy;
            }
        }
    }

L_clear:
    {
        s32 cnt;
        s32 neg1;
        s32 shift;
        cnt = D_800A33AC;
        neg1 = -1;
        cnt--;
        shift = cnt << 4;
        *(s16 *)((u8 *)D_800EED10 + shift) = neg1;
        *(s32 *)((u8 *)D_800EED1C + shift) = 0;
        D_800A33AC = cnt;
    }
    goto L_exit;

L_not_found:
    v0 = D_800A33AC;
    s0++;
    v1 += 0x10;
    if (s0 < v0) goto L_search;

L_exit:
    return;
}
void saSeMain_80045510(s32 a0, s32 a1) {
    volatile s32 sp_pad;
    s32 i = 0;
    s32 count = D_800A33AC;
    if (count <= 0) return;
    {
        s16 *s0 = (s16 *)&D_800EED18;
        s32 v1 = 0;
        do {
            if (*(s16 *)((s32)&D_800EED10 + v1) == a0) {
                s32 diff = a1 - *(s32 *)s0;
                if (diff == 0) return;
                func_80045294(i + 1, diff);
                *(s32 *)s0 = a1;
                return;
            }
            s0 = (s16 *)((u8 *)s0 + 0x10);
            count = D_800A33AC;
            i += 1;
            v1 += 0x10;
        } while (i < count);
    }
}
s32 *func_800455AC(s32 a0) {
    s32 idx;
    s32 *ret;
    s16 *slot;
    func_800453E0(a0);
    idx = D_800A33AC;
    slot = (s16 *)((u8 *)D_800EED10 + idx * 16);
    D_800A33AC = idx + 1;
    ret = (s32 *)D_800A33A0;
    *(s32 *)((u8 *)slot + 4) = (s32)ret;
    *slot = a0;
    *(s32 *)((u8 *)slot + 0xC) = 0;
    return ret;
}
void saSeMain_80045600(s32 a0, s32 a1) {
    volatile s32 sp_pad;
    s32 i = 0;
    s32 count = D_800A33AC;
    s16 *a3;
    if (count <= 0) goto not_found;
    {
        s16 *a2 = D_800EED10;
        do {
            a3 = a2;
            if (*(s16 *)a3 == a0) goto found;
            i++;
            a2 = (s16 *)((u8 *)a3 + 0x10);
        } while (i < count);
    }
found:
    if (i < D_800A33AC) {
        register s32 old_a0 asm("v0") = D_800A33A0;
        s32 old_a4 = D_800A33A4;
        a0 = a1 - old_a0;
        old_a0 = old_a0 + a0;
        old_a4 = old_a4 - a0;
        *(s32 *)((u8 *)a3 + 8) = a0;
        D_800A33A0 = old_a0;
        D_800A33A4 = old_a4;
        return;
    }
not_found:
    InitFadePanel();
}
extern s16 D_800EED10[];
extern s32 D_800EED1C[];
extern s32 D_800A33AC;
void saTan5TakeGetPos_80045694(s32 a0, s32 a1) {
    s32 i;
    s32 count = D_800A33AC;
    if (count <= 0) return;
    i = 0;
    do {
        if (*(s16 *)((u8 *)D_800EED10 + i) == a0) {
            *(s32 *)((u8 *)D_800EED1C + i) = a1;
            return;
        }
        i += 0x10;
    } while (i < count * 16);
}
void func_800456F0(s32 a0) {
    s32 i;
    s32 count = D_800A33AC;
    if (count <= 0) return;
    i = 0;
    do {
        if (*(s16 *)((u8 *)D_800EED10 + i) == a0) {
            *(s32 *)((u8 *)D_800EED1C + i) = 0;
            return;
        }
        i += 0x10;
    } while (i < count * 16);
}
s32 *func_8004574C(s32 arg0) {
    s32 *var_a1;
    s32 var_v1;
    s32 limit;

    if (D_800A33AC > 0) {
        var_a1 = (s32 *)&D_800EED10;
        var_v1 = 0;
        limit = D_800A33AC << 4;
        do {
            if (*(s16 *)((s32)&D_800EED10 + var_v1) == arg0) {
                return var_a1;
            }
            var_v1 += 0x10;
            var_a1 = (s32 *)((s32)var_a1 + 0x10);
        } while (var_v1 < limit);
    }
    return ((void *)0);
}
s32 func_800457A0(s32 a0) {
    s32 *v0 = func_8004574C();
    if (v0) {
        return v0[1];
    }
    return 0;
}
void func_800457D4(void) {
}
extern s32 D_800A33A4;
s32 func_800457DC(void) {
    return D_800A33A4;
}
extern s32 D_800A33A8;
s32 func_800457E8(void) {
    return 0x45000 - D_800A33A8;
}
extern s32 D_800A33A0;
s32 func_800457FC(void) {
    return D_800A33A0;
}
s32 func_80045808(void) {
    return 0x45000;
}
extern u8 D_800A9D10;
void *func_80045814(void) {
    return &D_800A9D10;
}
extern void func_800520B8(s32, s32, s32);
void md_mtest_init(s32 a0, s32 a1, s32 a2) {
    saTan5TakeGetPos_80045230(a1 + a2);
    func_800520B8(a0, a1, a2);
}
extern void saTan5TakeGetPos_80045230(s32);
extern void saTan5TakeGetPos_80045694(s32, s32);
extern void func_800400F8(s32);
extern void func_80044ED8(s32, s32);
extern s32 *func_8004574C(s32);
extern s32 *func_800455AC(s32);
extern void saSeMain_80045600(s32, s32);
extern void func_80045AA4(s32, s32);

void func_80045878(s32 a0, s32 a1, s32 a2) {
    s32 s3 = a0 + 3;
    s32 *v0;
    s16 *s1;
    s32 s0;
    v0 = func_8004574C(a0);
    if (v0 != 0) {
        s1 = (s16 *) v0[1];
    } else {
        s1 = (s16 *) func_800455AC(a0);
        saSeMain_80045600(a0, 0x1A88 + ((s32) s1));
        saTan5TakeGetPos_80045230(0);
        saTan5TakeGetPos_80045694(a0, (s32) (&func_80045AA4));
        s1[4] = -1;
        s1[3] = 0;
        s3 = a0 - -3;
    }
    if (func_8004574C(s3) != 0) {
        func_800400F8((s32) s1);
    }
    if (((func_8004574C(s3) != 0) && (s1[4] == a1)) && (s1[3] != (-2))) {
        s1[3] = 0;
    } else {
        *((s32 *) (((s32) s1) + 0x20)) = a2;
        s0 = (s32) func_800455AC(s3);
        *((s32 *) (((s32) s1) + 0x1C)) = s0;
        if (a2 != 0) {
            func_80044ED8(a1, a2);
        } else {
            func_80044ED8(a1, s0);
            s0 = s0 + ((((u32) ((s32 *) s0)[*((s32 *) s0)]) >> 2) << 2);
            saTan5TakeGetPos_80045230(s0);
        }
        saSeMain_80045600(s3, s0);
        saTan5TakeGetPos_80045694(s3, (s32) (&func_80045AA4));
        s1[3] = 1;
        *((s32 *) (((s32) s1) + 0x24)) = 0;
        *((s32 *) s1) = 0;
    }
    s1[11] = a0 + 3;
    s1[2] = a0;
    s1[4] = a1;
    s1[10] = a0;
    s1[8] = a0;
    *((s32 *) (((s32) s1) + 0x18)) = 0x8000;
}
void tslFileClose(s32 a0, s32 a1) {
    saSeMain_80045510(a0 + 3, a1);
    saTan5TakeGetPos_80045230(0);
}
extern void GetAllocPacketSize(void);
extern void func_800456F0(s32);
void func_80045A50(s32 a0) {
    s32 a0p3 = a0 + 3;
    GetAllocPacketSize();
    func_800456F0(a0p3);
    func_800456F0(a0);
    func_800453E0(a0p3);
    func_800453E0(a0);
}
extern void func_80044100(s32, s32);
extern void saFidLoad(s32, s32);
void func_80045AA4(s32 a0, s32 a1) {
    s32 *ptr;
    s32 idx;
    if (a0 < 3) {
        func_80041430(a0, a1);
        return;
    }
    idx = a0 - 3;
    func_80044100(idx, a1);
    func_80044100(a0, a1);
    ptr = (s32 *)func_800457A0(idx);
    if (ptr == 0) return;
    ptr[7] = ptr[7] + a1;
    func_8004019C((s32)ptr, a1);
    if ((ptr[0] >> 1) & 1) {
        s32 val = *(s16 *)((u8 *)ptr + 4);
        idx = 3 * val + 1;
        saFidLoad(a1, idx);
    }
}
void efc_rob_set_type_particle(s32 a0, s32 a1, s32 a2, s32 a3) {
    (void)a0;
    (void)a1;
    (void)a2;
    (void)a3;
}
extern void func_8005B6AC(void);
void saTanMainDispGnd_80046020(void) {
    func_800453E0(6);
    func_8005B6AC();
}
extern void saFidLoad(s32, s32);
void func_80046048(s32 a0, s32 a1) {
    s32 *s0;
    s32 count;
    func_80044100(6, a1);
    s0 = (s32 *)func_800457A0(6);
    if (s0 == ((void *)0)) {
        return;
    }
    {
        s32 off = *s0;
        if (off == 0) {
            return;
        }
        s0 = (s32 *)((u8 *)s0 + off);
    }
    count = *s0;
    count = count - 1;
    if (count == -1) {
        return;
    }
    s0++;
    do {
        saFidLoad(a1, *s0++);
        count--;
    } while (count != -1);
}
