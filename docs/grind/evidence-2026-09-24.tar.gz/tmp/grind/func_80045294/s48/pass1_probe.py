import json, sys, collections
sys.path.insert(0,'tools/sched_solver')
import simulate as S, perturb as P

model=json.load(open('tmp/sched_solver_work/text1a_c.sched.json'))
FUNC='func_80045294'
for f in model['funcs']:
    if f['func']!=FUNC or f['pass']!=1: continue
    for blk in f['blocks']:
        if blk['b']!=0: continue
        base=S.sim_block(P.apply_priorities(json.loads(json.dumps(blk))), False)
        print('block0 pass1 n_insns',blk['n_insns'],'baseline match',base['match'])
        print('baseline order',base['sim'])
        nodes={int(k):v for k,v in blk['nodes'].items()}
        for u in base['sim']:
            n=nodes.get(u,{})
            print('  uid',u,'luid',n.get('luid'),'pri',n.get('pri'),'icost',n.get('icost'),'rtl',str(n.get('rtl',''))[:90])
        atoms=P.enumerate_atoms(blk)
        seen=collections.Counter(); rep={}
        nchanged=0
        for at in atoms:
            b2=P.apply_atom(blk,at)
            if b2 is None: continue
            r=S.sim_block(b2, False)
            o=tuple(r['sim'])
            seen[o]+=1
            if o not in rep: rep[o]=P.describe(at)
        print('atoms tried',len(atoms),'distinct orders',len(seen))
        for o,c in seen.most_common():
            tag='BASELINE' if list(o)==base['sim'] else 'NOVEL'
            print(f'  {tag} x{c}: {list(o)}  e.g. {rep[o]}')
