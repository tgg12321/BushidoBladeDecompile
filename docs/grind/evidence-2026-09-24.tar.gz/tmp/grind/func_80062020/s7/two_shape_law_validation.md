# s7 — predictive validation of the two-shape theorem (func_80062020)

The two-shape theorem (s6) was DERIVED from five measured tree shapes (s5) plus the
MIPS `legitimize_address` rule set. A derivation that only explains the shapes it was
built from is an enumeration in disguise. This session tested two tree-node classes
the derivation had NEVER seen, choosing them because they are the two most plausible
falsifiers left: node types whose offset-0 access is spelled with a *different RTL
tree node* than the `ARRAY_REF` (`p[0]`) the law was built on.

Chassis for all rows: `sandbox func_80062020 --disable all`, candidate.c's loop body
and `ofs`-reuse register lever unchanged; only the col-a store spelling varies.
Baseline (candidate.c, `p[2]; p[1]; p[0]`): **score 4, build_insns 35, target 38,
rules_dropped 0, cheat_asm_stripped 173**.

| # | shape for col a | RTL tree node | law's prediction | measured |
|---|---|---|---|---|
| A | `*p = 0;` (`p` = `(s32*)((u8*)&D_800F1198+ofs)`) | INDIRECT_REF | base+disp, `sw zero,0(v0)` -> score 4 / 35 | **4 / 35** ✔ |
| B | `p->a = 0;` with `union RowU { s32 a; s32 w[3]; }`, cols b,c via `p->w[2]`, `p->w[1]` | COMPONENT_REF (union) over an aggregate whose offset-0 member aliases the whole row | base+disp incl. offset 0 -> score 4 / 35 | **4 / 35** ✔ |

Both predictions hit exactly, including insn count. Combined with s5's five shapes, the
prong-1 half of the law ("once the element address `sym + ofs` becomes a pointer VALUE
in the tree, every access off it — offset 0 included — expands to `(mem (plus base K))`")
is now validated across **seven distinct tree-node classes**: pointer ARRAY_REF,
pointer INDIRECT_REF, struct COMPONENT_REF, COMPONENT_REF whose member is a
1-element array, union COMPONENT_REF at offset 0, union COMPONENT_REF over an
array member, and (prong 2, the contrapositive) 2D ARRAY_REF `arr[i][K]`, which keeps
the symbol in the address and therefore folds K into the symbol for every column and
never forms a shared base.

Target's epilogue (asm/funcs/func_80062020.s:29-39, re-read this session) applies BOTH
treatments to the SAME address `&D_800F1198 + 12*count` held in `$v1`:

    sll  $v1,$a1,1 ; addu $v1,$v1,$a1 ; sll $v1,$v1,2      ; ofs = count*12
    lui  $v0,%hi(D_800F1198) ; addiu $v0,$v0,%lo(...)      ; la  -> pointer VALUE
    addu $v0,$v1,$v0                                        ; row base
    sw   $zero,0x8($v0)                                     ; col c  (base+disp)
    sw   $zero,0x4($v0)                                     ; col b  (base+disp)
    lui  $at,%hi(D_800F1198) ; addu $at,$at,$v1
    sw   $zero,%lo(D_800F1198)($at)                         ; col a  (LO_SUM, symbol
                                                            ;   never enters a register)

Since the treatment is selected per tree shape and is uniform across every access of
that shape, no single C expression shape can emit both. The original source therefore
wrote that one address in two different expression shapes. That is a statement about
the ORIGINAL SOURCE recovered from target bytes, not a statement about how to steer GCC.

Files: vA_indirect_ref_col_a.c, vB_union_member_offset0.c (both floor-equivalent, not
disproven -> kept here, not banked to rejected/).
