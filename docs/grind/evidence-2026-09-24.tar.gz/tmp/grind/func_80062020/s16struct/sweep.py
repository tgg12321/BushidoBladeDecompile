#!/usr/bin/env python3
"""s16 (structural, 2026-09-03): enumerate the EPILOGUE-SPELLING space on the
aggregate-declaration chassis and classify the three terminator stores.

Target arrangement (asm/funcs/func_80062020.s epilogue): the +8 and +4 columns
stored off a shared base register (DISP8 | DISP4) and the +0 column through the
inline-symbolic form (LOSUM0), in that emission order.

Chassis: the real function (real names, real copy loop) in a standalone TU with
the project's exact cc1 flags; only the epilogue statement(s) vary.  Declaration
variants get their own DECL block.
"""
import subprocess, pathlib, re
R = pathlib.Path("/mnt/c/Users/Trenton/Desktop/Bushido Blade 2 Decompile")
OUT = R / "tmp/grind/func_80062020/s16struct"
CC1 = R / "tools/gcc-2.7.2/build/cc1"
CPP = "mipsel-linux-gnu-cpp"
CC_FLAGS = "-O2 -G0 -funsigned-char -quiet -mcpu=3000 -mips1 -mno-abicalls -fno-builtin -w -mel".split()

BASE = "typedef int s32; typedef unsigned char u8;\nextern s32 D_800A32B8;\n"
DECL_REC = BASE + "typedef struct { s32 unk0; s32 unk4; s32 unk8; } Rec;\nextern Rec D_800F1198[];\n"
DECL_FLAT = BASE + "extern s32 D_800F1198[];\n"
DECL_2D = BASE + "extern s32 D_800F1198[][3];\n"

def fn(decl, loopstores, epi, extra_locals=""):
    return (decl + "void func_80062020(s32 *arg0) {\n    s32 i;\n    s32 ofs;\n    s32 t;\n"
            + extra_locals +
            "    t = *(s32 *)((u8 *)arg0 + 0);\n"
            "    D_800A32B8 = 0;\n    i = 0;\n"
            "    if ((t & 1) == 0) goto end;\n    ofs = 0;\n    do {\n"
            + loopstores +
            "        i = i + 1;\n        ofs = ofs + 12;\n"
            "        t = *(s32 *)((u8 *)arg0 + ofs + 0);\n"
            "    } while ((t & 1) != 0);\nend:\n" + epi + "\n}\n")

LS_REC = ("        D_800F1198[i].unk0 = *(s32 *)((u8 *)arg0 + ofs + 0);\n"
          "        D_800F1198[i].unk4 = *(s32 *)((u8 *)arg0 + ofs + 4);\n"
          "        D_800F1198[i].unk8 = *(s32 *)((u8 *)arg0 + ofs + 8);\n")
LS_FLAT = ("        D_800F1198[i * 3 + 0] = *(s32 *)((u8 *)arg0 + ofs + 0);\n"
           "        D_800F1198[i * 3 + 1] = *(s32 *)((u8 *)arg0 + ofs + 4);\n"
           "        D_800F1198[i * 3 + 2] = *(s32 *)((u8 *)arg0 + ofs + 8);\n")
LS_2D = ("        D_800F1198[i][0] = *(s32 *)((u8 *)arg0 + ofs + 0);\n"
         "        D_800F1198[i][1] = *(s32 *)((u8 *)arg0 + ofs + 4);\n"
         "        D_800F1198[i][2] = *(s32 *)((u8 *)arg0 + ofs + 8);\n")

def m(n):   return "D_800F1198[i].unk%d" % n
def f(n):   return "D_800F1198[i * 3 + %d]" % (n // 4)
def d(n):   return "D_800F1198[i][%d]" % (n // 4)

CASES = {}
# --- record chassis, chained (the banked control) ---
CASES["E01_rec_chain_048"]  = (DECL_REC, LS_REC, "    %s = %s = %s = 0;" % (m(0), m(4), m(8)), "")
CASES["E02_rec_chain_840"]  = (DECL_REC, LS_REC, "    %s = %s = %s = 0;" % (m(8), m(4), m(0)), "")
CASES["E03_rec_chain_408"]  = (DECL_REC, LS_REC, "    %s = %s = %s = 0;" % (m(4), m(0), m(8)), "")
CASES["E04_rec_chain_paren"]= (DECL_REC, LS_REC, "    %s = (%s = (%s = 0));" % (m(0), m(4), m(8)), "")
# --- record chassis, separate statements, all six orders ---
import itertools
for perm in itertools.permutations([0, 4, 8]):
    CASES["E05_rec_stmts_%d%d%d" % perm] = (DECL_REC, LS_REC,
        "".join("    %s = 0;\n" % m(x) for x in perm).rstrip("\n"), "")
# --- record chassis, 2-chain + statement mixes ---
CASES["E06_rec_chain48_then0"] = (DECL_REC, LS_REC, "    %s = %s = 0;\n    %s = 0;" % (m(4), m(8), m(0)), "")
CASES["E07_rec_chain84_then0"] = (DECL_REC, LS_REC, "    %s = %s = 0;\n    %s = 0;" % (m(8), m(4), m(0)), "")
CASES["E08_rec_0then_chain48"] = (DECL_REC, LS_REC, "    %s = 0;\n    %s = %s = 0;" % (m(0), m(4), m(8)), "")
CASES["E09_rec_chain04_then8"] = (DECL_REC, LS_REC, "    %s = %s = 0;\n    %s = 0;" % (m(0), m(4), m(8)), "")
# --- record chassis, comma operator ---
CASES["E10_rec_comma_840"] = (DECL_REC, LS_REC, "    %s = 0, %s = 0, %s = 0;" % (m(8), m(4), m(0)), "")
# --- record chassis, whole-struct assignment from a zeroed local ---
CASES["E11_rec_structassign"] = (DECL_REC, LS_REC,
    "    z.unk0 = 0;\n    z.unk4 = 0;\n    z.unk8 = 0;\n    D_800F1198[i] = z;", "    Rec z;\n")
# --- flat s32-array declaration ---
CASES["E12_flat_chain_048"] = (DECL_FLAT, LS_FLAT, "    %s = %s = %s = 0;" % (f(0), f(4), f(8)), "")
CASES["E13_flat_stmts_840"] = (DECL_FLAT, LS_FLAT, "    %s = 0;\n    %s = 0;\n    %s = 0;" % (f(8), f(4), f(0)), "")
# --- 2-D array declaration ---
CASES["E14_2d_chain_048"] = (DECL_2D, LS_2D, "    %s = %s = %s = 0;" % (d(0), d(4), d(8)), "")
CASES["E15_2d_stmts_840"] = (DECL_2D, LS_2D, "    %s = 0;\n    %s = 0;\n    %s = 0;" % (d(8), d(4), d(0)), "")

def classify(store):
    s = store.strip()
    mo = re.match(r"sw\s+\$\w+,\s*(-?\w+)\((\$\w+)\)", s)
    if not mo: return "??(%s)" % s
    off, base = mo.groups()
    if base == "$0": return "ABS%s" % off
    if off.startswith("%lo") or "D_800F1198" in off: return "LOSUM[%s]" % off
    return "DISP%s" % off

rows = []
for name, (decl, ls, epi, loc) in sorted(CASES.items()):
    src = OUT / (name + ".c"); src.write_text(fn(decl, ls, epi, loc))
    i = subprocess.run([CPP, "-lang-c", "-nostdinc", str(src)], capture_output=True, text=True)
    asm = OUT / (name + ".s")
    p = subprocess.run([str(CC1)] + CC_FLAGS + ["-o", str(asm)], input=i.stdout, capture_output=True, text=True)
    if p.returncode:
        rows.append((name, "CC1FAIL", p.stderr.strip()[:100], "")); continue
    txt = asm.read_text()
    lines = [l.strip() for l in txt.splitlines()]
    insns = [l for l in lines if l and not l.startswith(('.', '#')) and not l.endswith(':')]
    # terminator stores = the `sw $0`/`sw $zero` stores (value 0)
    zs = [l for l in lines if re.match(r"sw\s+\$(0|zero),", l)]
    rows.append((name, str(len(insns)), " | ".join(classify(z) for z in zs), " ; ".join(zs)))

w = OUT / "results.txt"
with w.open("w") as fh:
    fh.write("TARGET arrangement: DISP8 | DISP4 | LOSUM0   (target_insns 38)\n\n")
    for r in rows: fh.write("%-24s insns=%-4s %-40s   %s\n" % r)
print(w.read_text())
