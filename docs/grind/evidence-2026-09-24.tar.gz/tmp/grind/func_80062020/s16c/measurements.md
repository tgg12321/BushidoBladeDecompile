# func_80062020 — grind session s16c (rederive modality) — measurement log, 2026-09-03

Chassis: 2026-09-03, HEAD = c9e8d68a. No FAKE construct present in any body measured here.

## M1 — the banked s15 aggregate-merge body, re-proven on today's chassis (3rd independent proof)
    bash tools/wsl.sh 'python3 memory/grind/func_80062020/apply_s15.py apply'
      -> include/game.h + src/text1b.c + src/text1b_b.c modified (all three inside the
         live scope grant tools/grinder/scope_allow.txt:47)
    & tools/wteng.ps1 main verify-oracle --rebuild --allow-dirty   (full clean rebuild)
    & tools/wteng.ps1 main verify-oracle --allow-dirty
      -> "ok": true, "build_matches": true,
         "build_sha1": 62efab4f73f992798c43e8c730aa43baa10bb4fa
         == "original_sha1_locked": 62efab4f73f992798c43e8c730aa43baa10bb4fa
    & tools/wteng.ps1 main sandbox func_80062020 --disable all
      -> "score": 0, "target_insns": 38, "build_insns": 38, "scorable": true,
         "rules_dropped": 0, "cheat_asm_stripped": 165 (unrelated file-level asm)
Tree restored afterwards (apply_s15.py restore) and the scoring reference rebuilt from the
restored tree, so the next session's sandbox reads the honest HEAD chassis.

The form is BYTES-PROVEN on the live chassis. Nothing about the C is open.

## M2 — the ONLY remaining blocker is a one-line edit to a file outside this session's surface
The s16b ruling-request (prong (c) of the aggregate-merge family) was ANSWERED by the
operator amendment committed 2026-09-03 in 570210eb:

  .claude/rules/no-new-park-categories.md:245-259 — "(c) the merge is complete: every
  merged per-word symbol is removed from C and from the splat symbol config, leaving
  exactly one C handle per storage location — **amendment 2026-09-03 (operator, under the
  owner's 2026-08-19 self-serve discretion; func_80062020 20:46 layer-1 FAIL): a per-word
  symbol row may STAY in `undefined_syms_auto.txt` / `named_syms.txt` while a
  still-`INCLUDE_ASM` sibling's `asm/funcs/*.s` references it (deleting it would break that
  sibling's assembly), provided no C code names the symbol and the row is suffixed
  `/* alias of <base>+N; retire with <sibling> */`. Prong (c) is then satisfied; the row
  retires when the sibling lands**"

Two conditions. Status on the banked diff:
  (i) "no C code names the symbol" — SATISFIED. apply_s15.py deletes all nine vestigial
      `extern s32 D_800F1198 / D_800F119C / D_800F11A0;` declarations (src/text1b.c x2
      triples, src/text1b_b.c x1 triple); none had a use site. After the merge there is
      exactly one C handle, `extern Unk800F1198Record D_800F1198[];` in include/game.h.
      Verified this session: `grep -rn "D_800F119C\|D_800F11A0" src/ include/` -> no hits
      with the diff applied.
  (ii) "the row is suffixed `/* alias of <base>+N; retire with <sibling> */`" — NOT
      SATISFIABLE FROM THIS SESSION. The rows are undefined_syms_auto.txt:526-528. That
      path is NOT in this function's scope grant (tools/grinder/scope_allow.txt:47 grants
      `func_80062020 include/game.h src/text1b_b.c`), and the driver's end-of-session scope
      check is mechanical:
        grind.ps1:1002  $AllowedDirtyPattern = '^(\?\?|.M|M.|A.|.A)\s+("?)(memory/grind/|docs/grind/|tmp/|metrics/events\.jsonl|src/|include/)'
        grind.ps1:1150-1156  any dirty path not matching that pattern and not in
                             Get-ExtraScope is a SCOPE VIOLATION -> session discarded,
                             src reverted, outcome never read.
      i.e. a session that writes the suffix is thrown away BEFORE its candidate is seen —
      the exact "grant that silently no-ops" failure the comment at grind.ps1:1141-1149
      documents (func_80038170 burned two grants that way).

By contrast func_80033550's grant (scope_allow.txt:45) DOES include
`undefined_syms_auto.txt named_syms.txt`, for the same class of merge. The remedy here is
the identical one-line widening.

## M3 — the suffix is byte-neutral, so nothing about the proof changes when it is added
undefined_syms_auto.txt is fed to ld with `-T` (Makefile:99), i.e. it is parsed as a GNU ld
script, where `/* ... */` is a comment. Adding the mandated suffix to lines 527-528 cannot
move a byte; M1's SHA1 proof therefore stands unchanged for the suffixed tree. (The rows
themselves must NOT be deleted: bb2.ld does not define these symbols — undefined_syms_auto.txt
is the only definition site — and asm/funcs/func_800620B8.s, still INCLUDE_ASM, relocates
against both names. Deleting them is an undefined-symbol link error, which is precisely why
the amendment exists. Standing judge constraint says the same.)

## M4 — why this session did NOT return candidate-ready
Prong (c) as amended is a conjunction and condition (ii) is unmet on the submittable tree.
The aggregate-merge prongs are "ALL mandatory" and this body's last two layer-1 reviews
FAILed on family-prong grounds (0903-2023, 0903-2046). Submitting a diff that visibly fails
the literal text of the very amendment written for this function invites a third layer-1
FAIL and risks a construct-level ban on the only known matching declaration. The disciplined
move under the role contract ("if you cannot satisfy a prong, ask") is a ruling-request
naming the executable remedy (scope_paths widening), which is the same mechanism that
produced this function's existing grant on 2026-09-03.
