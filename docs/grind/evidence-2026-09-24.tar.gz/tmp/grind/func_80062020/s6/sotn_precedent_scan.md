# s6 SOTN-MASTER PRECEDENT SCAN — the gate s4 declared empty without running it

s4's OWNER-ESCALATION (docs/grind/decisions.md 2026-07-24) rests on this claim:

> "no SOTN/VS/ESA/oot/MGS precedent for a same-lvalue respelling (identical
> value/memory/store; only GCC's address-rtx CSE decision changes)."

That claim was asserted, not measured. This session measured it against the
sotn-decomp master clone at `C:/Users/Trenton/Desktop/sotn-decomp`
(HEAD `db41b28eee52969244a52cc269c8163d1ed8826a`), PSX sources only
(`src/main_psp`, `src/dra_psp`, `src/saturn`, `src/pc` excluded — different
compilers, no weight for a GCC 2.7.2 question).

## Scan 1 — alias to a global coexisting with direct access to that global

Script: `sotn_scan_alias_plus_direct.py`; output `sotn_alias_plus_direct_hits.txt`.

**830 functions** in SOTN master declare a local pointer alias `p = &GLOBAL;`,
dereference `p`, AND access `GLOBAL` directly in the same function body.
This is ordinary, pervasive SOTN idiom (`g_Entities`, `g_PrimBuf`, `g_Dop`,
`DOPPLEGANGER`, `g_Tilemap`, `PLAYER`, `g_MemcardInfo`, ...).

## Scan 2 — the NARROW gate: the SAME MEMBER spelled both ways in one function

Script: `sotn_scan_same_member_dual.py`; output `sotn_same_member_dual_hits.txt`.

**34 instances** where a function declares `p = &GLOBAL[idx];`, accesses
`p->member`, AND accesses `GLOBAL[idx].member` directly — the same lvalue,
two spellings, in one function. PSX (GCC 2.7.2) hits include:

- `src/st/cen/e_chamber.c` — `tilemap = &g_Tilemap;` / member `height`
- `src/st/lib/e_lock_camera.c` — `tilemap = &g_Tilemap;` / members `width`, `x`
- `src/boss/bo4/doppleganger.c` — `entity = &g_Entities[E_ID_41];` / `flags`
- `src/boss/rbo5/doppleganger.c` — same
- `src/dra/42398.c` — `g_CurrentBuffer = &g_GpuBuffers[0];` / `next`
- `src/dra/cd.c` — `cdFile = &g_LbaStagePrg;` / `loc`, `nextCdFileType`, `size`
- `src/dra/cd.c` — `new_var3 = &g_Cd;` / `D_80137F74`
- `src/main/psxsdk/libgpu/font.c` — `font = &Font[id];` / `buffer`
- `src/st/cen/e_chamber.c` — `holyGlassesEntity = &g_Entities[204];` /
  `flags`, `params`, `step`
- `src/servant/tt_000/bat.c` — `follow = &PLAYER;` / `posX`, `posY`
- `src/st/are/e_blade_master.c` — `player = &PLAYER;` / `step`

## Hand-verified exemplar (the citable one)

`src/st/cen/e_chamber.c`, function `EntityPlatform` (lines 70-571, one function
— boundaries confirmed by `grep -n '^[A-Za-z_].*(\|^}'`):

```
 72:    Tilemap* tilemap = &g_Tilemap;          <- the alias
201:            tilemap->height = ((s16)tilemap->scrollY.i.hi + 0x100);
240:        if (g_Tilemap.height == 0x200 && g_CutsceneFlags & 8) {   <- DIRECT, same member
335:            tilemap->height = tilemap->scrollY.i.hi + 0x100;
382:                tilemap->height = tilemap->scrollY.i.hi + 0x100;
432:        if (tilemap->height == 0x300) {
434:            g_Tilemap.y = 0;                                      <- DIRECT again
489:                tilemap->height = tilemap->scrollY.i.hi + 0x100;
547:            tilemap->height = tilemap->scrollY.i.hi + 0x100;
```

`g_Tilemap.height` is read directly at line 240 while every other access to that
exact member in the same function goes through the `tilemap` alias declared at
line 72. Semantically identical; the only difference is which address
computation GCC emits.

## What this does and does not establish

**Does:** SOTN master (PSX / GCC 2.7.2) ships the shape "one object, one member,
reached both through a local pointer alias and directly, within a single
function." The BB2 sanctioned family `.claude/rules/pointer-alias-fake-exception.md`
already covers the alias half of that shape verbatim: *"a local pointer that
provides a second C handle to a global — where using the global directly would be
semantically identical — is a sanctioned last-resort matching lever."*
s4's "no precedent exists" gate assertion is measured FALSE.

**Does not:** establish that BB2 may spell func_80062020's epilogue that way.
Two honest differences remain and are exactly what the ruling must resolve:

1. In every SOTN hit the alias is the *natural* handle for the object and the
   direct access is incidental (or vice versa) — the mix is a decompiler-noise
   artifact of the original programmer's habits. In func_80062020 the mix would
   be *load-bearing*: the alias carries cols b,c and the direct expression
   carries col a, and swapping either one moves bytes. A reader can ask "why
   isn't col a `row[0]`?" and the only honest answer names GCC's expand
   behaviour.
2. The SOTN hits are struct-member aliases where the alias covers the whole
   object; here the alias's own target (offset 0) is precisely the element that
   is *not* accessed through it. That inverted shape has no exemplar in the 34.

Which of those two readings governs is not a call this session can make — see
the ruling question in the outcome JSON.

## Current-chassis measurement of the contested form (exhibit, not a proposal)

`v_alias_plus_direct.c` (row alias for cols c,b + direct global store for col a),
applied to src/text1b.c on this chassis:

```
sandbox func_80062020 --disable all
  "score": 0, "target_insns": 38, "build_insns": 38, "rules_dropped": 0
```

Byte-exact, zero rules, zero pins, zero dead vars. src/text1b.c was restored to
the clean floor-4 candidate immediately afterwards (re-measured: score 4,
build_insns 35). The contested form was NOT saved as candidate.c and is NOT in
src — it is a ruling exhibit only, because the shape sits in this function's
rejected bank and the ledger's own frontier pre-registered "ruling-request, not
submission" as the correct disposition for it.
