import re,os
lines=open('tmp/grind/func_80062020/s9/all.dis').read().split('\n')
cur=None; funcs={}; order=[]
for l in lines:
    m=re.match(r'^([0-9a-f]{8}) <(.+)>:',l)
    if m: cur=m.group(2); funcs[cur]=[]; order.append(cur)
    elif cur is not None:
        m2=re.match(r'^\s*([0-9a-f]+):\s+[0-9a-f]{8}\s+(.*)$',l)
        if m2: funcs[cur].append(m2.group(2).strip())
def s16(v): return v-0x10000 if v>=0x8000 else v
unmatched=set(os.path.splitext(os.path.basename(p))[0] for p in os.listdir('asm/funcs'))
res=[]
for f in order:
    ins=funcs[f]
    la={}   # symbol addr -> True (register-materialized)
    losum=set()
    for i,x in enumerate(ins):
        m=re.match(r'lui\s+(\w+),0x([0-9a-f]+)$',x)
        if not m: continue
        r,h=m.group(1),int(m.group(2),16)
        # form A: addiu r,r,L
        for k in (i+1,i+2):
            if k<len(ins):
                m2=re.match(r'addiu\s+%s,%s,(-?\d+)$'%(r,r),ins[k])
                if m2: la.setdefault((h<<16)+s16(int(m2.group(1))&0xffff if int(m2.group(1))>=0 else int(m2.group(1))+0x10000),0); la[(h<<16)+int(m2.group(1))]=1
        if r=='at':
            for k in (i+1,i+2):
                if k<len(ins) and re.match(r'addu\s+at,at,\w+',ins[k]):
                    for k2 in (k+1,k+2):
                        if k2<len(ins):
                            m3=re.match(r'(sw|sh|sb|lw|lh|lbu|lhu|lb)\s+\w+,(-?\d+)\(at\)$',ins[k2])
                            if m3: losum.add((h<<16)+int(m3.group(2)))
    both=set(la)&losum
    if both: res.append((f,sorted(hex(x) for x in both)))
for f,b in res: print(('ASM' if f in unmatched else 'SRC'),f,b)
