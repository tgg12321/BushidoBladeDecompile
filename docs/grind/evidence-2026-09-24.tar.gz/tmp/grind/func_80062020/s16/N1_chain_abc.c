typedef int s32;
struct Rec { s32 a; s32 b; s32 c; };
extern struct Rec g_table[];
struct Rec4 { s32 a; s32 b; s32 c; s32 d; };
extern struct Rec4 g_t4[];
void f(s32 i){ g_table[i].a = g_table[i].b = g_table[i].c = 0; }
