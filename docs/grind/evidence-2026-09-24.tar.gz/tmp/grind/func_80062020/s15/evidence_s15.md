
---

## s15 (synthesis, 2026-09-03) — THE RESIDUAL IS CLOSED: bytes proven, full-build SHA1 == oracle

**Headline.** func_80062020 byte-matches with honest, uniform, ordinary C. The 15-session
epilogue residual was never a codegen-device problem; it was a DECLARATION problem. Under
the per-word-splat-symbol aggregate merge (.claude/rules/no-new-park-categories.md:238) the
three splat scalars D_800F1198 / D_800F119C / D_800F11A0 become one 3-word record array,
and a plain chained assignment then produces the target's mixed epilogue from a single
uniform spelling. Matching body: `memory/grind/func_80062020/candidate.c`. Reproduce the
tree edit with `tmp/grind/func_80062020/s15/apply.py apply|restore`.

**Measurements (in order, all this session).**
1. Chassis check on HEAD: `verify-oracle` ok:true, build_matches:true, build_sha1 ==
   62efab4f73f992798c43e8c730aa43baa10bb4fa.
2. `sandbox func_80062020 --disable all` with the s15 body applied: **score 2**,
   target_insns 38, build_insns 38, rules_dropped 0, cheat_asm_stripped 165. Measured
   against a FRESHLY REBUILT clean reference (`verify-oracle --rebuild` on HEAD first).
3. `engine build` (full clean-driver build + link) with the diff in place: sha1
   62efab4f73f992798c43e8c730aa43baa10bb4fa == oracle, **MATCH**.

**Why the sandbox prints 2 on a byte-matching function.** objdump -dr of the built .o shows
it is instruction-for-instruction identical to asm/funcs/func_80062020.s (38 == 38). The
only two words that differ BEFORE linking are the two in-loop stores: the merged
declaration relocates them R_MIPS_HI16/LO16 against D_800F1198 with in-field addends 4 and
8, where the reference .o relocates against the splat per-word symbols D_800F119C /
D_800F11A0 with addend 0. S+A is 0x800F119C / 0x800F11A0 either way, so the linked words
are identical — which the full-build SHA1 proves. engine/score.py masks section-relative
HI16/LO16 addends but DELIBERATELY NOT named-symbol ones (its module docstring, lines 8-11
and 61-63), so this scores as a difference. The residual is a pre-link spelling artefact of
the merge, not a codegen difference, and it is not removable in C while
asm/funcs/func_800620B8.s (still INCLUDE_ASM) keeps D_800F119C / D_800F11A0 alive as
link-time symbols. **A future session must not read "floor 2" as two missing
instructions.**

**The mechanism, measured not guessed.** Sweeps, all in tmp/grind/func_80062020/s15/:

- `sweep15.py` (15 shapes) KILLED H-s15-1, the last untried single-tree-shape idea: that
  the DISP-vs-LOSUM split was caused by the pointer VARIABLE, so subscripting a cast
  expression in place would leave expand a 3-term address for the +8/+4 stores and a
  legitimate 2-term address for the +0 store. It does not. For every in-place spelling
  tried — `((s32 *)((u8 *)&D_800F1198 + ofs))[K]`, `*((s32 *)(...) + K)`, the byte-cast
  round trip, the `(*(s32 (*)[3])(...))[K]` row cast, `((struct R *)(...))->m`, both
  operand orders, and the negative-subscript anchor-past-the-row variants — fold
  reassociates the constant K into the SYMBOL, giving all-LOSUM
  (LOSUM[D_800F1198+8] | LOSUM[D_800F1198+4] | LOSUM[D_800F1198]) at 25 harness insns.
  Same outcome as the s9 "&SYM + ofs + K" form. The s14 controls A0/A3 were re-included
  and reproduced exactly (Z0 = DISP8|DISP4|DISP0, Z1 = the target arrangement), so the
  chassis is stable and every s13/s14 instance kill stands on it.
- `sweep15b.py` found the crack. On a struct-array / 2D-array declaration, shape S5 — the
  FORWARD chained assignment `D_800F1198[i].c = D_800F1198[i].b = D_800F1198[i].a = 0;` —
  emitted `la $2,D_800F1198 / addu $2,$3,$2 / sw $0,0($2) / sw $0,4($2) /
  sw $0,D_800F1198+8($3)`, i.e. **DISP0 | DISP4 | LOSUM[D_800F1198+8]**: the target's
  arrangement MIRRORED, from ONE uniform spelling with no pointer local and no second
  address materialisation. Two facts combine to produce it. (i) With a record declaration
  the member offsets are COMPONENT_REF offsets on an ARRAY_REF, not integer constants
  added to an address expression, so fold has nothing to reassociate into the symbol —
  which is exactly what defeated every scalar-chassis spelling. (ii) GCC 2.7.2 stores a
  chained assignment right-to-left and leaves the LAST store of the chain in the
  inline-symbolic form while the earlier ones share a base pseudo.
- `sweep15c.py` spent that: reversing the chain puts column a last.
  `D_800F1198[i].a = D_800F1198[i].b = D_800F1198[i].c = 0;` gives
  **DISP8 | DISP4 | LOSUM[D_800F1198]** — the target arrangement — on both the struct-array
  (R1) and 2D-array (R2) declarations. Sub-chains (a chain of two plus a separate store,
  either order: R4/R5/R6) do NOT work — they fall back to all-LOSUM — so the effect needs
  the full three-link chain. On the scalar splat-symbol chassis the same chain gives
  all-LOSUM (R7/R8/R9), confirming the aggregate declaration is load-bearing, not the
  chain alone.
- `sweep15d.py` / `sweep15e.py` fitted the loop. Array-style reads plus `arg0 = arg0 + 3`
  make GCC keep TWO walking source pointers (3 insns over target). Keeping candidate.c's
  proven read spelling `*(s32 *)((u8 *)arg0 + ofs + N)` against a byte offset `ofs`, with
  the destination indexed by the record counter `i`, reproduces the target loop exactly
  (V1/V2, 27 harness insns, differing from the target listing ONLY in the assembler's
  symbol spelling `D_800F1198+4` vs `D_800F119C` — the same address). One further insn was
  spent and recovered in the sandbox: reading the terminator word into `t` BEFORE the
  `D_800A32B8 = 0;` store is what lets that store fill the load-delay slot; with `i = 0;`
  and the store hoisted ahead of the read the sandbox printed 39 insns / score 4.

**Object-model evidence for the merge (prong (a), independent of byte-chasing, not
adjacency — cf. [[splat-symbol-names-are-not-evidence]]).** The ORIGINAL binary walks the
table with a 12-byte-stride induction register (`addiu $v1, $v1, 0xC`, 0x80062080) writing
three words per step, and addresses the terminator record's members through one base
register at displacements 0x8 and 0x4 (0x8006209C, 0x800620A0). asm/funcs/func_800620B8.s
reads the same table with the same 12-byte stride, so the record shape is cross-function.

**Diff applied to the tree (three files).** `include/game.h` gains the aggregate
declaration (`typedef struct { s32 unk0; s32 unk4; s32 unk8; } Unk800F1198Record;` plus
`extern Unk800F1198Record D_800F1198[];`); `src/text1b.c` loses both stale
`extern s32 D_800F1198/119C/11A0;` triples (2145-2147, 3929-3931) and its INCLUDE_ASM
becomes the C body; `src/text1b_b.c` loses the third stale triple (387-389). None of the
nine removed declarations had a use site anywhere in src/ — they were vestigial. Merge
completeness is PARTIAL and disclosed: `undefined_syms_auto.txt:527-528` must keep
D_800F119C / D_800F11A0 defined while func_800620B8 is still INCLUDE_ASM and references
them in asm. Full prong-by-prong argument in `memory/grind/func_80062020/self_vet.md`.

**What this retires.** The s14 class kill ("the target's mixed epilogue requires two
different address trees for the same lvalue base — the banned construct") was correct about
the SCALAR chassis and wrong as a class: it was derived from a two-generator model of
`(mem (plus (reg) (symbol_ref)))` validated only on whole-function poles that all used
splat per-word scalars, and it never considered that the member offset could be a
COMPONENT_REF rather than an integer constant. The s15 body materialises the row address
exactly ONCE and still reaches the target mix. This is the CONTRADICTION RULE firing
exactly as written: the weakest foreclosure was the one whose predicate had never been
tested against a declaration change.
