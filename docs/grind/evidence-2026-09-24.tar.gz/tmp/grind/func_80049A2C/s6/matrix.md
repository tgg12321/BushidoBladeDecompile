# s6 measurement matrix — func_80049A2C frame-slot law + stripper-hole audit
Target prologue: `addiu $sp,-0x30` (48). Build without any local: 40.
"real" = frame of `make build/src/text1b.o` (unstripped, true cc1 output).
"sandbox" = `engine sandbox func_80049A2C --disable all` (cheat-invisible score).

| id  | local declaration                    | extra reference   | real frame | sandbox | stripped? |
|-----|--------------------------------------|-------------------|-----------:|--------:|-----------|
|base | `s32 dummy[2];  /* comment */`       | `(void) dummy;`   |         48 |       0 | shim only (comment defeats _ORPHAN_DECL_RE `;[ \t]*$`) |
| v1  | `s32 dummy[2];`                      | none              |         48 |      12 | decl (find_unused_local_arrays, 2<=n<=64, 0 refs) |
| v2  | `char dummy[1];`                     | none              |         40 |      12 | no (n=1 escapes) — REAL: no slot |
| v3  | `s16 a1_val_a[1];` **live**          | real reads/writes |         40 |      12 | no — REAL: register-allocated, zero stack traffic, 126 insns |
| v6  | `s32 dummy[1];`                      | `(void) dummy;`   |         40 |      12 | REAL: no slot (SImode pseudo) |
| v7  | `char dummy[4];`                     | `(void) dummy;`   |         48 |      12 | decl+shim |
| v13 | `s32 dummy[2];`                      | `(void) dummy[0];`|         48 |       0 | no (indexed read not matched by _VOID_DISCARD_NO_ADDR_RE) |
| v14 | `char dummy[2];`                     | none              |         48 |      12 | decl |
| v15 | `char dummy[3];`                     | none              |         48 |      12 | decl |
| v16 | `struct { s16 a; s16 b; } dummy;`    | none              |         48 |   **0** | no — NO detector covers a zero-reference struct-typed local |

## Derived law (all 10 rows consistent)
A local aggregate whose (size, alignment) admits a scalar integer machine mode
(`char[1]`=QI, `s16[1]`=HI, `s32[1]`=SI) is register-allocated by GCC 2.7.2 and
reserves NO frame bytes. One whose (size, alignment) does NOT
(`char[2..4]`, `s32[2]`, `struct{s16,s16}`) is BLKmode, goes through
`assign_stack_local`, and `get_frame_size()` becomes 1..8 -> ALIGN8 -> 8 ->
frame 40+8 = 48 = target. Size beyond that is irrelevant; ALIGNMENT, not size,
decides. `(void) dummy;` is NOT required for the slot (v1/v14/v15/v16 have zero
references and still reach 48) — s1's "shim is load-bearing" reading was an
artifact of the sandbox stripper, not codegen.
