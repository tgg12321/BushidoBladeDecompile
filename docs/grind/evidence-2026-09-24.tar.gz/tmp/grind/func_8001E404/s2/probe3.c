/* probe3.c — narrowing the deleted-call reconstruction.
 * (a) how many words does the dead call need for args=24?
 * (b) does a deleted call still emit its string literal into .rodata?
 *     (if yes, and the target has no orphan string, the original dead call
 *      carried no string argument — i.e. it was not a printf-style call.)
 */
typedef signed int s32;
typedef struct { s32 a[18]; } Buf;

extern s32 G;
extern s32 Gsrc[32];
extern void f4(s32 *, s32 *, s32);
extern void g5();
extern void gp();

void r_dead5(void) {
    Buf local;
    if (0) { g5(1, 2, 3, 4, 5); }
    local = *(Buf *)Gsrc;
    f4((s32 *)&local, (s32 *)&local.a[4], local.a[6]);
    G = (s32)&local;
}

void r_dead6(void) {
    Buf local;
    if (0) { g5(1, 2, 3, 4, 5, 6); }
    local = *(Buf *)Gsrc;
    f4((s32 *)&local, (s32 *)&local.a[4], local.a[6]);
    G = (s32)&local;
}

void r_dead7(void) {
    Buf local;
    if (0) { g5(1, 2, 3, 4, 5, 6, 7); }
    local = *(Buf *)Gsrc;
    f4((s32 *)&local, (s32 *)&local.a[4], local.a[6]);
    G = (s32)&local;
}

void r_deadstr(void) {
    Buf local;
    if (0) { gp("cam %d %d %d %d %d\n", 1, 2, 3, 4, 5); }
    local = *(Buf *)Gsrc;
    f4((s32 *)&local, (s32 *)&local.a[4], local.a[6]);
    G = (s32)&local;
}
