#!/usr/bin/env python3
"""Normalized instruction diff: our sandbox object vs splat target asm."""
import re, subprocess, sys, difflib

FUNC = "func_8001E404"
OBJ = sys.argv[1] if len(sys.argv) > 1 else "tmp/sandbox/%s/code6cac.o" % FUNC
TGT = "asm/funcs/%s.s" % FUNC
BRANCH = ('j', 'jal', 'b', 'beq', 'bne', 'beqz', 'bnez', 'blez', 'bgtz', 'bltz', 'bgez')


def num(tok):
    try:
        return str(int(tok, 0))
    except ValueError:
        return tok


def norm(mnem, ops):
    ops = ops.split('#')[0].strip().replace('$', '')
    ops = re.sub(r'%hi\([^)]*\)', 'HI', ops)
    ops = re.sub(r'%lo\([^)]*\)', 'LO', ops)
    ops = re.sub(r'\s+', '', ops)
    if mnem in BRANCH:
        parts = ops.split(',')
        parts[-1] = 'TGT'
        ops = ','.join(parts)
    parts = [p for p in ops.split(',')]
    out = []
    for p in parts:
        m = re.match(r'^(-?(?:0x)?[0-9a-fA-F]+)\((\w+)\)$', p)
        if m:
            out.append("%s(%s)" % (num(m.group(1)), m.group(2)))
        elif re.match(r'^-?(0x[0-9a-fA-F]+|\d+)$', p):
            out.append(num(p))
        else:
            out.append(p)
    ops = ','.join(out)
    # canonical pseudo-ops
    m = re.match(r'^(\w+),zero,(-?\d+)$', ops)
    if mnem == 'addiu' and m:
        mnem, ops = 'li', "%s,%s" % (m.group(1), m.group(2))
    m = re.match(r'^(\w+),(\w+),zero$', ops)
    if mnem == 'addu' and m:
        mnem, ops = 'move', "%s,%s" % (m.group(1), m.group(2))
    m = re.match(r'^(\w+),zero,(\w+)$', ops)
    if mnem == 'addu' and m:
        mnem, ops = 'move', "%s,%s" % (m.group(1), m.group(2))
    if mnem == 'jal':
        ops = 'TGT'
    if mnem == 'lui':
        ops = re.sub(r',(HI|0x0|0)$', ',HI', ops)
    ops = ops.replace('LO(', '0(')
    return "%-8s %s" % (mnem, ops)


def target():
    out = []
    for line in open(TGT):
        m = re.match(r'\s*/\*[^*]*\*/\s+(\S+)\s*(.*)', line)
        if m:
            out.append(norm(m.group(1), m.group(2)))
    return out


def ours():
    d = subprocess.run(["mipsel-linux-gnu-objdump", "-d", OBJ],
                       capture_output=True, text=True).stdout
    out, started = [], False
    for line in d.splitlines():
        if re.search(r'<%s>:' % FUNC, line):
            started = True
            continue
        if started:
            if not line.strip():
                break
            m = re.match(r'\s*[0-9a-f]+:\s+[0-9a-f ]{8,}\t(\S+)\s*(.*)', line)
            if m:
                out.append(norm(m.group(1), m.group(2)))
    return out


a, b = ours(), target()
print("ours=%d target=%d" % (len(a), len(b)))
sm = difflib.SequenceMatcher(None, b, a, autojunk=False)
ndiff = 0
for tag, i1, i2, j1, j2 in sm.get_opcodes():
    if tag == 'equal':
        continue
    ndiff += max(i2 - i1, j2 - j1)
    print("--- %s target[%d:%d] ours[%d:%d]" % (tag, i1, i2, j1, j2))
    for k in range(i1, i2):
        print("  T%3d  %s" % (k, b[k]))
    for k in range(j1, j2):
        print("  O%3d  %s" % (k, a[k]))
print("raw differing slots: %d" % ndiff)
