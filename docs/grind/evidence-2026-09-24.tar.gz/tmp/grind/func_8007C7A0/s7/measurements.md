# s7 (rederive) measurement log — func_8007C7A0, 2026-08-10

All scores: `& tools/wteng.ps1 main sandbox func_8007C7A0 --disable all`
(honest, display.c context, 21 rules dropped, cheat-asm stripped 153).
Chassis for every probe: the s6 per-arm-return chassis (Y clamp reassigning
arg1, `(u32)(D_8009BE74-1) < 2U` dispatch, per-arm block-scoped hi/lo with
split-init statements, per-arm returns). Only the X clamp varied.

| # | X-clamp spelling | score | build |
|---|---|---|---|
| 1 | three-arm direct into fresh local `s16 x` (x=D-1 / x=arg0 / x=0) | 12 | 50 |
| 2 | live-init `s16 x = arg0;` + two-arm overwrite (if-form) | 5 | 50 |
| 3 | live-init + self-read ternary `x = (arg0>=0)?((D-1<arg0)?D-1:x):0;` | 5 | 50 |
| 4 | param reassign if-form (X symmetric with Y) | 5 | 50 |
| 5 | param reassign ternary `arg0 = (...) ? (...) : arg0;` | 9 | 50 |
| 6 | two-var save: `x=arg0;` + fresh `cx` arms, `cx=x` in-range, masks read cx | 12 | 50 |
| 7 | form 4 + `arg0 = arg0;` self-assign in-range arm (dead-store family) | 5 | 50 |
| 8 | form 4 as K&R old-style definition | 5 | 50 |

Side-by-side of form 4 (the banked candidate) vs target:
target_51.s / ours_5form_50.s in this directory. 47/51 insns match 1:1;
the entire residual is the X-arm region (target insns 13-17):

    target                          ours
    bnez v0,JOIN                    beqz v0,SKIP
     addiu v0,a2,-1                  sll v0,a1,0x10      (Y-sll dup into delay)
    j JOIN                          j SKIP
     move v0,a3                      addiu a3,a2,-1
    move v0,zero                    move a3,zero
    JOIN: move a3,v0                SKIP: sll v0,a1,0x10

Target computes all three X arms into a $v0 join temp then copies home
(`move a3,v0`); ours writes the arms into $a3 directly (one insn fewer,
branch sense inverted, Y-sll duplicated into the freed delay slot). The
5 masked diffs are exactly this region.

Conclusion: GCC 2.7.2 materializes the join temp + writeback copy ONLY from
a source-level distinct temp written back into a live-initialized variable
(the banned x/tx construct, the s6 0-form). Ternary targets fold
(safe_from_p passes on arm reads), two-var saves coalesce (copy-preference),
self-assigns are elided, K&R is byte-identical.
