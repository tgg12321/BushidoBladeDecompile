import sys, re
# Robust body applier: strips EVERY existing S_80076D74 typedef block and the
# function itself, then inserts the body once (at the INCLUDE_ASM line if
# present, else where the function was).  The s1 apply.py left the typedef in
# place on re-apply, which is how the 5x typedef in the layer-1 FAILed diff arose.
src = open('src/text1b.c', 'rb').read().decode('utf-8')
body = open(sys.argv[1], 'rb').read().decode('utf-8').replace('\r\n', '\n')
src = re.sub(r'typedef struct \{\n(?:    [^\n]*\n)*\} S_80076D74;\n', '', src)
m = re.search(r'INCLUDE_ASM\("asm/funcs", func_80076D74\);\n', src)
if m:
    src = src[:m.start()] + body + src[m.end():]
else:
    s = src.index('s32 func_80076D74(')
    e = src.index('\n}\n', s) + 3
    src = src[:s] + body + src[e:]
open('src/text1b.c', 'wb').write(src.encode('utf-8'))
print("applied", sys.argv[1], "typedef count:", src.count('} S_80076D74;'))
