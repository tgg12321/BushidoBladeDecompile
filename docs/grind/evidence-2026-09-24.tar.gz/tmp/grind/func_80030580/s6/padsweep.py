"""s6b (driver session 6) — Judge-mandated route: Phantom-frame-slot volatile pad
local, exact sanctioned form (volatile u32 pre_pad[N]; first-decl position,
// !FAKE annotation).  Chassis = memory/grind/func_80030580/pure-c-floor2-body.c.

Usage: INSTR=1 PYTHONPATH=. python3 tmp/grind/func_80030580/s6/padsweep.py [N ...]
Prints vars= / bodydiff (vs s1/var_base.s) / ($sp) count / FRAMEDBG contexts.
"""
import shlex, subprocess, sys, re, os
from engine import buildconfig as B

S1 = 'tmp/grind/func_80030580/s1'
S6 = 'tmp/grind/func_80030580/s6'
base = open('memory/grind/func_80030580/pure-c-floor2-body.c', 'rb').read().decode().replace('\r\n', '\n')
ANCHOR = '    u8 *obj;\n'
assert ANCHOR in base

ANN = ('    volatile u32 pre_pad[%d]; // !FAKE: reserves the target frame\'s %d '
       'untouched locals bytes\n')

stem = 'code6cac_b'
cpp = f"{B.CPP} {B.CPP_FLAGS} {B.CPP_DEFS} src/{stem}.c"
flags = B.CC_FLAGS_GP if stem in getattr(B, 'GP_FILES', ()) else B.CC_FLAGS
cc1 = 'tools/gcc-2.7.2/cc1' if os.environ.get('INSTR') else B.CC1
env = dict(os.environ, BB2_FRAME_DEBUG='1') if os.environ.get('INSTR') else None
orig = open(f'src/{stem}.c', 'rb').read().decode()

def run(name, text):
    path = f'{S6}/var_{name}.c'
    open(path, 'w', newline='\n').write(text)
    subprocess.run(['python3', f'{S1}/apply.py', path], check=True)
    out = f'{S6}/var_{name}.s'
    if os.path.exists(out): os.remove(out)
    p1 = subprocess.run(shlex.split(cpp), capture_output=True, text=True)
    p2 = subprocess.run(shlex.split(f"{cc1} {flags} -o {out}"), input=p1.stdout,
                        capture_output=True, text=True, env=env)
    if not os.path.exists(out) or 'func_80030580:' not in open(out).read():
        print(name, 'CC1 FAIL', p2.stderr[-400:])
        open(f'src/{stem}.c', 'wb').write(orig.encode()); return
    dbg = [l for l in p2.stderr.splitlines() if l.startswith('FRAMEDBG') and 'func=func_80030580 ' in l]
    s = open(out).read(); i = s.find('func_80030580:')
    m = re.search(r'vars=\s*\d+', s[i:])
    fd = subprocess.run(['python3', 'tools/fdiff.py', f'{S1}/var_base.s', out, 'func_80030580'],
                        capture_output=True, text=True).stdout
    nd = sum(1 for l in fd.splitlines() if l[:1] in '+-' and not l.startswith(('+++', '---')))
    nsp = len(re.findall(r'\(\$sp\)', s[i:s.find('.end', i)]))
    print(f'{name:10s} {m.group(0) if m else "?":10s} bodydiff={nd:4d} sp={nsp}   '
          + ' | '.join(x.split('func=func_80030580 ')[1].split('mode=')[0] for x in dbg))
    open(f'src/{stem}.c', 'wb').write(orig.encode())

run('padbase', base)
for n in (sys.argv[1:] or ['1', '2', '3', '4', '5', '6']):
    n = int(n)
    run(f'pad{n}', base.replace(ANCHOR, ANN % (n, 4 * n) + ANCHOR))
subprocess.run(['python3', f'{S1}/apply.py', f'{S1}/draft3.c'], check=True)
