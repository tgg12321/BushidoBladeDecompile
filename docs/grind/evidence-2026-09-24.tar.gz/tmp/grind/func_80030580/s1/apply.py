import sys,re
src=open('src/code6cac_b.c','rb').read().decode()
body=open(sys.argv[1],'rb').read().decode().replace('\r\n','\n')
marker='INCLUDE_ASM("asm/funcs", func_80030580);\n'
if marker in src:
    src=src.replace(marker,'/*BEGIN_80030580*/\n'+body+'/*END_80030580*/\n')
else:
    src=re.sub(r'/\*BEGIN_80030580\*/\n.*?/\*END_80030580\*/\n','/*BEGIN_80030580*/\n'+body+'/*END_80030580*/\n',src,flags=re.S)
open('src/code6cac_b.c','wb').write(src.encode())
