# s7 forensics — pointer-type-matrix RTL census (idx25 operand-order lock)

Goal: prove the idx25 `addu` operand-order lock is a UNIVERSAL front-end
property across every pointer+int spelling — not an artifact of the single
`(u8*)a0 + v0` form s6 dumped — and pin the target's original source shape more
tightly than "integer domain".

Flags: real build cc1 flags (`-O2 -G0 -funsigned-char -mcpu=3000 -mips1
-mno-abicalls`), `tools/gcc-2.7.2/build/cc1 -da`. Source:
`tmp/grind/cpu_check_tubazeri_2/s7/typematrix.c`. Dumps: `typematrix.i.rtl`
(initial RTL), `typematrix.s` (final asm). Runner: `typematrix_dump.sh`.

In each probe `$4` = arg0 (base pointer), `$5` = arg1 (index), `$2` = the
scaled-index local (`i<<1`) where present. "base-first" = `addu rd,BASE,INDEX`;
"index-first" = `addu rd,INDEX,BASE`.

| probe | C expression | initial RTL `(plus …)` | final addu | order |
|---|---|---|---|---|
| p1 | `u8*  base + int idx`      | `(plus r72 r73)` | `addu $2,$4,$5` | base-first |
| p2 | `s16* base + int idx`      | base-first       | `addu $2,$4,$2` | base-first |
| p3 | `s32* base + int idx`      | base-first       | `addu $2,$4,$2` | base-first |
| p4 | `u8*  base + unsigned idx` | base-first       | `addu $2,$4,$5` | base-first |
| p5 | `u8*  base + long idx`     | base-first       | `addu $2,$4,$5` | base-first |
| p6 | `int idx + u8* base` (idx LEFT) | `(plus r72 r73)` | `addu $2,$4,$5` | base-first |
| p7 | `&base[idx]` (s16*)        | base-first       | `addu $2,$4,$2` | base-first |
| p8 | `(s32*)((u8*)a0 + v0)` (tubazeri exact) | base-first | `addu $2,$4,$2` | base-first |
| i1 | `(s32*)(v0 + (s32)a0)` (int, idx first) | `(plus r74 r72)` | `addu $2,$2,$4` | **index-first** |
| i2 | `(s32*)((s32)a0 + v0)` (int, base first) | `(plus r72 r74)` | `addu $2,$4,$2` | base-first |

## Findings

1. **Pointer domain is base-first UNCONDITIONALLY.** All 8 pointer spellings
   (p1–p8) — spanning pointee type (`u8*`/`s16*`/`s32*`), index signedness/width
   (`int`/`unsigned`/`long`), written order (p6 writes the index on the LEFT,
   `idx + base`), and syntax (`+` vs array-subscript `&base[idx]`) — lower to
   `(plus BASE INDEX)` at initial RTL and stay base-first through to final asm.
   This is the c-typeck.c mechanism s6 named, now exhaustively confirmed:
   `build_binary_op` forces the pointer operand to `ptrop` for both `ptr+int`
   (line 1986) and `int+ptr` (line 1988 — proven by p6: index written left, still
   base-first), and `pointer_int_sum` builds `PLUS_EXPR(ptrop, intop)` pointer-first
   unconditionally (line 2696). No pointer type, width, sign, order, or spelling
   escapes it.

2. **Integer domain preserves WRITTEN order.** i1 (`v0 + (s32)a0`, index written
   first) → `(plus r74=v0 r72=a0)` → index-first `addu $2,$2,$4` = the TARGET's
   idx25 (`addu s2,v0,s0`). i2 (`(s32)a0 + v0`, base written first) → base-first.
   So integer-domain `+` is the ordinary commutative PLUS_EXPR path that keeps the
   source operand order; the pointer path is the special-cased one.

3. **This tightens the source-domain inference (vs s6/s7-census).** The target's
   idx25 is index-first. Base-first is unreachable-from-index-first only crossing
   into the integer domain — but MORE specifically, integer-domain-with-the-index-
   operand-written-first. i2 shows even the integer domain is base-first if the
   base is written first. Therefore the original 1998 source's expression at this
   one add was not merely "integer arithmetic" but specifically
   `scaled_index + (int)base_pointer` — the exact shape of the reviewer-FAILED
   `v0 + (s32)a0` (rejected/int-cast-operand-swap.c). The compiler fingerprints
   both the DOMAIN (integer) and the OPERAND ORDER (index first).

## Bearing on disposition

This is a stronger version of the s7 whole-function census the 02:10 Judge already
verified SOUND (docs/grind/decisions.md 2026-07-22 02:10). It does not change the
Judge's FAIL: per endgame-lock-disposition-policy AND-gate #2, a coercion/spelling
family needs SOTN-master (or VS/ESA) community precedent in-hand, and the int-cast
is a novel in-house forensic justification, not community precedent — default =
refuse, not self-approvable. What this census adds for the OWNER's
faithfulness-vs-coercion call: the compiler proves the original source expression
at idx25 was integer-domain-index-first, so `v0 + (s32)a0` is not an arbitrary
order-steering respelling among many — it is the unique source shape consistent
with the target bytes under this frozen toolchain. Whether reconstructing that
proven shape is "faithful reconstruction" or "coercion" is the owner's call.

## Artifacts
- typematrix.c / typematrix.i / typematrix.i.rtl / typematrix.s / typematrix.cc1err
- typematrix_dump.sh (runner)
