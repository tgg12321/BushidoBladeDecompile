#!/bin/bash
set -e
cd "/mnt/c/Users/Trenton/Desktop/Bushido Blade 2 Decompile"
WS=tmp/perm_8003C714_s4
FN=func_8003C714
rm -rf $WS; mkdir -p $WS

mipsel-linux-gnu-cpp -Iinclude -undef -Wall -lang-c -fno-builtin \
  -Dmips -D__GNUC__=2 -D__OPTIMIZE__ -D__mips__ -D__mips -Dpsx -D__psx__ -D__psx \
  -D_PSYQ -D__EXTENSIONS__ -D_MIPSEL -D_LANGUAGE_C -DLANGUAGE_C -DPERMUTER \
  src/code6cac_c2.c > $WS/base.c

printf 'func_name = "%s"\ncompiler_type = "gcc"\n' "$FN" > $WS/settings.toml

cp tmp/grind/func_8003C714/s4/compile.sh $WS/compile.sh
chmod +x $WS/compile.sh

sed 's/^.set gp=64$//' tools/decomp-permuter/prelude.inc > $WS/prelude_r3k.inc
cat $WS/prelude_r3k.inc asm/funcs/$FN.s > $WS/target.s
mipsel-linux-gnu-as -Iinclude -march=r3000 -mtune=r3000 -no-pad-sections -O1 -G0 \
  -o $WS/target.o $WS/target.s

bash $WS/compile.sh $WS/base.c -o $WS/base.o
f() {
  mipsel-linux-gnu-objdump -d "$1" | awk '/<func_8003C714>:/{p=1;next} /^[0-9a-f]+ </{p=0} p' \
    | sed 's/^[^\t]*\t[^\t]*\t//' | sed 's/0x[0-9a-f]*//g' | grep -v '^$'
}
f $WS/base.o > /tmp/c714_base.txt
f $WS/target.o > /tmp/c714_tgt.txt
echo "base insns: $(wc -l < /tmp/c714_base.txt)  target: $(wc -l < /tmp/c714_tgt.txt)"
diff /tmp/c714_base.txt /tmp/c714_tgt.txt | head -30
