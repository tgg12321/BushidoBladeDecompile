import re,glob,os,json
INS=re.compile(r'/\*.*?\*/\s+([a-z][a-z0-9.]*)\s*(.*)')
def insns(path):
    out=[]
    for line in open(path,errors='ignore'):
        m=INS.search(line)
        if m: out.append((m.group(1),m.group(2).strip()))
        else:
            s=line.strip()
            if s.startswith('.L') or s.startswith('glabel'): out.append(('LABEL',s.rstrip(':')))
    return out
rf=open('regfix.txt',errors='ignore').read()+open('asmfix.txt',errors='ignore').read()
defs={}
for c in glob.glob('src/*.c'):
    t=open(c,errors='ignore').read()
    for m in re.finditer(r'\n[A-Za-z_][\w \*]*?\b(\w+)\s*\([^;{]*\)\s*\{',t):
        defs.setdefault(m.group(1),(c,t[:m.start()].count('\n')+2))
q=json.load(open('engine/queue.json'))
items=q['items'] if isinstance(q,dict) and 'items' in q else q
qf={it['func'] for it in items}
out=[]
for f in sorted(glob.glob('asm/funcs/*.s')):
    ins=insns(f); fn=os.path.basename(f)[:-2]
    for i,(op,a) in enumerate(ins):
        if op!='addu': continue
        p=[x.strip() for x in a.split(',')]
        if len(p)!=3 or p[2] not in('$zero','$0') or p[1] in('$zero','$0'): continue
        d,s=p[0],p[1]
        for j in range(i+1,min(i+4,len(ins))):
            op2,a2=ins[j]
            if op2=='LABEL': break
            if op2 in('addu','addiu','sll','lw','lbu','lhu','sw','subu'):
                q2=[x.strip() for x in a2.split(',')]
                if d in ' '.join(q2[1:]) and (fn in defs) and fn not in qf and fn not in rf:
                    out.append((fn,defs[fn],a,a2,op2,q2[0]==s))
            break
print("copy->consumer in MATCHED(pure-C-defined, no rules, not in queue) funcs: ",len(out))
for o in out: print("  ",o)
