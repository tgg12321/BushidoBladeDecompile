import re,glob,os,collections
def ops(path):
    out=[]
    for line in open(path,errors='ignore'):
        line=line.split('#')[0].strip()
        m=re.match(r'/\*.*?\*/\s*(\w+)',line) or re.match(r'^([a-z][a-z0-9.]*)\s',line)
        if m: out.append(m.group(1))
    return out
tgt=ops('asm/funcs/func_80017848.s')
def grams(o,n=5): return collections.Counter(tuple(o[i:i+n]) for i in range(len(o)-n+1))
G=grams(tgt); tot=sum(G.values())
res=[]
for f in glob.glob('asm/funcs/*.s'):
    if 'func_80017848' in f: continue
    o=ops(f)
    if not (0.6*len(tgt)<len(o)<1.8*len(tgt)): continue
    g=grams(o)
    inter=sum((G&g).values())
    res.append((inter/max(tot,1),len(o),os.path.basename(f)))
res.sort(reverse=True)
for r in res[:15]: print("%.3f %4d %s"%r)
