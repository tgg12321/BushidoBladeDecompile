#!/usr/bin/env python3
"""Splice a CD_ready variant (marionation_Exec-named candidate form) into src/system.c.

Usage: python3 splice.py <variant.c>      # apply (backup once)
       python3 splice.py --restore
"""
import sys, shutil, re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
SRC = ROOT / "src/system.c"
BAK = ROOT / "tmp/grind/CD_ready/s59/system.c.bak"
MARK = 'INCLUDE_ASM("asm/funcs", CD_ready);'

RENAME = [
    ("marionation_Exec", "CD_ready"),
    ("sys_VSync", "VSync"),
    ("tslTm2LoadImage_2", "puts"),
    ("debug_printf", "printf"),
    ("cdrom_ClearIrq", "CD_flush"),
    ("sys_GetVblankCount", "CheckCallback"),
    ("func_80080828", "getintr"),
]

def extract_fn(text):
    m = re.search(r"^s32 (marionation_Exec|CD_ready)\(s32 a0, u8 \*a1\)\s*\{", text, re.M)
    if not m:
        return None
    start = m.start(); depth = 0; i = m.end() - 1
    while i < len(text):
        c = text[i]
        if c == '{':
            depth += 1
        elif c == '}':
            depth -= 1
            if depth == 0:
                return text[start:i+1]
        i += 1
    return None

def main():
    if sys.argv[1] == "--restore":
        if BAK.exists():
            shutil.copy(BAK, SRC)
            print("restored")
        else:
            print("no backup")
        return
    fn = extract_fn(Path(sys.argv[1]).read_text())
    if fn is None:
        print("no function body found"); sys.exit(2)
    for a, b in RENAME:
        fn = re.sub(r"\b%s\b" % a, b, fn)
    if not BAK.exists():
        shutil.copy(SRC, BAK)
    src = BAK.read_text()
    assert MARK in src, "marker missing"
    src = src.replace(MARK, fn.rstrip())
    fh = open(str(SRC), "w", newline=chr(10)); fh.write(src); fh.close()
    print("applied", len(fn.splitlines()), "lines")

main()
