#!/bin/bash
# s63: run the INSTRUMENTED cc1 (tools/gcc-2.7.2/cc1) over src/system.c with the
# BB2_QTY_DEBUG / BB2_SUGG_DEBUG local-alloc hooks, capturing every qty_compare
# ordering decision.  $1 = output stderr file.
set -e
cd "$(dirname "$0")/../../../.."
source .venv/bin/activate
PYTHONPATH=. python3 - "$1" <<'PYEOF'
import shlex, subprocess, sys, os
from engine import buildconfig as B
out = sys.argv[1]
cpp = f"{B.CPP} {B.CPP_FLAGS} {B.CPP_DEFS} src/system.c"
cc = f"tools/gcc-2.7.2/cc1 {B.CC_FLAGS} -o /dev/null"
p1 = subprocess.run(shlex.split(cpp), capture_output=True, text=True)
env = dict(os.environ); env['BB2_QTY_DEBUG']='1'; env['BB2_SUGG_DEBUG']='1'
p2 = subprocess.run(shlex.split(cc), input=p1.stdout, capture_output=True, text=True, env=env)
open(out,'w').write(p2.stderr)
print("wrote", out, len(p2.stderr), "bytes, rc", p2.returncode)
PYEOF
