#!/bin/bash
set -e
cd "/mnt/c/Users/Trenton/Desktop/Bushido Blade 2 Decompile"
WS="$1"; SEED="$2"
rm -rf "$WS"; mkdir -p "$WS"
python3 memory/grind/CD_ready/apply_s78.py "$SEED" >/dev/null
mipsel-linux-gnu-cpp -Iinclude -undef -Wall -lang-c -fno-builtin \
  -Dmips -D__GNUC__=2 -D__OPTIMIZE__ -D__mips__ -D__mips -Dpsx -D__psx__ -D__psx \
  -D_PSYQ -D__EXTENSIONS__ -D_MIPSEL -D_LANGUAGE_C -DLANGUAGE_C src/system.c > "$WS/base.c" 2>/dev/null
python3 tmp/grind/CD_ready/s86/patchbase.py "$WS/base.c"
cat > "$WS/settings.toml" <<'EOF'
func_name = "CD_ready"
compiler_type = "gcc"

[weight_overrides]
perm_inline = 0.0
EOF
cat > "$WS/compile.sh" <<'EOF'
#!/bin/bash
set -e
cd "/mnt/c/Users/Trenton/Desktop/Bushido Blade 2 Decompile"
IN="$1"; OUT="$3"
TMPS=$(mktemp /tmp/cdrXXXXXX.s)
trap "rm -f $TMPS $TMPS.fn.s" EXIT
tools/gcc-2.7.2/build/cc1 -O2 -G0 -funsigned-char -quiet -mcpu=3000 -mips1 \
      -mno-abicalls -fno-builtin -w -mel "$IN" -o /dev/stdout 2>/dev/null \
  | python3 tools/prologue_fix.py \
  | python3 tools/maspsx/maspsx.py --expand-div --aspsx-version=2.34 \
      --sdata-syms=sdata_syms.txt --sdata-funcs=sdata_funcs.txt \
      --sdata-exclude=sdata_exclude.txt --expand-lb \
      --expand-lb-funcs=expand_lb_funcs.txt --multu-funcs=multu_funcs.txt \
      --expand-dest-funcs=expand_dest_funcs.txt \
      --label-nop-funcs=maspsx_label_nop_funcs.txt \
  | python3 tools/multu_pad.py --funcs multu_pad_funcs.txt > "$TMPS"
awk '/^[ \t]*\.ent[ \t]+CD_ready$/ {p=1} p {print} p && /^[ \t]*\.end[ \t]+CD_ready$/ {exit}' "$TMPS" > "$TMPS.fn.s"
cat "$TMPS.fn.s" | mipsel-linux-gnu-as -Iinclude -march=r3000 -mtune=r3000 -no-pad-sections -O1 -G0 -o "$OUT"
EOF
chmod +x "$WS/compile.sh"
sed 's/^.set gp=64$//' tools/decomp-permuter/prelude.inc > "$WS/prelude_r3k.inc"
cat "$WS/prelude_r3k.inc" asm/funcs/CD_ready.s > "$WS/target.s"
mipsel-linux-gnu-as -Iinclude -march=r3000 -mtune=r3000 -no-pad-sections -O1 -G0 -o "$WS/target.o" "$WS/target.s"
bash "$WS/compile.sh" "$WS/base.c" -o "$WS/base.o"
f() { mipsel-linux-gnu-objdump -d "$1" | awk '/<CD_ready>:/{p=1;next} /^[0-9a-f]+ </{p=0} p' | sed 's/^[^\t]*\t[^\t]*\t//' | sed 's/0x[0-9a-f]*//g' | grep -v '^$'; }
f "$WS/base.o" > /tmp/s86_base.txt
f "$WS/target.o" > /tmp/s86_tgt.txt
echo "WS=$WS base insns: $(wc -l < /tmp/s86_base.txt) target: $(wc -l < /tmp/s86_tgt.txt) difflines: $(diff /tmp/s86_base.txt /tmp/s86_tgt.txt | grep -c '^[<>]')"
cpp -P -nostdinc -DPERMUTER "$WS/base.c" > /dev/null && echo "permuter-cpp OK"
