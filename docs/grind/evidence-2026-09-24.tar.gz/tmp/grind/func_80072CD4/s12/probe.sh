#!/bin/bash
# Calibration-only probe (owner ruling 2026-08-30, escalation-batch ruling 7).
# Compiles the SAME preprocessed TU with (a) the frozen build cc1 (decompals
# mips-gcc-2.7.2) and (b) the original PsyQ cc1psx.exe, and extracts
# func_80072CD4 from both. DIAGNOSTIC ONLY -- never a build path.
set -u
cd "$(dirname "$0")/../../../.."   # repo root
S=tmp/grind/func_80072CD4/s12
BODY="$1"; TAG="$2"
python3 - "$BODY" "$S/tu_$TAG.c" <<'PY'
import re,sys
body=open(sys.argv[1],encoding='utf-8').read()
body=re.sub(r'^\s*/\*.*?\*/\s*','',body,count=1,flags=re.S)
txt=open('src/text1b.c',encoding='utf-8',newline='').read()
inc='INCLUDE_ASM("asm/funcs", func_80072CD4);\n'
assert inc in txt
open(sys.argv[2],'w',encoding='utf-8',newline='').write(txt.replace(inc, body if body.endswith('\n') else body+'\n',1))
PY
CPP_FLAGS="-Iinclude -undef -Wall -lang-c -fno-builtin"
CPP_DEFS="-Dmips -D__GNUC__=2 -D__OPTIMIZE__ -D__mips__ -D__mips -Dpsx -D__psx__ -D__psx -D_PSYQ -D__EXTENSIONS__ -D_MIPSEL -D_LANGUAGE_C -DLANGUAGE_C"
mipsel-linux-gnu-cpp $CPP_FLAGS $CPP_DEFS "$S/tu_$TAG.c" > "$S/tu_$TAG.i" || exit 1
wc -c "$S/tu_$TAG.i"
tools/gcc-2.7.2/build/cc1 -O2 -G0 -funsigned-char -quiet -mcpu=3000 -mips1 -mno-abicalls -fno-builtin -w -mel < "$S/tu_$TAG.i" > "$S/cc1_$TAG.s" 2> "$S/cc1_$TAG.err"
echo "cc1 rc=$? $(wc -l < "$S/cc1_$TAG.s") lines"
bash tools/cc1psx_wrapper.sh -O2 -G0 -mcpu=3000 -mips1 -funsigned-char -w < "$S/tu_$TAG.i" > "$S/psx_$TAG.s" 2> "$S/psx_$TAG.err"
echo "cc1psx rc=$? $(wc -l < "$S/psx_$TAG.s") lines"; head -3 "$S/psx_$TAG.err"
