	.file	1 "tmp/grind/func_80072CD4/s12/tu_xblock.c"

 # GNU C 2.7.2 [AL 1.1, MM 40] GNU MIPS/ELF compiled by GNU C

 # Cc1 defaults:
 # -mgas

 # Cc1 arguments (-G value = 0, Cpu = 3000, ISA = 1):
 # -O2 -G0 -funsigned-char -quiet -mcpu=3000 -mips1 -mno-abicalls -fno-builtin
 # -w -mel

	.version	"01.01"
gcc2_compiled.:
 #APP
	.include "include/macro.inc"

 #NO_APP
	.text
	.align	2
	.globl	func_80047ED0
	.type	 func_80047ED0,@function
	.ent	func_80047ED0
func_80047ED0:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$2,g_snd_volume
	#nop
	addu	$2,$2,$4
	sw	$2,g_snd_volume
	j	$31
	.end	func_80047ED0
.Lfe1:
	.size	 func_80047ED0,.Lfe1-func_80047ED0
	.align	2
	.globl	func_80047EE8
	.type	 func_80047EE8,@function
	.ent	func_80047EE8
func_80047EE8:
	.frame	$sp,72,$31		# vars= 32, regs= 4/0, args= 24, extra= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,72
	sw	$16,56($sp)
	move	$16,$4
	sw	$18,64($sp)
	move	$18,$16
	sll	$5,$5,16
	sra	$5,$5,14
	addu	$16,$16,$5
	sw	$31,68($sp)
	sw	$17,60($sp)
	lw	$2,0($16)
	#nop
	srl	$2,$2,2
	sll	$2,$2,2
	addu	$16,$18,$2
	lw	$17,0($16)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$17,$0,.L3
	addu	$16,$16,4
	.set	macro
	.set	reorder

	addu	$17,$17,-1
.L4:
	lw	$4,0($16)
	addu	$16,$16,4
	lhu	$5,0($16)
	addu	$16,$16,2
	lhu	$6,0($16)
	addu	$16,$16,2
	lhu	$7,0($16)
	addu	$16,$16,2
	lhu	$2,0($16)
	addu	$16,$16,2
	sll	$2,$2,16
	sra	$2,$2,16
	srl	$4,$4,2
	sll	$4,$4,2
	sll	$5,$5,16
	sll	$6,$6,16
	sll	$7,$7,16
	addu	$4,$18,$4
	sra	$5,$5,16
	sra	$6,$6,16
	sra	$7,$7,16
	.set	noreorder
	.set	nomacro
	jal	func_800482C8
	sw	$2,16($sp)
	.set	macro
	.set	reorder

	move	$2,$17
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L4
	addu	$17,$17,-1
	.set	macro
	.set	reorder

.L3:
	lw	$31,68($sp)
	lw	$18,64($sp)
	lw	$17,60($sp)
	lw	$16,56($sp)
	addu	$sp,$sp,72
	j	$31
	.end	func_80047EE8
.Lfe2:
	.size	 func_80047EE8,.Lfe2-func_80047EE8
	.align	2
	.globl	func_80047FBC
	.type	 func_80047FBC,@function
	.ent	func_80047FBC
func_80047FBC:
	.frame	$sp,80,$31		# vars= 32, regs= 6/0, args= 24, extra= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,80
	sw	$16,56($sp)
	move	$16,$4
	sw	$20,72($sp)
	move	$20,$16
	sll	$5,$5,16
	sra	$5,$5,14
	addu	$16,$16,$5
	sw	$31,76($sp)
	sw	$19,68($sp)
	sw	$18,64($sp)
	sw	$17,60($sp)
	lw	$2,0($16)
	#nop
	srl	$2,$2,2
	sll	$2,$2,2
	addu	$16,$20,$2
	lw	$17,0($16)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$17,$0,.L9
	addu	$16,$16,4
	.set	macro
	.set	reorder

	addu	$17,$17,-1
	sll	$2,$6,16
	sra	$19,$2,16
	sll	$2,$7,16
	sra	$18,$2,16
.L10:
	lw	$4,0($16)
	addu	$16,$16,4
	lhu	$5,0($16)
	addu	$16,$16,2
	lhu	$6,0($16)
	addu	$16,$16,2
	lhu	$7,0($16)
	addu	$16,$16,2
	lhu	$2,0($16)
	addu	$16,$16,2
	sll	$2,$2,16
	sra	$2,$2,16
	addu	$2,$2,$18
	srl	$4,$4,2
	sll	$4,$4,2
	sll	$5,$5,16
	sra	$5,$5,16
	sll	$6,$6,16
	sra	$6,$6,16
	sll	$7,$7,16
	sra	$7,$7,16
	addu	$4,$20,$4
	addu	$5,$5,$19
	addu	$6,$6,$18
	addu	$7,$7,$19
	.set	noreorder
	.set	nomacro
	jal	func_800482C8
	sw	$2,16($sp)
	.set	macro
	.set	reorder

	move	$2,$17
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L10
	addu	$17,$17,-1
	.set	macro
	.set	reorder

.L9:
	lw	$31,76($sp)
	lw	$20,72($sp)
	lw	$19,68($sp)
	lw	$18,64($sp)
	lw	$17,60($sp)
	lw	$16,56($sp)
	addu	$sp,$sp,80
	j	$31
	.end	func_80047FBC
.Lfe3:
	.size	 func_80047FBC,.Lfe3-func_80047FBC
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_800480C0.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_800481E8
	.type	 func_800481E8,@function
	.ent	func_800481E8
func_800481E8:
	.frame	$sp,72,$31		# vars= 32, regs= 4/0, args= 24, extra= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,72
	sw	$16,56($sp)
	move	$16,$4
	sw	$18,64($sp)
	move	$18,$16
	sll	$5,$5,16
	sra	$5,$5,14
	addu	$16,$16,$5
	sw	$31,68($sp)
	sw	$17,60($sp)
	lw	$2,0($16)
	#nop
	srl	$2,$2,2
	sll	$2,$2,2
	addu	$16,$18,$2
	lw	$17,0($16)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$17,$0,.L15
	addu	$16,$16,4
	.set	macro
	.set	reorder

	addu	$17,$17,-1
.L16:
	lw	$2,0($16)
	addu	$16,$16,4
	lhu	$5,0($16)
	addu	$16,$16,2
	lhu	$6,0($16)
	addu	$16,$16,2
	lhu	$3,0($16)
	addu	$16,$16,2
	lhu	$8,0($16)
	srl	$2,$2,2
	sll	$2,$2,2
	addu	$4,$18,$2
	sll	$3,$3,16
	sra	$7,$3,16
	slt	$2,$7,640
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L19
	addu	$16,$16,2
	.set	macro
	.set	reorder

	addu	$8,$8,1
.L19:
	sll	$2,$8,16
	sra	$2,$2,16
	sw	$2,16($sp)
	sll	$5,$5,16
	sll	$6,$6,16
	sra	$5,$5,16
	.set	noreorder
	.set	nomacro
	jal	func_800482C8
	sra	$6,$6,16
	.set	macro
	.set	reorder

	move	$2,$17
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L16
	addu	$17,$17,-1
	.set	macro
	.set	reorder

.L15:
	lw	$31,68($sp)
	lw	$18,64($sp)
	lw	$17,60($sp)
	lw	$16,56($sp)
	addu	$sp,$sp,72
	j	$31
	.end	func_800481E8
.Lfe4:
	.size	 func_800481E8,.Lfe4-func_800481E8
	.align	2
	.globl	func_800482C8
	.type	 func_800482C8,@function
	.ent	func_800482C8
func_800482C8:
	.frame	$sp,1072,$31		# vars= 1032, regs= 5/0, args= 16, extra= 0
	.mask	0x800f0000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,1072
	move	$8,$4
	sw	$31,1064($sp)
	sw	$19,1060($sp)
	sw	$18,1056($sp)
	sw	$17,1052($sp)
	sw	$16,1048($sp)
	lbu	$3,0($8)
	addu	$8,$8,4
	li	$2,0x00000010		# 16
	lhu	$18,1088($sp)
	.set	noreorder
	.set	nomacro
	bne	$3,$2,.L21
	move	$19,$7
	.set	macro
	.set	reorder

	lw	$2,0($8)
	#nop
	andi	$17,$2,0x0008
	.set	noreorder
	.set	nomacro
	beq	$17,$0,.L23
	addu	$8,$8,4
	.set	macro
	.set	reorder

	move	$16,$8
	lw	$2,0($16)
	#nop
	srl	$2,$2,2
	sll	$2,$2,2
	addu	$8,$16,$2
	addu	$16,$16,4
.L23:
	addu	$8,$8,8
	addu	$4,$sp,16
	sh	$5,16($sp)
	sh	$6,18($sp)
	lw	$3,0($8)
	addu	$5,$8,4
	srl	$2,$3,16
	sh	$2,22($sp)
	.set	noreorder
	.set	nomacro
	jal	LoadImage
	sh	$3,20($sp)
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	beq	$17,$0,.L21
	addu	$16,$16,4
	.set	macro
	.set	reorder

	sh	$19,16($sp)
	sh	$18,18($sp)
	lw	$3,0($16)
	addu	$16,$16,4
	srl	$2,$3,16
	sh	$2,22($sp)
	.set	noreorder
	.set	nomacro
	jal	func_800486FC
	sh	$3,20($sp)
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L25
	move	$4,$16
	.set	macro
	.set	reorder

	lh	$5,20($sp)
	addu	$16,$sp,24
	.set	noreorder
	.set	nomacro
	jal	func_8004876C
	move	$6,$16
	.set	macro
	.set	reorder

	addu	$4,$sp,16
	.set	noreorder
	.set	nomacro
	jal	LoadImage
	move	$5,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	j	.L21
.L25:
	addu	$4,$sp,16
	.set	noreorder
	.set	nomacro
	jal	LoadImage
	move	$5,$16
	.set	macro
	.set	reorder

.L21:
	lw	$31,1064($sp)
	lw	$19,1060($sp)
	lw	$18,1056($sp)
	lw	$17,1052($sp)
	lw	$16,1048($sp)
	addu	$sp,$sp,1072
	j	$31
	.end	func_800482C8
.Lfe5:
	.size	 func_800482C8,.Lfe5-func_800482C8
	.align	2
	.globl	func_800483DC
	.type	 func_800483DC,@function
	.ent	func_800483DC
func_800483DC:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, extra= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	sw	$16,16($sp)
	move	$16,$4
	sll	$5,$5,16
	sra	$5,$5,14
	addu	$5,$5,$16
	sw	$31,36($sp)
	sw	$20,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	lw	$2,0($5)
	move	$20,$16
	addu	$16,$16,$2
	lw	$17,0($16)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$17,$0,.L27
	addu	$16,$16,4
	.set	macro
	.set	reorder

	addu	$17,$17,-1
	sll	$2,$6,16
	sra	$19,$2,16
	sll	$2,$7,16
	sra	$18,$2,16
.L28:
	lw	$4,0($16)
	addu	$16,$16,8
	lhu	$5,0($16)
	addu	$16,$16,2
	lhu	$6,0($16)
	addu	$16,$16,2
	sll	$5,$5,16
	sra	$5,$5,16
	sll	$6,$6,16
	sra	$6,$6,16
	addu	$4,$20,$4
	addu	$5,$5,$19
	.set	noreorder
	.set	nomacro
	jal	func_800484A0
	addu	$6,$6,$18
	.set	macro
	.set	reorder

	move	$2,$17
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L28
	addu	$17,$17,-1
	.set	macro
	.set	reorder

.L27:
	lw	$31,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,40
	j	$31
	.end	func_800483DC
.Lfe6:
	.size	 func_800483DC,.Lfe6-func_800483DC
	.align	2
	.globl	func_800484A0
	.type	 func_800484A0,@function
	.ent	func_800484A0
func_800484A0:
	.frame	$sp,1056,$31		# vars= 1032, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,1056
	sw	$16,1048($sp)
	move	$16,$4
	sw	$31,1052($sp)
	lbu	$3,0($16)
	li	$2,0x00000010		# 16
	.set	noreorder
	.set	nomacro
	bne	$3,$2,.L32
	addu	$16,$16,4
	.set	macro
	.set	reorder

	lw	$2,0($16)
	#nop
	andi	$2,$2,0x0008
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L32
	addu	$16,$16,4
	.set	macro
	.set	reorder

	addu	$16,$16,8
	sh	$5,16($sp)
	sh	$6,18($sp)
	lw	$3,0($16)
	addu	$16,$16,4
	srl	$2,$3,16
	sh	$2,22($sp)
	.set	noreorder
	.set	nomacro
	jal	func_800486FC
	sh	$3,20($sp)
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L35
	move	$4,$16
	.set	macro
	.set	reorder

	lh	$5,20($sp)
	addu	$16,$sp,24
	.set	noreorder
	.set	nomacro
	jal	func_8004876C
	move	$6,$16
	.set	macro
	.set	reorder

.L35:
	addu	$4,$sp,16
	.set	noreorder
	.set	nomacro
	jal	LoadImage
	move	$5,$16
	.set	macro
	.set	reorder

.L32:
	lw	$31,1052($sp)
	lw	$16,1048($sp)
	addu	$sp,$sp,1056
	j	$31
	.end	func_800484A0
.Lfe7:
	.size	 func_800484A0,.Lfe7-func_800484A0
	.align	2
	.globl	func_80048530
	.type	 func_80048530,@function
	.ent	func_80048530
func_80048530:
	.frame	$sp,32,$31		# vars= 0, regs= 2/0, args= 24, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	move	$3,$4
	sll	$5,$5,2
	addu	$5,$5,$3
	move	$8,$3
	sw	$31,28($sp)
	sw	$16,24($sp)
	lw	$2,0($5)
	move	$5,$7
	addu	$3,$2,$3
	lw	$16,0($3)
	#nop
	sltu	$2,$6,$16
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L37
	addu	$3,$3,4
	.set	macro
	.set	reorder

	sll	$2,$6,1
	addu	$2,$2,$6
	sll	$2,$2,2
	addu	$3,$3,$2
	lw	$4,0($3)
	addu	$3,$3,4
	lhu	$6,0($3)
	addu	$3,$3,2
	lhu	$7,0($3)
	addu	$3,$3,2
	lhu	$2,0($3)
	lhu	$3,2($3)
	sll	$2,$2,16
	sra	$2,$2,16
	sll	$3,$3,16
	sra	$3,$3,16
	sll	$6,$6,16
	sll	$7,$7,16
	addu	$4,$4,$8
	sra	$6,$6,16
	sra	$7,$7,16
	sw	$2,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_800485EC
	sw	$3,20($sp)
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L38
	move	$2,$16
	.set	macro
	.set	reorder

.L37:
	li	$2,-1			# 0xffffffff
.L38:
	lw	$31,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,32
	j	$31
	.end	func_80048530
.Lfe8:
	.size	 func_80048530,.Lfe8-func_80048530
	.align	2
	.globl	func_800485EC
	.type	 func_800485EC,@function
	.ent	func_800485EC
func_800485EC:
	.frame	$sp,40,$31		# vars= 0, regs= 5/0, args= 16, extra= 0
	.mask	0x800f0000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	sw	$17,20($sp)
	move	$17,$4
	sw	$16,16($sp)
	move	$16,$5
	sw	$31,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	lbu	$3,0($17)
	addu	$17,$17,4
	move	$18,$6
	li	$2,0x00000010		# 16
	lhu	$4,56($sp)
	lhu	$5,60($sp)
	.set	noreorder
	.set	nomacro
	bne	$3,$2,.L40
	move	$19,$7
	.set	macro
	.set	reorder

	lw	$2,0($17)
	addu	$17,$17,4
	andi	$3,$2,0x0007
	andi	$2,$2,0x0008
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L41
	sh	$3,0($16)
	.set	macro
	.set	reorder

	move	$3,$17
	lw	$2,0($3)
	sh	$4,10($16)
	lh	$4,10($16)
	sh	$5,12($16)
	lh	$5,12($16)
	srl	$2,$2,2
	sll	$2,$2,2
	addu	$17,$3,$2
	addu	$3,$3,8
	lhu	$2,2($3)
	#nop
	sh	$2,16($16)
	lw	$2,0($3)
	addu	$3,$3,4
	sw	$3,28($16)
	.set	noreorder
	.set	nomacro
	jal	GetClut
	sh	$2,14($16)
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L42
	sh	$2,20($16)
	.set	macro
	.set	reorder

.L41:
	sh	$0,20($16)
.L42:
	lh	$4,0($16)
	addu	$3,$17,8
	sh	$18,2($16)
	sh	$19,4($16)
	lhu	$2,2($3)
	lh	$6,2($16)
	lh	$7,4($16)
	move	$5,$0
	sh	$2,8($16)
	lw	$2,0($3)
	addu	$3,$3,4
	andi	$6,$6,0xffc0
	andi	$7,$7,0xff00
	sw	$3,24($16)
	.set	noreorder
	.set	nomacro
	jal	GetTPage
	sh	$2,6($16)
	.set	macro
	.set	reorder

	sh	$2,18($16)
.L40:
	lw	$31,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,40
	j	$31
	.end	func_800485EC
.Lfe9:
	.size	 func_800485EC,.Lfe9-func_800485EC
	.align	2
	.globl	func_800486FC
	.type	 func_800486FC,@function
	.ent	func_800486FC
func_800486FC:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	jal	file_GetFlag0
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L44
	li	$2,0x00000001		# 1
	.set	macro
	.set	reorder

	sh	$2,g_color_mode
	j	.L45
.L44:
	sh	$0,g_color_mode
.L45:
	lh	$2,g_color_mode
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_800486FC
.Lfe10:
	.size	 func_800486FC,.Lfe10-func_800486FC
	.align	2
	.globl	func_80048744
	.type	 func_80048744,@function
	.ent	func_80048744
func_80048744:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	beq	$4,$0,.L47
	li	$2,0x00000001		# 1
	.set	macro
	.set	reorder

	sh	$2,g_color_mode
	j	.L48
.L47:
	sh	$0,g_color_mode
.L48:
	j	$31
	.end	func_80048744
.Lfe11:
	.size	 func_80048744,.Lfe11-func_80048744
	.align	2
	.globl	func_8004876C
	.type	 func_8004876C,@function
	.ent	func_8004876C
func_8004876C:
	.frame	$sp,8,$31		# vars= 8, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	subu	$sp,$sp,8
	move	$9,$4
	.set	noreorder
	.set	nomacro
	beq	$5,$0,.L50
	addu	$8,$5,-1
	.set	macro
	.set	reorder

	li	$11,-32768			# 0xffff8000
	li	$10,-1			# 0xffffffff
.L51:
	lhu	$5,0($9)
	addu	$9,$9,2
	addu	$8,$8,-1
	andi	$7,$5,0x001f
	sll	$2,$7,1
	addu	$2,$2,$7
	sll	$2,$2,6
	addu	$2,$2,$7
	sll	$3,$2,3
	subu	$7,$3,$2
	sll	$3,$5,16
	sra	$4,$3,26
	andi	$4,$4,0x001f
	sra	$3,$3,10
	andi	$3,$3,0xf800
	sll	$2,$4,1
	addu	$2,$2,$4
	sll	$2,$2,2
	subu	$2,$2,$4
	sll	$2,$2,3
	subu	$2,$2,$4
	sll	$2,$2,3
	addu	$3,$7,$3
	addu	$3,$3,$2
	sra	$3,$3,12
	andi	$7,$3,0x001f
	and	$5,$5,$11
	sll	$2,$7,10
	addu	$5,$5,$2
	sll	$2,$7,5
	addu	$5,$5,$2
	addu	$5,$5,$7
	sh	$5,0($6)
	.set	noreorder
	.set	nomacro
	bne	$8,$10,.L51
	addu	$6,$6,2
	.set	macro
	.set	reorder

.L50:
	addu	$sp,$sp,8
	j	$31
	.end	func_8004876C
.Lfe12:
	.size	 func_8004876C,.Lfe12-func_8004876C
	.align	2
	.globl	func_8004881C
	.type	 func_8004881C,@function
	.ent	func_8004881C
func_8004881C:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	sll	$2,$4,1
	addu	$2,$2,$4
	sll	$2,$2,6
	addu	$2,$2,$4
	sll	$3,$2,3
	subu	$4,$3,$2
	sll	$2,$5,11
	sll	$3,$6,1
	addu	$3,$3,$6
	sll	$3,$3,2
	subu	$3,$3,$6
	sll	$3,$3,3
	subu	$3,$3,$6
	sll	$3,$3,3
	addu	$2,$4,$2
	addu	$2,$2,$3
	.set	noreorder
	.set	nomacro
	j	$31
	sra	$2,$2,12
	.set	macro
	.set	reorder

	.end	func_8004881C
.Lfe13:
	.size	 func_8004881C,.Lfe13-func_8004881C
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80048864.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_80048A7C
	.type	 func_80048A7C,@function
	.ent	func_80048A7C
func_80048A7C:
	.frame	$sp,48,$31		# vars= 0, regs= 1/0, args= 40, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,48
	move	$8,$4
	move	$9,$5
	move	$10,$6
	move	$4,$0
	move	$5,$8
	lw	$2,64($sp)
	lw	$3,68($sp)
	move	$6,$9
	sw	$7,16($sp)
	move	$7,$10
	sw	$31,40($sp)
	sw	$8,28($sp)
	sw	$9,32($sp)
	sw	$2,20($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80048864
	sw	$3,24($sp)
	.set	macro
	.set	reorder

	lw	$31,40($sp)
	addu	$sp,$sp,48
	j	$31
	.end	func_80048A7C
.Lfe14:
	.size	 func_80048A7C,.Lfe14-func_80048A7C
	.align	2
	.globl	func_80048AD0
	.type	 func_80048AD0,@function
	.ent	func_80048AD0
func_80048AD0:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$16,16($sp)
	sw	$31,20($sp)
	.set	noreorder
	.set	nomacro
	jal	func_8004153C
	move	$16,$4
	.set	macro
	.set	reorder

	beq	$2,$0,.L66
	lh	$2,8($2)
	sw	$16,D_800A33E0
	lbu	$4,D_80099BCC($2)
	li	$2,0x000000ff		# 255
	bne	$4,$2,.L59
.L66:
	.set	noreorder
	.set	nomacro
	j	.L65
	move	$2,$0
	.set	macro
	.set	reorder

.L59:
	jal	snd_LoadBgm
	move	$4,$0
	li	$8,0x00000009		# 9
	lw	$3,8($2)
	li	$7,0x0000000f		# 15
	srl	$3,$3,2
	sll	$3,$3,2
	addu	$3,$2,$3
	subu	$6,$3,$2
	addu	$5,$3,10
	sw	$3,D_800A33E4
.L63:
	sh	$4,-8($5)
	sh	$8,-6($5)
	sb	$7,0($3)
	sb	$0,-9($5)
	sh	$16,0($5)
	addu	$5,$5,104
	addu	$4,$4,1
	slt	$2,$4,17
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L63
	addu	$3,$3,104
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	snd_PlayBgm
	addu	$4,$6,1768
	.set	macro
	.set	reorder

	li	$2,0x00000001		# 1
.L65:
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80048AD0
.Lfe15:
	.size	 func_80048AD0,.Lfe15-func_80048AD0
	.align	2
	.globl	func_80048B8C
	.type	 func_80048B8C,@function
	.ent	func_80048B8C
func_80048B8C:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$2,g_snd_play_count
	#nop
	addu	$2,$2,$4
	sw	$2,g_snd_play_count
	j	$31
	.end	func_80048B8C
.Lfe16:
	.size	 func_80048B8C,.Lfe16-func_80048B8C
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80048BA4.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_80048F58
	.type	 func_80048F58,@function
	.ent	func_80048F58
func_80048F58:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	sw	$17,20($sp)
	move	$17,$4
	sw	$16,16($sp)
	move	$16,$5
	.set	noreorder
	.set	nomacro
	blez	$16,.L69
	sw	$31,24($sp)
	.set	macro
	.set	reorder

	jal	func_80052C10
.L69:
	sll	$2,$16,2
	addu	$2,$2,$16
	sll	$2,$2,2
	subu	$2,$2,$16
	sll	$2,$2,2
	addu	$2,$2,$16
	sll	$2,$2,2
	la	$3,g_snd_ch_data
	addu	$2,$2,$3
	sw	$0,0($2)
	sll	$3,$17,3
	subu	$3,$3,$17
	sll	$3,$3,1
	la	$4,g_snd_se_bank
	addu	$3,$3,$4
	addu	$5,$2,292
	move	$4,$0
.L70:
	lhu	$2,0($3)
	addu	$3,$3,2
	addu	$4,$4,1
	sh	$2,0($5)
	slt	$2,$4,7
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L70
	addu	$5,$5,2
	.set	macro
	.set	reorder

	lw	$31,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,32
	j	$31
	.end	func_80048F58
.Lfe17:
	.size	 func_80048F58,.Lfe17-func_80048F58
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80048FFC.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_8004939C
	.type	 func_8004939C,@function
	.ent	func_8004939C
func_8004939C:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	li	$4,-1			# 0xffffffff
	li	$3,0x00000039		# 57
	la	$2,D_800EF9F2
.L75:
	sh	$4,0($2)
	addu	$3,$3,-1
	.set	noreorder
	.set	nomacro
	bgez	$3,.L75
	addu	$2,$2,-2
	.set	macro
	.set	reorder

	li	$2,-2			# 0xfffffffe
	sh	$2,D_800EF9F4
	li	$2,-1			# 0xffffffff
	sh	$2,D_800A33EA
	sh	$2,D_800A33E8
	li	$2,-1			# 0xffffffff
	sw	$2,D_800A33EC
	j	$31
	.end	func_8004939C
.Lfe18:
	.size	 func_8004939C,.Lfe18-func_8004939C
	.align	2
	.globl	func_800493E4
	.type	 func_800493E4,@function
	.ent	func_800493E4
func_800493E4:
	.frame	$sp,32,$31		# vars= 8, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	sw	$16,24($sp)
	move	$16,$4
	sll	$2,$16,1
	li	$3,0x00000001		# 1
	sw	$31,28($sp)
	sh	$3,D_800EF980($2)
	lw	$3,D_800A33EC
	li	$2,-1			# 0xffffffff
	.set	noreorder
	.set	nomacro
	bne	$3,$2,.L80
	slt	$2,$16,51
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L81
	li	$2,0x00000001		# 1
	.set	macro
	.set	reorder

	sw	$2,D_800A33EC
	.set	noreorder
	.set	nomacro
	j	.L91
	sll	$4,$16,1
	.set	macro
	.set	reorder

.L81:
	sw	$0,D_800A33EC
	.set	noreorder
	.set	nomacro
	j	.L91
	sll	$4,$16,1
	.set	macro
	.set	reorder

.L80:
	bne	$3,$0,.L84
	bne	$2,$0,.L84
	jal	func_80052C10
.L84:
	lw	$3,D_800A33EC
	li	$2,0x00000001		# 1
	.set	noreorder
	.set	nomacro
	bne	$3,$2,.L91
	sll	$4,$16,1
	.set	macro
	.set	reorder

	slt	$2,$16,51
	beq	$2,$0,.L91
	jal	func_80052C10
	sll	$4,$16,1
.L91:
	lbu	$3,D_80099CC8($4)
	li	$2,0x000000ff		# 255
	.set	noreorder
	.set	nomacro
	beq	$3,$2,.L86
	sll	$2,$3,1
	.set	macro
	.set	reorder

	li	$3,0x00000001		# 1
	sh	$3,D_800EF980($2)
	lbu	$2,D_80099CC9($4)
	#nop
	sll	$2,$2,1
	sh	$3,D_800EF980($2)
.L86:
	lw	$31,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,32
	j	$31
	.end	func_800493E4
.Lfe19:
	.size	 func_800493E4,.Lfe19-func_800493E4
	.align	2
	.globl	func_800494D4
	.type	 func_800494D4,@function
	.ent	func_800494D4
func_800494D4:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	lw	$2,D_800A33EC
	subu	$sp,$sp,32
	sw	$17,20($sp)
	move	$17,$4
	sw	$16,16($sp)
	move	$16,$5
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L93
	sw	$31,24($sp)
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L94
	slt	$2,$16,16
	.set	macro
	.set	reorder

.L93:
	slt	$2,$16,8
.L94:
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L97
	sltu	$2,$17,2
	.set	macro
	.set	reorder

	jal	func_80052C10
	sltu	$2,$17,2
.L97:
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L98
	sll	$2,$17,1
	.set	macro
	.set	reorder

	jal	func_80052C10
	sll	$2,$17,1
.L98:
	sh	$16,D_800A33E8($2)
	lw	$31,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,32
	j	$31
	.end	func_800494D4
.Lfe20:
	.size	 func_800494D4,.Lfe20-func_800494D4
	.align	2
	.globl	func_8004954C
	.type	 func_8004954C,@function
	.ent	func_8004954C
func_8004954C:
	.frame	$sp,8,$31		# vars= 8, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	subu	$sp,$sp,8
	move	$7,$0
	.set	noreorder
	.set	nomacro
	blez	$5,.L101
	move	$3,$0
	.set	macro
	.set	reorder

.L103:
	addu	$3,$3,$4
	addu	$7,$7,1
	slt	$2,$7,$5
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L103
	addu	$4,$4,-1
	.set	macro
	.set	reorder

.L101:
	subu	$2,$6,$5
	addu	$2,$3,$2
	addu	$sp,$sp,8
	j	$31
	.end	func_8004954C
.Lfe21:
	.size	 func_8004954C,.Lfe21-func_8004954C
	.align	2
	.globl	func_80049584
	.type	 func_80049584,@function
	.ent	func_80049584
func_80049584:
	.frame	$sp,40,$31		# vars= 8, regs= 4/0, args= 16, extra= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	sw	$18,32($sp)
	move	$18,$4
	sw	$17,28($sp)
	li	$17,0x00000001		# 1
	sw	$16,24($sp)
	move	$16,$0
	la	$5,D_80099C50
	la	$6,D_800EF980
	sw	$31,36($sp)
.L110:
	lh	$4,0($6)
	lh	$2,0($5)
	nor	$3,$0,$4
	srl	$3,$3,31
	nor	$2,$0,$2
	srl	$2,$2,31
	beq	$3,$2,.L113
	move	$17,$0
.L113:
	sh	$4,0($5)
	addu	$5,$5,2
	addu	$16,$16,1
	slt	$2,$16,58
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L110
	addu	$6,$6,2
	.set	macro
	.set	reorder

	move	$4,$0
	move	$16,$0
	la	$3,D_800EF980
.L115:
	lh	$2,0($3)
	#nop
	bltz	$2,.L118
	sh	$4,0($3)
	addu	$4,$4,1
.L118:
	addu	$16,$16,1
	slt	$2,$16,58
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L115
	addu	$3,$3,2
	.set	macro
	.set	reorder

	lw	$3,D_800A33EC
	#nop
	.set	noreorder
	.set	nomacro
	bne	$3,$0,.L120
	li	$4,0x00000008		# 8
	.set	macro
	.set	reorder

	li	$4,0x00000010		# 16
.L120:
	lh	$6,D_800A33E8
	li	$2,-1			# 0xffffffff
	bne	$6,$2,.L121
	lh	$5,D_800A33EA
	#nop
	bne	$5,$6,.L122
	.set	noreorder
	.set	nomacro
	bne	$3,$0,.L124
	li	$16,0x00000024		# 36
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L124
	li	$16,0x00000088		# 136
	.set	macro
	.set	reorder

.L122:
	.set	noreorder
	.set	nomacro
	j	.L125
	move	$6,$5
	.set	macro
	.set	reorder

.L121:
	lh	$3,D_800A33EA
	#nop
	.set	noreorder
	.set	nomacro
	beq	$3,$2,.L125
	move	$5,$6
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	beq	$6,$3,.L125
	slt	$2,$6,$3
	.set	macro
	.set	reorder

	beq	$2,$0,.L127
	.set	noreorder
	.set	nomacro
	j	.L125
	move	$6,$3
	.set	macro
	.set	reorder

.L127:
	move	$5,$3
.L125:
	jal	func_8004954C
	move	$16,$2
.L124:
	lw	$2,D_800A324C
	#nop
	beq	$2,$16,.L129
	sw	$16,D_800A324C
	move	$17,$0
.L129:
	bne	$17,$0,.L130
	jal	func_80046020
	lw	$4,D_800A33EC
	move	$5,$16
	la	$6,D_800EF980
	.set	noreorder
	.set	nomacro
	jal	func_80045B68
	move	$7,$18
	.set	macro
	.set	reorder

	jal	func_8003E120
.L130:
	lw	$31,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,40
	j	$31
	.end	func_80049584
.Lfe22:
	.size	 func_80049584,.Lfe22-func_80049584
	.align	2
	.globl	func_80049710
	.type	 func_80049710,@function
	.ent	func_80049710
func_80049710:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_80049710
.Lfe23:
	.size	 func_80049710,.Lfe23-func_80049710
	.align	2
	.globl	func_80049718
	.type	 func_80049718,@function
	.ent	func_80049718
func_80049718:
	.frame	$sp,56,$31		# vars= 8, regs= 8/0, args= 16, extra= 0
	.mask	0x807f0000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,56
	sw	$22,48($sp)
	move	$22,$4
	sw	$19,36($sp)
	move	$19,$5
	sw	$20,40($sp)
	move	$20,$6
	la	$2,D_800EF980
	sll	$3,$22,1
	sw	$16,24($sp)
	addu	$16,$3,$2
	sw	$31,52($sp)
	sw	$21,44($sp)
	sw	$18,32($sp)
	sw	$17,28($sp)
	lh	$2,0($16)
	#nop
	.set	noreorder
	.set	nomacro
	bgez	$2,.L133
	move	$17,$7
	.set	macro
	.set	reorder

	jal	func_80052C10
.L133:
	lw	$18,D_800A38B4
	move	$21,$0
	sb	$0,0($18)
	sb	$0,1($18)
	lh	$2,0($16)
	li	$3,0x00000006		# 6
	sh	$3,4($18)
	li	$3,0x00000004		# 4
	sh	$0,8($18)
	sw	$0,12($18)
	sh	$3,10($18)
	sll	$2,$2,1
	.set	noreorder
	.set	nomacro
	beq	$19,$0,.L134
	sh	$2,2($18)
	.set	macro
	.set	reorder

	li	$2,0x00000001		# 1
	bne	$19,$2,.L135
	lhu	$2,0($17)
	#nop
	sh	$2,16($18)
	lhu	$2,2($17)
	#nop
	sh	$2,18($18)
	lhu	$2,4($17)
	addu	$4,$18,16
	sh	$2,20($18)
	lw	$2,g_anim_func_table
	#nop
	.set	noreorder
	.set	nomacro
	jal	$31,$2
	addu	$5,$18,24
	.set	macro
	.set	reorder

	lw	$2,0($20)
	#nop
	sw	$2,44($18)
	lw	$2,4($20)
	#nop
	sw	$2,48($18)
	lw	$2,8($20)
	.set	noreorder
	.set	nomacro
	j	.L136
	sw	$2,52($18)
	.set	macro
	.set	reorder

.L135:
	andi	$19,$19,0x7fff
	.set	noreorder
	.set	nomacro
	jal	func_8004153C
	srl	$4,$19,1
	.set	macro
	.set	reorder

	andi	$3,$19,0x0001
	move	$17,$2
	sll	$16,$3,1
	addu	$16,$16,$3
	sll	$16,$16,2
	addu	$16,$16,$3
	sll	$16,$16,3
	addu	$16,$16,2020
	addu	$16,$17,$16
	lh	$3,18($17)
	lw	$2,76($16)
	#nop
	mult	$2,$3
	mflo	$8
	#nop
	#nop
	sra	$2,$8,12
	sw	$2,76($16)
	lh	$3,18($17)
	lw	$2,80($16)
	#nop
	mult	$2,$3
	mflo	$8
	#nop
	#nop
	sra	$2,$8,12
	sw	$2,80($16)
	lh	$3,18($17)
	lw	$2,84($16)
	#nop
	mult	$2,$3
	addu	$4,$17,68
	addu	$5,$16,56
	addu	$6,$18,24
	mflo	$8
	#nop
	#nop
	sra	$2,$8,12
	.set	noreorder
	.set	nomacro
	jal	MulMatrix0
	sw	$2,84($16)
	.set	macro
	.set	reorder

	lw	$2,76($16)
	#nop
	sh	$2,16($sp)
	lw	$2,80($16)
	#nop
	sh	$2,18($sp)
	lw	$2,84($16)
	addu	$5,$sp,16
	sh	$2,20($sp)
	lw	$4,12($16)
	addu	$6,$18,44
	.set	noreorder
	.set	nomacro
	jal	ApplyMatrix
	addu	$4,$4,24
	.set	macro
	.set	reorder

	lw	$3,12($16)
	lw	$2,44($18)
	lw	$3,44($3)
	#nop
	addu	$2,$2,$3
	sw	$2,44($18)
	lw	$3,12($16)
	lw	$2,48($18)
	lw	$3,48($3)
	#nop
	addu	$2,$2,$3
	sw	$2,48($18)
	lw	$3,12($16)
	lw	$2,52($18)
	lw	$3,52($3)
	ori	$19,$19,0x8000
	addu	$2,$2,$3
	sw	$2,52($18)
	lw	$2,24($18)
	lw	$3,28($18)
	lw	$4,32($18)
	lw	$5,36($18)
	sw	$2,24($16)
	sw	$3,28($16)
	sw	$4,32($16)
	sw	$5,36($16)
	lw	$2,40($18)
	lw	$3,44($18)
	lw	$4,48($18)
	lw	$5,52($18)
	sw	$2,40($16)
	sw	$3,44($16)
	sw	$4,48($16)
	sw	$5,52($16)
	lh	$21,6788($17)
.L136:
	lw	$2,D_800A3820
	#nop
	addu	$3,$2,4
	sw	$3,D_800A3820
	sw	$18,0($2)
	li	$2,0x00000001		# 1
	.set	noreorder
	.set	nomacro
	beq	$19,$2,.L137
	addu	$18,$18,104
	.set	macro
	.set	reorder

	sll	$2,$22,1
	lh	$3,D_800EF980($2)
	li	$2,0x00000003		# 3
	sb	$2,0($18)
	sb	$0,1($18)
	sw	$21,88($18)
	lw	$4,D_800A3820
	addu	$2,$18,-104
	sw	$2,12($18)
	li	$2,0x00000001		# 1
	sh	$2,6($18)
	li	$2,0x00000006		# 6
	sh	$0,8($18)
	sh	$0,10($18)
	sh	$2,4($18)
	sll	$3,$3,1
	addu	$3,$3,1
	addu	$2,$4,4
	sh	$3,2($18)
	sw	$2,D_800A3820
	sw	$18,0($4)
	addu	$18,$18,104
.L137:
	sw	$18,D_800A38B4
.L134:
	lw	$31,52($sp)
	lw	$22,48($sp)
	lw	$21,44($sp)
	lw	$20,40($sp)
	lw	$19,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,56
	j	$31
	.end	func_80049718
.Lfe24:
	.size	 func_80049718,.Lfe24-func_80049718
	.align	2
	.globl	func_80049A2C
	.type	 func_80049A2C,@function
	.ent	func_80049A2C
func_80049A2C:
	.frame	$sp,48,$31		# vars= 8, regs= 5/0, args= 16, extra= 0
	.mask	0x800f0000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,48
	sw	$17,28($sp)
	la	$2,D_80099CC8
	sll	$4,$4,1
	addu	$4,$4,$2
	addu	$4,$4,$6
	sw	$31,40($sp)
	sw	$19,36($sp)
	sw	$18,32($sp)
	sw	$16,24($sp)
	lbu	$3,0($4)
	li	$2,0x000000ff		# 255
	.set	noreorder
	.set	nomacro
	beq	$3,$2,.L138
	move	$17,$5
	.set	macro
	.set	reorder

	la	$2,D_800EF980
	sll	$3,$3,1
	addu	$19,$3,$2
	lh	$2,0($19)
	#nop
	bgez	$2,.L140
	jal	func_80052C10
.L140:
	.set	noreorder
	.set	nomacro
	jal	func_8004153C
	sra	$4,$17,1
	.set	macro
	.set	reorder

	andi	$4,$17,0x0001
	sll	$3,$4,1
	addu	$3,$3,$4
	sll	$3,$3,2
	la	$4,D_80099D3C
	addu	$3,$3,$4
	li	$18,0x00000006		# 6
	lw	$16,D_800A38B4
	li	$4,0x00000004		# 4
	sb	$0,0($16)
	sb	$0,1($16)
	lh	$5,0($19)
	move	$17,$2
	sh	$18,4($16)
	sh	$0,8($16)
	sh	$4,10($16)
	sll	$5,$5,1
	sh	$5,2($16)
	lh	$4,0($3)
	lh	$2,18($17)
	#nop
	mult	$4,$2
	addu	$3,$3,2
	mflo	$7
	#nop
	#nop
	sra	$2,$7,12
	sw	$2,76($16)
	lh	$4,0($3)
	lh	$2,18($17)
	#nop
	mult	$4,$2
	addu	$3,$3,2
	mflo	$7
	#nop
	#nop
	sra	$2,$7,12
	sw	$2,80($16)
	lh	$4,0($3)
	lh	$2,18($17)
	#nop
	mult	$4,$2
	addu	$3,$3,2
	mflo	$7
	#nop
	#nop
	sra	$2,$7,12
	sw	$2,84($16)
	lhu	$2,0($3)
	addu	$3,$3,2
	sh	$2,16($16)
	lhu	$2,0($3)
	move	$4,$16
	sh	$2,18($16)
	lhu	$3,2($3)
	addu	$2,$17,1292
	sw	$2,12($16)
	sh	$0,6($16)
	.set	noreorder
	.set	nomacro
	jal	func_800417D0
	sh	$3,20($16)
	.set	macro
	.set	reorder

	lw	$3,D_800A3820
	#nop
	addu	$2,$3,4
	sw	$2,D_800A3820
	sw	$16,0($3)
	addu	$16,$16,104
	lh	$3,0($19)
	li	$2,0x00000003		# 3
	sb	$2,0($16)
	addu	$2,$16,-104
	sw	$2,12($16)
	li	$2,0x00000001		# 1
	sb	$0,1($16)
	sh	$0,8($16)
	sh	$2,6($16)
	sh	$0,10($16)
	sh	$18,4($16)
	sll	$3,$3,1
	addu	$3,$3,1
	sh	$3,2($16)
	lh	$2,6788($17)
	#nop
	sw	$2,88($16)
	lw	$3,D_800A3820
	#nop
	addu	$2,$3,4
	sw	$2,D_800A3820
	sw	$16,0($3)
	addu	$16,$16,104
	sw	$16,D_800A38B4
.L138:
	lw	$31,40($sp)
	lw	$19,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,48
	j	$31
	.end	func_80049A2C
.Lfe25:
	.size	 func_80049A2C,.Lfe25-func_80049A2C
	.align	2
	.globl	func_80049C24
	.type	 func_80049C24,@function
	.ent	func_80049C24
func_80049C24:
	.frame	$sp,56,$31		# vars= 0, regs= 10/0, args= 16, extra= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,56
	sw	$31,52($sp)
	sw	$fp,48($sp)
	sw	$23,44($sp)
	sw	$22,40($sp)
	sw	$21,36($sp)
	sw	$20,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	sw	$16,16($sp)
	lw	$3,0($4)
	move	$19,$5
	sll	$2,$3,2
	addu	$2,$2,$4
	lw	$2,4($2)
	lw	$6,8($4)
	addu	$23,$4,$2
	lw	$2,4($4)
	slt	$3,$3,2
	addu	$fp,$4,$2
	.set	noreorder
	.set	nomacro
	bne	$3,$0,.L142
	subu	$21,$6,$2
	.set	macro
	.set	reorder

	lw	$2,12($4)
	addu	$22,$4,$6
	.set	noreorder
	.set	nomacro
	j	.L143
	subu	$20,$2,$6
	.set	macro
	.set	reorder

.L142:
	move	$22,$0
	move	$20,$0
.L143:
	li	$2,-1			# 0xffffffff
	lh	$16,D_800A33E8
	lh	$18,D_800A33EA
	.set	noreorder
	.set	nomacro
	bne	$16,$2,.L144
	addu	$17,$19,12
	.set	macro
	.set	reorder

	bne	$18,$16,.L164
	.set	noreorder
	.set	nomacro
	j	.L147
	move	$16,$18
	.set	macro
	.set	reorder

.L144:
	bne	$18,$2,.L148
	.set	noreorder
	.set	nomacro
	j	.L147
	move	$16,$0
	.set	macro
	.set	reorder

.L148:
	bne	$16,$18,.L150
	move	$16,$0
.L164:
	.set	noreorder
	.set	nomacro
	j	.L147
	move	$18,$0
	.set	macro
	.set	reorder

.L150:
	slt	$2,$16,$18
	beq	$2,$0,.L152
	move	$16,$0
	.set	noreorder
	.set	nomacro
	j	.L147
	li	$18,0x00000001		# 1
	.set	macro
	.set	reorder

.L152:
	slt	$2,$18,$16
	beq	$2,$0,.L154
	.set	noreorder
	.set	nomacro
	j	.L164
	li	$16,0x00000001		# 1
	.set	macro
	.set	reorder

.L154:
	jal	func_80052C10
.L147:
	nor	$2,$0,$16
	move	$3,$19
	addu	$19,$19,4
	.set	noreorder
	.set	nomacro
	bltz	$18,.L156
	srl	$2,$2,31
	.set	macro
	.set	reorder

	addu	$2,$2,1
.L156:
	.set	noreorder
	.set	nomacro
	bltz	$16,.L157
	sw	$2,0($3)
	.set	macro
	.set	reorder

	li	$2,0x00000002		# 2
	sw	$2,0($19)
	.set	noreorder
	.set	nomacro
	bne	$16,$0,.L158
	addu	$19,$19,4
	.set	macro
	.set	reorder

	move	$4,$fp
	move	$5,$17
	.set	noreorder
	.set	nomacro
	jal	func_800520B8
	move	$6,$21
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L159
	addu	$4,$17,$21
	.set	macro
	.set	reorder

.L158:
	move	$4,$22
	move	$5,$17
	.set	noreorder
	.set	nomacro
	jal	func_800520B8
	move	$6,$20
	.set	macro
	.set	reorder

	addu	$4,$17,$20
.L159:
	jal	func_80045230
	move	$4,$17
	li	$5,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	jal	func_8005C2A8
	move	$6,$23
	.set	macro
	.set	reorder

	addu	$17,$17,$2
.L157:
	.set	noreorder
	.set	nomacro
	bltz	$18,.L160
	li	$2,0x00000005		# 5
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	bne	$18,$0,.L161
	sw	$2,0($19)
	.set	macro
	.set	reorder

	move	$4,$fp
	move	$5,$17
	.set	noreorder
	.set	nomacro
	jal	func_800520B8
	move	$6,$21
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L162
	addu	$4,$17,$21
	.set	macro
	.set	reorder

.L161:
	move	$4,$22
	move	$5,$17
	.set	noreorder
	.set	nomacro
	jal	func_800520B8
	move	$6,$20
	.set	macro
	.set	reorder

	addu	$4,$17,$20
.L162:
	jal	func_80045230
	move	$4,$17
	li	$5,0x00000005		# 5
	.set	noreorder
	.set	nomacro
	jal	func_8005C2A8
	move	$6,$23
	.set	macro
	.set	reorder

	addu	$17,$17,$2
.L160:
	move	$2,$17
	lw	$31,52($sp)
	lw	$fp,48($sp)
	lw	$23,44($sp)
	lw	$22,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,56
	j	$31
	.end	func_80049C24
.Lfe26:
	.size	 func_80049C24,.Lfe26-func_80049C24
	.align	2
	.globl	func_80049E1C
	.type	 func_80049E1C,@function
	.ent	func_80049E1C
func_80049E1C:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	li	$4,-1			# 0xffffffff
	li	$3,0x00000039		# 57
	la	$2,D_80099CC2
.L166:
	sh	$4,0($2)
	addu	$3,$3,-1
	.set	noreorder
	.set	nomacro
	bgez	$3,.L166
	addu	$2,$2,-2
	.set	macro
	.set	reorder

	li	$2,-1			# 0xffffffff
	sw	$2,D_800A324C
	j	$31
	.end	func_80049E1C
.Lfe27:
	.size	 func_80049E1C,.Lfe27-func_80049E1C
	.align	2
	.globl	func_80049E4C
	.type	 func_80049E4C,@function
	.ent	func_80049E4C
func_80049E4C:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	sw	$17,20($sp)
	la	$17,D_80101DF0
	li	$2,0x00000064		# 100
	sw	$31,24($sp)
	sw	$16,16($sp)
	sb	$2,0($17)
	li	$2,0x00000005		# 5
	sb	$0,D_80101DF1
	sh	$0,D_80101E00
	sh	$0,D_80101E02
	sh	$0,D_80101E04
	sw	$0,D_80101E3C
	sw	$0,D_80101E40
	sw	$0,D_80101E44
	sw	$0,D_80101DFC
	sh	$2,D_80101DF8
	.set	noreorder
	.set	nomacro
	jal	func_800418D0
	move	$4,$17
	.set	macro
	.set	reorder

	la	$16,D_800FF638
	li	$2,0x00000065		# 101
	sb	$2,0($16)
	li	$2,0x00000002		# 2
	sb	$0,D_800FF639
	sh	$0,D_800FF648
	sh	$0,D_800FF64A
	sh	$0,D_800FF64C
	sw	$0,D_800FF684
	sw	$0,D_800FF688
	sw	$0,D_800FF68C
	sw	$0,D_800FF644
	sh	$2,D_800FF640
	.set	noreorder
	.set	nomacro
	jal	func_800418D0
	move	$4,$16
	.set	macro
	.set	reorder

	sw	$17,D_800A3708
	sw	$16,D_800A370C
	lw	$31,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,32
	j	$31
	.end	func_80049E4C
.Lfe28:
	.size	 func_80049E4C,.Lfe28-func_80049E4C
	.align	2
	.globl	func_80049F4C
	.type	 func_80049F4C,@function
	.ent	func_80049F4C
func_80049F4C:
	.frame	$sp,80,$31		# vars= 48, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,80
	addu	$7,$sp,16
	la	$6,D_800153F0
	or	$2,$7,$6
	andi	$2,$2,0x0003
	sw	$31,72($sp)
	sw	$17,68($sp)
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L172
	sw	$16,64($sp)
	.set	macro
	.set	reorder

	addu	$8,$6,32
.L174:
	lwl	$2,3($6)
	lwr	$2,0($6)
	lwl	$3,7($6)
	lwr	$3,4($6)
	lwl	$4,11($6)
	lwr	$4,8($6)
	lwl	$5,15($6)
	lwr	$5,12($6)
	swl	$2,3($7)
	swr	$2,0($7)
	swl	$3,7($7)
	swr	$3,4($7)
	swl	$4,11($7)
	swr	$4,8($7)
	swl	$5,15($7)
	swr	$5,12($7)
	addu	$6,$6,16
	.set	noreorder
	.set	nomacro
	bne	$6,$8,.L174
	addu	$7,$7,16
	.set	macro
	.set	reorder

	j	.L173
.L172:
	addu	$8,$6,32
.L175:
	lw	$2,0($6)
	lw	$3,4($6)
	lw	$4,8($6)
	lw	$5,12($6)
	sw	$2,0($7)
	sw	$3,4($7)
	sw	$4,8($7)
	sw	$5,12($7)
	addu	$6,$6,16
	.set	noreorder
	.set	nomacro
	bne	$6,$8,.L175
	addu	$7,$7,16
	.set	macro
	.set	reorder

.L173:
	lwl	$2,3($6)
	lwr	$2,0($6)
	lwl	$3,7($6)
	lwr	$3,4($6)
	lwl	$4,11($6)
	lwr	$4,8($6)
	swl	$2,3($7)
	swr	$2,0($7)
	swl	$3,7($7)
	swr	$3,4($7)
	swl	$4,11($7)
	swr	$4,8($7)
	move	$17,$0
	la	$16,D_800F62E0
.L176:
	move	$4,$16
	.set	noreorder
	.set	nomacro
	jal	func_8004A09C
	addu	$5,$sp,16
	.set	macro
	.set	reorder

	addu	$17,$17,1
	slt	$2,$17,8
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L176
	addu	$16,$16,96
	.set	macro
	.set	reorder

	la	$4,D_800F6318
	jal	gte_SetColorMatrix
	lbu	$4,D_800F6338
	lbu	$5,D_800F6339
	lbu	$6,D_800F633A
	jal	SetBackColor
	lw	$31,72($sp)
	lw	$17,68($sp)
	lw	$16,64($sp)
	addu	$sp,$sp,80
	j	$31
	.end	func_80049F4C
.Lfe29:
	.size	 func_80049F4C,.Lfe29-func_80049F4C
	.align	2
	.globl	func_8004A09C
	.type	 func_8004A09C,@function
	.ent	func_8004A09C
func_8004A09C:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	sw	$17,20($sp)
	move	$17,$4
	sw	$16,16($sp)
	move	$16,$5
	sw	$31,24($sp)
	lhu	$2,0($16)
	addu	$16,$16,2
	sh	$2,56($17)
	lhu	$2,0($16)
	addu	$16,$16,2
	sh	$2,62($17)
	lhu	$2,0($16)
	addu	$16,$16,2
	sh	$2,68($17)
	lhu	$2,0($16)
	addu	$16,$16,2
	sh	$2,58($17)
	lhu	$2,0($16)
	addu	$16,$16,2
	sh	$2,64($17)
	lhu	$2,0($16)
	addu	$16,$16,2
	sh	$2,70($17)
	lhu	$2,0($16)
	addu	$16,$16,2
	sh	$2,60($17)
	lhu	$2,0($16)
	addu	$16,$16,2
	sh	$2,66($17)
	lhu	$2,0($16)
	addu	$16,$16,2
	sh	$0,24($17)
	sh	$0,26($17)
	sh	$0,28($17)
	sh	$0,30($17)
	sh	$0,32($17)
	sh	$0,34($17)
	sh	$0,36($17)
	sh	$0,38($17)
	sh	$0,40($17)
	sh	$2,72($17)
	lhu	$2,0($16)
	addu	$16,$16,2
	sh	$2,0($17)
	lhu	$2,0($16)
	addu	$16,$16,2
	sh	$2,2($17)
	lhu	$2,0($16)
	addu	$16,$16,2
	sh	$2,4($17)
	lhu	$2,0($16)
	addu	$16,$16,2
	sh	$2,8($17)
	lhu	$2,0($16)
	addu	$16,$16,2
	sh	$2,10($17)
	lhu	$2,0($16)
	addu	$16,$16,2
	sh	$2,12($17)
	lhu	$2,0($16)
	addu	$16,$16,2
	sh	$2,16($17)
	lhu	$2,0($16)
	addu	$16,$16,2
	sh	$2,18($17)
	lhu	$2,0($16)
	addu	$16,$16,2
	.set	noreorder
	.set	nomacro
	jal	func_8004A1FC
	sh	$2,20($17)
	.set	macro
	.set	reorder

	lhu	$2,0($16)
	addu	$16,$16,2
	sb	$2,88($17)
	lhu	$2,0($16)
	addu	$16,$16,2
	sb	$2,89($17)
	lhu	$2,0($16)
	#nop
	sb	$2,90($17)
	lhu	$2,2($16)
	#nop
	sh	$2,92($17)
	lw	$31,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,32
	j	$31
	.end	func_8004A09C
.Lfe30:
	.size	 func_8004A09C,.Lfe30-func_8004A09C
	.align	2
	.globl	func_8004A1FC
	.type	 func_8004A1FC,@function
	.ent	func_8004A1FC
func_8004A1FC:
	.frame	$sp,48,$31		# vars= 0, regs= 7/0, args= 16, extra= 0
	.mask	0x803f0000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,48
	sw	$20,32($sp)
	move	$20,$4
	sw	$21,36($sp)
	move	$21,$0
	sw	$31,40($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	sw	$16,16($sp)
	sll	$2,$21,16
.L188:
	sra	$18,$2,16
	sll	$2,$18,3
	addu	$19,$20,$2
	lh	$2,4($19)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L185
	sll	$2,$18,1
	.set	macro
	.set	reorder

	lh	$4,0($19)
	.set	noreorder
	.set	nomacro
	jal	rcos
	sll	$16,$18,1
	.set	macro
	.set	reorder

	lh	$4,2($19)
	.set	noreorder
	.set	nomacro
	jal	rsin
	move	$17,$2
	.set	macro
	.set	reorder

	sll	$17,$17,16
	sra	$17,$17,16
	mult	$2,$17
	mflo	$5
	#nop
	lh	$3,92($20)
	sra	$2,$5,12
	mult	$2,$3
	addu	$16,$16,$18
	sll	$16,$16,1
	addu	$16,$20,$16
	mflo	$5
	#nop
	#nop
	subu	$2,$0,$5
	sra	$2,$2,12
	sh	$2,24($16)
	lh	$4,0($19)
	jal	rsin
	lh	$3,92($20)
	#nop
	mult	$2,$3
	mflo	$5
	#nop
	#nop
	sra	$2,$5,12
	sh	$2,26($16)
	lh	$4,2($19)
	jal	rcos
	mult	$2,$17
	mflo	$5
	#nop
	lh	$3,92($20)
	sra	$2,$5,12
	mult	$2,$3
	mflo	$5
	#nop
	#nop
	subu	$2,$0,$5
	sra	$2,$2,12
	.set	noreorder
	.set	nomacro
	j	.L186
	sh	$2,28($16)
	.set	macro
	.set	reorder

.L185:
	addu	$2,$2,$18
	sll	$2,$2,1
	addu	$2,$20,$2
	sh	$0,24($2)
	sh	$0,26($2)
	sh	$0,28($2)
.L186:
	addu	$2,$21,1
	move	$21,$2
	sll	$2,$2,16
	sra	$2,$2,16
	slt	$2,$2,3
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L188
	sll	$2,$21,16
	.set	macro
	.set	reorder

	lw	$31,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,48
	j	$31
	.end	func_8004A1FC
.Lfe31:
	.size	 func_8004A1FC,.Lfe31-func_8004A1FC
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8004A348.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8004A4E0.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8004A76C.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8004A808.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_8004A938
	.type	 func_8004A938,@function
	.ent	func_8004A938
func_8004A938:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_8004A938
.Lfe32:
	.size	 func_8004A938,.Lfe32-func_8004A938
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8004A940.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8004BB68.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8004BCC0.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8004C1F4.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8004C388.s"
    .set reorder
    .set at

	.section .text
    nop

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8004C404.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8004C994.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8004CB8C.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8004CDB0.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8004CFE0.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8004D244.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8004D424.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8004D634.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8004D838.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8004DA74.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8004DDB4.s"
    .set reorder
    .set at

	.section .text
    nop

 #NO_APP
	.align	2
	.globl	func_8004E564
	.type	 func_8004E564,@function
	.ent	func_8004E564
func_8004E564:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_8004E564
.Lfe33:
	.size	 func_8004E564,.Lfe33-func_8004E564
	.align	2
	.globl	func_8004E56C
	.type	 func_8004E56C,@function
	.ent	func_8004E56C
func_8004E56C:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_8004E56C
.Lfe34:
	.size	 func_8004E56C,.Lfe34-func_8004E56C
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8004E574.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8004E7E4.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8004EAC8.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8004ECC8.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8004EF10.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8004F0FC.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8004F314.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8004F53C.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8004F798.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8004F970.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8004FB74.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8004FD40.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8004FF40.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80050120.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80050334.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80050538.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80050774.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80050908.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80050AB8.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80050C68.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80050E60.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80051010.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80051208.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_800513B0.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_800515AC.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80051754.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80051944.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80051B04.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80051D08.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80051ED4.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_800520B8.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_800523E0.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_800525D8.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_800526A0.s"
    .set reorder
    .set at

	.section .text
    nop
    nop

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80052720.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80052754.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80052788.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_800527FC.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80052930.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80052A20.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80052A88.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80052B00.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80052B44.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80052B7C.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80052BE4.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80052C10.s"
    .set reorder
    .set at

	.section .text
    nop

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80052C28.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80052C4C.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80052CD4.s"
    .set reorder
    .set at

	.section .text
    nop
    nop
    nop

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80052D00.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_80053304
	.type	 func_80053304,@function
	.ent	func_80053304
func_80053304:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	la	$2,D_800EF9F8
	sw	$2,D_800A33F4
	lw	$2,D_800A33F4
	subu	$sp,$sp,32
	sw	$16,16($sp)
	move	$16,$6
	sw	$17,20($sp)
	move	$17,$7
	sw	$31,24($sp)
	la	$8,D_800EFA00
	lw	$3,0($4)
	lw	$6,4($4)
	lw	$7,8($4)
	sw	$3,0($8)
	sw	$6,4($8)
	sw	$7,8($8)
	lw	$3,12($4)
	sw	$3,12($8)
	lw	$3,0($5)
	lw	$4,4($5)
	lw	$6,8($5)
	lw	$7,12($5)
	sw	$3,24($2)
	sw	$4,28($2)
	sw	$6,32($2)
	sw	$7,36($2)
	lw	$2,D_800A33F4
	#nop
	lw	$3,24($2)
	lw	$4,8($2)
	lw	$7,28($2)
	lw	$5,12($2)
	lw	$6,16($2)
	subu	$4,$3,$4
	lw	$3,32($2)
	subu	$5,$7,$5
	.set	noreorder
	.set	nomacro
	jal	func_80052754
	subu	$6,$3,$6
	.set	macro
	.set	reorder

	li	$3,0x00009c3f		# 39999
	slt	$3,$3,$2
	bne	$3,$0,.L193
	lw	$4,D_800A33F4
	#nop
	lw	$3,24($4)
	lw	$6,8($4)
	lw	$5,28($4)
	lw	$7,12($4)
	la	$2,func_80053754
	sw	$2,92($4)
	lw	$2,32($4)
	subu	$3,$3,$6
	sll	$3,$3,1
	subu	$6,$6,$3
	subu	$5,$5,$7
	sll	$5,$5,1
	lw	$3,16($4)
	subu	$7,$7,$5
	sw	$6,8($4)
	sw	$7,12($4)
	subu	$2,$2,$3
	sll	$2,$2,1
	subu	$3,$3,$2
	.set	noreorder
	.set	nomacro
	j	.L194
	sw	$3,16($4)
	.set	macro
	.set	reorder

.L193:
	lw	$3,D_800A33F4
	la	$2,func_80053E9C
	sw	$2,92($3)
.L194:
	move	$4,$16
	.set	noreorder
	.set	nomacro
	jal	func_80052D00
	move	$5,$17
	.set	macro
	.set	reorder

	lw	$31,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,32
	j	$31
	.end	func_80053304
.Lfe35:
	.size	 func_80053304,.Lfe35-func_80053304
	.align	2
	.globl	func_8005344C
	.type	 func_8005344C,@function
	.ent	func_8005344C
func_8005344C:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	lw	$2,48($sp)
	sw	$16,16($sp)
	move	$16,$6
	sw	$17,20($sp)
	move	$17,$7
	sw	$31,24($sp)
	sw	$2,D_800A33F4
	lw	$3,0($4)
	lw	$6,4($4)
	lw	$7,8($4)
	lw	$8,12($4)
	sw	$3,8($2)
	sw	$6,12($2)
	sw	$7,16($2)
	sw	$8,20($2)
	lw	$2,D_800A33F4
	#nop
	lw	$3,0($5)
	lw	$4,4($5)
	lw	$6,8($5)
	lw	$7,12($5)
	sw	$3,24($2)
	sw	$4,28($2)
	sw	$6,32($2)
	sw	$7,36($2)
	lw	$2,D_800A33F4
	#nop
	lw	$3,24($2)
	lw	$4,8($2)
	lw	$7,28($2)
	lw	$5,12($2)
	lw	$6,16($2)
	subu	$4,$3,$4
	lw	$3,32($2)
	subu	$5,$7,$5
	.set	noreorder
	.set	nomacro
	jal	func_80052754
	subu	$6,$3,$6
	.set	macro
	.set	reorder

	li	$3,0x00009c3f		# 39999
	slt	$3,$3,$2
	bne	$3,$0,.L196
	lw	$4,D_800A33F4
	#nop
	lw	$3,24($4)
	lw	$6,8($4)
	lw	$5,28($4)
	lw	$7,12($4)
	la	$2,func_80053754
	sw	$2,92($4)
	lw	$2,32($4)
	subu	$3,$3,$6
	sll	$3,$3,1
	subu	$6,$6,$3
	subu	$5,$5,$7
	sll	$5,$5,1
	lw	$3,16($4)
	subu	$7,$7,$5
	sw	$6,8($4)
	sw	$7,12($4)
	subu	$2,$2,$3
	sll	$2,$2,1
	subu	$3,$3,$2
	.set	noreorder
	.set	nomacro
	j	.L197
	sw	$3,16($4)
	.set	macro
	.set	reorder

.L196:
	lw	$3,D_800A33F4
	la	$2,func_80053E9C
	sw	$2,92($3)
.L197:
	move	$4,$16
	.set	noreorder
	.set	nomacro
	jal	func_80052D00
	move	$5,$17
	.set	macro
	.set	reorder

	lw	$31,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,32
	j	$31
	.end	func_8005344C
.Lfe36:
	.size	 func_8005344C,.Lfe36-func_8005344C
	.align	2
	.globl	func_80053584
	.type	 func_80053584,@function
	.ent	func_80053584
func_80053584:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	la	$2,D_800EF9F8
	sw	$2,D_800A33F4
	lw	$2,D_800A33F4
	subu	$sp,$sp,24
	sw	$31,16($sp)
	la	$10,D_800EFA00
	lw	$3,0($4)
	lw	$8,4($4)
	lw	$9,8($4)
	sw	$3,0($10)
	sw	$8,4($10)
	sw	$9,8($10)
	lw	$3,12($4)
	sw	$3,12($10)
	lw	$3,0($5)
	lw	$4,4($5)
	lw	$8,8($5)
	lw	$9,12($5)
	sw	$3,24($2)
	sw	$4,28($2)
	sw	$8,32($2)
	sw	$9,36($2)
	la	$2,func_80053E9C
	move	$4,$6
	lw	$3,D_800A33F4
	move	$5,$7
	.set	noreorder
	.set	nomacro
	jal	func_80052D00
	sw	$2,92($3)
	.set	macro
	.set	reorder

	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80053584
.Lfe37:
	.size	 func_80053584,.Lfe37-func_80053584
	.align	2
	.globl	func_80053614
	.type	 func_80053614,@function
	.ent	func_80053614
func_80053614:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	lw	$2,40($sp)
	sw	$31,16($sp)
	sw	$2,D_800A33F4
	lw	$3,0($4)
	lw	$8,4($4)
	lw	$9,8($4)
	lw	$10,12($4)
	sw	$3,8($2)
	sw	$8,12($2)
	sw	$9,16($2)
	sw	$10,20($2)
	lw	$2,D_800A33F4
	#nop
	lw	$3,0($5)
	lw	$4,4($5)
	lw	$8,8($5)
	lw	$9,12($5)
	sw	$3,24($2)
	sw	$4,28($2)
	sw	$8,32($2)
	sw	$9,36($2)
	la	$2,func_80053E9C
	move	$4,$6
	lw	$3,D_800A33F4
	move	$5,$7
	.set	noreorder
	.set	nomacro
	jal	func_80052D00
	sw	$2,92($3)
	.set	macro
	.set	reorder

	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80053614
.Lfe38:
	.size	 func_80053614,.Lfe38-func_80053614
	.align	2
	.globl	func_80053694
	.type	 func_80053694,@function
	.ent	func_80053694
func_80053694:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$6,D_800A33F4
	li	$3,0x7fff0000		# 2147418112
	lw	$2,0($6)
	ori	$3,$3,0xffff
	.set	noreorder
	.set	nomacro
	beq	$2,$3,.L202
	move	$2,$0
	.set	macro
	.set	reorder

	lh	$3,72($6)
	#nop
	sll	$2,$3,5
	subu	$2,$2,$3
	sll	$2,$2,2
	addu	$2,$2,$3
	sll	$2,$2,4
	lw	$3,56($6)
	addu	$2,$2,-32000
	addu	$3,$3,$2
	sw	$3,0($4)
	lw	$2,60($6)
	#nop
	sw	$2,4($4)
	lh	$3,74($6)
	#nop
	sll	$2,$3,5
	subu	$2,$2,$3
	sll	$2,$2,2
	addu	$2,$2,$3
	sll	$2,$2,4
	lw	$3,64($6)
	addu	$2,$2,-32000
	addu	$3,$3,$2
	sw	$3,8($4)
	lw	$2,40($6)
	#nop
	sra	$2,$2,2
	sh	$2,0($5)
	lw	$2,44($6)
	#nop
	sra	$2,$2,2
	sh	$2,2($5)
	lw	$2,48($6)
	#nop
	sra	$2,$2,2
	sh	$2,4($5)
	lhu	$3,4($6)
	li	$2,0x00000001		# 1
	sh	$3,D_800A33F8
.L202:
	j	$31
	.end	func_80053694
.Lfe39:
	.size	 func_80053694,.Lfe39-func_80053694
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80053754.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80053E9C.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_80054410
	.type	 func_80054410,@function
	.ent	func_80054410
func_80054410:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	sw	$4,D_800A33F0
	j	$31
	.end	func_80054410
.Lfe40:
	.size	 func_80054410,.Lfe40-func_80054410
	.align	2
	.globl	func_8005441C
	.type	 func_8005441C,@function
	.ent	func_8005441C
func_8005441C:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$2,D_800A33F0
	#nop
	addu	$2,$2,$4
	sw	$2,D_800A33F0
	j	$31
	.end	func_8005441C
.Lfe41:
	.size	 func_8005441C,.Lfe41-func_8005441C
	.align	2
	.globl	func_80054434
	.type	 func_80054434,@function
	.ent	func_80054434
func_80054434:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lh	$2,D_800A33F8
	j	$31
	.end	func_80054434
.Lfe42:
	.size	 func_80054434,.Lfe42-func_80054434
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80054440.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_800545F4.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80054604.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_80054884
	.type	 func_80054884,@function
	.ent	func_80054884
func_80054884:
	.frame	$sp,40,$31		# vars= 0, regs= 1/0, args= 32, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	lw	$2,60($sp)
	lw	$3,64($sp)
	sll	$4,$4,1
	sw	$31,32($sp)
	lh	$4,InfoPosYTbl1($4)
	lw	$8,68($sp)
	addu	$4,$4,$5
	move	$5,$6
	move	$6,$7
	sw	$2,16($sp)
	sw	$3,20($sp)
	sw	$8,24($sp)
	lw	$7,56($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80054604
	addu	$4,$4,-305
	.set	macro
	.set	reorder

	lw	$31,32($sp)
	addu	$sp,$sp,40
	j	$31
	.end	func_80054884
.Lfe43:
	.size	 func_80054884,.Lfe43-func_80054884
	.align	2
	.globl	func_800548DC
	.type	 func_800548DC,@function
	.ent	func_800548DC
func_800548DC:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_8004659C
	li	$4,-1			# 0xffffffff
	.set	macro
	.set	reorder

	jal	snd_StopSelection
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_800548DC
.Lfe44:
	.size	 func_800548DC,.Lfe44-func_800548DC
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8005490C.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_80054F68
	.type	 func_80054F68,@function
	.ent	func_80054F68
func_80054F68:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	la	$2,D_80102C00
	sw	$2,D_800A3820
	lhu	$2,D_800A38D6
	lw	$3,D_800A374C
	subu	$sp,$sp,24
	sw	$31,20($sp)
	sw	$16,16($sp)
	addu	$2,$2,1
	sw	$3,D_800A3808
	addu	$3,$3,16
	sh	$2,D_800A38D6
	sw	$3,D_800A378C
	jal	func_8005490C
	.set	noreorder
	.set	nomacro
	jal	func_800444E0
	move	$16,$2
	.set	macro
	.set	reorder

	move	$2,$16
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80054F68
.Lfe45:
	.size	 func_80054F68,.Lfe45-func_80054F68
	.align	2
	.globl	func_80054FDC
	.type	 func_80054FDC,@function
	.ent	func_80054FDC
func_80054FDC:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	la	$2,D_800EFB14
	lw	$3,0($2)
	#nop
	addu	$3,$4,$3
	sw	$3,0($2)
	lw	$2,D_800EFB18
	lw	$3,D_800EFB1C
	addu	$2,$4,$2
	sw	$2,D_800EFB18
	.set	noreorder
	.set	nomacro
	beq	$3,$0,.L210
	addu	$2,$4,$3
	.set	macro
	.set	reorder

	sw	$2,D_800EFB1C
.L210:
	lw	$2,D_800EFB20
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L211
	addu	$2,$4,$2
	.set	macro
	.set	reorder

	sw	$2,D_800EFB20
.L211:
	lw	$2,D_800EFB24
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L212
	addu	$2,$4,$2
	.set	macro
	.set	reorder

	sw	$2,D_800EFB24
.L212:
	lw	$2,D_800EFB28
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L213
	addu	$2,$4,$2
	.set	macro
	.set	reorder

	sw	$2,D_800EFB28
.L213:
	j	$31
	.end	func_80054FDC
.Lfe46:
	.size	 func_80054FDC,.Lfe46-func_80054FDC
	.align	2
	.globl	func_8005507C
	.type	 func_8005507C,@function
	.ent	func_8005507C
func_8005507C:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	la	$2,D_800EFB0C
	j	$31
	.end	func_8005507C
.Lfe47:
	.size	 func_8005507C,.Lfe47-func_8005507C
	.align	2
	.globl	func_8005508C
	.type	 func_8005508C,@function
	.ent	func_8005508C
func_8005508C:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	la	$2,D_80101E1C
	j	$31
	.end	func_8005508C
.Lfe48:
	.size	 func_8005508C,.Lfe48-func_8005508C
	.align	2
	.globl	func_8005509C
	.type	 func_8005509C,@function
	.ent	func_8005509C
func_8005509C:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	move	$5,$0
	sll	$2,$4,4
	addu	$2,$2,$4
	sll	$2,$2,2
	addu	$2,$2,$4
	sll	$2,$2,2
	subu	$2,$2,$4
	sll	$2,$2,2
	la	$3,D_80101EC8
	addu	$3,$2,$3
.L217:
	sb	$0,1045($3)
	sb	$0,1044($3)
	addu	$5,$5,1
	slt	$2,$5,8
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L217
	addu	$3,$3,2
	.set	macro
	.set	reorder

	j	$31
	.end	func_8005509C
.Lfe49:
	.size	 func_8005509C,.Lfe49-func_8005509C
	.align	2
	.globl	func_800550E8
	.type	 func_800550E8,@function
	.ent	func_800550E8
func_800550E8:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	move	$5,$0
	sll	$2,$4,4
	addu	$2,$2,$4
	sll	$2,$2,2
	addu	$2,$2,$4
	sll	$2,$2,2
	subu	$2,$2,$4
	sll	$2,$2,2
	la	$3,D_80101EC8
	addu	$3,$2,$3
.L222:
	lbu	$2,1045($3)
	addu	$5,$5,1
	srl	$2,$2,1
	sb	$2,1045($3)
	slt	$2,$5,8
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L222
	addu	$3,$3,2
	.set	macro
	.set	reorder

	j	$31
	.end	func_800550E8
.Lfe50:
	.size	 func_800550E8,.Lfe50-func_800550E8
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80055138.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_80055948
	.type	 func_80055948,@function
	.ent	func_80055948
func_80055948:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lbu	$3,952($4)
	lw	$6,948($4)
	beq	$3,$0,.L227
	lh	$2,70($4)
	#nop
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L229
	addu	$2,$3,-1
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L229
	sb	$2,952($4)
	.set	macro
	.set	reorder

.L227:
	lbu	$2,956($4)
	#nop
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L231
	li	$2,0x00000016		# 22
	.set	macro
	.set	reorder

	lbu	$3,1091($4)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$3,$2,.L231
	sll	$2,$3,1
	.set	macro
	.set	reorder

	addu	$2,$2,$3
	sll	$2,$2,3
	lhu	$2,D_80099D88($2)
	#nop
	andi	$2,$2,0xbf00
	bne	$2,$0,.L231
	lw	$2,1072($4)
	#nop
	andi	$2,$2,0x0200
	beq	$2,$0,.L234
	lh	$2,1084($4)
	.set	noreorder
	.set	nomacro
	j	.L235
	slt	$2,$2,2049
	.set	macro
	.set	reorder

.L234:
	lh	$2,1084($4)
	#nop
	slt	$2,$2,1025
.L235:
	beq	$2,$0,.L237
	lw	$2,1072($4)
	#nop
	andi	$2,$2,0x0800
	bne	$2,$0,.L237
	lbu	$2,1061($4)
	#nop
	addu	$2,$2,-1
	sltu	$2,$2,2
	bne	$2,$0,.L237
	lbu	$2,1090($4)
	#nop
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L237
	li	$2,0x0000002d		# 45
	.set	macro
	.set	reorder

	lw	$5,0($4)
	#nop
	lhu	$3,106($5)
	#nop
	beq	$3,$2,.L237
	lh	$3,1038($4)
	lw	$2,244($5)
	#nop
	subu	$2,$2,$3
	mult	$2,$2
	lh	$3,1040($4)
	lw	$2,252($5)
	mflo	$7
	#nop
	subu	$2,$2,$3
	mult	$2,$2
	mflo	$3
	#nop
	lh	$2,1042($4)
	#nop
	mult	$2,$2
	addu	$2,$7,$3
	mflo	$5
	#nop
	#nop
	slt	$2,$5,$2
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L256
	li	$8,0x00000080		# 128
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L257
	sw	$0,948($4)
	.set	macro
	.set	reorder

.L231:
	lbu	$3,956($4)
	li	$2,0x00000001		# 1
	.set	noreorder
	.set	nomacro
	bne	$3,$2,.L256
	li	$8,0x00000080		# 128
	.set	macro
	.set	reorder

	lw	$2,1072($4)
	#nop
	andi	$2,$2,0x0800
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L249
	li	$7,0x00000001		# 1
	.set	macro
	.set	reorder

.L237:
	sw	$0,948($4)
.L257:
	.set	noreorder
	.set	nomacro
	j	.L255
	li	$2,-1			# 0xffffffff
	.set	macro
	.set	reorder

.L246:
	.set	noreorder
	.set	nomacro
	j	.L229
	sw	$0,948($4)
	.set	macro
	.set	reorder

.L256:
	li	$7,0x00000001		# 1
.L249:
	lbu	$3,0($6)
	#nop
	andi	$2,$3,0x0080
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L250
	addu	$6,$6,1
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	beq	$3,$8,.L246
	andi	$2,$3,0x007f
	.set	macro
	.set	reorder

	addu	$2,$2,-1
	sw	$6,948($4)
	.set	noreorder
	.set	nomacro
	j	.L229
	sb	$2,952($4)
	.set	macro
	.set	reorder

.L250:
	andi	$2,$3,0x000f
	sll	$5,$7,$2
	andi	$2,$3,0x0010
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L252
	nor	$3,$0,$5
	.set	macro
	.set	reorder

	lw	$2,968($4)
	#nop
	and	$2,$2,$3
	.set	noreorder
	.set	nomacro
	j	.L249
	sw	$2,968($4)
	.set	macro
	.set	reorder

.L252:
	lw	$2,968($4)
	#nop
	or	$2,$2,$5
	.set	noreorder
	.set	nomacro
	j	.L249
	sw	$2,968($4)
	.set	macro
	.set	reorder

.L229:
	lw	$2,968($4)
.L255:
	j	$31
	.end	func_80055948
.Lfe51:
	.size	 func_80055948,.Lfe51-func_80055948
	.align	2
	.globl	func_80055B44
	.type	 func_80055B44,@function
	.ent	func_80055B44
func_80055B44:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	li	$2,-1			# 0xffffffff
	sw	$5,948($4)
	sb	$6,956($4)
	sb	$7,952($4)
	sw	$0,968($4)
	.set	noreorder
	.set	nomacro
	j	$31
	sw	$2,972($4)
	.set	macro
	.set	reorder

	.end	func_80055B44
.Lfe52:
	.size	 func_80055B44,.Lfe52-func_80055B44
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80055B60.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80056CB8.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_80056FE8
	.type	 func_80056FE8,@function
	.ent	func_80056FE8
func_80056FE8:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$6,0($4)
	#nop
	lw	$2,88($6)
	#nop
	lbu	$3,3($2)
	#nop
	sll	$2,$3,2
	addu	$2,$2,$3
	sll	$5,$2,3
	lbu	$3,163($6)
	li	$2,0x000000ff		# 255
	beq	$3,$2,.L260
	lh	$2,94($4)
	#nop
	bne	$2,$0,.L261
	lh	$2,14($6)
	#nop
	lbu	$2,D_8009A830($2)
	.set	noreorder
	.set	nomacro
	j	.L265
	sll	$2,$2,1
	.set	macro
	.set	reorder

.L261:
	lh	$2,14($6)
	#nop
	lb	$2,D_8009A838($2)
	.set	noreorder
	.set	nomacro
	j	.L265
	sll	$2,$2,3
	.set	macro
	.set	reorder

.L260:
	lh	$2,20($6)
	#nop
	lbu	$2,D_8009A840($2)
	#nop
	sll	$2,$2,1
.L265:
	addu	$5,$5,$2
	lw	$2,0($4)
	#nop
	lh	$2,1034($2)
	#nop
	addu	$2,$5,$2
	.set	noreorder
	.set	nomacro
	j	$31
	addu	$2,$2,300
	.set	macro
	.set	reorder

	.end	func_80056FE8
.Lfe53:
	.size	 func_80056FE8,.Lfe53-func_80056FE8
	.align	2
	.globl	func_80057094
	.type	 func_80057094,@function
	.ent	func_80057094
func_80057094:
	.frame	$sp,48,$31		# vars= 8, regs= 5/0, args= 16, extra= 0
	.mask	0x800f0000,-8
	.fmask	0x00000000,0
	lw	$3,D_800F6608
	subu	$sp,$sp,48
	sw	$18,32($sp)
	move	$18,$4
	sw	$16,24($sp)
	move	$16,$5
	sw	$17,28($sp)
	move	$17,$6
	sw	$19,36($sp)
	move	$19,$7
	sw	$31,40($sp)
	lw	$4,244($18)
	lw	$2,D_800F6608+8
	lw	$5,252($18)
	subu	$4,$3,$4
	.set	noreorder
	.set	nomacro
	jal	ratan2
	subu	$5,$2,$5
	.set	macro
	.set	reorder

	lw	$4,244($18)
	lw	$5,252($18)
	subu	$4,$16,$4
	subu	$5,$17,$5
	.set	noreorder
	.set	nomacro
	jal	ratan2
	move	$16,$2
	.set	macro
	.set	reorder

	subu	$16,$16,$2
	addu	$16,$16,-256
	sra	$2,$16,9
	andi	$3,$2,0x0007
	.set	noreorder
	.set	nomacro
	bne	$19,$0,.L267
	sw	$3,16($sp)
	.set	macro
	.set	reorder

	andi	$2,$2,0x0001
	bne	$2,$0,.L267
	lhu	$2,1000($18)
	#nop
	andi	$2,$2,0x0010
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L268
	addu	$2,$3,1
	.set	macro
	.set	reorder

	sw	$2,16($sp)
	slt	$2,$2,8
	bne	$2,$0,.L267
	.set	noreorder
	.set	nomacro
	j	.L267
	sw	$0,16($sp)
	.set	macro
	.set	reorder

.L268:
	addu	$2,$3,-1
	.set	noreorder
	.set	nomacro
	bgez	$2,.L267
	sw	$2,16($sp)
	.set	macro
	.set	reorder

	li	$2,0x00000007		# 7
	sw	$2,16($sp)
.L267:
	lw	$2,16($sp)
	#nop
	andi	$2,$2,0x0007
	sll	$2,$2,2
	lw	$16,D_8009AA50($2)
	li	$2,0x00000001		# 1
	.set	noreorder
	.set	nomacro
	bne	$19,$2,.L274
	move	$4,$18
	.set	macro
	.set	reorder

	ori	$16,$16,0x0004
.L274:
	.set	noreorder
	.set	nomacro
	jal	func_800233AC
	addu	$5,$sp,16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L275
	move	$2,$16
	.set	macro
	.set	reorder

	ori	$16,$16,0x0008
	move	$2,$16
.L275:
	lw	$31,40($sp)
	lw	$19,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,48
	j	$31
	.end	func_80057094
.Lfe54:
	.size	 func_80057094,.Lfe54-func_80057094
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_800571C0.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8005763C.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80057ACC.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80057CC8.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80057E84.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80058580.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_8005B43C
	.type	 func_8005B43C,@function
	.ent	func_8005B43C
func_8005B43C:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	move	$5,$0
	la	$4,D_800EFB38
	la	$3,D_800EFC38
.L277:
	sw	$0,0($3)
	sw	$0,0($4)
	addu	$4,$4,4
	addu	$5,$5,1
	slt	$2,$5,16
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L277
	addu	$3,$3,4
	.set	macro
	.set	reorder

	jal	SsInit
	.set	noreorder
	.set	nomacro
	jal	func_800858D0
	move	$4,$0
	.set	macro
	.set	reorder

	jal	SsUtReverbOff
	.set	noreorder
	.set	nomacro
	jal	SsUtSetReverbType
	move	$4,$0
	.set	macro
	.set	reorder

	move	$4,$0
	.set	noreorder
	.set	nomacro
	jal	SsUtSetReverbDepth
	move	$5,$0
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	SsSetReservedVoice
	move	$4,$0
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	SsSetTickMode
	li	$4,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$5,0x0000007f		# 127
	la	$4,D_800EFB78
	move	$3,$0
.L281:
	sw	$0,D_800EFB78($3)
	sb	$5,5($4)
	sb	$5,D_800EFB7C($3)
	addu	$3,$3,8
	slt	$2,$3,192
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L281
	addu	$4,$4,8
	.set	macro
	.set	reorder

	jal	SsStart
	sw	$0,D_800A3408
	sh	$0,D_800A3400
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_8005B43C
.Lfe55:
	.size	 func_8005B43C,.Lfe55-func_8005B43C
	.align	2
	.globl	func_8005B50C
	.type	 func_8005B50C,@function
	.ent	func_8005B50C
func_8005B50C:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_800858D0
	move	$4,$0
	.set	macro
	.set	reorder

	jal	SsUtReverbOff
	.set	noreorder
	.set	nomacro
	jal	SsUtSetReverbType
	move	$4,$0
	.set	macro
	.set	reorder

	move	$4,$0
	.set	noreorder
	.set	nomacro
	jal	SsUtSetReverbDepth
	move	$5,$0
	.set	macro
	.set	reorder

	jal	SsEnd
	jal	SsQuit
	move	$5,$0
	la	$4,D_800EFB38
	la	$3,D_800EFC38
.L286:
	sw	$0,0($3)
	sw	$0,0($4)
	addu	$4,$4,4
	addu	$5,$5,1
	slt	$2,$5,16
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L286
	addu	$3,$3,4
	.set	macro
	.set	reorder

	sw	$0,D_800A3408
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_8005B50C
.Lfe56:
	.size	 func_8005B50C,.Lfe56-func_8005B50C
	.align	2
	.globl	func_8005B58C
	.type	 func_8005B58C,@function
	.ent	func_8005B58C
func_8005B58C:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_800858D0
	move	$4,$0
	.set	macro
	.set	reorder

	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_8005B58C
.Lfe57:
	.size	 func_8005B58C,.Lfe57-func_8005B58C
	.align	2
	.globl	obj_InitChars
	.type	 obj_InitChars,@function
	.ent	obj_InitChars
obj_InitChars:
	.frame	$sp,40,$31		# vars= 0, regs= 5/0, args= 16, extra= 0
	.mask	0x800f0000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	move	$4,$0
	sw	$31,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	.set	noreorder
	.set	nomacro
	jal	func_800858D0
	sw	$16,16($sp)
	.set	macro
	.set	reorder

	move	$17,$0
	li	$19,0x0000007f		# 127
	la	$18,D_800EFB78
	move	$16,$0
.L292:
	sll	$4,$17,16
	sra	$4,$4,16
	move	$5,$0
	sw	$0,D_800EFB78($16)
	sb	$19,5($18)
	sb	$19,D_800EFB7C($16)
	.set	noreorder
	.set	nomacro
	jal	func_80086130
	move	$6,$0
	.set	macro
	.set	reorder

	addu	$18,$18,8
	addu	$17,$17,1
	slt	$2,$17,24
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L292
	addu	$16,$16,8
	.set	macro
	.set	reorder

	lw	$31,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,40
	j	$31
	.end	obj_InitChars
.Lfe58:
	.size	 obj_InitChars,.Lfe58-obj_InitChars
	.align	2
	.globl	func_8005B644
	.type	 func_8005B644,@function
	.ent	func_8005B644
func_8005B644:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	sw	$16,16($sp)
	move	$16,$4
	move	$4,$0
	sw	$31,24($sp)
	.set	noreorder
	.set	nomacro
	jal	func_800858D0
	sw	$17,20($sp)
	.set	macro
	.set	reorder

	sll	$17,$16,1
	addu	$17,$17,$16
	addu	$17,$17,1
	sll	$4,$17,16
	.set	noreorder
	.set	nomacro
	jal	SsVabClose
	sra	$4,$4,16
	.set	macro
	.set	reorder

	sll	$17,$17,2
	sw	$0,D_800EFC38($17)
	sw	$0,D_800EFB38($17)
	lw	$31,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,32
	j	$31
	.end	func_8005B644
.Lfe59:
	.size	 func_8005B644,.Lfe59-func_8005B644
	.align	2
	.globl	func_8005B6AC
	.type	 func_8005B6AC,@function
	.ent	func_8005B6AC
func_8005B6AC:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_800858D0
	move	$4,$0
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	SsVabClose
	li	$4,0x00000002		# 2
	.set	macro
	.set	reorder

	sw	$0,D_800EFC40
	sw	$0,D_800EFB40
	.set	noreorder
	.set	nomacro
	jal	SsVabClose
	li	$4,0x00000005		# 5
	.set	macro
	.set	reorder

	sw	$0,D_800EFC4C
	sw	$0,D_800EFB4C
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_8005B6AC
.Lfe60:
	.size	 func_8005B6AC,.Lfe60-func_8005B6AC
	.align	2
	.globl	func_8005B6FC
	.type	 func_8005B6FC,@function
	.ent	func_8005B6FC
func_8005B6FC:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	SsVabClose
	li	$4,0x00000001		# 1
	.set	macro
	.set	reorder

	sw	$0,D_800EFC3C
	sw	$0,D_800EFB3C
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_8005B6FC
.Lfe61:
	.size	 func_8005B6FC,.Lfe61-func_8005B6FC
	.align	2
	.globl	obj_InitAll
	.type	 obj_InitAll,@function
	.ent	obj_InitAll
obj_InitAll:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, extra= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	move	$4,$0
	sw	$31,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	.set	noreorder
	.set	nomacro
	jal	func_800858D0
	sw	$16,16($sp)
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	SsUtReverbOff
	li	$16,0x00000001		# 1
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	SsUtSetReverbType
	move	$4,$0
	.set	macro
	.set	reorder

	move	$4,$0
	.set	noreorder
	.set	nomacro
	jal	SsUtSetReverbDepth
	move	$5,$0
	.set	macro
	.set	reorder

	la	$18,D_800EFB3C
	la	$17,D_800EFC3C
.L303:
	sll	$4,$16,16
	.set	noreorder
	.set	nomacro
	jal	SsVabClose
	sra	$4,$4,16
	.set	macro
	.set	reorder

	sw	$0,0($17)
	sw	$0,0($18)
	addu	$18,$18,4
	addu	$16,$16,1
	slt	$2,$16,16
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L303
	addu	$17,$17,4
	.set	macro
	.set	reorder

	sw	$0,D_800A3408
	jal	obj_InitChars
	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,32
	j	$31
	.end	obj_InitAll
.Lfe62:
	.size	 obj_InitAll,.Lfe62-obj_InitAll
	.align	2
	.globl	func_8005B7C4
	.type	 func_8005B7C4,@function
	.ent	func_8005B7C4
func_8005B7C4:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	sw	$17,20($sp)
	move	$17,$4
	move	$4,$0
	sw	$31,24($sp)
	.set	noreorder
	.set	nomacro
	jal	func_800858D0
	sw	$16,16($sp)
	.set	macro
	.set	reorder

	la	$4,D_800158B4
	.set	noreorder
	.set	nomacro
	jal	printf
	move	$5,$17
	.set	macro
	.set	reorder

	jal	game_FrameLoop
	li	$4,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	jal	func_80036EA8
	li	$5,0x00000001		# 1
	.set	macro
	.set	reorder

	move	$16,$2
	move	$4,$16
	.set	noreorder
	.set	nomacro
	jal	replay_camera_Init
	move	$5,$17
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_80036F28
	move	$4,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	game_FrameLoop
	move	$16,$2
	.set	macro
	.set	reorder

	move	$4,$17
	move	$5,$0
	li	$2,0x00001010		# 4112
	sw	$0,D_800A3408
	sw	$2,D_800A340C
	sw	$2,D_800A3404
	.set	noreorder
	.set	nomacro
	jal	func_8005C2A8
	addu	$6,$4,$16
	.set	macro
	.set	reorder

	lw	$3,D_800A3404
	#nop
	sw	$3,D_800A340C
	lw	$31,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,32
	j	$31
	.end	func_8005B7C4
.Lfe63:
	.size	 func_8005B7C4,.Lfe63-func_8005B7C4
	.align	2
	.globl	obj_InitPair
	.type	 obj_InitPair,@function
	.ent	obj_InitPair
obj_InitPair:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_800858D0
	move	$4,$0
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	SsVabClose
	li	$4,0x00000008		# 8
	.set	macro
	.set	reorder

	sw	$0,D_800EFC58
	sw	$0,D_800EFB58
	.set	noreorder
	.set	nomacro
	jal	SsVabClose
	li	$4,0x00000004		# 4
	.set	macro
	.set	reorder

	sw	$0,D_800EFC48
	sw	$0,D_800EFB48
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	obj_InitPair
.Lfe64:
	.size	 obj_InitPair,.Lfe64-obj_InitPair
	.align	2
	.globl	func_8005B8B8
	.type	 func_8005B8B8,@function
	.ent	func_8005B8B8
func_8005B8B8:
	.frame	$sp,40,$31		# vars= 0, regs= 5/0, args= 16, extra= 0
	.mask	0x800f0000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	sw	$19,28($sp)
	move	$19,$4
	sw	$31,32($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	.set	noreorder
	.set	nomacro
	jal	obj_InitPair
	sw	$16,16($sp)
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_800858D0
	move	$4,$0
	.set	macro
	.set	reorder

	li	$4,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	jal	func_80036EA8
	li	$5,0x0000005d		# 93
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	game_FrameLoop
	move	$16,$2
	.set	macro
	.set	reorder

	move	$4,$16
	.set	noreorder
	.set	nomacro
	jal	replay_camera_Init
	move	$5,$19
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_80036F28
	move	$4,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	game_FrameLoop
	move	$17,$2
	.set	macro
	.set	reorder

	move	$4,$19
	li	$5,0x00000008		# 8
	.set	noreorder
	.set	nomacro
	jal	func_8005C2A8
	addu	$6,$19,$17
	.set	macro
	.set	reorder

	li	$4,0x00000002		# 2
	li	$5,0x0000005e		# 94
	.set	noreorder
	.set	nomacro
	jal	func_80036EA8
	move	$16,$2
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	game_FrameLoop
	move	$17,$2
	.set	macro
	.set	reorder

	move	$4,$17
	addu	$18,$19,$16
	.set	noreorder
	.set	nomacro
	jal	replay_camera_Init
	move	$5,$18
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_80036F28
	move	$4,$17
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	game_FrameLoop
	addu	$17,$2,$16
	.set	macro
	.set	reorder

	move	$4,$18
	li	$5,0x00000004		# 4
	.set	noreorder
	.set	nomacro
	jal	func_8005C2A8
	addu	$6,$19,$17
	.set	macro
	.set	reorder

	addu	$2,$2,$16
	lw	$31,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,40
	j	$31
	.end	func_8005B8B8
.Lfe65:
	.size	 func_8005B8B8,.Lfe65-func_8005B8B8
	.align	2
	.globl	func_8005B98C
	.type	 func_8005B98C,@function
	.ent	func_8005B98C
func_8005B98C:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$16,16($sp)
	move	$16,$4
	sw	$31,20($sp)
	.set	noreorder
	.set	nomacro
	jal	func_8005C4C0
	li	$5,0x00000008		# 8
	.set	macro
	.set	reorder

	move	$4,$16
	.set	noreorder
	.set	nomacro
	jal	func_8005C4C0
	li	$5,0x00000004		# 4
	.set	macro
	.set	reorder

	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_8005B98C
.Lfe66:
	.size	 func_8005B98C,.Lfe66-func_8005B98C
	.align	2
	.globl	obj_InitTask
	.type	 obj_InitTask,@function
	.ent	obj_InitTask
obj_InitTask:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_800858D0
	move	$4,$0
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	SsVabClose
	li	$4,0x00000009		# 9
	.set	macro
	.set	reorder

	sw	$0,D_800EFC5C
	sw	$0,D_800EFB5C
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	obj_InitTask
.Lfe67:
	.size	 obj_InitTask,.Lfe67-obj_InitTask
	.align	2
	.globl	obj_InitTaskCamera
	.type	 obj_InitTaskCamera,@function
	.ent	obj_InitTaskCamera
obj_InitTaskCamera:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	sw	$16,16($sp)
	move	$16,$4
	sw	$31,24($sp)
	.set	noreorder
	.set	nomacro
	jal	obj_InitTask
	sw	$17,20($sp)
	.set	macro
	.set	reorder

	li	$4,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	jal	func_80036EA8
	li	$5,0x00000008		# 8
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	game_FrameLoop
	move	$17,$2
	.set	macro
	.set	reorder

	move	$4,$17
	.set	noreorder
	.set	nomacro
	jal	replay_camera_Init
	move	$5,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_80036F28
	move	$4,$17
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	game_FrameLoop
	move	$17,$2
	.set	macro
	.set	reorder

	move	$4,$16
	li	$5,0x00000009		# 9
	.set	noreorder
	.set	nomacro
	jal	func_8005C2A8
	addu	$6,$4,$17
	.set	macro
	.set	reorder

	lw	$31,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,32
	j	$31
	.end	obj_InitTaskCamera
.Lfe68:
	.size	 obj_InitTaskCamera,.Lfe68-obj_InitTaskCamera
	.align	2
	.globl	obj_ExecTask
	.type	 obj_ExecTask,@function
	.ent	obj_ExecTask
obj_ExecTask:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_8005C4C0
	li	$5,0x00000009		# 9
	.set	macro
	.set	reorder

	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	obj_ExecTask
.Lfe69:
	.size	 obj_ExecTask,.Lfe69-obj_ExecTask
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8005BA8C.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_8005BD30
	.type	 func_8005BD30,@function
	.ent	func_8005BD30
func_8005BD30:
	.frame	$sp,40,$31		# vars= 0, regs= 5/0, args= 16, extra= 0
	.mask	0x800f0000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	sw	$19,28($sp)
	move	$19,$4
	move	$4,$0
	sw	$31,32($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	.set	noreorder
	.set	nomacro
	jal	func_800858D0
	sw	$16,16($sp)
	.set	macro
	.set	reorder

	lw	$3,D_800EFC50
	lw	$2,D_800EFC44
	#nop
	.set	noreorder
	.set	nomacro
	bne	$3,$2,.L313
	li	$17,0x00000003		# 3
	.set	macro
	.set	reorder

	li	$17,0x00000002		# 2
.L313:
	andi	$2,$17,0x00ff
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L315
	move	$16,$0
	.set	macro
	.set	reorder

	move	$18,$2
	move	$4,$19
.L321:
	andi	$2,$16,0x00ff
	lbu	$5,D_8009AD18($2)
	.set	noreorder
	.set	nomacro
	jal	func_8005C4C0
	addu	$16,$16,1
	.set	macro
	.set	reorder

	andi	$2,$16,0x00ff
	sltu	$2,$2,$18
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L321
	move	$4,$19
	.set	macro
	.set	reorder

.L315:
	andi	$3,$17,0x00ff
	li	$2,0x00000002		# 2
	bne	$3,$2,.L320
	lw	$2,D_800EFC44
	#nop
	sw	$2,D_800EFC50
.L320:
	lw	$31,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,40
	j	$31
	.end	func_8005BD30
.Lfe70:
	.size	 func_8005BD30,.Lfe70-func_8005BD30
	.align	2
	.globl	func_8005BDF0
	.type	 func_8005BDF0,@function
	.ent	func_8005BDF0
func_8005BDF0:
	.frame	$sp,40,$31		# vars= 0, regs= 5/0, args= 16, extra= 0
	.mask	0x800f0000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	sw	$19,28($sp)
	la	$19,D_800EFC38
	sw	$18,24($sp)
	la	$18,D_800EFB38
	sw	$16,16($sp)
	la	$16,D_8009AD18
	sw	$17,20($sp)
	addu	$17,$16,3
	sw	$31,32($sp)
.L323:
	lbu	$4,0($16)
	jal	SsVabClose
	lbu	$2,0($16)
	#nop
	sll	$2,$2,2
	addu	$2,$2,$19
	sw	$0,0($2)
	lbu	$2,0($16)
	addu	$16,$16,1
	sll	$2,$2,2
	addu	$2,$2,$18
	sw	$0,0($2)
	slt	$2,$16,$17
	bne	$2,$0,.L323
	lw	$31,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,40
	j	$31
	.end	func_8005BDF0
.Lfe71:
	.size	 func_8005BDF0,.Lfe71-func_8005BDF0
	.align	2
	.globl	func_8005BE84
	.type	 func_8005BE84,@function
	.ent	func_8005BE84
func_8005BE84:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	sw	$16,16($sp)
	move	$16,$4
	move	$4,$0
	sw	$31,24($sp)
	.set	noreorder
	.set	nomacro
	jal	func_800858D0
	sw	$17,20($sp)
	.set	macro
	.set	reorder

	la	$3,D_8009AD1C
	sll	$2,$16,2
	addu	$17,$2,$3
	lh	$2,0($17)
	#nop
	.set	noreorder
	.set	nomacro
	bltz	$2,.L328
	sll	$16,$16,1
	.set	macro
	.set	reorder

	jal	SsUtReverbOff
	.set	noreorder
	.set	nomacro
	jal	SsUtSetReverbType
	move	$4,$0
	.set	macro
	.set	reorder

	move	$4,$0
	.set	noreorder
	.set	nomacro
	jal	SsUtSetReverbDepth
	move	$5,$0
	.set	macro
	.set	reorder

	lh	$4,0($17)
	jal	SsUtSetReverbType
	lh	$4,0($17)
	.set	noreorder
	.set	nomacro
	jal	SpuClearReverbWorkArea
	move	$17,$2
	.set	macro
	.set	reorder

	addu	$4,$16,1
	sll	$4,$4,16
	sra	$4,$4,16
	.set	noreorder
	.set	nomacro
	jal	SsUtSetReverbDepth
	move	$5,$4
	.set	macro
	.set	reorder

	jal	SsUtReverbOn
	.set	noreorder
	.set	nomacro
	j	.L330
	sll	$2,$17,16
	.set	macro
	.set	reorder

.L328:
	li	$17,-1			# 0xffffffff
	sll	$2,$17,16
.L330:
	sra	$2,$2,16
	lw	$31,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,32
	j	$31
	.end	func_8005BE84
.Lfe72:
	.size	 func_8005BE84,.Lfe72-func_8005BE84
	.align	2
	.globl	obj_Reset
	.type	 obj_Reset,@function
	.ent	obj_Reset
obj_Reset:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_800858D0
	move	$4,$0
	.set	macro
	.set	reorder

	jal	SsUtReverbOff
	.set	noreorder
	.set	nomacro
	jal	SsUtSetReverbType
	move	$4,$0
	.set	macro
	.set	reorder

	move	$4,$0
	.set	noreorder
	.set	nomacro
	jal	SsUtSetReverbDepth
	move	$5,$0
	.set	macro
	.set	reorder

	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	obj_Reset
.Lfe73:
	.size	 obj_Reset,.Lfe73-obj_Reset
	.align	2
	.globl	func_8005BF78
	.type	 func_8005BF78,@function
	.ent	func_8005BF78
func_8005BF78:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, extra= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	sw	$20,32($sp)
	move	$20,$4
	sw	$18,24($sp)
	move	$18,$5
	sw	$19,28($sp)
	move	$19,$6
	sw	$16,16($sp)
	move	$16,$7
	move	$4,$0
	sw	$31,36($sp)
	.set	noreorder
	.set	nomacro
	jal	func_800858D0
	sw	$17,20($sp)
	.set	macro
	.set	reorder

	sll	$17,$18,16
	sra	$17,$17,16
	.set	noreorder
	.set	nomacro
	jal	SsVabClose
	move	$4,$17
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	SpuSetTransferStartAddr
	move	$4,$16
	.set	macro
	.set	reorder

	la	$16,D_800EFC38
	sll	$18,$18,2
	addu	$16,$18,$16
	lw	$2,0($16)
	#nop
	lw	$5,12($2)
	.set	noreorder
	.set	nomacro
	jal	SpuRead
	move	$4,$20
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	SpuIsTransferCompleted
	li	$4,0x00000001		# 1
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	SpuSetTransferStartAddr
	move	$4,$19
	.set	macro
	.set	reorder

	lw	$2,0($16)
	#nop
	lw	$5,12($2)
	.set	noreorder
	.set	nomacro
	jal	SpuWrite
	move	$4,$20
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	SpuIsTransferCompleted
	li	$4,0x00000001		# 1
	.set	macro
	.set	reorder

	lw	$2,0($16)
	move	$5,$17
	lw	$4,4($2)
	.set	noreorder
	.set	nomacro
	jal	SsVabFakeHead
	move	$6,$19
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	SsVabFakeBody
	move	$4,$17
	.set	macro
	.set	reorder

	sw	$19,D_800EFB38($18)
	lw	$2,0($16)
	#nop
	lw	$2,12($2)
	#nop
	addu	$2,$19,$2
	lw	$31,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,40
	j	$31
	.end	func_8005BF78
.Lfe74:
	.size	 func_8005BF78,.Lfe74-func_8005BF78
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8005C074.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8005C2A8.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_8005C4C0
	.type	 func_8005C4C0,@function
	.ent	func_8005C4C0
func_8005C4C0:
	.frame	$sp,40,$31		# vars= 0, regs= 5/0, args= 16, extra= 0
	.mask	0x800f0000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	sw	$17,20($sp)
	move	$17,$4
	sw	$16,16($sp)
	move	$16,$5
	move	$4,$0
	sw	$31,32($sp)
	sw	$19,28($sp)
	.set	noreorder
	.set	nomacro
	jal	func_800858D0
	sw	$18,24($sp)
	.set	macro
	.set	reorder

	sll	$16,$16,16
	sra	$18,$16,16
	la	$2,D_800EFC38
	sll	$19,$18,2
	addu	$16,$19,$2
	lw	$3,0($16)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$3,$0,.L334
	addu	$3,$3,$17
	.set	macro
	.set	reorder

	sw	$3,0($16)
	lw	$2,0($3)
	#nop
	addu	$2,$2,$17
	sw	$2,0($3)
	lw	$3,0($16)
	#nop
	lw	$2,4($3)
	move	$4,$18
	addu	$2,$2,$17
	.set	noreorder
	.set	nomacro
	jal	SsVabClose
	sw	$2,4($3)
	.set	macro
	.set	reorder

	lw	$2,0($16)
	lw	$6,D_800EFB38($19)
	lw	$4,4($2)
	.set	noreorder
	.set	nomacro
	jal	SsVabFakeHead
	move	$5,$18
	.set	macro
	.set	reorder

	sll	$2,$2,16
	sra	$2,$2,16
	bne	$2,$18,.L337
	.set	noreorder
	.set	nomacro
	jal	SsVabFakeBody
	move	$4,$2
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L338
	sll	$2,$2,16
	.set	macro
	.set	reorder

.L334:
	li	$2,-1			# 0xffffffff
	sll	$2,$2,16
.L338:
	sra	$2,$2,16
.L337:
	lw	$31,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,40
	j	$31
	.end	func_8005C4C0
.Lfe75:
	.size	 func_8005C4C0,.Lfe75-func_8005C4C0
	.align	2
	.globl	func_8005C5A8
	.type	 func_8005C5A8,@function
	.ent	func_8005C5A8
func_8005C5A8:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	sw	$17,20($sp)
	move	$17,$4
	sw	$16,16($sp)
	sll	$16,$5,16
	sra	$16,$16,16
	sw	$31,24($sp)
	.set	noreorder
	.set	nomacro
	jal	SsVabClose
	move	$4,$16
	.set	macro
	.set	reorder

	lw	$4,4($17)
	lw	$6,D_800A3404
	.set	noreorder
	.set	nomacro
	jal	SsVabOpenHeadSticky
	move	$5,$16
	.set	macro
	.set	reorder

	lw	$2,4($17)
	#nop
	sw	$16,8($2)
	lw	$4,8($17)
	.set	noreorder
	.set	nomacro
	jal	SsVabTransBody
	move	$5,$16
	.set	macro
	.set	reorder

	sll	$2,$2,16
	sra	$2,$2,16
	lw	$31,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,32
	j	$31
	.end	func_8005C5A8
.Lfe76:
	.size	 func_8005C5A8,.Lfe76-func_8005C5A8
	.align	2
	.globl	func_8005C614
	.type	 func_8005C614,@function
	.ent	func_8005C614
func_8005C614:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	li	$4,0x0000007f		# 127
	.set	noreorder
	.set	nomacro
	jal	SsSetMVol
	li	$5,0x0000007f		# 127
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_800858D0
	move	$4,$0
	.set	macro
	.set	reorder

	jal	SsSetStereo
	.set	noreorder
	.set	nomacro
	jal	SsSetAutoKeyOffMode
	move	$4,$0
	.set	macro
	.set	reorder

	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_8005C614
.Lfe77:
	.size	 func_8005C614,.Lfe77-func_8005C614
	.align	2
	.globl	func_8005C650
	.type	 func_8005C650,@function
	.ent	func_8005C650
func_8005C650:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	move	$7,$0
	sll	$4,$4,2
	la	$2,D_8009AA70
	addu	$4,$4,$2
	sll	$2,$7,16
.L347:
	sra	$3,$2,13
	lw	$2,D_800EFB78($3)
	#nop
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L345
	addu	$2,$7,1
	.set	macro
	.set	reorder

	sw	$4,D_800EFB78($3)
	sb	$5,D_800EFB7C($3)
	sb	$6,D_800EFB7D($3)
	j	.L341
.L345:
	move	$7,$2
	sll	$2,$2,16
	sra	$2,$2,16
	slt	$2,$2,24
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L347
	sll	$2,$7,16
	.set	macro
	.set	reorder

.L341:
	j	$31
	.end	func_8005C650
.Lfe78:
	.size	 func_8005C650,.Lfe78-func_8005C650
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8005C6D0.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8005C8A8.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_8005D46C
	.type	 func_8005D46C,@function
	.ent	func_8005D46C
func_8005D46C:
	.frame	$sp,88,$31		# vars= 48, regs= 5/0, args= 16, extra= 0
	.mask	0x800f0000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,88
	move	$3,$4
	move	$2,$5
	sw	$31,80($sp)
	sw	$19,76($sp)
	sw	$18,72($sp)
	sw	$17,68($sp)
	.set	noreorder
	.set	nomacro
	blez	$2,.L349
	sw	$16,64($sp)
	.set	macro
	.set	reorder

	addu	$2,$2,-1
.L349:
	addu	$4,$sp,16
	move	$5,$0
	sll	$16,$2,4
	subu	$16,$16,$2
	sll	$16,$16,2
	la	$17,D_8009B2C8
	addu	$2,$16,$17
	sw	$2,16($sp)
	la	$2,D_8009B340
	li	$18,0x00000100		# 256
	li	$19,0x00000001		# 1
	sb	$0,56($sp)
	sw	$2,20($sp)
	sw	$18,52($sp)
	sw	$18,48($sp)
	sw	$0,44($sp)
	sw	$0,40($sp)
	sw	$0,32($sp)
	sw	$19,36($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80073728
	sw	$3,28($sp)
	.set	macro
	.set	reorder

	addu	$4,$sp,16
	move	$5,$0
	addu	$17,$17,12
	addu	$16,$16,$17
	la	$3,D_8009B358
	sb	$0,56($sp)
	sw	$16,16($sp)
	sw	$3,20($sp)
	sw	$18,52($sp)
	sw	$18,48($sp)
	sw	$0,44($sp)
	sw	$0,40($sp)
	sw	$0,32($sp)
	sw	$19,36($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80073728
	sw	$2,28($sp)
	.set	macro
	.set	reorder

	lw	$31,80($sp)
	lw	$19,76($sp)
	lw	$18,72($sp)
	lw	$17,68($sp)
	lw	$16,64($sp)
	addu	$sp,$sp,88
	j	$31
	.end	func_8005D46C
.Lfe79:
	.size	 func_8005D46C,.Lfe79-func_8005D46C
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8005D554.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8005D814.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8005E098.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_8005E51C
	.type	 func_8005E51C,@function
	.ent	func_8005E51C
func_8005E51C:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	move	$2,$5
	move	$7,$6
	addu	$5,$4,-1
	li	$4,-1			# 0xffffffff
	.set	noreorder
	.set	nomacro
	jal	func_8005E098
	move	$6,$2
	.set	macro
	.set	reorder

	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_8005E51C
.Lfe80:
	.size	 func_8005E51C,.Lfe80-func_8005E51C
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8005E54C.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8005F1C8.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_8005FA98
	.type	 func_8005FA98,@function
	.ent	func_8005FA98
func_8005FA98:
	.frame	$sp,80,$31		# vars= 48, regs= 4/0, args= 16, extra= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,80
	sw	$16,64($sp)
	move	$16,$4
	sw	$17,68($sp)
	move	$17,$5
	li	$2,0x00000200		# 512
	sw	$2,48($sp)
	li	$2,0x00000100		# 256
	sw	$2,52($sp)
	sll	$2,$16,1
	addu	$2,$2,$16
	sll	$2,$2,2
	la	$3,D_8009B63C
	addu	$2,$2,$3
	move	$3,$17
	sw	$18,72($sp)
	addu	$18,$17,400
	sw	$2,16($sp)
	li	$2,0x00000001		# 1
	sw	$31,76($sp)
	sb	$0,56($sp)
	sw	$0,44($sp)
	sw	$0,40($sp)
	sw	$0,32($sp)
	.set	noreorder
	.set	nomacro
	beq	$16,$2,.L354
	sw	$6,36($sp)
	.set	macro
	.set	reorder

	slt	$2,$16,2
	beq	$2,$0,.L358
	.set	noreorder
	.set	nomacro
	beq	$16,$0,.L353
	addu	$4,$sp,16
	.set	macro
	.set	reorder

	j	.L360
.L358:
	li	$2,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	beq	$16,$2,.L355
	addu	$4,$sp,16
	.set	macro
	.set	reorder

	j	.L360
.L353:
	la	$2,D_8009B660
	.set	noreorder
	.set	nomacro
	j	.L361
	sw	$2,20($sp)
	.set	macro
	.set	reorder

.L354:
	la	$2,D_8009B670
	.set	noreorder
	.set	nomacro
	j	.L361
	sw	$2,20($sp)
	.set	macro
	.set	reorder

.L355:
	la	$2,D_8009B678
	sw	$2,20($sp)
.L361:
	addu	$4,$sp,16
.L360:
	move	$5,$0
	.set	noreorder
	.set	nomacro
	jal	func_80073728
	sw	$3,28($sp)
	.set	macro
	.set	reorder

	addu	$4,$sp,16
	move	$5,$0
	sll	$3,$16,1
	addu	$3,$3,$16
	sll	$3,$3,2
	la	$6,D_8009B610
	addu	$3,$3,$6
	sw	$3,16($sp)
	la	$3,D_8009B634
	sw	$3,20($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80073728
	sw	$2,28($sp)
	.set	macro
	.set	reorder

	subu	$2,$18,$17
	lw	$31,76($sp)
	lw	$18,72($sp)
	lw	$17,68($sp)
	lw	$16,64($sp)
	addu	$sp,$sp,80
	j	$31
	.end	func_8005FA98
.Lfe81:
	.size	 func_8005FA98,.Lfe81-func_8005FA98
	.align	2
	.globl	func_8005FBC8
	.type	 func_8005FBC8,@function
	.ent	func_8005FBC8
func_8005FBC8:
	.frame	$sp,48,$31		# vars= 16, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,48
	sw	$17,36($sp)
	move	$17,$5
	addu	$5,$4,51
	li	$4,0x00000002		# 2
	sw	$31,40($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80036EA8
	sw	$16,32($sp)
	.set	macro
	.set	reorder

	move	$16,$2
	move	$4,$16
	.set	noreorder
	.set	nomacro
	jal	replay_camera_Init
	move	$5,$17
	.set	macro
	.set	reorder

	jal	game_FrameLoop
	.set	noreorder
	.set	nomacro
	jal	func_80036F28
	move	$4,$16
	.set	macro
	.set	reorder

	la	$5,D_800A327C
	lwl	$2,3($5)
	lwr	$2,0($5)
	lwl	$3,7($5)
	lwr	$3,4($5)
	swl	$2,19($sp)
	swr	$2,16($sp)
	swl	$3,23($sp)
	swr	$3,20($sp)
	la	$5,D_800A3284
	lwl	$2,3($5)
	lwr	$2,0($5)
	lwl	$3,7($5)
	lwr	$3,4($5)
	swl	$2,27($sp)
	swr	$2,24($sp)
	swl	$3,31($sp)
	swr	$3,28($sp)
	addu	$4,$sp,16
	.set	noreorder
	.set	nomacro
	jal	LoadImage
	addu	$5,$17,64
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	addu	$4,$sp,24
	.set	noreorder
	.set	nomacro
	jal	LoadImage
	addu	$5,$17,20
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	sw	$0,D_800A3278
	lw	$31,40($sp)
	lw	$17,36($sp)
	lw	$16,32($sp)
	addu	$sp,$sp,48
	j	$31
	.end	func_8005FBC8
.Lfe82:
	.size	 func_8005FBC8,.Lfe82-func_8005FBC8
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8005FC9C.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_800600C8
	.type	 func_800600C8,@function
	.ent	func_800600C8
func_800600C8:
	.frame	$sp,112,$31		# vars= 56, regs= 7/0, args= 24, extra= 0
	.mask	0x803f0000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,112
	sw	$17,84($sp)
	move	$17,$4
	sw	$18,88($sp)
	move	$18,$5
	sw	$20,96($sp)
	move	$20,$6
	move	$9,$18
	la	$2,D_8009B6F0
	sw	$19,92($sp)
	addu	$19,$18,180
	sw	$21,100($sp)
	addu	$21,$18,192
	sw	$2,24($sp)
	slt	$2,$17,10
	sw	$31,104($sp)
	sw	$16,80($sp)
	sb	$0,64($sp)
	sw	$0,40($sp)
	sw	$0,52($sp)
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L364
	sw	$20,44($sp)
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L371
	li	$2,0x00000093		# 147
	.set	macro
	.set	reorder

.L364:
	li	$2,0x000000a3		# 163
.L371:
	sw	$2,48($sp)
	addu	$4,$sp,24
	la	$2,D_8009B758
	sw	$2,28($sp)
	.set	noreorder
	.set	nomacro
	jal	func_8007352C
	sw	$9,32($sp)
	.set	macro
	.set	reorder

	li	$8,0x66660000		# 1717960704
	ori	$8,$8,0x6667
	sll	$3,$17,16
	sra	$6,$3,16
	mult	$6,$8
	move	$9,$2
	sra	$3,$3,31
	move	$16,$0
	mfhi	$10
	#nop
	#nop
	sra	$4,$10,2
	subu	$4,$4,$3
	sll	$5,$4,16
	sra	$7,$5,16
	mult	$7,$8
	la	$2,D_8009B6FC
	sw	$2,24($sp)
	move	$2,$17
	sh	$2,74($sp)
	sh	$2,72($sp)
	sll	$2,$4,2
	addu	$2,$2,$4
	sll	$2,$2,1
	subu	$6,$6,$2
	sra	$5,$5,31
	sh	$6,72($sp)
	mfhi	$10
	#nop
	#nop
	sra	$3,$10,2
	subu	$3,$3,$5
	sll	$2,$3,2
	addu	$2,$2,$3
	sll	$2,$2,1
	subu	$7,$7,$2
	sh	$7,74($sp)
	sll	$2,$16,1
.L373:
	addu	$2,$sp,$2
	lh	$2,72($2)
	la	$3,D_8009B708
	sll	$2,$2,3
	addu	$2,$2,$3
	sw	$2,28($sp)
	slt	$2,$17,10
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L372
	li	$2,0x00000064		# 100
	.set	macro
	.set	reorder

	li	$2,0x00000001		# 1
	subu	$2,$2,$16
	sll	$2,$2,5
	addu	$2,$2,84
.L372:
	sw	$2,48($sp)
	addu	$4,$sp,24
	.set	noreorder
	.set	nomacro
	jal	func_8007352C
	sw	$9,32($sp)
	.set	macro
	.set	reorder

	lh	$3,74($sp)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$3,$0,.L369
	move	$9,$2
	.set	macro
	.set	reorder

	addu	$16,$16,1
	slt	$2,$16,2
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L373
	sll	$2,$16,1
	.set	macro
	.set	reorder

.L369:
	la	$4,D_8009B6F0
	.set	noreorder
	.set	nomacro
	jal	func_8006E480
	move	$5,$0
	.set	macro
	.set	reorder

	move	$4,$19
	li	$5,0x00000001		# 1
	move	$6,$0
	move	$7,$2
	.set	noreorder
	.set	nomacro
	jal	SetDrawMode
	sw	$0,16($sp)
	.set	macro
	.set	reorder

	move	$5,$19
	lw	$2,D_800A374C
	sll	$4,$20,2
	.set	noreorder
	.set	nomacro
	jal	AddPrim
	addu	$4,$2,$4
	.set	macro
	.set	reorder

	subu	$2,$21,$18
	lw	$31,104($sp)
	lw	$21,100($sp)
	lw	$20,96($sp)
	lw	$19,92($sp)
	lw	$18,88($sp)
	lw	$17,84($sp)
	lw	$16,80($sp)
	addu	$sp,$sp,112
	j	$31
	.end	func_800600C8
.Lfe83:
	.size	 func_800600C8,.Lfe83-func_800600C8
	.align	2
	.globl	func_800602AC
	.type	 func_800602AC,@function
	.ent	func_800602AC
func_800602AC:
	.frame	$sp,64,$31		# vars= 32, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,64
	sw	$16,48($sp)
	move	$16,$5
	addu	$5,$4,61
	li	$4,0x00000002		# 2
	sw	$31,56($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80036EA8
	sw	$17,52($sp)
	.set	macro
	.set	reorder

	move	$17,$2
	move	$4,$17
	.set	noreorder
	.set	nomacro
	jal	replay_camera_Init
	move	$5,$16
	.set	macro
	.set	reorder

	jal	game_FrameLoop
	.set	noreorder
	.set	nomacro
	jal	func_80036F28
	move	$4,$17
	.set	macro
	.set	reorder

	lw	$2,0($16)
	lw	$3,4($16)
	addu	$2,$2,$16
	addu	$3,$3,$16
	sw	$2,0($16)
	sw	$3,4($16)
	la	$5,D_800A3294
	lwl	$2,3($5)
	lwr	$2,0($5)
	lwl	$3,7($5)
	lwr	$3,4($5)
	swl	$2,19($sp)
	swr	$2,16($sp)
	swl	$3,23($sp)
	swr	$3,20($sp)
	la	$5,D_800A329C
	lwl	$2,3($5)
	lwr	$2,0($5)
	lwl	$3,7($5)
	lwr	$3,4($5)
	swl	$2,27($sp)
	swr	$2,24($sp)
	swl	$3,31($sp)
	swr	$3,28($sp)
	lw	$17,0($16)
	addu	$4,$sp,16
	.set	noreorder
	.set	nomacro
	jal	LoadImage
	addu	$5,$17,64
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	addu	$4,$sp,24
	.set	noreorder
	.set	nomacro
	jal	LoadImage
	addu	$5,$17,20
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	la	$5,D_800A32A4
	lwl	$2,3($5)
	lwr	$2,0($5)
	lwl	$3,7($5)
	lwr	$3,4($5)
	swl	$2,35($sp)
	swr	$2,32($sp)
	swl	$3,39($sp)
	swr	$3,36($sp)
	la	$5,D_800A32AC
	lwl	$2,3($5)
	lwr	$2,0($5)
	lwl	$3,7($5)
	lwr	$3,4($5)
	swl	$2,43($sp)
	swr	$2,40($sp)
	swl	$3,47($sp)
	swr	$3,44($sp)
	lw	$16,4($16)
	addu	$4,$sp,32
	.set	noreorder
	.set	nomacro
	jal	LoadImage
	addu	$5,$16,96
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	addu	$4,$sp,40
	.set	noreorder
	.set	nomacro
	jal	LoadImage
	addu	$5,$16,20
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	lw	$31,56($sp)
	lw	$17,52($sp)
	lw	$16,48($sp)
	addu	$sp,$sp,64
	j	$31
	.end	func_800602AC
.Lfe84:
	.size	 func_800602AC,.Lfe84-func_800602AC
	.align	2
	.globl	func_80060414
	.type	 func_80060414,@function
	.ent	func_80060414
func_80060414:
	.frame	$sp,96,$31		# vars= 48, regs= 5/0, args= 24, extra= 0
	.mask	0x800f0000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,96
	sw	$16,72($sp)
	move	$16,$5
	sw	$18,80($sp)
	move	$18,$6
	andi	$3,$4,0x7fff
	la	$2,D_8009B850
	sll	$3,$3,1
	addu	$3,$3,$2
	sw	$17,76($sp)
	addu	$17,$16,20
	sw	$19,84($sp)
	addu	$19,$16,44
	sw	$31,88($sp)
	sb	$0,64($sp)
	sw	$0,40($sp)
	sw	$18,44($sp)
	lhu	$2,0($3)
	andi	$4,$4,0x8000
	srl	$2,$2,7
	addu	$2,$2,55
	sw	$2,48($sp)
	lhu	$2,0($3)
	move	$3,$16
	andi	$2,$2,0x007f
	addu	$2,$2,42
	.set	noreorder
	.set	nomacro
	beq	$4,$0,.L376
	sw	$2,52($sp)
	.set	macro
	.set	reorder

	la	$2,D_8009B7AC
	.set	noreorder
	.set	nomacro
	j	.L381
	sw	$2,24($sp)
	.set	macro
	.set	reorder

.L376:
	lbu	$2,D_8009BD24
	#nop
	sltu	$2,$2,12
	beq	$2,$0,.L378
	la	$2,D_8009B7B8
	.set	noreorder
	.set	nomacro
	j	.L381
	sw	$2,24($sp)
	.set	macro
	.set	reorder

.L378:
	la	$2,D_8009B7C4
	sw	$2,24($sp)
.L381:
	addu	$4,$sp,24
	la	$2,D_800A328C
	sw	$2,28($sp)
	.set	noreorder
	.set	nomacro
	jal	func_8007352C
	sw	$3,32($sp)
	.set	macro
	.set	reorder

	lw	$4,24($sp)
	.set	noreorder
	.set	nomacro
	jal	func_8006E480
	move	$5,$0
	.set	macro
	.set	reorder

	move	$4,$17
	li	$5,0x00000001		# 1
	move	$6,$0
	move	$7,$2
	.set	noreorder
	.set	nomacro
	jal	SetDrawMode
	sw	$0,16($sp)
	.set	macro
	.set	reorder

	move	$5,$17
	lw	$2,D_800A374C
	sll	$4,$18,2
	.set	noreorder
	.set	nomacro
	jal	AddPrim
	addu	$4,$2,$4
	.set	macro
	.set	reorder

	subu	$2,$19,$16
	lw	$31,88($sp)
	lw	$19,84($sp)
	lw	$18,80($sp)
	lw	$17,76($sp)
	lw	$16,72($sp)
	addu	$sp,$sp,96
	j	$31
	.end	func_80060414
.Lfe85:
	.size	 func_80060414,.Lfe85-func_80060414
	.align	2
	.globl	func_80060544
	.type	 func_80060544,@function
	.ent	func_80060544
func_80060544:
	.frame	$sp,112,$31		# vars= 48, regs= 10/0, args= 24, extra= 0
	.mask	0xc0ff0000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,112
	sw	$20,88($sp)
	move	$20,$4
	sw	$23,100($sp)
	move	$23,$5
	sw	$19,84($sp)
	move	$19,$20
	sw	$18,80($sp)
	addu	$18,$20,1260
	sw	$22,96($sp)
	addu	$22,$20,1500
	sw	$fp,104($sp)
	addu	$fp,$20,1524
	sw	$16,72($sp)
	move	$16,$0
	sw	$21,92($sp)
	li	$21,0x00000003		# 3
	sw	$17,76($sp)
	move	$17,$0
	li	$2,0x00000200		# 512
	sw	$2,56($sp)
	li	$2,0x00000100		# 256
	sw	$31,108($sp)
	sb	$0,64($sp)
	sw	$0,40($sp)
	sw	$23,44($sp)
	sw	$2,60($sp)
	sw	$0,52($sp)
	sw	$0,48($sp)
.L383:
	la	$2,D_8009B770
	addu	$2,$17,$2
	sw	$2,24($sp)
	slt	$2,$16,3
	beq	$2,$0,.L386
	bgtz	$16,.L388
	beq	$16,$0,.L390
	j	.L391
.L386:
	.set	noreorder
	.set	nomacro
	beq	$16,$21,.L393
	addu	$4,$sp,24
	.set	macro
	.set	reorder

	j	.L391
.L390:
	la	$2,D_8009B7D8
	.set	noreorder
	.set	nomacro
	j	.L391
	sw	$2,28($sp)
	.set	macro
	.set	reorder

.L388:
	la	$2,D_8009B800
	.set	noreorder
	.set	nomacro
	j	.L391
	sw	$2,28($sp)
	.set	macro
	.set	reorder

.L393:
	move	$5,$0
	la	$2,D_8009B7D0
	sw	$2,28($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80073728
	sw	$18,36($sp)
	.set	macro
	.set	reorder

	move	$18,$2
.L391:
	beq	$16,$21,.L394
	sw	$19,32($sp)
	.set	noreorder
	.set	nomacro
	jal	func_8007352C
	addu	$4,$sp,24
	.set	macro
	.set	reorder

	move	$19,$2
.L394:
	addu	$16,$16,1
	slt	$2,$16,4
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L383
	addu	$17,$17,12
	.set	macro
	.set	reorder

	addu	$4,$sp,24
	la	$2,D_8009B7A0
	sw	$2,24($sp)
	la	$2,D_8009B820
	sw	$2,28($sp)
	.set	noreorder
	.set	nomacro
	jal	func_8007352C
	sw	$19,32($sp)
	.set	macro
	.set	reorder

	move	$19,$2
	move	$18,$0
	la	$17,D_8009B840
	la	$16,D_8009B3B0
	li	$2,0x000000ff		# 255
	sb	$2,65($sp)
	li	$2,0x00000010		# 16
	sb	$2,67($sp)
	sb	$2,66($sp)
	li	$2,0x00000001		# 1
	sb	$2,64($sp)
.L396:
	addu	$4,$sp,24
	sw	$16,24($sp)
	sw	$17,28($sp)
	.set	noreorder
	.set	nomacro
	jal	func_8007352C
	sw	$19,32($sp)
	.set	macro
	.set	reorder

	move	$19,$2
	addu	$17,$17,8
	addu	$18,$18,1
	slt	$2,$18,2
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L396
	addu	$16,$16,12
	.set	macro
	.set	reorder

	lw	$4,24($sp)
	.set	noreorder
	.set	nomacro
	jal	func_8006E480
	move	$5,$0
	.set	macro
	.set	reorder

	move	$4,$22
	li	$5,0x00000001		# 1
	move	$6,$0
	move	$7,$2
	.set	noreorder
	.set	nomacro
	jal	SetDrawMode
	sw	$0,16($sp)
	.set	macro
	.set	reorder

	move	$5,$22
	lw	$2,D_800A374C
	sll	$4,$23,2
	.set	noreorder
	.set	nomacro
	jal	AddPrim
	addu	$4,$2,$4
	.set	macro
	.set	reorder

	subu	$2,$fp,$20
	lw	$31,108($sp)
	lw	$fp,104($sp)
	lw	$23,100($sp)
	lw	$22,96($sp)
	lw	$21,92($sp)
	lw	$20,88($sp)
	lw	$19,84($sp)
	lw	$18,80($sp)
	lw	$17,76($sp)
	lw	$16,72($sp)
	addu	$sp,$sp,112
	j	$31
	.end	func_80060544
.Lfe86:
	.size	 func_80060544,.Lfe86-func_80060544
	.align	2
	.globl	func_80060758
	.type	 func_80060758,@function
	.ent	func_80060758
func_80060758:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	sh	$0,D_800A32B6
	sh	$0,D_800A32B4
	j	$31
	.end	func_80060758
.Lfe87:
	.size	 func_80060758,.Lfe87-func_80060758
	.align	2
	.globl	func_80060768
	.type	 func_80060768,@function
	.ent	func_80060768
func_80060768:
	.frame	$sp,56,$31		# vars= 8, regs= 6/0, args= 24, extra= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,56
	sw	$18,40($sp)
	move	$18,$4
	sw	$19,44($sp)
	move	$19,$5
	sw	$16,32($sp)
	move	$16,$6
	sw	$17,36($sp)
	addu	$17,$18,2000
	addu	$4,$sp,24
	addu	$5,$sp,28
	la	$6,D_8009B0C0
	move	$7,$19
	addu	$2,$18,2160
	sw	$31,52($sp)
	sw	$20,48($sp)
	sw	$18,24($sp)
	sw	$2,28($sp)
	.set	noreorder
	.set	nomacro
	jal	func_8006D808
	sw	$16,16($sp)
	.set	macro
	.set	reorder

	sltu	$2,$16,3
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L402
	addu	$20,$18,2760
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	SetTile
	move	$4,$17
	.set	macro
	.set	reorder

	li	$5,-2004353024			# 0x88880000
	li	$2,0x000000ff		# 255
	sb	$2,2004($18)
	li	$2,0x0000006a		# 106
	sh	$2,2008($18)
	sll	$2,$16,1
	addu	$2,$2,$16
	sll	$2,$2,2
	addu	$2,$2,$16
	sll	$2,$2,1
	addu	$2,$2,91
	sb	$0,2005($18)
	sb	$0,2006($18)
	sh	$2,2010($18)
	lhu	$4,D_800A32B4
	ori	$5,$5,0x8889
	sll	$3,$4,16
	sra	$3,$3,16
	sll	$2,$3,3
	addu	$2,$2,$3
	sll	$2,$2,3
	subu	$2,$2,$3
	sll	$3,$2,2
	subu	$3,$3,$2
	sll	$3,$3,1
	mult	$3,$5
	addu	$4,$4,1
	li	$2,0x00000002		# 2
	sh	$4,D_800A32B4
	sh	$2,2014($18)
	mfhi	$8
	#nop
	#nop
	addu	$2,$8,$3
	sra	$2,$2,4
	sra	$3,$3,31
	subu	$2,$2,$3
	sh	$2,2012($18)
	lh	$2,D_800A32B4
	#nop
	slt	$2,$2,31
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L403
	li	$2,0x0000001e		# 30
	.set	macro
	.set	reorder

	sh	$2,D_800A32B4
.L403:
	move	$4,$17
	.set	noreorder
	.set	nomacro
	jal	SetSemiTrans
	move	$5,$0
	.set	macro
	.set	reorder

	move	$5,$17
	addu	$17,$18,2016
	lw	$2,D_800A374C
	sll	$4,$19,2
	.set	noreorder
	.set	nomacro
	jal	AddPrim
	addu	$4,$2,$4
	.set	macro
	.set	reorder

.L402:
	.set	noreorder
	.set	nomacro
	jal	SetTile
	move	$4,$17
	.set	macro
	.set	reorder

	li	$5,-2004353024			# 0x88880000
	li	$2,0x000000ff		# 255
	sb	$2,4($17)
	li	$2,0x0000009e		# 158
	sh	$2,8($17)
	li	$2,0x000000bd		# 189
	sb	$0,5($17)
	sb	$0,6($17)
	sh	$2,10($17)
	lhu	$4,D_800A32B6
	ori	$5,$5,0x8889
	sll	$3,$4,16
	sra	$3,$3,16
	sll	$2,$3,2
	addu	$2,$2,$3
	sll	$2,$2,4
	addu	$2,$2,$3
	sll	$2,$2,2
	mult	$2,$5
	addu	$4,$4,1
	li	$3,0x00000002		# 2
	sh	$4,D_800A32B6
	sh	$3,14($17)
	mfhi	$8
	#nop
	#nop
	addu	$3,$8,$2
	sra	$3,$3,4
	sra	$2,$2,31
	subu	$3,$3,$2
	sh	$3,12($17)
	lh	$2,D_800A32B6
	#nop
	slt	$2,$2,31
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L404
	li	$2,0x0000001e		# 30
	.set	macro
	.set	reorder

	sh	$2,D_800A32B6
.L404:
	move	$4,$17
	.set	noreorder
	.set	nomacro
	jal	SetSemiTrans
	move	$5,$0
	.set	macro
	.set	reorder

	move	$5,$17
	addu	$17,$17,16
	lw	$4,D_800A374C
	sll	$16,$19,2
	.set	noreorder
	.set	nomacro
	jal	AddPrim
	addu	$4,$4,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	SetTile
	move	$4,$17
	.set	macro
	.set	reorder

	move	$4,$17
	li	$5,0x00000001		# 1
	li	$2,0x0000003f		# 63
	sh	$2,8($17)
	li	$2,0x0000002d		# 45
	sh	$2,10($17)
	li	$2,0x00000202		# 514
	sh	$2,12($17)
	li	$2,0x0000006c		# 108
	sb	$0,4($17)
	sb	$0,5($17)
	sb	$0,6($17)
	.set	noreorder
	.set	nomacro
	jal	SetSemiTrans
	sh	$2,14($17)
	.set	macro
	.set	reorder

	move	$5,$17
	lw	$4,D_800A374C
	addu	$17,$17,16
	.set	noreorder
	.set	nomacro
	jal	AddPrim
	addu	$4,$4,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	SetTile
	move	$4,$17
	.set	macro
	.set	reorder

	move	$4,$17
	li	$5,0x00000001		# 1
	li	$2,0x00000092		# 146
	sh	$2,8($17)
	li	$2,0x000000aa		# 170
	sh	$2,10($17)
	li	$2,0x0000015c		# 348
	sh	$2,12($17)
	li	$2,0x0000001a		# 26
	sb	$0,4($17)
	sb	$0,5($17)
	sb	$0,6($17)
	.set	noreorder
	.set	nomacro
	jal	SetSemiTrans
	sh	$2,14($17)
	.set	macro
	.set	reorder

	lw	$4,D_800A374C
	move	$5,$17
	.set	noreorder
	.set	nomacro
	jal	AddPrim
	addu	$4,$4,$16
	.set	macro
	.set	reorder

	li	$5,0x00000001		# 1
	move	$6,$0
	sw	$0,16($sp)
	lw	$4,28($sp)
	.set	noreorder
	.set	nomacro
	jal	SetDrawMode
	move	$7,$0
	.set	macro
	.set	reorder

	lw	$4,D_800A374C
	lw	$5,28($sp)
	.set	noreorder
	.set	nomacro
	jal	AddPrim
	addu	$4,$4,$16
	.set	macro
	.set	reorder

	lw	$3,28($sp)
	subu	$2,$20,$18
	addu	$3,$3,12
	sw	$3,28($sp)
	lw	$31,52($sp)
	lw	$20,48($sp)
	lw	$19,44($sp)
	lw	$18,40($sp)
	lw	$17,36($sp)
	lw	$16,32($sp)
	addu	$sp,$sp,56
	j	$31
	.end	func_80060768
.Lfe88:
	.size	 func_80060768,.Lfe88-func_80060768
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80060A68.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_80060B70
	.type	 func_80060B70,@function
	.ent	func_80060B70
func_80060B70:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	lw	$3,D_800A3468
	subu	$sp,$sp,24
	sw	$31,16($sp)
	lw	$2,4($3)
	lw	$4,D_800A346C
	lhu	$2,0($2)
	#nop
	sh	$2,0($4)
	lw	$2,4($3)
	#nop
	lhu	$2,2($2)
	#nop
	sh	$2,2($4)
	lw	$2,4($3)
	#nop
	lhu	$2,4($2)
	#nop
	sh	$2,4($4)
	lw	$2,8($3)
	lw	$5,D_800A3470
	lw	$2,0($2)
	#nop
	sw	$2,0($5)
	lw	$2,8($3)
	#nop
	lw	$2,4($2)
	#nop
	sw	$2,4($5)
	lw	$2,8($3)
	lw	$6,D_800A3474
	lw	$2,8($2)
	.set	noreorder
	.set	nomacro
	jal	func_80061FAC
	sw	$2,8($5)
	.set	macro
	.set	reorder

	lw	$2,D_800A3468
	#nop
	lhu	$2,0($2)
	#nop
	sll	$3,$2,2
	lbu	$2,D_8009BA60($2)
	lw	$3,D_800F10D0($3)
	#nop
	addu	$2,$2,$3
	sll	$2,$2,2
	lw	$2,chractar_use_pset_combo_id_table($2)
	#nop
	jal	$31,$2
	lw	$3,D_800A3468
	#nop
	lw	$3,20($3)
	.set	noreorder
	lw	$31,16($sp)
	sb	$2,0($3)
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80060B70
.Lfe89:
	.size	 func_80060B70,.Lfe89-func_80060B70
	.align	2
	.globl	func_80060C60
	.type	 func_80060C60,@function
	.ent	func_80060C60
func_80060C60:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	move	$3,$0
	la	$4,D_800F10D0
.L407:
	sw	$0,0($4)
	sb	$0,D_800F1150($3)
	addu	$3,$3,1
	slt	$2,$3,28
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L407
	addu	$4,$4,4
	.set	macro
	.set	reorder

	sh	$0,D_800A345E
	sh	$0,D_800A345C
	sw	$0,D_800A3458
	sw	$0,D_800A3454
	sw	$0,D_800A3450
	sw	$0,D_800A344C
	sw	$0,D_800A3460
	sw	$0,D_800A3444
	sw	$0,D_800A3448
	j	$31
	.end	func_80060C60
.Lfe90:
	.size	 func_80060C60,.Lfe90-func_80060C60
	.align	2
	.globl	func_80060CB8
	.type	 func_80060CB8,@function
	.ent	func_80060CB8
func_80060CB8:
	.frame	$sp,40,$31		# vars= 8, regs= 4/0, args= 16, extra= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	sw	$18,32($sp)
	move	$18,$5
	sw	$17,28($sp)
	move	$17,$4
	sw	$31,36($sp)
	.set	noreorder
	.set	nomacro
	jal	game_FrameLoop
	sw	$16,24($sp)
	.set	macro
	.set	reorder

	lw	$2,D_8009BD38
	#nop
	andi	$3,$2,0x000f
	.set	noreorder
	.set	nomacro
	bne	$3,$0,.L412
	li	$2,0x00000003		# 3
	.set	macro
	.set	reorder

	li	$4,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	j	.L420
	li	$5,0x0000003c		# 60
	.set	macro
	.set	reorder

.L412:
	.set	noreorder
	.set	nomacro
	bne	$3,$2,.L414
	li	$2,0x00000002		# 2
	.set	macro
	.set	reorder

	li	$4,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	j	.L420
	li	$5,0x0000002f		# 47
	.set	macro
	.set	reorder

.L414:
	.set	noreorder
	.set	nomacro
	bne	$3,$2,.L416
	li	$2,0x00000005		# 5
	.set	macro
	.set	reorder

	li	$4,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	j	.L420
	li	$5,0x00000030		# 48
	.set	macro
	.set	reorder

.L416:
	bne	$3,$2,.L418
	li	$4,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	j	.L420
	li	$5,0x00000031		# 49
	.set	macro
	.set	reorder

.L418:
	li	$4,0x00000002		# 2
	move	$5,$0
.L420:
	.set	noreorder
	.set	nomacro
	jal	func_80036EA8
	li	$16,0x000001dc		# 476
	.set	macro
	.set	reorder

	move	$4,$2
	.set	noreorder
	.set	nomacro
	jal	replay_camera_Init
	move	$5,$17
	.set	macro
	.set	reorder

	jal	game_FrameLoop
	move	$4,$0
	li	$2,0x00000380		# 896
	sh	$2,16($sp)
	li	$2,0x00000080		# 128
	sh	$0,18($sp)
	sh	$2,20($sp)
	.set	noreorder
	.set	nomacro
	jal	DrawSync
	sh	$16,22($sp)
	.set	macro
	.set	reorder

	addu	$4,$sp,16
	.set	noreorder
	.set	nomacro
	jal	LoadImage
	move	$5,$17
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	li	$5,0x00010000		# 65536
	ori	$5,$5,0xdc00
	addu	$4,$sp,16
	addu	$5,$17,$5
	li	$2,0x00000070		# 112
	sh	$2,20($sp)
	li	$2,0x00000024		# 36
	sh	$16,18($sp)
	.set	noreorder
	.set	nomacro
	jal	LoadImage
	sh	$2,22($sp)
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	jal	func_80060C60
	jal	rand
	.set	noreorder
	.set	nomacro
	jal	srand
	move	$4,$2
	.set	macro
	.set	reorder

	addu	$3,$18,18000
	addu	$2,$3,18000
	sw	$18,D_800A3420
	sw	$3,D_800A3424
	lw	$31,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,40
	j	$31
	.end	func_80060CB8
.Lfe91:
	.size	 func_80060CB8,.Lfe91-func_80060CB8
	.align	2
	.globl	func_80060E04
	.type	 func_80060E04,@function
	.ent	func_80060E04
func_80060E04:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	beq	$4,$0,.L422
	lw	$2,D_800A3424
	j	.L424
.L422:
	lw	$2,D_800A3420
.L424:
	sw	$2,D_800A37D4
	lw	$2,D_800A37D4
	#nop
	sw	$2,D_800A3720
	j	$31
	.end	func_80060E04
.Lfe92:
	.size	 func_80060E04,.Lfe92-func_80060E04
	.align	2
	.globl	func_80060E38
	.type	 func_80060E38,@function
	.ent	func_80060E38
func_80060E38:
	.frame	$sp,112,$31		# vars= 72, regs= 9/0, args= 0, extra= 0
	.mask	0x40ff0000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,112
	li	$2,0x1f800000		# 528482304
	ori	$2,$2,0x0018
	sw	$2,0($sp)
	li	$2,0x1f800000		# 528482304
	ori	$2,$2,0x0020
	sw	$2,8($sp)
	li	$2,0x1f800000		# 528482304
	ori	$2,$2,0x0030
	sw	$2,16($sp)
	li	$2,0x1f800000		# 528482304
	ori	$2,$2,0x0050
	sw	$2,24($sp)
	li	$2,0x1f800000		# 528482304
	ori	$2,$2,0x0058
	sw	$2,32($sp)
	li	$2,0x1f800000		# 528482304
	ori	$2,$2,0x005c
	sw	$2,40($sp)
	li	$2,0x1f800000		# 528482304
	ori	$2,$2,0x0060
	sw	$2,48($sp)
	li	$2,0x1f800000		# 528482304
	ori	$2,$2,0x0062
	sw	$2,56($sp)
	li	$2,0x1f800000		# 528482304
	ori	$2,$2,0x0064
	sw	$fp,104($sp)
	li	$fp,0x1f800000		# 528482304
	ori	$fp,$fp,0x0066
	li	$25,0x1f800000		# 528482304
	ori	$25,$25,0x0068
	li	$24,0x1f800000		# 528482304
	ori	$24,$24,0x006a
	sw	$23,100($sp)
	li	$23,0x1f800000		# 528482304
	ori	$23,$23,0x006c
	sw	$22,96($sp)
	li	$22,0x1f800000		# 528482304
	ori	$22,$22,0x0070
	sw	$21,92($sp)
	li	$21,0x1f800000		# 528482304
	ori	$21,$21,0x0074
	sw	$20,88($sp)
	li	$20,0x1f800000		# 528482304
	ori	$20,$20,0x0080
	sw	$19,84($sp)
	li	$19,0x1f800000		# 528482304
	ori	$19,$19,0x0082
	sw	$18,80($sp)
	li	$18,0x1f800000		# 528482304
	ori	$18,$18,0x0084
	sw	$17,76($sp)
	li	$17,0x1f800000		# 528482304
	ori	$17,$17,0x0088
	sw	$16,72($sp)
	li	$16,0x1f800000		# 528482304
	ori	$16,$16,0x008c
	li	$15,0x1f800000		# 528482304
	ori	$15,$15,0x0090
	li	$14,0x1f800000		# 528482304
	ori	$14,$14,0x0098
	li	$13,0x1f800000		# 528482304
	ori	$13,$13,0x009a
	li	$12,0x1f800000		# 528482304
	ori	$12,$12,0x009c
	li	$11,0x1f800000		# 528482304
	ori	$11,$11,0x009e
	li	$10,0x1f800000		# 528482304
	ori	$10,$10,0x00a0
	li	$9,0x1f800000		# 528482304
	sw	$2,64($sp)
	li	$2,0x1f800000		# 528482304
	sw	$2,D_800A3468
	lw	$2,0($sp)
	ori	$9,$9,0x00a4
	sw	$2,D_800A346C
	lw	$2,8($sp)
	li	$8,0x1f800000		# 528482304
	sw	$2,D_800A3470
	lw	$2,16($sp)
	ori	$8,$8,0x00a8
	sw	$2,D_800A3474
	lw	$2,24($sp)
	li	$7,0x1f800000		# 528482304
	sw	$2,D_800A3488
	lw	$2,32($sp)
	ori	$7,$7,0x00ac
	sw	$2,D_800A3490
	lw	$2,40($sp)
	li	$6,0x1f800000		# 528482304
	sw	$2,D_800A3494
	lw	$2,48($sp)
	ori	$6,$6,0x00b0
	sw	$2,D_800A3498
	lw	$2,56($sp)
	li	$3,0x1f800000		# 528482304
	sw	$2,D_800A349C
	lw	$2,64($sp)
	ori	$3,$3,0x00b8
	sw	$fp,D_800A34A4
	sw	$25,D_800A34A8
	sw	$24,D_800A34AC
	sw	$23,D_800A34B0
	sw	$22,D_800A34B4
	sw	$21,D_800A34B8
	sw	$20,D_800A34BC
	sw	$19,D_800A34C0
	sw	$18,D_800A34C4
	sw	$17,D_800A34C8
	sw	$16,D_800A34CC
	sw	$15,D_800A34D0
	sw	$14,D_800A34D4
	sw	$13,D_800A34D8
	sw	$12,D_800A34DC
	sw	$11,D_800A34E0
	sw	$10,D_800A34E4
	sw	$9,D_800A34E8
	sw	$8,D_800A3480
	sw	$7,D_800A3484
	sw	$6,D_800A348C
	sw	$3,D_800A34EC
	sw	$4,528482308
	sw	$2,D_800A34A0
	sw	$5,528482312
	lw	$fp,104($sp)
	lw	$23,100($sp)
	lw	$22,96($sp)
	lw	$21,92($sp)
	lw	$20,88($sp)
	lw	$19,84($sp)
	lw	$18,80($sp)
	lw	$17,76($sp)
	lw	$16,72($sp)
	addu	$sp,$sp,112
	j	$31
	.end	func_80060E38
.Lfe93:
	.size	 func_80060E38,.Lfe93-func_80060E38
	.align	2
	.globl	func_80061064
	.type	 func_80061064,@function
	.ent	func_80061064
func_80061064:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	sw	$31,24($sp)
	sw	$17,20($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80060E38
	sw	$16,16($sp)
	.set	macro
	.set	reorder

	move	$16,$0
	la	$17,D_800F1150
.L427:
	lw	$3,D_800A3468
	addu	$2,$16,$17
	sw	$2,20($3)
	lbu	$2,D_800F1150($16)
	#nop
	beq	$2,$0,.L430
	.set	noreorder
	.set	nomacro
	jal	func_80060B70
	sw	$16,0($3)
	.set	macro
	.set	reorder

.L430:
	addu	$16,$16,1
	slt	$2,$16,28
	bne	$2,$0,.L427
	lw	$3,D_800A32BC
	#nop
	slt	$2,$3,2
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L432
	li	$2,0x00000001		# 1
	.set	macro
	.set	reorder

	la	$4,D_800F1140
	lw	$5,D_800A3464
	addu	$2,$3,-1
	sw	$2,D_800A32BC
	jal	func_80041E10
	j	.L433
.L432:
	bne	$3,$2,.L433
	jal	func_800421A4
	sw	$0,D_800A32BC
.L433:
	lw	$3,D_800A37D4
	lw	$2,D_800A3720
	#nop
	subu	$3,$3,$2
	sll	$2,$3,1
	addu	$2,$2,$3
	sll	$3,$2,4
	addu	$2,$2,$3
	sll	$3,$2,8
	addu	$2,$2,$3
	sll	$3,$2,16
	addu	$2,$2,$3
	subu	$2,$0,$2
	sra	$5,$2,3
	slt	$2,$5,450
	bne	$2,$0,.L435
	la	$4,D_800158E0
	.set	noreorder
	.set	nomacro
	jal	printf
	addu	$5,$5,-450
	.set	macro
	.set	reorder

.L435:
	lw	$31,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,32
	j	$31
	.end	func_80061064
.Lfe94:
	.size	 func_80061064,.Lfe94-func_80061064
	.align	2
	.globl	game_Cleanup
	.type	 game_Cleanup,@function
	.ent	game_Cleanup
game_Cleanup:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	jal	func_80060C60
	jal	func_800421A4
	sw	$0,D_800A32BC
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	game_Cleanup
.Lfe95:
	.size	 game_Cleanup,.Lfe95-game_Cleanup
	.align	2
	.globl	func_800611A4
	.type	 func_800611A4,@function
	.ent	func_800611A4
func_800611A4:
	.frame	$sp,32,$31		# vars= 8, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	sw	$16,24($sp)
	move	$16,$4
	li	$6,0x00210000		# 2162688
	sw	$31,28($sp)
	lhu	$2,0($5)
	ori	$6,$6,0x001a
	sh	$2,16($sp)
	lhu	$2,2($5)
	la	$3,D_800F116C
	sw	$3,D_800A3468
	sh	$2,18($sp)
	lhu	$4,4($5)
	addu	$2,$sp,16
	sw	$2,D_800F117C
	la	$2,D_800F116A
	sw	$16,D_800F1178
	sw	$2,D_800F1180
	sw	$6,0($3)
	.set	noreorder
	.set	nomacro
	jal	func_80060A68
	sh	$4,20($sp)
	.set	macro
	.set	reorder

	lw	$2,0($16)
	#nop
	sw	$2,D_800F1140
	lw	$2,4($16)
	li	$3,0x00ff0000		# 16711680
	sw	$2,D_800F1144
	lw	$2,8($16)
	ori	$3,$3,0xffef
	sw	$3,D_800A3464
	sw	$2,D_800F1148
	lw	$31,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,32
	j	$31
	.end	func_800611A4
.Lfe96:
	.size	 func_800611A4,.Lfe96-func_800611A4
	.align	2
	.globl	func_80061250
	.type	 func_80061250,@function
	.ent	func_80061250
func_80061250:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$16,16($sp)
	move	$16,$4
	la	$3,D_800F1154+5
	sw	$31,20($sp)
	lbu	$2,0($3)
	la	$5,D_800F116C
	sw	$5,D_800A3468
	sw	$16,D_800F1178
	beq	$2,$0,.L439
	lbu	$2,1($3)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L440
	addu	$4,$3,1
	.set	macro
	.set	reorder

	sb	$0,1($3)
	sb	$0,0($3)
.L440:
	lbu	$2,0($3)
	#nop
	bne	$2,$0,.L442
.L439:
	li	$4,0x00210000		# 2162688
	ori	$4,$4,0x0009
	lw	$3,D_800A3468
	la	$2,D_800F1154+5
	sw	$2,20($3)
	.set	noreorder
	.set	nomacro
	j	.L443
	sw	$4,0($3)
	.set	macro
	.set	reorder

.L442:
	lbu	$2,1($3)
	#nop
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L443
	li	$2,0x00210000		# 2162688
	.set	macro
	.set	reorder

	ori	$2,$2,0x000a
	sw	$4,D_800F1180
	sw	$2,0($5)
.L443:
	jal	func_80060A68
	lw	$2,0($16)
	#nop
	sw	$2,D_800F1140
	lw	$2,4($16)
	li	$3,0x00ff0000		# 16711680
	sw	$2,D_800F1144
	lw	$2,8($16)
	ori	$3,$3,0x0060
	sw	$3,D_800A3464
	sw	$2,D_800F1148
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80061250
.Lfe97:
	.size	 func_80061250,.Lfe97-func_80061250
	.align	2
	.globl	func_8006133C
	.type	 func_8006133C,@function
	.ent	func_8006133C
func_8006133C:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$16,16($sp)
	move	$16,$4
	li	$4,0x00210000		# 2162688
	ori	$4,$4,0x0004
	la	$3,D_800F116C
	la	$2,D_800F1154
	sw	$31,20($sp)
	sw	$3,D_800A3468
	sw	$16,D_800F1178
	sw	$2,D_800F1180
	.set	noreorder
	.set	nomacro
	jal	func_80060A68
	sw	$4,0($3)
	.set	macro
	.set	reorder

	lw	$2,0($16)
	#nop
	sw	$2,D_800F1140
	lw	$2,4($16)
	li	$3,0x00800000		# 8388608
	sw	$2,D_800F1144
	lw	$2,8($16)
	ori	$3,$3,0x80ff
	sw	$3,D_800A3464
	sw	$2,D_800F1148
	li	$2,0x00000001		# 1
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_8006133C
.Lfe98:
	.size	 func_8006133C,.Lfe98-func_8006133C
	.align	2
	.globl	func_800613C8
	.type	 func_800613C8,@function
	.ent	func_800613C8
func_800613C8:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$16,16($sp)
	move	$16,$4
	li	$4,0x00210000		# 2162688
	ori	$4,$4,0x000b
	la	$3,D_800F116C
	la	$2,D_800F115B
	sw	$31,20($sp)
	sw	$3,D_800A3468
	sw	$16,D_800F1178
	sw	$2,D_800F1180
	.set	noreorder
	.set	nomacro
	jal	func_80060A68
	sw	$4,0($3)
	.set	macro
	.set	reorder

	lw	$2,0($16)
	#nop
	sw	$2,D_800F1140
	lw	$2,4($16)
	li	$3,0x00800000		# 8388608
	sw	$2,D_800F1144
	lw	$2,8($16)
	ori	$3,$3,0x80ff
	sw	$3,D_800A3464
	sw	$2,D_800F1148
	li	$2,0x00000010		# 16
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_800613C8
.Lfe99:
	.size	 func_800613C8,.Lfe99-func_800613C8
	.align	2
	.globl	func_80061454
	.type	 func_80061454,@function
	.ent	func_80061454
func_80061454:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$16,16($sp)
	move	$16,$4
	li	$4,0x00290000		# 2686976
	ori	$4,$4,0x000b
	la	$3,D_800F116C
	la	$2,D_800F115B
	sw	$31,20($sp)
	sw	$3,D_800A3468
	sw	$16,D_800F1178
	sw	$2,D_800F1180
	.set	noreorder
	.set	nomacro
	jal	func_80060A68
	sw	$4,0($3)
	.set	macro
	.set	reorder

	lw	$2,0($16)
	#nop
	sw	$2,D_800F1140
	lw	$2,4($16)
	li	$3,0x00800000		# 8388608
	sw	$2,D_800F1144
	lw	$2,8($16)
	ori	$3,$3,0x80ff
	sw	$3,D_800A3464
	sw	$2,D_800F1148
	li	$2,0x00000008		# 8
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80061454
.Lfe100:
	.size	 func_80061454,.Lfe100-func_80061454
	.align	2
	.globl	func_800614E0
	.type	 func_800614E0,@function
	.ent	func_800614E0
func_800614E0:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$16,16($sp)
	move	$16,$4
	li	$4,0x00310000		# 3211264
	ori	$4,$4,0x000b
	la	$3,D_800F116C
	la	$2,D_800F115B
	sw	$31,20($sp)
	sw	$3,D_800A3468
	sw	$16,D_800F1178
	sw	$2,D_800F1180
	.set	noreorder
	.set	nomacro
	jal	func_80060A68
	sw	$4,0($3)
	.set	macro
	.set	reorder

	lw	$2,0($16)
	#nop
	sw	$2,D_800F1140
	lw	$2,4($16)
	li	$3,0x00800000		# 8388608
	sw	$2,D_800F1144
	lw	$2,8($16)
	ori	$3,$3,0x80ff
	sw	$3,D_800A3464
	sw	$2,D_800F1148
	li	$2,0x00000005		# 5
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_800614E0
.Lfe101:
	.size	 func_800614E0,.Lfe101-func_800614E0
	.align	2
	.globl	func_8006156C
	.type	 func_8006156C,@function
	.ent	func_8006156C
func_8006156C:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$16,16($sp)
	move	$16,$4
	la	$3,D_800F1154+1
	sw	$31,20($sp)
	lbu	$2,0($3)
	la	$5,D_800F116C
	sw	$5,D_800A3468
	sw	$16,D_800F1178
	beq	$2,$0,.L450
	lbu	$2,1($3)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L451
	addu	$4,$3,1
	.set	macro
	.set	reorder

	sb	$0,1($3)
	sb	$0,0($3)
.L451:
	lbu	$2,0($3)
	#nop
	bne	$2,$0,.L453
.L450:
	li	$4,0x00210000		# 2162688
	ori	$4,$4,0x0005
	lw	$3,D_800A3468
	la	$2,D_800F1154+1
	sw	$2,20($3)
	.set	noreorder
	.set	nomacro
	j	.L454
	sw	$4,0($3)
	.set	macro
	.set	reorder

.L453:
	lbu	$2,1($3)
	#nop
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L454
	li	$2,0x00210000		# 2162688
	.set	macro
	.set	reorder

	ori	$2,$2,0x0006
	sw	$4,D_800F1180
	sw	$2,0($5)
.L454:
	jal	func_80060A68
	lw	$2,0($16)
	#nop
	sw	$2,D_800F1140
	lw	$2,4($16)
	li	$3,0x00ff0000		# 16711680
	sw	$2,D_800F1144
	lw	$2,8($16)
	ori	$3,$3,0x8080
	sw	$3,D_800A3464
	sw	$2,D_800F1148
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_8006156C
.Lfe102:
	.size	 func_8006156C,.Lfe102-func_8006156C
	.align	2
	.globl	func_80061658
	.type	 func_80061658,@function
	.ent	func_80061658
func_80061658:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$16,16($sp)
	move	$16,$4
	la	$4,D_800F116C
	sw	$31,20($sp)
	sw	$4,D_800A3468
	sw	$16,D_800F1178
	.set	noreorder
	.set	nomacro
	beq	$5,$0,.L458
	li	$2,0x00000001		# 1
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	beq	$5,$2,.L459
	li	$3,0x00210000		# 2162688
	.set	macro
	.set	reorder

	j	.L461
.L458:
	li	$3,0x00210000		# 2162688
	la	$2,D_800F115C
	.set	noreorder
	.set	nomacro
	j	.L457
	ori	$3,$3,0x000c
	.set	macro
	.set	reorder

.L459:
	ori	$3,$3,0x000d
	la	$2,D_800F115C+1
.L457:
	sb	$0,0($2)
	sw	$2,D_800F1180
	sw	$3,0($4)
.L461:
	jal	func_80060A68
	lw	$2,0($16)
	#nop
	sw	$2,D_800F1140
	lw	$2,4($16)
	li	$3,0x00100000		# 1048576
	sw	$2,D_800F1144
	lw	$2,8($16)
	ori	$3,$3,0xffff
	sw	$3,D_800A3464
	sw	$2,D_800F1148
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80061658
.Lfe103:
	.size	 func_80061658,.Lfe103-func_80061658
	.align	2
	.globl	func_80061710
	.type	 func_80061710,@function
	.ent	func_80061710
func_80061710:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$16,16($sp)
	move	$16,$4
	la	$4,D_800F116C
	sw	$31,20($sp)
	sw	$4,D_800A3468
	sw	$16,D_800F1178
	.set	noreorder
	.set	nomacro
	beq	$5,$0,.L465
	li	$2,0x00000001		# 1
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	beq	$5,$2,.L466
	li	$3,0x00210000		# 2162688
	.set	macro
	.set	reorder

	j	.L468
.L465:
	li	$3,0x00210000		# 2162688
	la	$2,D_800F115C+2
	.set	noreorder
	.set	nomacro
	j	.L464
	ori	$3,$3,0x000e
	.set	macro
	.set	reorder

.L466:
	ori	$3,$3,0x000f
	la	$2,D_800F115C+3
.L464:
	sb	$0,0($2)
	sw	$2,D_800F1180
	sw	$3,0($4)
.L468:
	jal	func_80060A68
	lw	$2,0($16)
	#nop
	sw	$2,D_800F1140
	lw	$2,4($16)
	li	$3,0x00100000		# 1048576
	sw	$2,D_800F1144
	lw	$2,8($16)
	ori	$3,$3,0xff10
	sw	$3,D_800A3464
	sw	$2,D_800F1148
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80061710
.Lfe104:
	.size	 func_80061710,.Lfe104-func_80061710
	.align	2
	.globl	func_800617C8
	.type	 func_800617C8,@function
	.ent	func_800617C8
func_800617C8:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$16,16($sp)
	move	$16,$4
	la	$3,D_800F1160
	sw	$31,20($sp)
	lbu	$2,0($3)
	la	$5,D_800F116C
	sw	$5,D_800A3468
	sw	$16,D_800F1178
	beq	$2,$0,.L471
	lbu	$2,1($3)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L472
	addu	$4,$3,1
	.set	macro
	.set	reorder

	sb	$0,1($3)
	sb	$0,0($3)
.L472:
	lbu	$2,0($3)
	#nop
	bne	$2,$0,.L474
.L471:
	li	$4,0x00210000		# 2162688
	ori	$4,$4,0x0010
	lw	$3,D_800A3468
	la	$2,D_800F1160
	sw	$2,20($3)
	.set	noreorder
	.set	nomacro
	j	.L475
	sw	$4,0($3)
	.set	macro
	.set	reorder

.L474:
	lbu	$2,1($3)
	#nop
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L475
	li	$2,0x00210000		# 2162688
	.set	macro
	.set	reorder

	ori	$2,$2,0x0011
	sw	$4,D_800F1180
	sw	$2,0($5)
.L475:
	jal	func_80060A68
	lw	$2,0($16)
	#nop
	sw	$2,D_800F1140
	lw	$2,4($16)
	li	$3,0x00c00000		# 12582912
	sw	$2,D_800F1144
	lw	$2,8($16)
	ori	$3,$3,0x6013
	sw	$3,D_800A3464
	sw	$2,D_800F1148
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_800617C8
.Lfe105:
	.size	 func_800617C8,.Lfe105-func_800617C8
	.align	2
	.globl	func_800618B4
	.type	 func_800618B4,@function
	.ent	func_800618B4
func_800618B4:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$16,16($sp)
	move	$16,$4
	la	$3,D_800F1152
	sw	$31,20($sp)
	lbu	$2,0($3)
	la	$6,D_800F116C
	sw	$6,D_800A3468
	sw	$16,D_800F1178
	sw	$5,D_800F117C
	beq	$2,$0,.L478
	lbu	$2,1($3)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L479
	addu	$4,$3,1
	.set	macro
	.set	reorder

	sb	$0,1($3)
	sb	$0,0($3)
.L479:
	lbu	$2,0($3)
	#nop
	bne	$2,$0,.L481
.L478:
	li	$4,0x00210000		# 2162688
	ori	$4,$4,0x0002
	lw	$3,D_800A3468
	la	$2,D_800F1152
	sw	$2,20($3)
	.set	noreorder
	.set	nomacro
	j	.L482
	sw	$4,0($3)
	.set	macro
	.set	reorder

.L481:
	lbu	$2,1($3)
	#nop
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L482
	li	$2,0x00210000		# 2162688
	.set	macro
	.set	reorder

	ori	$2,$2,0x0003
	sw	$4,D_800F1180
	sw	$2,0($6)
.L482:
	jal	func_80060A68
	lw	$2,0($16)
	#nop
	sw	$2,D_800F1140
	lw	$2,4($16)
	#nop
	sw	$2,D_800F1144
	lw	$3,8($16)
	li	$2,0x00ff0000		# 16711680
	sw	$2,D_800A3464
	sw	$3,D_800F1148
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_800618B4
.Lfe106:
	.size	 func_800618B4,.Lfe106-func_800618B4
	.align	2
	.globl	func_800619A4
	.type	 func_800619A4,@function
	.ent	func_800619A4
func_800619A4:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	li	$5,0x00010000		# 65536
	ori	$5,$5,0x0008
	la	$3,D_800F116C
	la	$2,D_800F1158
	sw	$31,16($sp)
	sw	$3,D_800A3468
	sw	$4,D_800F1178
	sw	$2,D_800F1180
	.set	noreorder
	.set	nomacro
	jal	func_80060A68
	sw	$5,0($3)
	.set	macro
	.set	reorder

	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_800619A4
.Lfe107:
	.size	 func_800619A4,.Lfe107-func_800619A4
	.align	2
	.globl	func_800619F0
	.type	 func_800619F0,@function
	.ent	func_800619F0
func_800619F0:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	li	$5,0x00010000		# 65536
	ori	$5,$5,0x0007
	la	$3,D_800F116C
	la	$2,D_800F1154+3
	sw	$31,16($sp)
	sw	$3,D_800A3468
	sw	$4,D_800F1178
	sw	$2,D_800F1180
	.set	noreorder
	.set	nomacro
	jal	func_80060A68
	sw	$5,0($3)
	.set	macro
	.set	reorder

	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_800619F0
.Lfe108:
	.size	 func_800619F0,.Lfe108-func_800619F0
	.align	2
	.globl	func_80061A3C
	.type	 func_80061A3C,@function
	.ent	func_80061A3C
func_80061A3C:
	.frame	$sp,32,$31		# vars= 8, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	la	$8,D_800F116C
	addu	$2,$sp,16
	sw	$31,24($sp)
	sw	$8,D_800A3468
	sh	$0,20($sp)
	sh	$0,16($sp)
	sh	$5,18($sp)
	sw	$4,D_800F1178
	sw	$2,D_800F117C
	.set	noreorder
	.set	nomacro
	bne	$7,$0,.L487
	li	$3,0x00010000		# 65536
	.set	macro
	.set	reorder

	la	$2,D_800F1150
	sw	$2,D_800F1180
	li	$2,0x00010000		# 65536
	addu	$2,$6,$2
	.set	noreorder
	.set	nomacro
	j	.L488
	sw	$2,0($8)
	.set	macro
	.set	reorder

.L487:
	ori	$3,$3,0x0001
	la	$2,D_800F1151
	addu	$3,$6,$3
	sw	$2,D_800F1180
	sw	$3,0($8)
.L488:
	jal	func_80060A68
	lw	$31,24($sp)
	addu	$sp,$sp,32
	j	$31
	.end	func_80061A3C
.Lfe109:
	.size	 func_80061A3C,.Lfe109-func_80061A3C
	.align	2
	.globl	func_80061ACC
	.type	 func_80061ACC,@function
	.ent	func_80061ACC
func_80061ACC:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	sw	$17,20($sp)
	move	$17,$4
	sw	$16,16($sp)
	la	$16,D_800F1164
	sw	$31,24($sp)
	lbu	$2,0($16)
	la	$4,D_800F116C
	sw	$4,D_800A3468
	sw	$17,D_800F1178
	sw	$5,D_800F117C
	beq	$2,$0,.L490
	lbu	$2,1($16)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L491
	addu	$3,$16,1
	.set	macro
	.set	reorder

	sb	$0,1($16)
	sb	$0,0($16)
.L491:
	lbu	$2,0($16)
	#nop
	bne	$2,$0,.L493
.L490:
	li	$3,0x00210000		# 2162688
	ori	$3,$3,0x0014
	lw	$2,D_800A3468
	la	$16,D_800F1164
	sw	$16,20($2)
	.set	noreorder
	.set	nomacro
	jal	func_80060A68
	sw	$3,0($2)
	.set	macro
	.set	reorder

	li	$3,0x00010000		# 65536
	ori	$3,$3,0x0007
	lw	$2,D_800A3468
	addu	$16,$16,-13
	sw	$16,20($2)
	.set	noreorder
	.set	nomacro
	j	.L494
	sw	$3,0($2)
	.set	macro
	.set	reorder

.L493:
	lbu	$2,1($16)
	#nop
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L494
	li	$2,0x00210000		# 2162688
	.set	macro
	.set	reorder

	ori	$2,$2,0x0015
	sw	$3,D_800F1180
	.set	noreorder
	.set	nomacro
	jal	func_80060A68
	sw	$2,0($4)
	.set	macro
	.set	reorder

	li	$4,0x00010000		# 65536
	ori	$4,$4,0x0007
	lw	$3,D_800A3468
	addu	$2,$16,-13
	sw	$2,20($3)
	sw	$4,0($3)
.L494:
	jal	func_80060A68
	lw	$2,0($17)
	#nop
	sw	$2,D_800F1140
	lw	$2,4($17)
	li	$3,0x00ff0000		# 16711680
	sw	$2,D_800F1144
	lw	$2,8($17)
	ori	$3,$3,0x8080
	sw	$3,D_800A3464
	sw	$2,D_800F1148
	lw	$31,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,32
	j	$31
	.end	func_80061ACC
.Lfe110:
	.size	 func_80061ACC,.Lfe110-func_80061ACC
	.align	2
	.globl	func_80061C00
	.type	 func_80061C00,@function
	.ent	func_80061C00
func_80061C00:
	.frame	$sp,104,$31		# vars= 72, regs= 4/0, args= 16, extra= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,104
	sw	$18,96($sp)
	move	$18,$4
	move	$3,$5
	sw	$17,92($sp)
	move	$17,$6
	la	$2,D_800F116C
	sw	$2,D_800A3468
	li	$2,0x00000001		# 1
	sw	$31,100($sp)
	.set	noreorder
	.set	nomacro
	beq	$17,$2,.L497
	sw	$16,88($sp)
	.set	macro
	.set	reorder

	move	$17,$0
.L497:
	addu	$4,$sp,24
	addu	$16,$sp,48
	move	$5,$16
	li	$2,-2560			# 0xfffff600
	sh	$2,18($sp)
	li	$2,0x00000a00		# 2560
	sh	$0,16($sp)
	sh	$2,20($sp)
	sw	$0,40($sp)
	sw	$0,36($sp)
	sw	$0,32($sp)
	sh	$3,26($sp)
	sh	$0,28($sp)
	.set	noreorder
	.set	nomacro
	jal	RotMatrix
	sh	$0,24($sp)
	.set	macro
	.set	reorder

	move	$4,$16
	sw	$0,76($sp)
	sw	$0,72($sp)
	.set	noreorder
	.set	nomacro
	jal	SetRotMatrix
	sw	$0,68($sp)
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	SetTransMatrix
	move	$4,$16
	.set	macro
	.set	reorder

	addu	$4,$sp,16
	addu	$5,$sp,32
	.set	noreorder
	.set	nomacro
	jal	RotTrans
	addu	$6,$sp,80
	.set	macro
	.set	reorder

	lw	$2,32($sp)
	lw	$3,36($sp)
	lw	$4,40($sp)
	lw	$5,D_800A3468
	sh	$2,16($sp)
	addu	$2,$sp,16
	sh	$3,18($sp)
	la	$3,D_800F1164+2
	sh	$4,20($sp)
	sw	$18,12($5)
	sw	$2,16($5)
	lbu	$2,0($3)
	#nop
	beq	$2,$0,.L498
	lbu	$2,1($3)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L499
	addu	$4,$3,1
	.set	macro
	.set	reorder

	sb	$0,1($3)
	sb	$0,0($3)
.L499:
	lbu	$2,0($3)
	#nop
	bne	$2,$0,.L501
.L498:
	li	$4,0x00010000		# 65536
	ori	$4,$4,0x0016
	lw	$3,D_800A3468
	la	$2,D_800F1164+2
	sw	$2,20($3)
	sw	$4,0($3)
	sh	$17,D_800A34F0
	j	.L502
.L501:
	lbu	$2,1($3)
	#nop
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L502
	li	$2,0x00010000		# 65536
	.set	macro
	.set	reorder

	ori	$2,$2,0x0017
	sw	$4,20($5)
	sw	$2,0($5)
	sh	$17,D_800A34F2
.L502:
	jal	func_80060A68
	lw	$31,100($sp)
	lw	$18,96($sp)
	lw	$17,92($sp)
	lw	$16,88($sp)
	addu	$sp,$sp,104
	j	$31
	.end	func_80061C00
.Lfe111:
	.size	 func_80061C00,.Lfe111-func_80061C00
	.align	2
	.globl	func_80061D74
	.type	 func_80061D74,@function
	.ent	func_80061D74
func_80061D74:
	.frame	$sp,104,$31		# vars= 72, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,104
	sw	$17,92($sp)
	move	$17,$4
	addu	$4,$sp,24
	sw	$16,88($sp)
	addu	$16,$sp,48
	sh	$5,26($sp)
	move	$5,$16
	la	$2,D_800F116C
	sw	$2,D_800A3468
	li	$2,-2560			# 0xfffff600
	sh	$2,18($sp)
	li	$2,0x00000a00		# 2560
	sw	$31,96($sp)
	sh	$0,16($sp)
	sh	$2,20($sp)
	sw	$0,40($sp)
	sw	$0,36($sp)
	sw	$0,32($sp)
	sh	$0,28($sp)
	.set	noreorder
	.set	nomacro
	jal	RotMatrix
	sh	$0,24($sp)
	.set	macro
	.set	reorder

	move	$4,$16
	sw	$0,76($sp)
	sw	$0,72($sp)
	.set	noreorder
	.set	nomacro
	jal	SetRotMatrix
	sw	$0,68($sp)
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	SetTransMatrix
	move	$4,$16
	.set	macro
	.set	reorder

	addu	$4,$sp,16
	addu	$5,$sp,32
	.set	noreorder
	.set	nomacro
	jal	RotTrans
	addu	$6,$sp,80
	.set	macro
	.set	reorder

	lw	$2,32($sp)
	lw	$3,36($sp)
	lw	$4,40($sp)
	lw	$5,D_800A3468
	sh	$2,16($sp)
	addu	$2,$sp,16
	sh	$3,18($sp)
	la	$3,D_800F1168
	sh	$4,20($sp)
	sw	$17,12($5)
	sw	$2,16($5)
	lbu	$2,0($3)
	#nop
	beq	$2,$0,.L505
	lbu	$2,1($3)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L506
	addu	$4,$3,1
	.set	macro
	.set	reorder

	sb	$0,1($3)
	sb	$0,0($3)
.L506:
	lbu	$2,0($3)
	#nop
	bne	$2,$0,.L508
.L505:
	li	$4,0x00010000		# 65536
	ori	$4,$4,0x0018
	lw	$3,D_800A3468
	la	$2,D_800F1168
	sw	$2,20($3)
	.set	noreorder
	.set	nomacro
	j	.L509
	sw	$4,0($3)
	.set	macro
	.set	reorder

.L508:
	lbu	$2,1($3)
	#nop
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L509
	li	$2,0x00010000		# 65536
	.set	macro
	.set	reorder

	ori	$2,$2,0x0019
	sw	$4,20($5)
	sw	$2,0($5)
.L509:
	jal	func_80060A68
	lw	$31,96($sp)
	lw	$17,92($sp)
	lw	$16,88($sp)
	addu	$sp,$sp,104
	j	$31
	.end	func_80061D74
.Lfe112:
	.size	 func_80061D74,.Lfe112-func_80061D74
	.align	2
	.globl	func_80061EC0
	.type	 func_80061EC0,@function
	.ent	func_80061EC0
func_80061EC0:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$16,16($sp)
	move	$16,$4
	la	$3,D_800F1160+2
	sw	$31,20($sp)
	lbu	$2,0($3)
	la	$5,D_800F116C
	sw	$5,D_800A3468
	sw	$16,D_800F1178
	beq	$2,$0,.L512
	lbu	$2,1($3)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L513
	addu	$4,$3,1
	.set	macro
	.set	reorder

	sb	$0,1($3)
	sb	$0,0($3)
.L513:
	lbu	$2,0($3)
	#nop
	bne	$2,$0,.L515
.L512:
	li	$4,0x00210000		# 2162688
	ori	$4,$4,0x0012
	lw	$3,D_800A3468
	la	$2,D_800F1160+2
	sw	$2,20($3)
	.set	noreorder
	.set	nomacro
	j	.L516
	sw	$4,0($3)
	.set	macro
	.set	reorder

.L515:
	lbu	$2,1($3)
	#nop
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L516
	li	$2,0x00210000		# 2162688
	.set	macro
	.set	reorder

	ori	$2,$2,0x0013
	sw	$4,D_800F1180
	sw	$2,0($5)
.L516:
	jal	func_80060A68
	lw	$2,0($16)
	#nop
	sw	$2,D_800F1140
	lw	$2,4($16)
	li	$3,0x00ff0000		# 16711680
	sw	$2,D_800F1144
	lw	$2,8($16)
	ori	$3,$3,0x00ff
	sw	$3,D_800A3464
	sw	$2,D_800F1148
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80061EC0
.Lfe113:
	.size	 func_80061EC0,.Lfe113-func_80061EC0
	.align	2
	.globl	func_80061FAC
	.type	 func_80061FAC,@function
	.ent	func_80061FAC
func_80061FAC:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	move	$3,$4
	lw	$4,D_800A34EC
	subu	$sp,$sp,24
	sw	$31,20($sp)
	sw	$16,16($sp)
	lhu	$2,0($3)
	#nop
	sh	$2,0($4)
	lhu	$2,2($3)
	move	$16,$6
	sh	$2,2($4)
	lhu	$2,4($3)
	move	$5,$16
	.set	noreorder
	.set	nomacro
	jal	RotMatrix
	sh	$2,4($4)
	.set	macro
	.set	reorder

	move	$4,$16
	la	$5,D_8009BB74
	sw	$0,28($16)
	sw	$0,24($16)
	.set	noreorder
	.set	nomacro
	jal	ScaleMatrixL
	sw	$0,20($16)
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	SetRotMatrix
	move	$4,$16
	.set	macro
	.set	reorder

	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80061FAC
.Lfe114:
	.size	 func_80061FAC,.Lfe114-func_80061FAC
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80062020.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_800620B8.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_8006288C
	.type	 func_8006288C,@function
	.ent	func_8006288C
func_8006288C:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	move	$4,$0
	li	$11,0x00000001		# 1
	la	$10,D_800F0C04
	move	$5,$0
	move	$3,$0
	lw	$8,D_800A347C
	lw	$9,D_800A3478
	li	$2,0x00000001		# 1
	sw	$2,D_800F1138
.L520:
	lw	$7,D_800A3460
	sll	$6,$11,$4
	and	$2,$7,$6
	bne	$2,$0,.L523
	lw	$2,0($8)
	#nop
	sw	$2,D_800F0FB8($3)
	lw	$2,4($8)
	#nop
	sw	$2,D_800F0FBC($3)
	lw	$2,8($8)
	#nop
	sw	$2,D_800F0FC0($3)
	lhu	$2,0($9)
	#nop
	sh	$2,D_800F10A0($5)
	lhu	$2,2($9)
	#nop
	sh	$2,D_800F10A2($5)
	lhu	$3,4($9)
	or	$2,$7,$6
	sw	$2,D_800A3460
	sh	$3,D_800F10A4($5)
	.set	noreorder
	.set	nomacro
	j	.L524
	sh	$0,0($10)
	.set	macro
	.set	reorder

.L523:
	addu	$10,$10,2
	addu	$5,$5,8
	addu	$4,$4,1
	slt	$2,$4,6
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L520
	addu	$3,$3,12
	.set	macro
	.set	reorder

.L524:
	.set	noreorder
	.set	nomacro
	j	$31
	li	$2,0x00000001		# 1
	.set	macro
	.set	reorder

	.end	func_8006288C
.Lfe115:
	.size	 func_8006288C,.Lfe115-func_8006288C
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8006295C.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_80062FEC
	.type	 func_80062FEC,@function
	.ent	func_80062FEC
func_80062FEC:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	li	$2,0x00000001		# 1
	sw	$2,D_800F10F0
	move	$6,$0
	li	$5,0x00000001		# 1
.L527:
	lw	$4,D_800A3448
	sll	$3,$5,$6
	and	$2,$4,$3
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L530
	or	$2,$4,$3
	.set	macro
	.set	reorder

	sw	$2,D_800A3448
	.set	noreorder
	.set	nomacro
	j	.L538
	sll	$5,$6,1
	.set	macro
	.set	reorder

.L530:
	addu	$6,$6,1
	slt	$2,$6,12
	bne	$2,$0,.L527
	sll	$5,$6,1
.L538:
	lw	$4,D_800A347C
	addu	$3,$5,$6
	lw	$2,0($4)
	sll	$3,$3,2
	sw	$2,D_800F0E38($3)
	lw	$2,4($4)
	#nop
	sw	$2,D_800F0E3C($3)
	lw	$2,8($4)
	#nop
	sw	$2,D_800F0E40($3)
	sh	$0,D_800F0BEC($5)
	.set	noreorder
	.set	nomacro
	j	$31
	li	$2,0x00000001		# 1
	.set	macro
	.set	reorder

	.end	func_80062FEC
.Lfe116:
	.size	 func_80062FEC,.Lfe116-func_80062FEC
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80063084.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_80063AF0
	.type	 func_80063AF0,@function
	.ent	func_80063AF0
func_80063AF0:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	lw	$3,D_800A3468
	li	$2,0x00000001		# 1
	sw	$31,16($sp)
	sw	$2,D_800F10D0
	lw	$2,0($3)
	#nop
	sra	$2,$2,17
	andi	$2,$2,0x0003
	sh	$2,D_800A345C
	.set	noreorder
	.set	nomacro
	jal	func_80063BD0
	move	$4,$0
	.set	macro
	.set	reorder

	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80063AF0
.Lfe117:
	.size	 func_80063AF0,.Lfe117-func_80063AF0
	.align	2
	.globl	func_80063B34
	.type	 func_80063B34,@function
	.ent	func_80063B34
func_80063B34:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	lw	$3,D_800A3468
	li	$2,0x00000001		# 1
	sw	$31,16($sp)
	sw	$2,D_800F10D4
	lw	$2,0($3)
	#nop
	sra	$2,$2,17
	andi	$2,$2,0x0003
	sh	$2,D_800A345E
	.set	noreorder
	.set	nomacro
	jal	func_80063BD0
	li	$4,0x00000001		# 1
	.set	macro
	.set	reorder

	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80063B34
.Lfe118:
	.size	 func_80063B34,.Lfe118-func_80063B34
	.align	2
	.globl	func_80063B78
	.type	 func_80063B78,@function
	.ent	func_80063B78
func_80063B78:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	lw	$3,D_800A3480
	lh	$2,D_800A345C
	move	$4,$0
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80063E10
	sw	$2,0($3)
	.set	macro
	.set	reorder

	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80063B78
.Lfe119:
	.size	 func_80063B78,.Lfe119-func_80063B78
	.align	2
	.globl	func_80063BA4
	.type	 func_80063BA4,@function
	.ent	func_80063BA4
func_80063BA4:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	lw	$3,D_800A3480
	lh	$2,D_800A345E
	li	$4,0x00000001		# 1
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80063E10
	sw	$2,0($3)
	.set	macro
	.set	reorder

	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80063BA4
.Lfe120:
	.size	 func_80063BA4,.Lfe120-func_80063BA4
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80063BD0.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80063E10.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_800644FC.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_800645B0.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_800646E8.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_80064E90
	.type	 func_80064E90,@function
	.ent	func_80064E90
func_80064E90:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$3,D_800A347C
	#nop
	lw	$2,0($3)
	#nop
	sw	$2,D_800F0CA0
	lw	$2,4($3)
	#nop
	sw	$2,D_800F0CA4
	lw	$3,8($3)
	li	$2,0x00000001		# 1
	sw	$2,D_800F10E0
	sh	$0,D_800F0BA8
	sw	$3,D_800F0CA8
	j	$31
	.end	func_80064E90
.Lfe121:
	.size	 func_80064E90,.Lfe121-func_80064E90
	.align	2
	.globl	func_80064ED8
	.type	 func_80064ED8,@function
	.ent	func_80064ED8
func_80064ED8:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$3,D_800A347C
	#nop
	lw	$2,0($3)
	#nop
	sw	$2,D_800F0CAC
	lw	$2,4($3)
	#nop
	sw	$2,D_800F0CB0
	lw	$3,8($3)
	li	$2,0x00000001		# 1
	sw	$2,D_800F10E4
	sh	$0,D_800F0BAA
	sw	$3,D_800F0CB4
	j	$31
	.end	func_80064ED8
.Lfe122:
	.size	 func_80064ED8,.Lfe122-func_80064ED8
	.align	2
	.globl	func_80064F20
	.type	 func_80064F20,@function
	.ent	func_80064F20
func_80064F20:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$3,D_800A347C
	#nop
	lw	$2,0($3)
	#nop
	sw	$2,D_800F0CB8
	lw	$2,4($3)
	#nop
	sw	$2,D_800F0CBC
	lw	$3,8($3)
	li	$2,0x00000001		# 1
	sw	$2,D_800F10E8
	sh	$0,D_800F0BAC
	sw	$3,D_800F0CC0
	j	$31
	.end	func_80064F20
.Lfe123:
	.size	 func_80064F20,.Lfe123-func_80064F20
	.align	2
	.globl	func_80064F68
	.type	 func_80064F68,@function
	.ent	func_80064F68
func_80064F68:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$3,D_800A347C
	#nop
	lw	$2,0($3)
	#nop
	sw	$2,D_800F0CC4
	lw	$2,4($3)
	#nop
	sw	$2,D_800F0CC8
	lw	$3,8($3)
	li	$2,0x00000001		# 1
	sw	$2,D_800F10F4
	li	$2,0x00000040		# 64
	sh	$2,D_800F0BAE
	sw	$3,D_800F0CCC
	.set	noreorder
	.set	nomacro
	j	$31
	li	$2,0x00000001		# 1
	.set	macro
	.set	reorder

	.end	func_80064F68
.Lfe124:
	.size	 func_80064F68,.Lfe124-func_80064F68
	.align	2
	.globl	func_80064FB4
	.type	 func_80064FB4,@function
	.ent	func_80064FB4
func_80064FB4:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$3,D_800A347C
	#nop
	lw	$2,0($3)
	#nop
	sw	$2,D_800F0CD0
	lw	$2,4($3)
	#nop
	sw	$2,D_800F0CD4
	lw	$3,8($3)
	li	$2,0x00000001		# 1
	sw	$2,D_800F10F8
	li	$2,0x00000040		# 64
	sh	$2,D_800F0BB0
	sw	$3,D_800F0CD8
	.set	noreorder
	.set	nomacro
	j	$31
	li	$2,0x00000001		# 1
	.set	macro
	.set	reorder

	.end	func_80064FB4
.Lfe125:
	.size	 func_80064FB4,.Lfe125-func_80064FB4
	.align	2
	.globl	func_80065000
	.type	 func_80065000,@function
	.ent	func_80065000
func_80065000:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$3,D_800A347C
	lw	$4,D_800A3468
	lw	$2,0($3)
	#nop
	sw	$2,D_800F0CDC
	lw	$2,4($3)
	#nop
	sw	$2,D_800F0CE0
	lw	$3,8($3)
	li	$2,0x00000001		# 1
	sw	$2,D_800F10FC
	sh	$0,D_800F0BB2
	sw	$3,D_800F0CE4
	lw	$2,0($4)
	#nop
	sra	$2,$2,19
	andi	$2,$2,0x0003
	sh	$2,D_800A3440
	.set	noreorder
	.set	nomacro
	j	$31
	li	$2,0x00000001		# 1
	.set	macro
	.set	reorder

	.end	func_80065000
.Lfe126:
	.size	 func_80065000,.Lfe126-func_80065000
	.align	2
	.globl	func_8006505C
	.type	 func_8006505C,@function
	.ent	func_8006505C
func_8006505C:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$3,D_800A347C
	#nop
	lw	$2,0($3)
	#nop
	sw	$2,D_800F0CE8
	lw	$2,4($3)
	#nop
	sw	$2,D_800F0CEC
	lw	$3,8($3)
	li	$2,0x00000001		# 1
	sw	$2,D_800F1100
	sh	$0,D_800F0BB4
	sw	$3,D_800F0CF0
	j	$31
	.end	func_8006505C
.Lfe127:
	.size	 func_8006505C,.Lfe127-func_8006505C
	.align	2
	.globl	func_800650A4
	.type	 func_800650A4,@function
	.ent	func_800650A4
func_800650A4:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$3,D_800A347C
	#nop
	lw	$2,0($3)
	#nop
	sw	$2,D_800F0CF4
	lw	$2,4($3)
	#nop
	sw	$2,D_800F0CF8
	lw	$3,8($3)
	li	$2,0x00000001		# 1
	sw	$2,D_800F1104
	sh	$0,D_800F0BB6
	sw	$3,D_800F0CFC
	j	$31
	.end	func_800650A4
.Lfe128:
	.size	 func_800650A4,.Lfe128-func_800650A4
	.align	2
	.globl	func_800650EC
	.type	 func_800650EC,@function
	.ent	func_800650EC
func_800650EC:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$3,D_800A347C
	#nop
	lw	$2,0($3)
	#nop
	sw	$2,D_800F0D18
	lw	$2,4($3)
	#nop
	sw	$2,D_800F0D1C
	lw	$3,8($3)
	li	$2,0x00000001		# 1
	sw	$2,D_800F1108
	sh	$0,D_800F0BBC
	sw	$3,D_800F0D20
	j	$31
	.end	func_800650EC
.Lfe129:
	.size	 func_800650EC,.Lfe129-func_800650EC
	.align	2
	.globl	func_80065134
	.type	 func_80065134,@function
	.ent	func_80065134
func_80065134:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$3,D_800A347C
	#nop
	lw	$2,0($3)
	#nop
	sw	$2,D_800F0D24
	lw	$2,4($3)
	#nop
	sw	$2,D_800F0D28
	lw	$3,8($3)
	li	$2,0x00000001		# 1
	sw	$2,D_800F110C
	sh	$0,D_800F0BBE
	sw	$3,D_800F0D2C
	j	$31
	.end	func_80065134
.Lfe130:
	.size	 func_80065134,.Lfe130-func_80065134
	.align	2
	.globl	func_8006517C
	.type	 func_8006517C,@function
	.ent	func_8006517C
func_8006517C:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$3,D_800A347C
	#nop
	lw	$2,0($3)
	#nop
	sw	$2,D_800F0D30
	lw	$2,4($3)
	#nop
	sw	$2,D_800F0D34
	lw	$2,8($3)
	sh	$0,D_800F0BC0
	sw	$2,D_800F0D38
	lw	$2,0($3)
	#nop
	sw	$2,D_800F0D48
	lw	$2,4($3)
	#nop
	sw	$2,D_800F0D4C
	lw	$3,8($3)
	li	$2,0x00000001		# 1
	sw	$2,D_800F1110
	sh	$0,D_800F0BC4
	sw	$3,D_800F0D50
	j	$31
	.end	func_8006517C
.Lfe131:
	.size	 func_8006517C,.Lfe131-func_8006517C
	.align	2
	.globl	func_800651F0
	.type	 func_800651F0,@function
	.ent	func_800651F0
func_800651F0:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$3,D_800A347C
	#nop
	lw	$2,0($3)
	#nop
	sw	$2,D_800F0D3C
	lw	$2,4($3)
	#nop
	sw	$2,D_800F0D40
	lw	$2,8($3)
	sh	$0,D_800F0BC2
	sw	$2,D_800F0D44
	lw	$2,0($3)
	#nop
	sw	$2,D_800F0D54
	lw	$2,4($3)
	#nop
	sw	$2,D_800F0D58
	lw	$3,8($3)
	li	$2,0x00000001		# 1
	sw	$2,D_800F1114
	sh	$0,D_800F0BC6
	sw	$3,D_800F0D5C
	j	$31
	.end	func_800651F0
.Lfe132:
	.size	 func_800651F0,.Lfe132-func_800651F0
	.align	2
	.globl	func_80065264
	.type	 func_80065264,@function
	.ent	func_80065264
func_80065264:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$3,D_800A347C
	#nop
	lw	$2,0($3)
	#nop
	sw	$2,D_800F0D60
	lw	$2,4($3)
	#nop
	sw	$2,D_800F0D64
	lw	$3,8($3)
	li	$2,0x00000001		# 1
	sw	$2,D_800F1118
	sh	$0,D_800F0BC8
	sw	$3,D_800F0D68
	j	$31
	.end	func_80065264
.Lfe133:
	.size	 func_80065264,.Lfe133-func_80065264
	.align	2
	.globl	func_800652AC
	.type	 func_800652AC,@function
	.ent	func_800652AC
func_800652AC:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$3,D_800A347C
	#nop
	lw	$2,0($3)
	#nop
	sw	$2,D_800F0D6C
	lw	$2,4($3)
	#nop
	sw	$2,D_800F0D70
	lw	$3,8($3)
	li	$2,0x00000001		# 1
	sw	$2,D_800F111C
	sh	$0,D_800F0BCA
	sw	$3,D_800F0D74
	j	$31
	.end	func_800652AC
.Lfe134:
	.size	 func_800652AC,.Lfe134-func_800652AC
	.align	2
	.globl	func_800652F4
	.type	 func_800652F4,@function
	.ent	func_800652F4
func_800652F4:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80065800
	move	$4,$0
	.set	macro
	.set	reorder

	la	$4,D_800F0BA8
	lhu	$3,0($4)
	#nop
	addu	$3,$3,511
	sh	$3,0($4)
	sll	$3,$3,16
	sra	$3,$3,16
	slt	$3,$3,4097
	.set	noreorder
	.set	nomacro
	bne	$3,$0,.L558
	andi	$2,$2,0x00ff
	.set	macro
	.set	reorder

	move	$2,$0
.L558:
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_800652F4
.Lfe135:
	.size	 func_800652F4,.Lfe135-func_800652F4
	.align	2
	.globl	func_80065344
	.type	 func_80065344,@function
	.ent	func_80065344
func_80065344:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80065800
	li	$4,0x00000001		# 1
	.set	macro
	.set	reorder

	la	$4,D_800F0BAA
	lhu	$3,0($4)
	#nop
	addu	$3,$3,454
	sh	$3,0($4)
	sll	$3,$3,16
	sra	$3,$3,16
	slt	$3,$3,4552
	.set	noreorder
	.set	nomacro
	bne	$3,$0,.L561
	andi	$2,$2,0x00ff
	.set	macro
	.set	reorder

	move	$2,$0
.L561:
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80065344
.Lfe136:
	.size	 func_80065344,.Lfe136-func_80065344
	.align	2
	.globl	func_80065394
	.type	 func_80065394,@function
	.ent	func_80065394
func_80065394:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80065800
	li	$4,0x00000002		# 2
	.set	macro
	.set	reorder

	la	$4,D_800F0BAC
	lhu	$3,0($4)
	#nop
	addu	$3,$3,454
	sh	$3,0($4)
	sll	$3,$3,16
	sra	$3,$3,16
	slt	$3,$3,4552
	.set	noreorder
	.set	nomacro
	bne	$3,$0,.L564
	andi	$2,$2,0x00ff
	.set	macro
	.set	reorder

	move	$2,$0
.L564:
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80065394
.Lfe137:
	.size	 func_80065394,.Lfe137-func_80065394
	.align	2
	.globl	func_800653E4
	.type	 func_800653E4,@function
	.ent	func_800653E4
func_800653E4:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80065800
	li	$4,0x00000003		# 3
	.set	macro
	.set	reorder

	la	$4,D_800F0BAE
	lhu	$3,0($4)
	#nop
	addu	$3,$3,25
	sh	$3,0($4)
	sll	$3,$3,16
	sra	$3,$3,16
	slt	$3,$3,201
	.set	noreorder
	.set	nomacro
	bne	$3,$0,.L567
	andi	$2,$2,0x00ff
	.set	macro
	.set	reorder

	move	$2,$0
.L567:
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_800653E4
.Lfe138:
	.size	 func_800653E4,.Lfe138-func_800653E4
	.align	2
	.globl	func_80065434
	.type	 func_80065434,@function
	.ent	func_80065434
func_80065434:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80065800
	li	$4,0x00000004		# 4
	.set	macro
	.set	reorder

	la	$4,D_800F0BB0
	lhu	$3,0($4)
	#nop
	addu	$3,$3,25
	sh	$3,0($4)
	sll	$3,$3,16
	sra	$3,$3,16
	slt	$3,$3,201
	.set	noreorder
	.set	nomacro
	bne	$3,$0,.L570
	andi	$2,$2,0x00ff
	.set	macro
	.set	reorder

	move	$2,$0
.L570:
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80065434
.Lfe139:
	.size	 func_80065434,.Lfe139-func_80065434
	.align	2
	.globl	func_80065484
	.type	 func_80065484,@function
	.ent	func_80065484
func_80065484:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	lw	$3,D_800A3484
	lh	$2,D_800A3440
	li	$4,0x00000005		# 5
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80065800
	sw	$2,0($3)
	.set	macro
	.set	reorder

	lw	$3,D_800A3484
	move	$4,$2
	lw	$3,0($3)
	li	$2,0x00000001		# 1
	beq	$3,$2,.L575
	beq	$3,$0,.L574
	li	$2,0x00000002		# 2
	beq	$3,$2,.L576
	j	.L573
.L574:
	la	$3,D_800F0BB2
	lhu	$2,0($3)
	.set	noreorder
	.set	nomacro
	j	.L581
	addu	$2,$2,511
	.set	macro
	.set	reorder

.L575:
	la	$3,D_800F0BB2
	lhu	$2,0($3)
	.set	noreorder
	.set	nomacro
	j	.L581
	addu	$2,$2,1022
	.set	macro
	.set	reorder

.L576:
	la	$3,D_800F0BB2
	lhu	$2,0($3)
	#nop
	addu	$2,$2,1533
.L581:
	sh	$2,0($3)
.L573:
	lh	$2,D_800F0BB2
	#nop
	slt	$2,$2,8193
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L579
	andi	$2,$4,0x00ff
	.set	macro
	.set	reorder

	move	$2,$0
.L579:
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80065484
.Lfe140:
	.size	 func_80065484,.Lfe140-func_80065484
	.align	2
	.globl	func_80065540
	.type	 func_80065540,@function
	.ent	func_80065540
func_80065540:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80065800
	li	$4,0x00000006		# 6
	.set	macro
	.set	reorder

	la	$4,D_800F0BB4
	lhu	$3,0($4)
	#nop
	addu	$3,$3,50
	sh	$3,0($4)
	sll	$3,$3,16
	sra	$3,$3,16
	slt	$3,$3,256
	.set	noreorder
	.set	nomacro
	bne	$3,$0,.L583
	andi	$2,$2,0x00ff
	.set	macro
	.set	reorder

	move	$2,$0
.L583:
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80065540
.Lfe141:
	.size	 func_80065540,.Lfe141-func_80065540
	.align	2
	.globl	func_80065590
	.type	 func_80065590,@function
	.ent	func_80065590
func_80065590:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80065800
	li	$4,0x00000007		# 7
	.set	macro
	.set	reorder

	la	$4,D_800F0BB6
	lhu	$3,0($4)
	#nop
	addu	$3,$3,50
	sh	$3,0($4)
	sll	$3,$3,16
	sra	$3,$3,16
	slt	$3,$3,256
	.set	noreorder
	.set	nomacro
	bne	$3,$0,.L586
	andi	$2,$2,0x00ff
	.set	macro
	.set	reorder

	move	$2,$0
.L586:
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80065590
.Lfe142:
	.size	 func_80065590,.Lfe142-func_80065590
	.align	2
	.globl	func_800655E0
	.type	 func_800655E0,@function
	.ent	func_800655E0
func_800655E0:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80065800
	li	$4,0x0000000a		# 10
	.set	macro
	.set	reorder

	la	$4,D_800F0BBC
	lhu	$3,0($4)
	#nop
	addu	$3,$3,50
	sh	$3,0($4)
	sll	$3,$3,16
	sra	$3,$3,16
	slt	$3,$3,256
	.set	noreorder
	.set	nomacro
	bne	$3,$0,.L589
	andi	$2,$2,0x00ff
	.set	macro
	.set	reorder

	move	$2,$0
.L589:
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_800655E0
.Lfe143:
	.size	 func_800655E0,.Lfe143-func_800655E0
	.align	2
	.globl	func_80065630
	.type	 func_80065630,@function
	.ent	func_80065630
func_80065630:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80065800
	li	$4,0x0000000b		# 11
	.set	macro
	.set	reorder

	la	$4,D_800F0BBE
	lhu	$3,0($4)
	#nop
	addu	$3,$3,50
	sh	$3,0($4)
	sll	$3,$3,16
	sra	$3,$3,16
	slt	$3,$3,256
	.set	noreorder
	.set	nomacro
	bne	$3,$0,.L592
	andi	$2,$2,0x00ff
	.set	macro
	.set	reorder

	move	$2,$0
.L592:
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80065630
.Lfe144:
	.size	 func_80065630,.Lfe144-func_80065630
	.align	2
	.globl	func_80065680
	.type	 func_80065680,@function
	.ent	func_80065680
func_80065680:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80065800
	li	$4,0x0000000c		# 12
	.set	macro
	.set	reorder

	la	$3,D_800F0BC0
	lhu	$2,0($3)
	li	$4,0x0000000e		# 14
	addu	$2,$2,1
	.set	noreorder
	.set	nomacro
	jal	func_80065800
	sh	$2,0($3)
	.set	macro
	.set	reorder

	lhu	$3,D_800F0BC4
	#nop
	addu	$3,$3,1
	sh	$3,D_800F0BC4
	sll	$3,$3,16
	sra	$3,$3,16
	slt	$3,$3,11
	.set	noreorder
	.set	nomacro
	bne	$3,$0,.L595
	andi	$2,$2,0x00ff
	.set	macro
	.set	reorder

	move	$2,$0
.L595:
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80065680
.Lfe145:
	.size	 func_80065680,.Lfe145-func_80065680
	.align	2
	.globl	func_800656EC
	.type	 func_800656EC,@function
	.ent	func_800656EC
func_800656EC:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	li	$4,0x0000000d		# 13
	sw	$31,20($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80065800
	sw	$16,16($sp)
	.set	macro
	.set	reorder

	la	$16,D_800F0BC2
	lhu	$2,0($16)
	li	$4,0x0000000f		# 15
	addu	$2,$2,1
	.set	noreorder
	.set	nomacro
	jal	func_80065800
	sh	$2,0($16)
	.set	macro
	.set	reorder

	lhu	$3,D_800F0BC6
	#nop
	addu	$3,$3,1
	sh	$3,D_800F0BC6
	lh	$3,0($16)
	#nop
	slt	$3,$3,11
	.set	noreorder
	.set	nomacro
	bne	$3,$0,.L598
	andi	$2,$2,0x00ff
	.set	macro
	.set	reorder

	move	$2,$0
.L598:
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_800656EC
.Lfe146:
	.size	 func_800656EC,.Lfe146-func_800656EC
	.align	2
	.globl	func_80065760
	.type	 func_80065760,@function
	.ent	func_80065760
func_80065760:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80065800
	li	$4,0x00000010		# 16
	.set	macro
	.set	reorder

	la	$4,D_800F0BC8
	lhu	$3,0($4)
	#nop
	addu	$3,$3,454
	sh	$3,0($4)
	sll	$3,$3,16
	sra	$3,$3,16
	slt	$3,$3,4552
	.set	noreorder
	.set	nomacro
	bne	$3,$0,.L601
	andi	$2,$2,0x00ff
	.set	macro
	.set	reorder

	move	$2,$0
.L601:
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80065760
.Lfe147:
	.size	 func_80065760,.Lfe147-func_80065760
	.align	2
	.globl	func_800657B0
	.type	 func_800657B0,@function
	.ent	func_800657B0
func_800657B0:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80065800
	li	$4,0x00000011		# 17
	.set	macro
	.set	reorder

	la	$4,D_800F0BCA
	lhu	$3,0($4)
	#nop
	addu	$3,$3,454
	sh	$3,0($4)
	sll	$3,$3,16
	sra	$3,$3,16
	slt	$3,$3,4552
	.set	noreorder
	.set	nomacro
	bne	$3,$0,.L604
	andi	$2,$2,0x00ff
	.set	macro
	.set	reorder

	move	$2,$0
.L604:
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_800657B0
.Lfe148:
	.size	 func_800657B0,.Lfe148-func_800657B0
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80065800.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_80066EC0
	.type	 func_80066EC0,@function
	.ent	func_80066EC0
func_80066EC0:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	move	$4,$0
	move	$5,$0
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80067200
	move	$6,$0
	.set	macro
	.set	reorder

	li	$3,0x00000001		# 1
	sw	$3,D_800F10D8
	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80066EC0
.Lfe149:
	.size	 func_80066EC0,.Lfe149-func_80066EC0
	.align	2
	.globl	func_80066EF4
	.type	 func_80066EF4,@function
	.ent	func_80066EF4
func_80066EF4:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	move	$4,$0
	move	$5,$0
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80067200
	li	$6,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$3,0x00000002		# 2
	sw	$3,D_800F10D8
	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80066EF4
.Lfe150:
	.size	 func_80066EF4,.Lfe150-func_80066EF4
	.align	2
	.globl	func_80066F28
	.type	 func_80066F28,@function
	.ent	func_80066F28
func_80066F28:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	li	$4,0x00000001		# 1
	li	$5,0x00000001		# 1
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80067200
	move	$6,$0
	.set	macro
	.set	reorder

	li	$3,0x00000001		# 1
	sw	$3,D_800F10DC
	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80066F28
.Lfe151:
	.size	 func_80066F28,.Lfe151-func_80066F28
	.align	2
	.globl	func_80066F5C
	.type	 func_80066F5C,@function
	.ent	func_80066F5C
func_80066F5C:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	li	$4,0x00000001		# 1
	li	$5,0x00000001		# 1
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80067200
	li	$6,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$3,0x00000002		# 2
	sw	$3,D_800F10DC
	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80066F5C
.Lfe152:
	.size	 func_80066F5C,.Lfe152-func_80066F5C
	.align	2
	.globl	func_80066F90
	.type	 func_80066F90,@function
	.ent	func_80066F90
func_80066F90:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	li	$4,0x00000002		# 2
	li	$5,0x00000001		# 1
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80067200
	move	$6,$0
	.set	macro
	.set	reorder

	li	$3,0x00000001		# 1
	sw	$3,D_800F1120
	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80066F90
.Lfe153:
	.size	 func_80066F90,.Lfe153-func_80066F90
	.align	2
	.globl	func_80066FC4
	.type	 func_80066FC4,@function
	.ent	func_80066FC4
func_80066FC4:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	li	$4,0x00000002		# 2
	li	$5,0x00000001		# 1
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80067200
	li	$6,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$3,0x00000002		# 2
	sw	$3,D_800F1120
	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80066FC4
.Lfe154:
	.size	 func_80066FC4,.Lfe154-func_80066FC4
	.align	2
	.globl	func_80066FF8
	.type	 func_80066FF8,@function
	.ent	func_80066FF8
func_80066FF8:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	li	$4,0x00000003		# 3
	move	$5,$0
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80067200
	move	$6,$0
	.set	macro
	.set	reorder

	li	$3,0x00000001		# 1
	sw	$3,D_800F1124
	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80066FF8
.Lfe155:
	.size	 func_80066FF8,.Lfe155-func_80066FF8
	.align	2
	.globl	func_8006702C
	.type	 func_8006702C,@function
	.ent	func_8006702C
func_8006702C:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	li	$4,0x00000003		# 3
	move	$5,$0
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80067200
	li	$6,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$3,0x00000002		# 2
	sw	$3,D_800F1124
	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_8006702C
.Lfe156:
	.size	 func_8006702C,.Lfe156-func_8006702C
	.align	2
	.globl	func_80067060
	.type	 func_80067060,@function
	.ent	func_80067060
func_80067060:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	li	$4,0x00000004		# 4
	li	$5,0x00000002		# 2
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80067200
	move	$6,$0
	.set	macro
	.set	reorder

	li	$3,0x00000001		# 1
	sw	$3,D_800F1128
	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80067060
.Lfe157:
	.size	 func_80067060,.Lfe157-func_80067060
	.align	2
	.globl	func_80067094
	.type	 func_80067094,@function
	.ent	func_80067094
func_80067094:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	li	$4,0x00000004		# 4
	li	$5,0x00000002		# 2
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80067200
	li	$6,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$3,0x00000002		# 2
	sw	$3,D_800F1128
	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80067094
.Lfe158:
	.size	 func_80067094,.Lfe158-func_80067094
	.align	2
	.globl	func_800670C8
	.type	 func_800670C8,@function
	.ent	func_800670C8
func_800670C8:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	li	$4,0x00000005		# 5
	li	$5,0x00000003		# 3
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80067200
	move	$6,$0
	.set	macro
	.set	reorder

	li	$3,0x00000001		# 1
	sw	$3,D_800F112C
	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_800670C8
.Lfe159:
	.size	 func_800670C8,.Lfe159-func_800670C8
	.align	2
	.globl	func_800670FC
	.type	 func_800670FC,@function
	.ent	func_800670FC
func_800670FC:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	li	$4,0x00000005		# 5
	li	$5,0x00000003		# 3
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80067200
	li	$6,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$3,0x00000002		# 2
	sw	$3,D_800F112C
	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_800670FC
.Lfe160:
	.size	 func_800670FC,.Lfe160-func_800670FC
	.align	2
	.globl	func_80067130
	.type	 func_80067130,@function
	.ent	func_80067130
func_80067130:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	li	$4,0x00000006		# 6
	li	$5,0x00000003		# 3
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80067200
	move	$6,$0
	.set	macro
	.set	reorder

	li	$3,0x00000001		# 1
	sw	$3,D_800F1130
	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80067130
.Lfe161:
	.size	 func_80067130,.Lfe161-func_80067130
	.align	2
	.globl	func_80067164
	.type	 func_80067164,@function
	.ent	func_80067164
func_80067164:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	li	$4,0x00000006		# 6
	li	$5,0x00000003		# 3
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80067200
	li	$6,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$3,0x00000002		# 2
	sw	$3,D_800F1130
	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80067164
.Lfe162:
	.size	 func_80067164,.Lfe162-func_80067164
	.align	2
	.globl	func_80067198
	.type	 func_80067198,@function
	.ent	func_80067198
func_80067198:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	li	$4,0x00000007		# 7
	li	$5,0x00000002		# 2
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80067200
	move	$6,$0
	.set	macro
	.set	reorder

	li	$3,0x00000001		# 1
	sw	$3,D_800F1134
	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80067198
.Lfe163:
	.size	 func_80067198,.Lfe163-func_80067198
	.align	2
	.globl	func_800671CC
	.type	 func_800671CC,@function
	.ent	func_800671CC
func_800671CC:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	li	$4,0x00000007		# 7
	li	$5,0x00000002		# 2
	sw	$31,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80067200
	li	$6,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$3,0x00000002		# 2
	sw	$3,D_800F1134
	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_800671CC
.Lfe164:
	.size	 func_800671CC,.Lfe164-func_800671CC
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80067200.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_800676C8
	.type	 func_800676C8,@function
	.ent	func_800676C8
func_800676C8:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	move	$4,$0
	.set	noreorder
	.set	nomacro
	jal	func_800678A8
	move	$5,$0
	.set	macro
	.set	reorder

	move	$4,$0
	.set	noreorder
	.set	nomacro
	jal	func_80067D14
	move	$5,$0
	.set	macro
	.set	reorder

	move	$4,$0
	.set	noreorder
	.set	nomacro
	jal	func_80068D88
	move	$5,$0
	.set	macro
	.set	reorder

	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_800676C8
.Lfe165:
	.size	 func_800676C8,.Lfe165-func_800676C8
	.align	2
	.globl	func_80067704
	.type	 func_80067704,@function
	.ent	func_80067704
func_80067704:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	li	$4,0x00000001		# 1
	.set	noreorder
	.set	nomacro
	jal	func_800678A8
	li	$5,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$4,0x00000001		# 1
	.set	noreorder
	.set	nomacro
	jal	func_80067D14
	li	$5,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$4,0x00000001		# 1
	.set	noreorder
	.set	nomacro
	jal	func_80068D88
	li	$5,0x00000001		# 1
	.set	macro
	.set	reorder

	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80067704
.Lfe166:
	.size	 func_80067704,.Lfe166-func_80067704
	.align	2
	.globl	func_80067740
	.type	 func_80067740,@function
	.ent	func_80067740
func_80067740:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	li	$4,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	jal	func_800678A8
	li	$5,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$4,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	jal	func_80067D14
	li	$5,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$4,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	jal	func_80068D88
	li	$5,0x00000001		# 1
	.set	macro
	.set	reorder

	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80067740
.Lfe167:
	.size	 func_80067740,.Lfe167-func_80067740
	.align	2
	.globl	func_8006777C
	.type	 func_8006777C,@function
	.ent	func_8006777C
func_8006777C:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	li	$4,0x00000003		# 3
	.set	noreorder
	.set	nomacro
	jal	func_800678A8
	move	$5,$0
	.set	macro
	.set	reorder

	li	$4,0x00000003		# 3
	.set	noreorder
	.set	nomacro
	jal	func_80067D14
	move	$5,$0
	.set	macro
	.set	reorder

	li	$4,0x00000003		# 3
	.set	noreorder
	.set	nomacro
	jal	func_80068D88
	move	$5,$0
	.set	macro
	.set	reorder

	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_8006777C
.Lfe168:
	.size	 func_8006777C,.Lfe168-func_8006777C
	.align	2
	.globl	func_800677B8
	.type	 func_800677B8,@function
	.ent	func_800677B8
func_800677B8:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	li	$4,0x00000004		# 4
	.set	noreorder
	.set	nomacro
	jal	func_800678A8
	li	$5,0x00000002		# 2
	.set	macro
	.set	reorder

	li	$4,0x00000004		# 4
	.set	noreorder
	.set	nomacro
	jal	func_80067D14
	li	$5,0x00000002		# 2
	.set	macro
	.set	reorder

	li	$4,0x00000004		# 4
	.set	noreorder
	.set	nomacro
	jal	func_80068D88
	li	$5,0x00000002		# 2
	.set	macro
	.set	reorder

	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_800677B8
.Lfe169:
	.size	 func_800677B8,.Lfe169-func_800677B8
	.align	2
	.globl	func_800677F4
	.type	 func_800677F4,@function
	.ent	func_800677F4
func_800677F4:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	li	$4,0x00000005		# 5
	.set	noreorder
	.set	nomacro
	jal	func_800678A8
	li	$5,0x00000003		# 3
	.set	macro
	.set	reorder

	li	$4,0x00000005		# 5
	.set	noreorder
	.set	nomacro
	jal	func_80067D14
	li	$5,0x00000003		# 3
	.set	macro
	.set	reorder

	li	$4,0x00000005		# 5
	.set	noreorder
	.set	nomacro
	jal	func_80068D88
	li	$5,0x00000003		# 3
	.set	macro
	.set	reorder

	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_800677F4
.Lfe170:
	.size	 func_800677F4,.Lfe170-func_800677F4
	.align	2
	.globl	func_80067830
	.type	 func_80067830,@function
	.ent	func_80067830
func_80067830:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	li	$4,0x00000006		# 6
	.set	noreorder
	.set	nomacro
	jal	func_800678A8
	li	$5,0x00000003		# 3
	.set	macro
	.set	reorder

	li	$4,0x00000006		# 6
	.set	noreorder
	.set	nomacro
	jal	func_80067D14
	li	$5,0x00000003		# 3
	.set	macro
	.set	reorder

	li	$4,0x00000006		# 6
	.set	noreorder
	.set	nomacro
	jal	func_80068D88
	li	$5,0x00000003		# 3
	.set	macro
	.set	reorder

	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80067830
.Lfe171:
	.size	 func_80067830,.Lfe171-func_80067830
	.align	2
	.globl	func_8006786C
	.type	 func_8006786C,@function
	.ent	func_8006786C
func_8006786C:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	li	$4,0x00000007		# 7
	.set	noreorder
	.set	nomacro
	jal	func_800678A8
	li	$5,0x00000002		# 2
	.set	macro
	.set	reorder

	li	$4,0x00000007		# 7
	.set	noreorder
	.set	nomacro
	jal	func_80067D14
	li	$5,0x00000002		# 2
	.set	macro
	.set	reorder

	li	$4,0x00000007		# 7
	.set	noreorder
	.set	nomacro
	jal	func_80068D88
	li	$5,0x00000002		# 2
	.set	macro
	.set	reorder

	.set	noreorder
	lw	$31,16($sp)
	andi	$2,$2,0x00ff
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_8006786C
.Lfe172:
	.size	 func_8006786C,.Lfe172-func_8006786C
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_800678A8.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80067D14.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_80068D88
	.type	 func_80068D88,@function
	.ent	func_80068D88
func_80068D88:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$4,D_800A34EC
	lw	$7,D_800A37D4
	addu	$2,$4,428
	addu	$8,$4,110
	addu	$10,$4,124
	addu	$6,$4,128
	sw	$2,D_800A3724
	lw	$5,128($4)
	#nop
	subu	$3,$5,$7
	sll	$2,$3,1
	addu	$2,$2,$3
	sll	$3,$2,4
	addu	$2,$2,$3
	sll	$3,$2,8
	addu	$2,$2,$3
	sll	$3,$2,16
	addu	$2,$2,$3
	subu	$2,$0,$2
	sra	$2,$2,3
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L631
	addu	$12,$4,140
	.set	macro
	.set	reorder

	sw	$7,128($4)
	lw	$2,128($4)
	sw	$5,124($4)
	lw	$3,124($4)
	li	$11,0x00000001		# 1
	sltu	$2,$2,$3
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L632
	sh	$0,110($4)
	.set	macro
	.set	reorder

	li	$9,-16777216			# 0xff000000
	li	$7,0x00ff0000		# 16711680
	ori	$7,$7,0xffff
.L633:
	lh	$2,0($8)
	#nop
	sll	$2,$2,1
	addu	$2,$2,$12
	lhu	$2,0($2)
	lw	$4,D_800A374C
	sll	$2,$2,2
	addu	$4,$4,$2
	sw	$4,D_800A34E4
	lw	$5,0($6)
	#nop
	sw	$5,D_800A34E8
	lw	$3,0($5)
	lw	$2,0($4)
	and	$3,$3,$9
	and	$2,$2,$7
	or	$3,$3,$2
	sw	$3,0($5)
	lw	$4,D_800A34E4
	lw	$3,D_800A34E8
	lw	$2,0($4)
	and	$3,$3,$7
	and	$2,$2,$9
	or	$3,$3,$2
	sw	$3,0($4)
	lw	$2,0($6)
	#nop
	addu	$2,$2,40
	sw	$2,0($6)
	lhu	$2,0($8)
	#nop
	addu	$2,$2,1
	sh	$2,0($8)
	lw	$2,0($6)
	lw	$3,0($10)
	#nop
	sltu	$2,$2,$3
	bne	$2,$0,.L633
.L632:
	lw	$2,0($10)
	#nop
	sw	$2,D_800A37D4
	j	.L637
.L631:
	move	$11,$0
.L637:
	.set	noreorder
	.set	nomacro
	j	$31
	move	$2,$11
	.set	macro
	.set	reorder

	.end	func_80068D88
.Lfe173:
	.size	 func_80068D88,.Lfe173-func_80068D88
	.align	2
	.globl	func_80068ECC
	.type	 func_80068ECC,@function
	.ent	func_80068ECC
func_80068ECC:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	la	$5,D_8009BC04
	lw	$2,0($5)
	li	$3,-2			# 0xfffffffe
	and	$2,$2,$3
	andi	$3,$4,0x0001
	or	$2,$2,$3
	li	$3,-3			# 0xfffffffd
	and	$2,$2,$3
	andi	$3,$4,0x0002
	or	$2,$2,$3
	li	$3,-5			# 0xfffffffb
	and	$2,$2,$3
	andi	$3,$4,0x0004
	or	$2,$2,$3
	li	$3,-9			# 0xfffffff7
	and	$2,$2,$3
	srl	$3,$4,1
	andi	$3,$3,0x0008
	or	$2,$2,$3
	li	$3,-17			# 0xffffffef
	and	$2,$2,$3
	srl	$3,$4,1
	andi	$3,$3,0x0010
	or	$2,$2,$3
	li	$3,-33			# 0xffffffdf
	and	$2,$2,$3
	srl	$3,$4,1
	andi	$3,$3,0x0020
	or	$2,$2,$3
	li	$3,-65			# 0xffffffbf
	and	$2,$2,$3
	sll	$3,$4,3
	andi	$3,$3,0x0040
	or	$2,$2,$3
	li	$3,-129			# 0xffffff7f
	and	$2,$2,$3
	andi	$4,$4,0x0080
	or	$2,$2,$4
	.set	noreorder
	.set	nomacro
	j	$31
	sw	$2,0($5)
	.set	macro
	.set	reorder

	.end	func_80068ECC
.Lfe174:
	.size	 func_80068ECC,.Lfe174-func_80068ECC
	.align	2
	.globl	func_80068F70
	.type	 func_80068F70,@function
	.ent	func_80068F70
func_80068F70:
	.frame	$sp,40,$31		# vars= 8, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	sw	$16,24($sp)
	move	$16,$4
	sw	$17,28($sp)
	sw	$16,D_800A3500
	sw	$16,D_800A351C
	addu	$16,$16,88
	sw	$31,32($sp)
	sw	$16,D_800A3500
	.set	noreorder
	.set	nomacro
	jal	snd_StopAll
	move	$17,$5
	.set	macro
	.set	reorder

	lw	$5,D_800A3500
	.set	noreorder
	.set	nomacro
	jal	func_8006E950
	li	$4,0x00000002		# 2
	.set	macro
	.set	reorder

	lw	$4,D_800A3500
	#nop
	sw	$4,D_800A372C
	jal	func_8006919C
	lw	$5,D_800A351C
	move	$4,$2
	sw	$4,D_800A3500
	jal	func_8006E49C
	sw	$16,36($2)
	sw	$2,D_800A3500
	sw	$2,D_800A34FC
	addu	$2,$2,52
	sw	$2,D_800A3500
	li	$2,-16			# 0xfffffff0
	lw	$3,D_800A34F8
	lw	$4,D_8009BC04
	and	$3,$3,$2
	andi	$2,$4,0x0001
	sw	$3,D_800A34F8
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L654
	li	$2,0x00000005		# 5
	.set	macro
	.set	reorder

	li	$5,-16			# 0xfffffff0
	move	$6,$4
.L641:
	lw	$3,D_800A34F8
	#nop
	andi	$4,$3,0x000f
	slt	$2,$4,7
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L644
	addu	$2,$4,1
	.set	macro
	.set	reorder

	and	$2,$3,$5
	sw	$2,D_800A34F8
	.set	noreorder
	.set	nomacro
	j	.L654
	li	$2,0x00000005		# 5
	.set	macro
	.set	reorder

.L644:
	and	$3,$3,$5
	andi	$2,$2,0x000f
	or	$3,$3,$2
	sw	$3,D_800A34F8
	andi	$3,$3,0x000f
	srl	$3,$6,$3
	andi	$3,$3,0x0001
	.set	noreorder
	.set	nomacro
	beq	$3,$0,.L641
	li	$2,0x00000005		# 5
	.set	macro
	.set	reorder

.L654:
	lw	$5,D_800A34FC
	sw	$17,D_800A3524
	sw	$0,D_800A3518
	sh	$0,D_800A3528
	sh	$2,42($5)
	sh	$2,40($5)
	lw	$3,D_800A34F8
	li	$2,-7169			# 0xffffe3ff
	sh	$0,D_800A3512
	sh	$0,D_800A3510
	sh	$0,D_800A350E
	sh	$0,D_800A350C
	and	$3,$3,$2
	ori	$3,$3,0x1000
	sw	$3,D_800A34F8
	sh	$0,18($5)
	sh	$0,16($5)
	sh	$0,14($5)
	sh	$0,12($5)
	la	$6,D_800A32C0
	lwl	$2,3($6)
	lwr	$2,0($6)
	lwl	$3,7($6)
	lwr	$3,4($6)
	swl	$2,19($sp)
	swr	$2,16($sp)
	swl	$3,23($sp)
	swr	$3,20($sp)
	.set	noreorder
	.set	nomacro
	jal	DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	addu	$4,$sp,16
	li	$5,0x000003c0		# 960
	.set	noreorder
	.set	nomacro
	jal	MoveImage
	li	$6,0x000001fe		# 510
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	lw	$3,D_800A3524
	li	$2,0x00000001		# 1
	lw	$3,32($3)
	lw	$4,D_800A34FC
	andi	$3,$3,0x0001
	sb	$3,48($4)
	lw	$31,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,40
	j	$31
	.end	func_80068F70
.Lfe175:
	.size	 func_80068F70,.Lfe175-func_80068F70
	.align	2
	.globl	func_80069120
	.type	 func_80069120,@function
	.ent	func_80069120
func_80069120:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	lw	$2,D_800A3524
	lw	$3,D_800A34FC
	subu	$sp,$sp,24
	sw	$16,16($sp)
	sw	$31,20($sp)
	lw	$2,32($2)
	lbu	$3,48($3)
	andi	$2,$2,0x0001
	.set	noreorder
	.set	nomacro
	beq	$3,$2,.L656
	move	$16,$4
	.set	macro
	.set	reorder

	lw	$4,D_800A372C
	jal	func_8006E8CC
.L656:
	lw	$2,D_800A3524
	#nop
	lw	$2,32($2)
	lw	$3,D_800A34FC
	andi	$2,$2,0x0001
	sb	$2,48($3)
	sll	$2,$16,1
	addu	$2,$2,$16
	sll	$2,$2,2
	subu	$2,$2,$16
	lw	$3,D_800A351C
	sll	$2,$2,2
	addu	$2,$3,$2
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80069120
.Lfe176:
	.size	 func_80069120,.Lfe176-func_80069120
	.align	2
	.globl	func_8006919C
	.type	 func_8006919C,@function
	.ent	func_8006919C
func_8006919C:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, extra= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	sw	$18,24($sp)
	move	$18,$4
	sw	$17,20($sp)
	move	$17,$0
	sw	$16,16($sp)
	addu	$16,$18,20
	sw	$31,28($sp)
	move	$4,$18
.L662:
	lw	$5,0($16)
	addu	$16,$16,4
	.set	noreorder
	.set	nomacro
	jal	func_8006920C
	addu	$17,$17,1
	.set	macro
	.set	reorder

	slt	$2,$17,12
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L662
	move	$4,$18
	.set	macro
	.set	reorder

	lw	$4,0($18)
	lw	$6,4($18)
	.set	noreorder
	.set	nomacro
	jal	func_8005C2A8
	li	$5,0x00000001		# 1
	.set	macro
	.set	reorder

	lw	$2,4($18)
	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,32
	j	$31
	.end	func_8006919C
.Lfe177:
	.size	 func_8006919C,.Lfe177-func_8006919C
	.align	2
	.globl	func_8006920C
	.type	 func_8006920C,@function
	.ent	func_8006920C
func_8006920C:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$2,0($5)
	#nop
	beq	$2,$0,.L663
	li	$3,-1			# 0xffffffff
.L667:
	lw	$2,0($5)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$3,.L668
	addu	$2,$2,$4
	.set	macro
	.set	reorder

	sw	$2,0($5)
.L668:
	addu	$5,$5,4
	lw	$2,0($5)
	#nop
	bne	$2,$0,.L667
.L663:
	j	$31
	.end	func_8006920C
.Lfe178:
	.size	 func_8006920C,.Lfe178-func_8006920C
	.align	2
	.globl	func_80069250
	.type	 func_80069250,@function
	.ent	func_80069250
func_80069250:
	.frame	$sp,64,$31		# vars= 40, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,64
	sw	$16,56($sp)
	move	$16,$5
	la	$5,D_800A3518
	sw	$31,60($sp)
	sw	$0,D_800A3514
	.set	noreorder
	.set	nomacro
	jal	func_8006E390
	addu	$4,$sp,16
	.set	macro
	.set	reorder

	addu	$4,$sp,16
	.set	noreorder
	.set	nomacro
	jal	func_80069E18
	move	$5,$0
	.set	macro
	.set	reorder

	li	$2,0x00400000		# 4194304
	ori	$2,$2,0x0040
	and	$16,$16,$2
	.set	noreorder
	.set	nomacro
	bne	$16,$0,.L671
	li	$4,0x00000001		# 1
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L672
	move	$2,$0
	.set	macro
	.set	reorder

.L671:
	li	$5,0x0000007f		# 127
	.set	noreorder
	.set	nomacro
	jal	func_8005C650
	li	$6,0x0000007f		# 127
	.set	macro
	.set	reorder

	li	$2,0x00000001		# 1
.L672:
	lw	$31,60($sp)
	lw	$16,56($sp)
	addu	$sp,$sp,64
	j	$31
	.end	func_80069250
.Lfe179:
	.size	 func_80069250,.Lfe179-func_80069250
	.align	2
	.globl	func_800692C0
	.type	 func_800692C0,@function
	.ent	func_800692C0
func_800692C0:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	move	$10,$0
	move	$11,$0
	sll	$5,$5,4
	li	$14,0x00000001		# 1
	move	$13,$0
	move	$9,$0
	la	$12,D_800A32D0
.L677:
	addu	$7,$7,$13
	lw	$2,0($12)
	sll	$3,$11,2
	sll	$8,$2,$5
	lw	$2,D_800A32C8($3)
	lh	$3,0($6)
	#nop
	.set	noreorder
	.set	nomacro
	bne	$3,$0,.L680
	sll	$2,$2,$5
	.set	macro
	.set	reorder

	lw	$3,0($4)
	#nop
	and	$2,$3,$2
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L681
	and	$2,$3,$8
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L684
	sh	$14,0($7)
	.set	macro
	.set	reorder

.L681:
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L684
	li	$2,-1			# 0xffffffff
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L684
	sh	$2,0($7)
	.set	macro
	.set	reorder

.L680:
	lw	$3,0($4)
	#nop
	and	$2,$3,$2
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L685
	li	$2,0x00000006		# 6
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L686
	sh	$2,0($6)
	.set	macro
	.set	reorder

.L685:
	and	$2,$3,$8
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L686
	li	$2,-6			# 0xfffffffa
	.set	macro
	.set	reorder

	sh	$2,0($7)
.L686:
	lh	$3,0($6)
	#nop
	slt	$2,$3,6
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L688
	slt	$2,$3,-5
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L693
	sll	$2,$14,$9
	.set	macro
	.set	reorder

.L688:
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L684
	li	$2,0x00000002		# 2
	.set	macro
	.set	reorder

	sll	$2,$2,$9
.L693:
	addu	$10,$10,$2
	sh	$0,0($7)
	sh	$0,0($6)
.L684:
	addu	$13,$13,2
	addu	$9,$9,16
	addu	$12,$12,4
	lhu	$2,0($6)
	lhu	$3,0($7)
	addu	$11,$11,1
	addu	$2,$2,$3
	sh	$2,0($6)
	slt	$2,$11,2
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L677
	addu	$6,$6,2
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	$31
	move	$2,$10
	.set	macro
	.set	reorder

	.end	func_800692C0
.Lfe180:
	.size	 func_800692C0,.Lfe180-func_800692C0
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_800693CC.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_80069898
	.type	 func_80069898,@function
	.ent	func_80069898
func_80069898:
	.frame	$sp,40,$31		# vars= 0, regs= 6/0, args= 16, extra= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	sw	$20,32($sp)
	move	$20,$4
	sw	$17,20($sp)
	move	$17,$5
	sw	$31,36($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$16,16($sp)
	lw	$16,24($20)
	move	$19,$6
	.set	noreorder
	.set	nomacro
	jal	SetTile
	move	$4,$16
	.set	macro
	.set	reorder

	li	$2,0x000000ff		# 255
	li	$18,0x00000080		# 128
	sb	$2,4($16)
	sb	$2,5($16)
	sb	$2,6($16)
	sb	$18,4($16)
	sb	$18,5($16)
	sb	$18,6($16)
	lhu	$2,0($17)
	#nop
	sh	$2,8($16)
	lhu	$2,2($17)
	#nop
	sh	$2,10($16)
	lhu	$2,4($17)
	move	$4,$16
	sh	$2,12($16)
	lhu	$2,6($17)
	move	$5,$0
	.set	noreorder
	.set	nomacro
	jal	SetSemiTrans
	sh	$2,14($16)
	.set	macro
	.set	reorder

	move	$5,$16
	addu	$16,$16,16
	lw	$4,D_800A374C
	sll	$19,$19,2
	.set	noreorder
	.set	nomacro
	jal	AddPrim
	addu	$4,$4,$19
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	SetTile
	move	$4,$16
	.set	macro
	.set	reorder

	sb	$18,4($16)
	sb	$18,5($16)
	sb	$18,6($16)
	lhu	$2,0($17)
	#nop
	sh	$2,8($16)
	lhu	$2,2($17)
	#nop
	addu	$2,$2,-1
	sh	$2,10($16)
	lhu	$2,4($17)
	move	$4,$16
	sh	$2,12($16)
	lhu	$2,6($17)
	li	$5,0x00000001		# 1
	.set	noreorder
	.set	nomacro
	jal	SetSemiTrans
	sh	$2,14($16)
	.set	macro
	.set	reorder

	move	$5,$16
	lw	$4,D_800A374C
	addu	$16,$16,16
	.set	noreorder
	.set	nomacro
	jal	AddPrim
	addu	$4,$4,$19
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	SetTile
	move	$4,$16
	.set	macro
	.set	reorder

	li	$2,0x00000040		# 64
	sb	$2,4($16)
	sb	$2,5($16)
	sb	$2,6($16)
	lhu	$2,0($17)
	#nop
	sh	$2,8($16)
	lhu	$2,2($17)
	#nop
	addu	$2,$2,-2
	sh	$2,10($16)
	lhu	$2,4($17)
	move	$4,$16
	sh	$2,12($16)
	lhu	$2,6($17)
	li	$5,0x00000001		# 1
	.set	noreorder
	.set	nomacro
	jal	SetSemiTrans
	sh	$2,14($16)
	.set	macro
	.set	reorder

	move	$5,$16
	lw	$4,D_800A374C
	addu	$16,$16,16
	.set	noreorder
	.set	nomacro
	jal	AddPrim
	addu	$4,$4,$19
	.set	macro
	.set	reorder

	sw	$16,24($20)
	lw	$31,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,40
	j	$31
	.end	func_80069898
.Lfe181:
	.size	 func_80069898,.Lfe181-func_80069898
	.align	2
	.globl	func_80069A30
	.type	 func_80069A30,@function
	.ent	func_80069A30
func_80069A30:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$16,16($sp)
	sw	$31,20($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80077D00
	move	$16,$4
	.set	macro
	.set	reorder

	lw	$2,32($2)
	#nop
	andi	$2,$2,0x0001
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L696
	li	$2,0x00000022		# 34
	.set	macro
	.set	reorder

	sb	$2,4($16)
	.set	noreorder
	.set	nomacro
	j	.L697
	sb	$2,5($16)
	.set	macro
	.set	reorder

.L696:
	li	$2,0x0000004c		# 76
	sb	$2,4($16)
	sb	$2,5($16)
	li	$2,0x0000006c		# 108
.L697:
	sb	$2,6($16)
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80069A30
.Lfe182:
	.size	 func_80069A30,.Lfe182-func_80069A30
	.align	2
	.globl	func_80069A8C
	.type	 func_80069A8C,@function
	.ent	func_80069A8C
func_80069A8C:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$16,16($sp)
	sw	$31,20($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80077D00
	move	$16,$4
	.set	macro
	.set	reorder

	lw	$2,32($2)
	#nop
	andi	$2,$2,0x0001
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L699
	li	$2,0x00000008		# 8
	.set	macro
	.set	reorder

	sb	$2,4($16)
	.set	noreorder
	.set	nomacro
	j	.L700
	sb	$2,5($16)
	.set	macro
	.set	reorder

.L699:
	li	$2,0x00000031		# 49
	sb	$0,4($16)
	sb	$0,5($16)
.L700:
	sb	$2,6($16)
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80069A8C
.Lfe183:
	.size	 func_80069A8C,.Lfe183-func_80069A8C
	.align	2
	.globl	func_80069AE4
	.type	 func_80069AE4,@function
	.ent	func_80069AE4
func_80069AE4:
	.frame	$sp,96,$31		# vars= 48, regs= 6/0, args= 24, extra= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,96
	sw	$20,88($sp)
	move	$20,$4
	li	$2,0x00000002		# 2
	sw	$31,92($sp)
	sw	$19,84($sp)
	sw	$18,80($sp)
	sw	$17,76($sp)
	sw	$16,72($sp)
	lw	$19,24($20)
	.set	noreorder
	.set	nomacro
	bne	$5,$2,.L702
	li	$2,0x00000001		# 1
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	SetTile
	move	$4,$19
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_80069A30
	move	$4,$19
	.set	macro
	.set	reorder

	move	$4,$19
	li	$5,0x00000001		# 1
	li	$2,0x0000004e		# 78
	li	$18,0x00000030		# 48
	li	$17,0x000000cc		# 204
	li	$16,0x000000b0		# 176
	sh	$2,8($19)
	sh	$18,10($19)
	sh	$17,12($19)
	.set	noreorder
	.set	nomacro
	jal	SetSemiTrans
	sh	$16,14($19)
	.set	macro
	.set	reorder

	move	$5,$19
	lw	$4,D_800A374C
	addu	$19,$19,16
	.set	noreorder
	.set	nomacro
	jal	AddPrim
	addu	$4,$4,68
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	SetTile
	move	$4,$19
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_80069A30
	move	$4,$19
	.set	macro
	.set	reorder

	move	$4,$19
	li	$5,0x00000001		# 1
	li	$2,0x00000166		# 358
	sh	$2,8($19)
	sh	$18,10($19)
	sh	$17,12($19)
	.set	noreorder
	.set	nomacro
	j	.L710
	sh	$16,14($19)
	.set	macro
	.set	reorder

.L702:
	bne	$5,$2,.L704
	.set	noreorder
	.set	nomacro
	jal	SetTile
	move	$4,$19
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_80069A30
	move	$4,$19
	.set	macro
	.set	reorder

	move	$4,$19
	li	$5,0x00000001		# 1
	li	$2,0x0000003f		# 63
	sh	$2,8($19)
	li	$2,0x00000030		# 48
	sh	$2,10($19)
	li	$2,0x00000202		# 514
	sh	$2,12($19)
	.set	noreorder
	.set	nomacro
	j	.L711
	li	$2,0x000000b0		# 176
	.set	macro
	.set	reorder

.L704:
	.set	noreorder
	.set	nomacro
	jal	SetTile
	move	$4,$19
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_80069A30
	move	$4,$19
	.set	macro
	.set	reorder

	move	$4,$19
	li	$5,0x00000001		# 1
	li	$2,0x00000130		# 304
	sh	$2,8($19)
	li	$2,0x0000003a		# 58
	sh	$2,10($19)
	li	$2,0x00000126		# 294
	sh	$2,12($19)
	li	$2,0x000000ab		# 171
.L711:
	sh	$2,14($19)
.L710:
	.set	noreorder
	.set	nomacro
	jal	SetSemiTrans
	move	$17,$0
	.set	macro
	.set	reorder

	move	$5,$19
	lw	$4,D_800A374C
	addu	$19,$19,16
	.set	noreorder
	.set	nomacro
	jal	AddPrim
	addu	$4,$4,68
	.set	macro
	.set	reorder

	li	$2,0x00000012		# 18
	sw	$19,24($20)
	sw	$2,44($sp)
	sb	$0,64($sp)
	sw	$0,40($sp)
	lw	$2,4($20)
	#nop
	lw	$18,52($2)
	sw	$0,48($sp)
	sw	$0,52($sp)
	move	$16,$18
.L706:
	addu	$4,$sp,24
	lw	$2,0($16)
	addu	$16,$16,4
	sw	$2,24($sp)
	addu	$2,$2,12
	sw	$2,28($sp)
	lw	$2,20($20)
	addu	$17,$17,1
	.set	noreorder
	.set	nomacro
	jal	func_8007352C
	sw	$2,32($sp)
	.set	macro
	.set	reorder

	sw	$2,20($20)
	slt	$2,$17,3
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L706
	move	$5,$0
	.set	macro
	.set	reorder

	lw	$4,0($18)
	.set	noreorder
	.set	nomacro
	jal	func_8006E480
	sw	$4,24($sp)
	.set	macro
	.set	reorder

	li	$5,0x00000001		# 1
	move	$6,$0
	sw	$0,16($sp)
	lw	$4,28($20)
	.set	noreorder
	.set	nomacro
	jal	SetDrawMode
	move	$7,$2
	.set	macro
	.set	reorder

	lw	$4,D_800A374C
	lw	$5,28($20)
	.set	noreorder
	.set	nomacro
	jal	AddPrim
	addu	$4,$4,72
	.set	macro
	.set	reorder

	lw	$16,12($20)
	lw	$2,28($20)
	move	$4,$16
	addu	$2,$2,12
	.set	noreorder
	.set	nomacro
	jal	SetPolyF4
	sw	$2,28($20)
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_80069A8C
	move	$4,$16
	.set	macro
	.set	reorder

	move	$4,$16
	move	$5,$0
	li	$2,0x000000b9		# 185
	li	$19,0x00000122		# 290
	li	$18,0x000000ef		# 239
	sh	$0,8($16)
	sh	$2,10($16)
	sh	$19,12($16)
	sh	$0,14($16)
	sh	$0,16($16)
	sh	$18,18($16)
	sh	$19,20($16)
	.set	noreorder
	.set	nomacro
	jal	SetSemiTrans
	sh	$18,22($16)
	.set	macro
	.set	reorder

	move	$5,$16
	lw	$4,D_800A374C
	addu	$16,$16,24
	.set	noreorder
	.set	nomacro
	jal	AddPrim
	addu	$4,$4,76
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	SetPolyF4
	move	$4,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_80069A8C
	move	$4,$16
	.set	macro
	.set	reorder

	move	$4,$16
	move	$5,$0
	li	$17,0x0000015e		# 350
	li	$2,0x0000027f		# 639
	sh	$2,12($16)
	sh	$2,20($16)
	li	$2,0x00000036		# 54
	sh	$17,8($16)
	sh	$0,10($16)
	sh	$0,14($16)
	sh	$17,16($16)
	sh	$18,18($16)
	.set	noreorder
	.set	nomacro
	jal	SetSemiTrans
	sh	$2,22($16)
	.set	macro
	.set	reorder

	move	$5,$16
	lw	$4,D_800A374C
	addu	$16,$16,24
	.set	noreorder
	.set	nomacro
	jal	AddPrim
	addu	$4,$4,76
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	SetPolyF4
	move	$4,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_80069A8C
	move	$4,$16
	.set	macro
	.set	reorder

	move	$4,$16
	move	$5,$0
	sh	$19,8($16)
	sh	$0,10($16)
	sh	$17,12($16)
	sh	$0,14($16)
	sh	$19,16($16)
	sh	$18,18($16)
	sh	$17,20($16)
	.set	noreorder
	.set	nomacro
	jal	SetSemiTrans
	sh	$18,22($16)
	.set	macro
	.set	reorder

	move	$5,$16
	lw	$4,D_800A374C
	addu	$16,$16,24
	.set	noreorder
	.set	nomacro
	jal	AddPrim
	addu	$4,$4,76
	.set	macro
	.set	reorder

	sw	$16,12($20)
	lw	$31,92($sp)
	lw	$20,88($sp)
	lw	$19,84($sp)
	lw	$18,80($sp)
	lw	$17,76($sp)
	lw	$16,72($sp)
	addu	$sp,$sp,96
	j	$31
	.end	func_80069AE4
.Lfe184:
	.size	 func_80069AE4,.Lfe184-func_80069AE4
	.align	2
	.globl	func_80069E18
	.type	 func_80069E18,@function
	.ent	func_80069E18
func_80069E18:
	.frame	$sp,88,$31		# vars= 48, regs= 3/0, args= 24, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,88
	sw	$17,76($sp)
	move	$17,$4
	sw	$31,80($sp)
	sw	$16,72($sp)
	lw	$16,24($17)
	.set	noreorder
	.set	nomacro
	jal	SetTile
	move	$4,$16
	.set	macro
	.set	reorder

	move	$4,$16
	move	$5,$0
	li	$2,0x000000ff		# 255
	sb	$2,4($16)
	sb	$2,5($16)
	sb	$2,6($16)
	li	$2,0x00000280		# 640
	sh	$2,12($16)
	li	$2,0x000000f0		# 240
	sh	$0,8($16)
	sh	$0,10($16)
	.set	noreorder
	.set	nomacro
	jal	SetSemiTrans
	sh	$2,14($16)
	.set	macro
	.set	reorder

	lw	$4,D_800A374C
	move	$5,$16
	.set	noreorder
	.set	nomacro
	jal	AddPrim
	addu	$4,$4,80
	.set	macro
	.set	reorder

	lw	$2,4($17)
	addu	$16,$16,16
	sw	$16,24($17)
	lw	$16,20($2)
	li	$2,0x00000010		# 16
	sw	$2,44($sp)
	sw	$0,40($sp)
	sw	$0,48($sp)
	sw	$0,52($sp)
	sb	$0,64($sp)
	lw	$4,0($16)
	move	$5,$0
	.set	noreorder
	.set	nomacro
	jal	func_8006E480
	sw	$4,24($sp)
	.set	macro
	.set	reorder

	li	$5,0x00000001		# 1
	move	$6,$0
	sw	$0,16($sp)
	lw	$4,28($17)
	.set	noreorder
	.set	nomacro
	jal	SetDrawMode
	move	$7,$2
	.set	macro
	.set	reorder

	lw	$4,D_800A374C
	lw	$5,28($17)
	.set	noreorder
	.set	nomacro
	jal	AddPrim
	addu	$4,$4,68
	.set	macro
	.set	reorder

	lw	$2,28($17)
	#nop
	addu	$2,$2,12
	sw	$2,28($17)
	lw	$2,24($sp)
	#nop
	addu	$3,$2,12
	sw	$3,28($sp)
	lw	$2,20($17)
	addu	$4,$sp,24
	.set	noreorder
	.set	nomacro
	jal	func_8007352C
	sw	$2,32($sp)
	.set	macro
	.set	reorder

	sw	$2,20($17)
	lw	$2,4($16)
	#nop
	addu	$3,$2,12
	sw	$2,24($sp)
	sw	$3,28($sp)
	lw	$2,20($17)
	addu	$4,$sp,24
	.set	noreorder
	.set	nomacro
	jal	func_8007352C
	sw	$2,32($sp)
	.set	macro
	.set	reorder

	sw	$2,20($17)
	lw	$2,8($16)
	#nop
	addu	$3,$2,12
	sw	$2,24($sp)
	sw	$3,28($sp)
	lw	$2,20($17)
	addu	$4,$sp,24
	.set	noreorder
	.set	nomacro
	jal	func_8007352C
	sw	$2,32($sp)
	.set	macro
	.set	reorder

	sw	$2,20($17)
	lw	$31,80($sp)
	lw	$17,76($sp)
	lw	$16,72($sp)
	addu	$sp,$sp,88
	j	$31
	.end	func_80069E18
.Lfe185:
	.size	 func_80069E18,.Lfe185-func_80069E18
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80069F80.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8006A1A0.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_8006A3CC
	.type	 func_8006A3CC,@function
	.ent	func_8006A3CC
func_8006A3CC:
	.frame	$sp,40,$31		# vars= 0, regs= 3/0, args= 24, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	sw	$17,28($sp)
	move	$17,$4
	sw	$31,32($sp)
	sw	$16,24($sp)
	lw	$2,4($17)
	#nop
	lw	$2,28($2)
	#nop
	lw	$2,16($2)
	move	$16,$5
	sw	$2,0($16)
	lw	$2,0($16)
	li	$3,0x00000001		# 1
	sw	$0,24($16)
	sw	$0,28($16)
	sb	$0,40($16)
	sw	$0,16($16)
	sw	$3,20($16)
	addu	$2,$2,12
	sw	$2,4($16)
	lw	$2,20($17)
	move	$4,$16
	.set	noreorder
	.set	nomacro
	jal	func_8007352C
	sw	$2,8($16)
	.set	macro
	.set	reorder

	sw	$2,20($17)
	lw	$4,0($16)
	.set	noreorder
	.set	nomacro
	jal	func_8006E480
	move	$5,$0
	.set	macro
	.set	reorder

	li	$5,0x00000001		# 1
	move	$6,$0
	sw	$0,16($sp)
	lw	$4,28($17)
	.set	noreorder
	.set	nomacro
	jal	SetDrawMode
	move	$7,$2
	.set	macro
	.set	reorder

	lw	$4,D_800A374C
	lw	$5,28($17)
	.set	noreorder
	.set	nomacro
	jal	AddPrim
	addu	$4,$4,4
	.set	macro
	.set	reorder

	lw	$2,28($17)
	#nop
	addu	$2,$2,12
	sw	$2,28($17)
	lw	$31,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,40
	j	$31
	.end	func_8006A3CC
.Lfe186:
	.size	 func_8006A3CC,.Lfe186-func_8006A3CC
	.align	2
	.globl	func_8006A494
	.type	 func_8006A494,@function
	.ent	func_8006A494
func_8006A494:
	.frame	$sp,40,$31		# vars= 0, regs= 3/0, args= 24, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	sw	$17,28($sp)
	move	$17,$4
	sw	$31,32($sp)
	sw	$16,24($sp)
	lw	$2,4($17)
	move	$16,$5
	lw	$2,28($2)
	move	$4,$16
	lw	$3,36($2)
	li	$2,0x00000001		# 1
	sw	$0,24($16)
	sw	$0,28($16)
	sb	$0,40($16)
	sw	$0,16($16)
	sw	$2,20($16)
	sw	$3,0($16)
	lw	$2,0($16)
	li	$3,0x00000100		# 256
	sw	$3,32($16)
	sw	$3,36($16)
	addu	$2,$2,12
	sw	$2,4($16)
	lw	$2,8($17)
	move	$5,$0
	.set	noreorder
	.set	nomacro
	jal	func_80073728
	sw	$2,12($16)
	.set	macro
	.set	reorder

	sw	$2,8($17)
	lw	$4,0($16)
	.set	noreorder
	.set	nomacro
	jal	func_8006E480
	move	$5,$0
	.set	macro
	.set	reorder

	li	$5,0x00000001		# 1
	move	$6,$0
	sw	$0,16($sp)
	lw	$4,28($17)
	.set	noreorder
	.set	nomacro
	jal	SetDrawMode
	move	$7,$2
	.set	macro
	.set	reorder

	lw	$4,D_800A374C
	lw	$5,28($17)
	.set	noreorder
	.set	nomacro
	jal	AddPrim
	addu	$4,$4,4
	.set	macro
	.set	reorder

	lw	$2,28($17)
	#nop
	addu	$2,$2,12
	sw	$2,28($17)
	lw	$31,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,40
	j	$31
	.end	func_8006A494
.Lfe187:
	.size	 func_8006A494,.Lfe187-func_8006A494
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8006A564.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8006A880.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8006B120.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8006B578.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_8006B898
	.type	 func_8006B898,@function
	.ent	func_8006B898
func_8006B898:
	.frame	$sp,64,$31		# vars= 40, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,64
	sw	$4,64($sp)
	addu	$4,$sp,16
	sw	$5,68($sp)
	lw	$2,D_800A3514
	lw	$3,D_800A36AC
	la	$5,D_800A3518
	sw	$31,60($sp)
	sw	$16,56($sp)
	addu	$2,$2,1
	andi	$3,$3,0x0001
	sll	$16,$3,7
	addu	$16,$16,$3
	sll	$16,$16,3
	addu	$16,$16,$3
	sll	$16,$16,4
	sw	$2,D_800A3514
	la	$2,g_disp_fb_base
	.set	noreorder
	.set	nomacro
	jal	func_8006E390
	addu	$16,$16,$2
	.set	macro
	.set	reorder

	addu	$4,$sp,16
	li	$5,0x00000001		# 1
	.set	noreorder
	.set	nomacro
	jal	func_80069AE4
	move	$6,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_8006B120
	addu	$4,$sp,16
	.set	macro
	.set	reorder

	addu	$4,$sp,64
	.set	noreorder
	.set	nomacro
	jal	func_8006B578
	addu	$5,$sp,68
	.set	macro
	.set	reorder

	lw	$31,60($sp)
	lw	$16,56($sp)
	addu	$sp,$sp,64
	j	$31
	.end	func_8006B898
.Lfe188:
	.size	 func_8006B898,.Lfe188-func_8006B898
	.align	2
	.globl	func_8006B92C
	.type	 func_8006B92C,@function
	.ent	func_8006B92C
func_8006B92C:
	.frame	$sp,40,$31		# vars= 8, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	sw	$17,28($sp)
	move	$17,$5
	sw	$16,24($sp)
	move	$16,$0
	addu	$4,$sp,16
	move	$5,$0
	lw	$6,D_800A34FC
	la	$7,D_800A350C
	sw	$31,32($sp)
	lw	$3,0($17)
	addu	$6,$6,12
	andi	$2,$3,0xffff
	srl	$3,$3,16
	or	$2,$2,$3
	.set	noreorder
	.set	nomacro
	jal	func_800692C0
	sw	$2,16($sp)
	.set	macro
	.set	reorder

	sra	$3,$2,16
	li	$2,0x00000001		# 1
	.set	noreorder
	.set	nomacro
	beq	$3,$2,.L718
	li	$2,0x00000002		# 2
	.set	macro
	.set	reorder

	beq	$3,$2,.L722
	j	.L717
.L718:
	lw	$4,D_800A34F8
	li	$2,0x00004000		# 16384
	andi	$3,$4,0xe000
	.set	noreorder
	.set	nomacro
	bne	$3,$2,.L719
	li	$3,-65536			# 0xffff0000
	.set	macro
	.set	reorder

	li	$2,-65536			# 0xffff0000
	ori	$2,$2,0x1fff
	and	$2,$4,$2
	sw	$2,D_800A34F8
	.set	noreorder
	.set	nomacro
	j	.L739
	move	$4,$0
	.set	macro
	.set	reorder

.L719:
	ori	$3,$3,0x1fff
	and	$3,$4,$3
	srl	$2,$4,13
	andi	$2,$2,0x0007
	.set	noreorder
	.set	nomacro
	j	.L738
	addu	$2,$2,1
	.set	macro
	.set	reorder

.L722:
	lw	$4,D_800A34F8
	#nop
	andi	$2,$4,0xe000
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L723
	li	$3,-65536			# 0xffff0000
	.set	macro
	.set	reorder

	li	$2,-65536			# 0xffff0000
	ori	$2,$2,0x1fff
	and	$2,$4,$2
	ori	$2,$2,0x4000
	sw	$2,D_800A34F8
	.set	noreorder
	.set	nomacro
	j	.L739
	move	$4,$0
	.set	macro
	.set	reorder

.L723:
	ori	$3,$3,0x1fff
	and	$3,$4,$3
	srl	$2,$4,13
	andi	$2,$2,0x0007
	addu	$2,$2,-1
.L738:
	andi	$2,$2,0x0007
	sll	$2,$2,13
	or	$3,$3,$2
	sw	$3,D_800A34F8
	move	$4,$0
.L739:
	li	$5,0x0000007f		# 127
	.set	noreorder
	.set	nomacro
	jal	func_8005C650
	li	$6,0x0000007f		# 127
	.set	macro
	.set	reorder

.L717:
	lw	$2,D_800A34F8
	#nop
	srl	$2,$2,13
	andi	$3,$2,0x0007
	li	$2,0x00000001		# 1
	.set	noreorder
	.set	nomacro
	beq	$3,$2,.L730
	slt	$2,$3,2
	.set	macro
	.set	reorder

	beq	$2,$0,.L736
	.set	noreorder
	.set	nomacro
	beq	$3,$0,.L728
	li	$3,0x00400000		# 4194304
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L740
	li	$3,0x00100000		# 1048576
	.set	macro
	.set	reorder

.L736:
	li	$2,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	beq	$3,$2,.L732
	li	$3,0x00400000		# 4194304
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L740
	li	$3,0x00100000		# 1048576
	.set	macro
	.set	reorder

.L728:
	lw	$2,0($17)
	ori	$3,$3,0x0040
	and	$2,$2,$3
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L727
	li	$4,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$5,0x0000007f		# 127
	.set	noreorder
	.set	nomacro
	jal	func_8005C650
	li	$6,0x0000007f		# 127
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L727
	li	$16,0x00000002		# 2
	.set	macro
	.set	reorder

.L730:
	li	$3,0x00400000		# 4194304
	lw	$2,0($17)
	ori	$3,$3,0x0040
	and	$2,$2,$3
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L727
	li	$4,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$5,0x0000007f		# 127
	.set	noreorder
	.set	nomacro
	jal	func_8005C650
	li	$6,0x0000007f		# 127
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L727
	li	$16,0x00000003		# 3
	.set	macro
	.set	reorder

.L732:
	lw	$2,0($17)
	ori	$3,$3,0x0040
	and	$2,$2,$3
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L727
	li	$4,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$5,0x0000007f		# 127
	.set	noreorder
	.set	nomacro
	jal	func_8005C650
	li	$6,0x0000007f		# 127
	.set	macro
	.set	reorder

	li	$16,0x00000001		# 1
	lw	$2,D_800A34F8
	li	$3,-7169			# 0xffffe3ff
	and	$3,$2,$3
	srl	$2,$2,10
	andi	$2,$2,0x0007
	addu	$2,$2,1
	andi	$2,$2,0x0007
	sll	$2,$2,10
	or	$3,$3,$2
	sw	$3,D_800A34F8
.L727:
	li	$3,0x00100000		# 1048576
.L740:
	lw	$2,0($17)
	ori	$3,$3,0x0010
	and	$2,$2,$3
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L737
	li	$4,0x00000002		# 2
	.set	macro
	.set	reorder

	li	$5,0x0000007f		# 127
	.set	noreorder
	.set	nomacro
	jal	func_8005C650
	li	$6,0x0000007f		# 127
	.set	macro
	.set	reorder

	li	$16,0x00000001		# 1
.L737:
	move	$2,$16
	lw	$31,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,40
	j	$31
	.end	func_8006B92C
.Lfe189:
	.size	 func_8006B92C,.Lfe189-func_8006B92C
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8006BB68.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8006BD28.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8006BEC4.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_8006C168
	.type	 func_8006C168,@function
	.ent	func_8006C168
func_8006C168:
	.frame	$sp,112,$31		# vars= 88, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,112
	sw	$4,112($sp)
	addu	$4,$sp,16
	sw	$5,116($sp)
	lw	$2,D_800A3514
	lw	$3,D_800A36AC
	la	$5,D_800A3518
	sw	$31,108($sp)
	sw	$16,104($sp)
	addu	$2,$2,1
	andi	$3,$3,0x0001
	sll	$16,$3,7
	addu	$16,$16,$3
	sll	$16,$16,3
	addu	$16,$16,$3
	sll	$16,$16,4
	sw	$2,D_800A3514
	la	$2,g_disp_fb_base
	.set	noreorder
	.set	nomacro
	jal	func_8006E390
	addu	$16,$16,$2
	.set	macro
	.set	reorder

	addu	$4,$sp,16
	li	$5,0x00000001		# 1
	.set	noreorder
	.set	nomacro
	jal	func_80069AE4
	move	$6,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_8006BB68
	addu	$4,$sp,16
	.set	macro
	.set	reorder

	addu	$4,$sp,112
	.set	noreorder
	.set	nomacro
	jal	func_8006B92C
	addu	$5,$sp,116
	.set	macro
	.set	reorder

	lw	$31,108($sp)
	lw	$16,104($sp)
	addu	$sp,$sp,112
	j	$31
	.end	func_8006C168
.Lfe190:
	.size	 func_8006C168,.Lfe190-func_8006C168
	.align	2
	.globl	func_8006C1FC
	.type	 func_8006C1FC,@function
	.ent	func_8006C1FC
func_8006C1FC:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	jal	func_8006C168
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_8006C1FC
.Lfe191:
	.size	 func_8006C1FC,.Lfe191-func_8006C1FC
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8006C21C.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_8006CBD4
	.type	 func_8006CBD4,@function
	.ent	func_8006CBD4
func_8006CBD4:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	sll	$6,$4,4
	li	$2,0x00000010		# 16
	sll	$2,$2,$6
	and	$2,$5,$2
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L744
	li	$2,0x00000040		# 64
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L745
	li	$7,0x00000001		# 1
	.set	macro
	.set	reorder

.L744:
	sll	$2,$2,$6
	and	$2,$5,$2
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L746
	li	$2,0x00000080		# 128
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L745
	li	$7,0x00000002		# 2
	.set	macro
	.set	reorder

.L746:
	sll	$2,$2,$6
	and	$2,$5,$2
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L748
	li	$2,0x00000020		# 32
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L745
	li	$7,0x00000003		# 3
	.set	macro
	.set	reorder

.L748:
	sll	$2,$2,$6
	and	$2,$5,$2
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L759
	move	$5,$0
	.set	macro
	.set	reorder

	move	$7,$0
.L745:
	move	$5,$0
.L759:
	sll	$8,$4,1
	li	$2,0x00000001		# 1
	sll	$2,$2,$7
	sll	$3,$4,2
	sll	$6,$2,$3
	nor	$7,$0,$6
.L754:
	lw	$2,D_800A34FC
	sll	$3,$5,16
	addu	$2,$8,$2
	lh	$2,40($2)
	sra	$4,$3,16
	bne	$4,$2,.L755
	lw	$3,D_800A3524
	#nop
	addu	$3,$3,$4
	lbu	$2,23($3)
	.set	noreorder
	.set	nomacro
	j	.L758
	or	$2,$2,$6
	.set	macro
	.set	reorder

.L755:
	lw	$3,D_800A3524
	#nop
	addu	$3,$3,$4
	lbu	$2,23($3)
	#nop
	and	$2,$2,$7
.L758:
	sb	$2,23($3)
	addu	$2,$5,1
	move	$5,$2
	sll	$2,$2,16
	sra	$2,$2,16
	slt	$2,$2,3
	bne	$2,$0,.L754
	j	$31
	.end	func_8006CBD4
.Lfe192:
	.size	 func_8006CBD4,.Lfe192-func_8006CBD4
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8006CCC8.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8006CFBC.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_8006D324
	.type	 func_8006D324,@function
	.ent	func_8006D324
func_8006D324:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$3,D_800A34FC
	li	$2,0x00000005		# 5
	sh	$2,42($3)
	.set	noreorder
	.set	nomacro
	j	$31
	sh	$2,40($3)
	.set	macro
	.set	reorder

	.end	func_8006D324
.Lfe193:
	.size	 func_8006D324,.Lfe193-func_8006D324
	.align	2
	.globl	func_8006D338
	.type	 func_8006D338,@function
	.ent	func_8006D338
func_8006D338:
	.frame	$sp,112,$31		# vars= 88, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,112
	sw	$4,112($sp)
	addu	$4,$sp,16
	sw	$5,116($sp)
	lw	$2,D_800A3514
	lw	$3,D_800A36AC
	la	$5,D_800A3518
	sw	$31,108($sp)
	sw	$16,104($sp)
	addu	$2,$2,1
	andi	$3,$3,0x0001
	sll	$16,$3,7
	addu	$16,$16,$3
	sll	$16,$16,3
	addu	$16,$16,$3
	sll	$16,$16,4
	sw	$2,D_800A3514
	la	$2,g_disp_fb_base
	.set	noreorder
	.set	nomacro
	jal	func_8006E390
	addu	$16,$16,$2
	.set	macro
	.set	reorder

	addu	$4,$sp,16
	li	$5,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	jal	func_80069AE4
	move	$6,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_8006C21C
	addu	$4,$sp,16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_8006CFBC
	addu	$4,$sp,16
	.set	macro
	.set	reorder

	addu	$4,$sp,112
	addu	$5,$sp,116
	sll	$2,$2,16
	.set	noreorder
	.set	nomacro
	jal	func_8006CCC8
	sra	$6,$2,16
	.set	macro
	.set	reorder

	lw	$31,108($sp)
	lw	$16,104($sp)
	addu	$sp,$sp,112
	j	$31
	.end	func_8006D338
.Lfe194:
	.size	 func_8006D338,.Lfe194-func_8006D338
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8006D3DC.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_8006D5D4
	.type	 func_8006D5D4,@function
	.ent	func_8006D5D4
func_8006D5D4:
	.frame	$sp,40,$31		# vars= 8, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	sw	$16,24($sp)
	move	$16,$5
	sw	$17,28($sp)
	move	$17,$0
	addu	$4,$sp,16
	move	$5,$0
	andi	$2,$16,0xffff
	srl	$3,$16,16
	or	$2,$2,$3
	lw	$6,D_800A34FC
	la	$7,D_800A350C
	sw	$31,32($sp)
	sw	$2,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_800692C0
	addu	$6,$6,12
	.set	macro
	.set	reorder

	sra	$3,$2,16
	li	$2,0x00000001		# 1
	.set	noreorder
	.set	nomacro
	bne	$3,$2,.L763
	move	$4,$0
	.set	macro
	.set	reorder

	li	$5,0x0000007f		# 127
	lhu	$2,D_800A3528
	li	$6,0x0000007f		# 127
	.set	noreorder
	.set	nomacro
	j	.L772
	addu	$2,$2,1
	.set	macro
	.set	reorder

.L763:
	li	$2,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	bne	$3,$2,.L764
	li	$5,0x0000007f		# 127
	.set	macro
	.set	reorder

	lhu	$2,D_800A3528
	li	$6,0x0000007f		# 127
	addu	$2,$2,-1
.L772:
	sh	$2,D_800A3528
	jal	func_8005C650
.L764:
	lh	$2,D_800A3528
	#nop
	.set	noreorder
	.set	nomacro
	bgez	$2,.L773
	li	$2,0x55550000		# 1431633920
	.set	macro
	.set	reorder

	li	$2,0x00000002		# 2
	sh	$2,D_800A3528
	li	$2,0x55550000		# 1431633920
.L773:
	lhu	$3,D_800A3528
	ori	$2,$2,0x5556
	sll	$3,$3,16
	sra	$4,$3,16
	mult	$4,$2
	li	$5,0x00100000		# 1048576
	ori	$5,$5,0x0010
	and	$5,$16,$5
	sra	$3,$3,31
	mfhi	$8
	#nop
	#nop
	subu	$3,$8,$3
	sll	$2,$3,1
	addu	$2,$2,$3
	subu	$4,$4,$2
	sh	$4,D_800A3528
	.set	noreorder
	.set	nomacro
	beq	$5,$0,.L767
	li	$4,0x00000002		# 2
	.set	macro
	.set	reorder

	li	$5,0x0000007f		# 127
	.set	noreorder
	.set	nomacro
	jal	func_8005C650
	li	$6,0x0000007f		# 127
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L768
	li	$17,-1			# 0xffffffff
	.set	macro
	.set	reorder

.L767:
	li	$2,0x00400000		# 4194304
	ori	$2,$2,0x0040
	and	$2,$16,$2
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L768
	li	$4,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$5,0x0000007f		# 127
	.set	noreorder
	.set	nomacro
	jal	func_8005C650
	li	$6,0x0000007f		# 127
	.set	macro
	.set	reorder

	lh	$5,D_800A3528
	li	$2,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	bne	$5,$2,.L770
	li	$2,-196608			# 0xfffd0000
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L768
	li	$17,-1			# 0xffffffff
	.set	macro
	.set	reorder

.L770:
	lw	$4,D_800A3524
	ori	$2,$2,0xffff
	lw	$3,20($4)
	li	$17,0x00000001		# 1
	and	$3,$3,$2
	andi	$2,$5,0x0001
	sll	$2,$2,17
	or	$3,$3,$2
	sw	$3,20($4)
.L768:
	move	$2,$17
	lw	$31,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,40
	j	$31
	.end	func_8006D5D4
.Lfe195:
	.size	 func_8006D5D4,.Lfe195-func_8006D5D4
	.align	2
	.globl	func_8006D74C
	.type	 func_8006D74C,@function
	.ent	func_8006D74C
func_8006D74C:
	.frame	$sp,120,$31		# vars= 88, regs= 4/0, args= 16, extra= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,120
	sw	$17,108($sp)
	move	$17,$4
	sw	$18,112($sp)
	move	$18,$5
	addu	$4,$sp,16
	lw	$2,D_800A3514
	lw	$3,D_800A36AC
	la	$5,D_800A3518
	sw	$31,116($sp)
	sw	$16,104($sp)
	addu	$2,$2,1
	andi	$3,$3,0x0001
	sll	$16,$3,7
	addu	$16,$16,$3
	sll	$16,$16,3
	addu	$16,$16,$3
	sll	$16,$16,4
	sw	$2,D_800A3514
	la	$2,D_800F7438
	.set	noreorder
	.set	nomacro
	jal	func_8006E390
	addu	$16,$16,$2
	.set	macro
	.set	reorder

	addu	$4,$sp,16
	li	$5,0x00000001		# 1
	.set	noreorder
	.set	nomacro
	jal	func_80069AE4
	move	$6,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_8006D3DC
	addu	$4,$sp,16
	.set	macro
	.set	reorder

	move	$4,$17
	.set	noreorder
	.set	nomacro
	jal	func_8006D5D4
	move	$5,$18
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_8005C6D0
	move	$16,$2
	.set	macro
	.set	reorder

	move	$2,$16
	lw	$31,116($sp)
	lw	$18,112($sp)
	lw	$17,108($sp)
	lw	$16,104($sp)
	addu	$sp,$sp,120
	j	$31
	.end	func_8006D74C
.Lfe196:
	.size	 func_8006D74C,.Lfe196-func_8006D74C
	.align	2
	.globl	func_8006D7FC
	.type	 func_8006D7FC,@function
	.ent	func_8006D7FC
func_8006D7FC:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	sw	$0,D_800A352C
	.set	noreorder
	.set	nomacro
	j	$31
	li	$2,0x00000001		# 1
	.set	macro
	.set	reorder

	.end	func_8006D7FC
.Lfe197:
	.size	 func_8006D7FC,.Lfe197-func_8006D7FC
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8006D808.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8006DD94.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_8006DF68
	.type	 func_8006DF68,@function
	.ent	func_8006DF68
func_8006DF68:
	.frame	$sp,40,$31		# vars= 8, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	sw	$16,24($sp)
	move	$16,$5
	sw	$17,28($sp)
	move	$17,$0
	addu	$4,$sp,16
	move	$5,$0
	andi	$2,$16,0xffff
	srl	$3,$16,16
	or	$2,$2,$3
	lw	$6,D_800A34FC
	la	$7,D_800A350C
	sw	$31,32($sp)
	sw	$2,16($sp)
	.set	noreorder
	.set	nomacro
	jal	func_800692C0
	addu	$6,$6,12
	.set	macro
	.set	reorder

	sra	$2,$2,16
	andi	$2,$2,0x00ff
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L777
	move	$4,$0
	.set	macro
	.set	reorder

	li	$5,0x0000007f		# 127
	lw	$2,D_800A352C
	#nop
	addu	$2,$2,1
	sw	$2,D_800A352C
	.set	noreorder
	.set	nomacro
	jal	func_8005C650
	li	$6,0x0000007f		# 127
	.set	macro
	.set	reorder

.L777:
	li	$3,0x00100000		# 1048576
	ori	$3,$3,0x0010
	lw	$2,D_800A352C
	and	$3,$16,$3
	andi	$2,$2,0x0001
	sw	$2,D_800A352C
	.set	noreorder
	.set	nomacro
	beq	$3,$0,.L778
	li	$4,0x00000002		# 2
	.set	macro
	.set	reorder

	li	$17,-1			# 0xffffffff
	li	$5,0x0000007f		# 127
	.set	noreorder
	.set	nomacro
	jal	func_8005C650
	li	$6,0x0000007f		# 127
	.set	macro
	.set	reorder

	j	.L779
.L778:
	li	$2,0x00400000		# 4194304
	ori	$2,$2,0x0040
	and	$2,$16,$2
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L779
	li	$4,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$5,0x0000007f		# 127
	.set	noreorder
	.set	nomacro
	jal	func_8005C650
	li	$6,0x0000007f		# 127
	.set	macro
	.set	reorder

	lw	$2,D_800A352C
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L779
	li	$17,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$17,-1			# 0xffffffff
.L779:
	jal	func_8005C6D0
	move	$2,$17
	lw	$31,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,40
	j	$31
	.end	func_8006DF68
.Lfe198:
	.size	 func_8006DF68,.Lfe198-func_8006DF68
	.align	2
	.globl	func_8006E068
	.type	 func_8006E068,@function
	.ent	func_8006E068
func_8006E068:
	.frame	$sp,120,$31		# vars= 88, regs= 4/0, args= 16, extra= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,120
	sw	$17,108($sp)
	move	$17,$4
	sw	$18,112($sp)
	move	$18,$5
	addu	$4,$sp,16
	lw	$2,D_800A3514
	lw	$3,D_800A36AC
	la	$5,D_800A3518
	sw	$31,116($sp)
	sw	$16,104($sp)
	addu	$2,$2,1
	andi	$3,$3,0x0001
	sll	$16,$3,7
	addu	$16,$16,$3
	sll	$16,$16,3
	addu	$16,$16,$3
	sll	$16,$16,4
	sw	$2,D_800A3514
	la	$2,g_disp_fb_base
	.set	noreorder
	.set	nomacro
	jal	func_8006E390
	addu	$16,$16,$2
	.set	macro
	.set	reorder

	addu	$4,$sp,16
	li	$5,0x00000001		# 1
	.set	noreorder
	.set	nomacro
	jal	func_80069AE4
	move	$6,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_8006DD94
	addu	$4,$sp,16
	.set	macro
	.set	reorder

	move	$4,$17
	.set	noreorder
	.set	nomacro
	jal	func_8006DF68
	move	$5,$18
	.set	macro
	.set	reorder

	lw	$31,116($sp)
	lw	$18,112($sp)
	lw	$17,108($sp)
	lw	$16,104($sp)
	addu	$sp,$sp,120
	j	$31
	.end	func_8006E068
.Lfe199:
	.size	 func_8006E068,.Lfe199-func_8006E068
	.align	2
	.globl	func_8006E10C
	.type	 func_8006E10C,@function
	.ent	func_8006E10C
func_8006E10C:
	.frame	$sp,56,$31		# vars= 8, regs= 5/0, args= 24, extra= 0
	.mask	0x800f0000,-8
	.fmask	0x00000000,0
	lw	$2,D_800A3524
	subu	$sp,$sp,56
	sw	$31,48($sp)
	sw	$19,44($sp)
	sw	$18,40($sp)
	sw	$17,36($sp)
	sw	$16,32($sp)
	la	$6,D_800A32D8
	lwl	$3,3($6)
	lwr	$3,0($6)
	lwl	$4,7($6)
	lwr	$4,4($6)
	swl	$3,27($sp)
	swr	$3,24($sp)
	swl	$4,31($sp)
	swr	$4,28($sp)
	lw	$2,32($2)
	lw	$19,D_800A3500
	andi	$2,$2,0x0001
	beq	$2,$0,.L785
	li	$4,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	j	.L786
	li	$5,0x00000060		# 96
	.set	macro
	.set	reorder

.L785:
	li	$4,0x00000002		# 2
	li	$5,0x00000007		# 7
.L786:
	.set	noreorder
	.set	nomacro
	jal	func_80036EA8
	li	$17,0x000000f0		# 240
	.set	macro
	.set	reorder

	move	$16,$2
	lw	$5,D_800A3500
	.set	noreorder
	.set	nomacro
	jal	replay_camera_Init
	move	$4,$16
	.set	macro
	.set	reorder

	jal	game_FrameLoop
	.set	noreorder
	.set	nomacro
	jal	func_80036F28
	move	$4,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	SetDispMask
	move	$4,$0
	.set	macro
	.set	reorder

	la	$16,D_800F7438
	move	$4,$16
	move	$5,$0
	move	$6,$0
	li	$7,0x00000280		# 640
	.set	noreorder
	.set	nomacro
	jal	SetDefDrawEnv
	sw	$17,16($sp)
	.set	macro
	.set	reorder

	addu	$4,$16,16528
	move	$5,$0
	li	$6,0x000000f0		# 240
	li	$7,0x00000280		# 640
	.set	noreorder
	.set	nomacro
	jal	SetDefDrawEnv
	sw	$17,16($sp)
	.set	macro
	.set	reorder

	addu	$4,$16,92
	move	$5,$0
	li	$6,0x000000f0		# 240
	li	$7,0x00000280		# 640
	.set	noreorder
	.set	nomacro
	jal	SetDefDispEnv
	sw	$17,16($sp)
	.set	macro
	.set	reorder

	addu	$18,$16,16620
	move	$4,$18
	move	$5,$0
	move	$6,$0
	li	$7,0x00000280		# 640
	.set	noreorder
	.set	nomacro
	jal	SetDefDispEnv
	sw	$17,16($sp)
	.set	macro
	.set	reorder

	sb	$0,D_800F74A4
	sb	$0,D_800FB534
	sb	$0,D_800F74A5
	sb	$0,D_800FB535
	.set	noreorder
	.set	nomacro
	jal	DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	addu	$4,$sp,24
	move	$5,$0
	move	$6,$0
	.set	noreorder
	.set	nomacro
	jal	ClearImage
	move	$7,$0
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	addu	$4,$sp,24
	.set	noreorder
	.set	nomacro
	jal	LoadImage
	addu	$5,$19,20
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	PutDrawEnv
	move	$4,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	PutDispEnv
	move	$4,$18
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	SetDispMask
	li	$4,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$2,0x00000001		# 1
	lw	$31,48($sp)
	lw	$19,44($sp)
	lw	$18,40($sp)
	lw	$17,36($sp)
	lw	$16,32($sp)
	addu	$sp,$sp,56
	j	$31
	.end	func_8006E10C
.Lfe200:
	.size	 func_8006E10C,.Lfe200-func_8006E10C
	.align	2
	.globl	func_8006E2A8
	.type	 func_8006E2A8,@function
	.ent	func_8006E2A8
func_8006E2A8:
	.frame	$sp,32,$31		# vars= 8, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	move	$4,$0
	sw	$31,28($sp)
	.set	noreorder
	.set	nomacro
	jal	SetDispMask
	sw	$16,24($sp)
	.set	macro
	.set	reorder

	lw	$2,D_800A3518
	la	$16,D_800F7438
	andi	$2,$2,0x0001
	sll	$4,$2,7
	addu	$4,$4,$2
	sll	$4,$4,3
	addu	$4,$4,$2
	sll	$4,$4,4
	.set	noreorder
	.set	nomacro
	jal	PutDrawEnv
	addu	$4,$4,$16
	.set	macro
	.set	reorder

	lw	$2,D_800A3518
	addu	$16,$16,92
	andi	$2,$2,0x0001
	sll	$4,$2,7
	addu	$4,$4,$2
	sll	$4,$4,3
	addu	$4,$4,$2
	sll	$4,$4,4
	.set	noreorder
	.set	nomacro
	jal	PutDispEnv
	addu	$4,$4,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	la	$5,D_800A32E0
	lwl	$2,3($5)
	lwr	$2,0($5)
	lwl	$3,7($5)
	lwr	$3,4($5)
	swl	$2,19($sp)
	swr	$2,16($sp)
	swl	$3,23($sp)
	swr	$3,20($sp)
	addu	$4,$sp,16
	move	$5,$0
	move	$6,$0
	.set	noreorder
	.set	nomacro
	jal	ClearImage
	move	$7,$0
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	li	$4,0x00000001		# 1
	move	$5,$0
	move	$6,$0
	.set	noreorder
	.set	nomacro
	jal	disp_SetFramebufferMode
	move	$7,$0
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	SetDispMask
	li	$4,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$2,0x00000001		# 1
	lw	$31,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,32
	j	$31
	.end	func_8006E2A8
.Lfe201:
	.size	 func_8006E2A8,.Lfe201-func_8006E2A8
	.align	2
	.globl	func_8006E390
	.type	 func_8006E390,@function
	.ent	func_8006E390
func_8006E390:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$16,16($sp)
	move	$16,$4
	sw	$31,20($sp)
	lw	$4,0($5)
	#nop
	addu	$4,$4,1
	sw	$4,0($5)
	.set	noreorder
	.set	nomacro
	jal	func_80069120
	andi	$4,$4,0x0001
	.set	macro
	.set	reorder

	lw	$3,D_800A34FC
	#nop
	lw	$3,36($3)
	#nop
	sw	$3,4($16)
	lw	$3,4($2)
	#nop
	sw	$3,12($16)
	lw	$3,0($2)
	#nop
	sw	$3,8($16)
	lw	$3,8($2)
	#nop
	sw	$3,16($16)
	lw	$3,16($2)
	#nop
	sw	$3,20($16)
	lw	$3,12($2)
	#nop
	sw	$3,24($16)
	lw	$3,20($2)
	#nop
	sw	$3,28($16)
	lw	$3,24($2)
	#nop
	sw	$3,32($16)
	lw	$3,28($2)
	sw	$2,D_800A3520
	sw	$3,36($16)
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_8006E390
.Lfe202:
	.size	 func_8006E390,.Lfe202-func_8006E390
	.align	2
	.globl	func_8006E440
	.type	 func_8006E440,@function
	.ent	func_8006E440
func_8006E440:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$3,0($4)
	li	$2,-1			# 0xffffffff
	.set	noreorder
	.set	nomacro
	beq	$3,$2,.L793
	move	$5,$4
	.set	macro
	.set	reorder

	li	$3,-1			# 0xffffffff
	lw	$2,0($4)
	#nop
	addu	$2,$2,$5
.L799:
	sw	$2,0($4)
	addu	$4,$4,4
	lw	$2,0($4)
	#nop
	.set	noreorder
	.set	nomacro
	bne	$2,$3,.L799
	addu	$2,$2,$5
	.set	macro
	.set	reorder

.L793:
	j	$31
	.end	func_8006E440
.Lfe203:
	.size	 func_8006E440,.Lfe203-func_8006E440
	.align	2
	.globl	func_8006E480
	.type	 func_8006E480,@function
	.ent	func_8006E480
func_8006E480:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lbu	$2,0($4)
	lbu	$3,1($4)
	andi	$2,$2,0xfe1f
	sll	$3,$3,7
	addu	$2,$2,$3
	.set	noreorder
	.set	nomacro
	j	$31
	addu	$2,$2,$5
	.set	macro
	.set	reorder

	.end	func_8006E480
.Lfe204:
	.size	 func_8006E480,.Lfe204-func_8006E480
	.align	2
	.globl	func_8006E49C
	.type	 func_8006E49C,@function
	.ent	func_8006E49C
func_8006E49C:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	li	$3,0x00009c40		# 40000
	sw	$4,0($5)
	addu	$4,$4,$3
	addu	$2,$4,24000
	sw	$2,8($5)
	addu	$2,$4,25080
	sw	$4,4($5)
	addu	$4,$4,26680
	sw	$2,12($5)
	addu	$2,$4,7000
	sw	$2,20($5)
	addu	$2,$4,7600
	sw	$2,24($5)
	addu	$2,$4,7720
	sw	$2,28($5)
	addu	$2,$4,7840
	sw	$4,16($5)
	addu	$4,$4,8112
	sw	$4,44($5)
	addu	$4,$4,$3
	sw	$2,32($5)
	addu	$2,$4,24000
	sw	$2,52($5)
	addu	$2,$4,25080
	sw	$4,48($5)
	addu	$4,$4,26680
	sw	$2,56($5)
	addu	$2,$4,7000
	sw	$2,64($5)
	addu	$2,$4,7600
	sw	$2,68($5)
	addu	$2,$4,7720
	sw	$2,72($5)
	addu	$2,$4,7840
	sw	$2,76($5)
	addu	$2,$4,8112
	.set	noreorder
	.set	nomacro
	j	$31
	sw	$4,60($5)
	.set	macro
	.set	reorder

	.end	func_8006E49C
.Lfe205:
	.size	 func_8006E49C,.Lfe205-func_8006E49C
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8006E534.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_8006E8AC
	.type	 func_8006E8AC,@function
	.ent	func_8006E8AC
func_8006E8AC:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	sll	$2,$4,1
	addu	$2,$2,$4
	sll	$2,$2,2
	subu	$2,$2,$4
	lw	$3,D_800A35AC
	sll	$2,$2,2
	.set	noreorder
	.set	nomacro
	j	$31
	addu	$2,$3,$2
	.set	macro
	.set	reorder

	.end	func_8006E8AC
.Lfe206:
	.size	 func_8006E8AC,.Lfe206-func_8006E8AC
	.align	2
	.globl	func_8006E8CC
	.type	 func_8006E8CC,@function
	.ent	func_8006E8CC
func_8006E8CC:
	.frame	$sp,32,$31		# vars= 8, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	sw	$16,24($sp)
	sw	$31,28($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80077D00
	move	$16,$4
	.set	macro
	.set	reorder

	lw	$2,32($2)
	#nop
	andi	$2,$2,0x0001
	beq	$2,$0,.L804
	lw	$16,16($16)
	.set	noreorder
	.set	nomacro
	j	.L806
	move	$4,$0
	.set	macro
	.set	reorder

.L804:
	lw	$16,12($16)
	move	$4,$0
.L806:
	li	$2,0x000001e0		# 480
	sh	$2,18($sp)
	li	$2,0x00000280		# 640
	sh	$2,20($sp)
	li	$2,0x00000020		# 32
	sh	$0,16($sp)
	.set	noreorder
	.set	nomacro
	jal	DrawSync
	sh	$2,22($sp)
	.set	macro
	.set	reorder

	addu	$4,$sp,16
	.set	noreorder
	.set	nomacro
	jal	LoadImage
	move	$5,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	DrawSync
	move	$4,$0
	.set	macro
	.set	reorder

	lw	$31,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,32
	j	$31
	.end	func_8006E8CC
.Lfe207:
	.size	 func_8006E8CC,.Lfe207-func_8006E8CC
	.align	2
	.globl	func_8006E950
	.type	 func_8006E950,@function
	.ent	func_8006E950
func_8006E950:
	.frame	$sp,48,$31		# vars= 8, regs= 5/0, args= 16, extra= 0
	.mask	0x800f0000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,48
	sw	$16,24($sp)
	move	$16,$4
	sw	$17,28($sp)
	move	$17,$5
	sw	$31,40($sp)
	sw	$19,36($sp)
	.set	noreorder
	.set	nomacro
	jal	game_FrameLoop
	sw	$18,32($sp)
	.set	macro
	.set	reorder

	li	$4,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	jal	func_80036EA8
	move	$5,$16
	.set	macro
	.set	reorder

	move	$4,$2
	.set	noreorder
	.set	nomacro
	jal	replay_camera_Init
	move	$5,$17
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	game_FrameLoop
	li	$18,0x00000280		# 640
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_8006E440
	move	$4,$17
	.set	macro
	.set	reorder

	move	$4,$0
	li	$2,0x00000180		# 384
	lw	$19,8($17)
	li	$16,0x000001dc		# 476
	sh	$18,16($sp)
	sh	$0,18($sp)
	sh	$2,20($sp)
	.set	noreorder
	.set	nomacro
	jal	DrawSync
	sh	$16,22($sp)
	.set	macro
	.set	reorder

	addu	$4,$sp,16
	.set	noreorder
	.set	nomacro
	jal	LoadImage
	move	$5,$19
	.set	macro
	.set	reorder

	move	$4,$0
	li	$2,0x00000170		# 368
	sh	$2,20($sp)
	li	$2,0x00000024		# 36
	sh	$18,16($sp)
	sh	$16,18($sp)
	.set	noreorder
	.set	nomacro
	jal	DrawSync
	sh	$2,22($sp)
	.set	macro
	.set	reorder

	li	$5,0x00050000		# 327680
	ori	$5,$5,0x9400
	addu	$4,$sp,16
	.set	noreorder
	.set	nomacro
	jal	LoadImage
	addu	$5,$19,$5
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_8006E8CC
	move	$4,$17
	.set	macro
	.set	reorder

	lw	$31,40($sp)
	lw	$19,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,48
	j	$31
	.end	func_8006E950
.Lfe208:
	.size	 func_8006E950,.Lfe208-func_8006E950
	.align	2
	.globl	func_8006EA28
	.type	 func_8006EA28,@function
	.ent	func_8006EA28
func_8006EA28:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$16,16($sp)
	move	$16,$4
	sw	$31,20($sp)
	lw	$5,84($16)
	jal	func_8006920C
	lw	$5,88($16)
	.set	noreorder
	.set	nomacro
	jal	func_8006920C
	move	$4,$16
	.set	macro
	.set	reorder

	lw	$5,92($16)
	.set	noreorder
	.set	nomacro
	jal	func_8006920C
	move	$4,$16
	.set	macro
	.set	reorder

	lw	$5,96($16)
	.set	noreorder
	.set	nomacro
	jal	func_8006920C
	move	$4,$16
	.set	macro
	.set	reorder

	lw	$5,100($16)
	.set	noreorder
	.set	nomacro
	jal	func_8006920C
	move	$4,$16
	.set	macro
	.set	reorder

	lw	$5,104($16)
	.set	noreorder
	.set	nomacro
	jal	func_8006920C
	move	$4,$16
	.set	macro
	.set	reorder

	lw	$5,108($16)
	.set	noreorder
	.set	nomacro
	jal	func_8006920C
	move	$4,$16
	.set	macro
	.set	reorder

	lw	$5,112($16)
	.set	noreorder
	.set	nomacro
	jal	func_8006920C
	move	$4,$16
	.set	macro
	.set	reorder

	lw	$5,116($16)
	.set	noreorder
	.set	nomacro
	jal	func_8006920C
	move	$4,$16
	.set	macro
	.set	reorder

	lw	$4,0($16)
	lw	$6,4($16)
	.set	noreorder
	.set	nomacro
	jal	func_8005C2A8
	li	$5,0x00000001		# 1
	.set	macro
	.set	reorder

	lw	$2,4($16)
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_8006EA28
.Lfe209:
	.size	 func_8006EA28,.Lfe209-func_8006EA28
	.align	2
	.globl	func_8006EACC
	.type	 func_8006EACC,@function
	.ent	func_8006EACC
func_8006EACC:
	.frame	$sp,64,$31		# vars= 40, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	lw	$3,D_800A36AC
	#nop
	andi	$3,$3,0x0001
	sll	$2,$3,7
	addu	$2,$2,$3
	sll	$2,$2,3
	addu	$2,$2,$3
	sll	$2,$2,4
	la	$3,D_800F7438
	addu	$2,$2,$3
	lw	$3,D_800A35BC
	subu	$sp,$sp,64
	sw	$31,56($sp)
	sw	$4,D_800A3548
	sw	$5,D_800A354C
	sw	$2,D_800A35C0
	li	$2,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	bne	$3,$2,.L810
	andi	$2,$5,0xffff
	.set	macro
	.set	reorder

	sw	$2,D_800A354C
.L810:
	jal	func_8006EC0C
	lw	$5,D_800A35C4
	#nop
	lw	$3,12($5)
	lw	$2,8($5)
	addu	$3,$3,1
	andi	$4,$3,0x0001
	addu	$2,$2,1
	sw	$2,8($5)
	.set	noreorder
	.set	nomacro
	jal	func_8006E8AC
	sw	$3,12($5)
	.set	macro
	.set	reorder

	lw	$3,D_800A35A8
	#nop
	sw	$3,16($sp)
	lw	$3,0($2)
	#nop
	sw	$3,20($sp)
	lw	$3,8($2)
	#nop
	sw	$3,28($sp)
	lw	$3,16($2)
	#nop
	sw	$3,32($sp)
	lw	$3,12($2)
	#nop
	sw	$3,36($sp)
	lw	$3,20($2)
	#nop
	sw	$3,40($sp)
	lw	$3,24($2)
	#nop
	sw	$3,44($sp)
	lw	$3,28($2)
	sw	$2,D_800A35A4
	sw	$3,48($sp)
	lhu	$3,D_800A3580
	lw	$4,32($2)
	addu	$3,$3,-2
	sltu	$3,$3,2
	.set	noreorder
	.set	nomacro
	bne	$3,$0,.L811
	sw	$4,52($sp)
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_8006F528
	addu	$4,$sp,16
	.set	macro
	.set	reorder

.L811:
	lh	$2,D_800A3580
	#nop
	sll	$2,$2,2
	lw	$2,D_8009BC1C($2)
	#nop
	.set	noreorder
	.set	nomacro
	jal	$31,$2
	addu	$4,$sp,16
	.set	macro
	.set	reorder

	lw	$2,D_800A35A0
	lw	$31,56($sp)
	addu	$sp,$sp,64
	j	$31
	.end	func_8006EACC
.Lfe210:
	.size	 func_8006EACC,.Lfe210-func_8006EACC
	.align	2
	.globl	func_8006EC0C
	.type	 func_8006EC0C,@function
	.ent	func_8006EC0C
func_8006EC0C:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	lbu	$3,D_800A3578
	li	$2,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	beq	$3,$2,.L814
	sw	$31,16($sp)
	.set	macro
	.set	reorder

	slt	$2,$3,3
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L815
	li	$2,0x00000001		# 1
	.set	macro
	.set	reorder

	beq	$3,$2,.L817
	j	.L818
.L815:
	li	$2,0x00000003		# 3
	.set	noreorder
	.set	nomacro
	beq	$3,$2,.L817
	li	$2,0x00000004		# 4
	.set	macro
	.set	reorder

	beq	$3,$2,.L814
	j	.L818
.L817:
	lhu	$2,D_800A3570
	#nop
	addu	$2,$2,32
	sh	$2,D_800A3570
	sll	$2,$2,16
	sra	$2,$2,16
	slt	$2,$2,488
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L818
	li	$3,0x000001e8		# 488
	.set	macro
	.set	reorder

	lhu	$2,D_800A3584
	lhu	$4,D_800A3578
	sh	$3,D_800A3570
	sh	$2,D_800A3580
	srl	$2,$4,8
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L818
	addu	$2,$4,1
	.set	macro
	.set	reorder

	sh	$2,D_800A3578
	j	.L818
.L814:
	lh	$3,D_800A3570
	li	$2,0x000001e8		# 488
	.set	noreorder
	.set	nomacro
	bne	$3,$2,.L823
	li	$4,0x00000005		# 5
	.set	macro
	.set	reorder

	li	$5,0x0000007f		# 127
	.set	noreorder
	.set	nomacro
	jal	func_8005C650
	li	$6,0x0000007f		# 127
	.set	macro
	.set	reorder

.L823:
	lhu	$2,D_800A3570
	#nop
	addu	$2,$2,-32
	sh	$2,D_800A3570
	sll	$2,$2,16
	bgtz	$2,.L818
	sh	$0,D_800A3570
	sh	$0,D_800A3578
.L818:
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_8006EC0C
.Lfe211:
	.size	 func_8006EC0C,.Lfe211-func_8006EC0C
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8006ECF4.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_8006F038
	.type	 func_8006F038,@function
	.ent	func_8006F038
func_8006F038:
	.frame	$sp,40,$31		# vars= 0, regs= 3/0, args= 24, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	sw	$17,28($sp)
	move	$17,$4
	sw	$31,32($sp)
	sw	$16,24($sp)
	lw	$16,20($17)
	.set	noreorder
	.set	nomacro
	jal	SetTile
	move	$4,$16
	.set	macro
	.set	reorder

	move	$4,$16
	lhu	$2,D_800A3550
	li	$5,0x00000001		# 1
	sh	$0,8($16)
	sh	$0,10($16)
	sb	$2,4($16)
	lhu	$3,D_800A3550
	li	$2,0x00000280		# 640
	sh	$2,12($16)
	sb	$3,5($16)
	lhu	$3,D_800A3550
	li	$2,0x000000f0		# 240
	sh	$2,14($16)
	.set	noreorder
	.set	nomacro
	jal	SetSemiTrans
	sb	$3,6($16)
	.set	macro
	.set	reorder

	move	$5,$16
	lw	$4,D_800A374C
	.set	noreorder
	.set	nomacro
	jal	AddPrim
	addu	$16,$16,16
	.set	macro
	.set	reorder

	li	$5,0x00000001		# 1
	move	$6,$0
	sw	$16,20($17)
	sw	$0,16($sp)
	lw	$4,24($17)
	.set	noreorder
	.set	nomacro
	jal	SetDrawMode
	li	$7,0x00000040		# 64
	.set	macro
	.set	reorder

	lw	$4,D_800A374C
	lw	$5,24($17)
	jal	AddPrim
	lw	$2,24($17)
	#nop
	addu	$2,$2,12
	sw	$2,24($17)
	lw	$31,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,40
	j	$31
	.end	func_8006F038
.Lfe212:
	.size	 func_8006F038,.Lfe212-func_8006F038
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8006F100.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8006F528.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8006F97C.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80070188.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80070C70.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80070F78.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_80071C20
	.type	 func_80071C20,@function
	.ent	func_80071C20
func_80071C20:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lbu	$2,D_800A3561
	#nop
	lbu	$2,D_8009BC7C($2)
	#nop
	andi	$2,$2,0x0002
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L827
	li	$3,0x00000003		# 3
	.set	macro
	.set	reorder

	li	$3,0x00000009		# 9
.L827:
	.set	noreorder
	.set	nomacro
	j	$31
	move	$2,$3
	.set	macro
	.set	reorder

	.end	func_80071C20
.Lfe213:
	.size	 func_80071C20,.Lfe213-func_80071C20
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80071C4C.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_80072084
	.type	 func_80072084,@function
	.ent	func_80072084
func_80072084:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	lw	$2,D_800A35A8
	subu	$sp,$sp,24
	sw	$31,16($sp)
	lw	$5,104($2)
	.set	noreorder
	.set	nomacro
	jal	func_800720FC
	move	$6,$0
	.set	macro
	.set	reorder

	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80072084
.Lfe214:
	.size	 func_80072084,.Lfe214-func_80072084
	.align	2
	.globl	func_800720AC
	.type	 func_800720AC,@function
	.ent	func_800720AC
func_800720AC:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	lw	$2,D_800A35A8
	subu	$sp,$sp,24
	sw	$31,16($sp)
	lw	$5,108($2)
	.set	noreorder
	.set	nomacro
	jal	func_800720FC
	li	$6,0x00000001		# 1
	.set	macro
	.set	reorder

	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_800720AC
.Lfe215:
	.size	 func_800720AC,.Lfe215-func_800720AC
	.align	2
	.globl	func_800720D4
	.type	 func_800720D4,@function
	.ent	func_800720D4
func_800720D4:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	lw	$2,D_800A35A8
	subu	$sp,$sp,24
	sw	$31,16($sp)
	lw	$5,112($2)
	.set	noreorder
	.set	nomacro
	jal	func_800720FC
	li	$6,0x00000002		# 2
	.set	macro
	.set	reorder

	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_800720D4
.Lfe216:
	.size	 func_800720D4,.Lfe216-func_800720D4
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_800720FC.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_80072BC4
	.type	 func_80072BC4,@function
	.ent	func_80072BC4
func_80072BC4:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	sw	$16,16($sp)
	move	$16,$4
	sw	$17,20($sp)
	move	$17,$5
	sw	$31,24($sp)
	.set	noreorder
	.set	nomacro
	jal	SetPolyG4
	move	$4,$17
	.set	macro
	.set	reorder

	move	$4,$17
	.set	noreorder
	.set	nomacro
	jal	SetSemiTrans
	move	$5,$0
	.set	macro
	.set	reorder

	slt	$16,$16,4
	.set	noreorder
	.set	nomacro
	beq	$16,$0,.L832
	li	$3,0x000000fc		# 252
	.set	macro
	.set	reorder

	li	$2,0x00000082		# 130
	sb	$0,4($17)
	sb	$0,5($17)
	sb	$0,6($17)
	sb	$3,12($17)
	sb	$2,13($17)
	sb	$0,14($17)
	sb	$3,20($17)
	sb	$2,21($17)
	sb	$0,22($17)
	lw	$2,D_800A35C4
	#nop
	lw	$2,8($2)
	#nop
	andi	$2,$2,0x0004
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L833
	li	$2,0x000000c3		# 195
	.set	macro
	.set	reorder

	sb	$2,29($17)
	.set	noreorder
	.set	nomacro
	j	.L834
	li	$2,0x0000001e		# 30
	.set	macro
	.set	reorder

.L833:
	sb	$2,29($17)
	li	$2,0x00000050		# 80
.L834:
	sb	$3,28($17)
	.set	noreorder
	.set	nomacro
	j	.L835
	sb	$2,30($17)
	.set	macro
	.set	reorder

.L832:
	li	$3,0x00000040		# 64
	li	$4,0x00000080		# 128
	li	$2,0x00000050		# 80
	sb	$2,20($17)
	li	$2,0x000000a0		# 160
	sb	$2,21($17)
	li	$2,0x00000010		# 16
	sb	$0,4($17)
	sb	$0,5($17)
	sb	$0,6($17)
	sb	$3,12($17)
	sb	$0,13($17)
	sb	$4,14($17)
	sb	$3,22($17)
	sb	$2,28($17)
	sb	$3,29($17)
	sb	$4,30($17)
.L835:
	lw	$4,D_800A374C
	move	$5,$17
	.set	noreorder
	.set	nomacro
	jal	AddPrim
	addu	$4,$4,96
	.set	macro
	.set	reorder

	addu	$2,$17,36
	lw	$31,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,32
	j	$31
	.end	func_80072BC4
.Lfe217:
	.size	 func_80072BC4,.Lfe217-func_80072BC4
	.align	2
	.globl	func_80072CD4
	.type	 func_80072CD4,@function
	.ent	func_80072CD4
func_80072CD4:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	sw	$16,16($sp)
	move	$16,$4
	sw	$17,20($sp)
	move	$17,$5
	sw	$31,24($sp)
	.set	noreorder
	.set	nomacro
	jal	SetPolyG4
	move	$4,$17
	.set	macro
	.set	reorder

	move	$4,$17
	.set	noreorder
	.set	nomacro
	jal	SetSemiTrans
	move	$5,$0
	.set	macro
	.set	reorder

	slt	$16,$16,4
	.set	noreorder
	.set	nomacro
	beq	$16,$0,.L837
	li	$2,0x00000010		# 16
	.set	macro
	.set	reorder

	lw	$2,D_800A35C4
	#nop
	lw	$2,8($2)
	#nop
	andi	$2,$2,0x0004
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L838
	li	$4,0x000000fc		# 252
	.set	macro
	.set	reorder

	li	$3,0x00000032		# 50
	li	$2,0x000000c3		# 195
	sb	$2,5($17)
	li	$2,0x0000001e		# 30
	sb	$2,6($17)
	.set	noreorder
	.set	nomacro
	j	.L841
	li	$2,0x000000c8		# 200
	.set	macro
	.set	reorder

.L838:
	li	$3,0x00000046		# 70
	li	$2,0x000000c3		# 195
	sb	$2,5($17)
	li	$2,0x00000050		# 80
	sb	$2,6($17)
	li	$2,0x000000dc		# 220
.L841:
	sb	$2,13($17)
	li	$2,0x000000fc		# 252
	sb	$2,20($17)
	li	$2,0x00000082		# 130
	sb	$2,21($17)
	li	$2,0x00000032		# 50
	sb	$2,28($17)
	li	$2,0x00000028		# 40
	sb	$2,29($17)
	li	$2,0x0000000a		# 10
	sb	$4,4($17)
	sb	$4,12($17)
	sb	$3,14($17)
	sb	$0,22($17)
	.set	noreorder
	.set	nomacro
	j	.L840
	sb	$2,30($17)
	.set	macro
	.set	reorder

.L837:
	li	$3,0x00000030		# 48
	li	$4,0x00000060		# 96
	sb	$2,4($17)
	li	$2,0x00000018		# 24
	sb	$2,12($17)
	li	$2,0x00000040		# 64
	sb	$3,5($17)
	sb	$4,6($17)
	sb	$0,13($17)
	sb	$2,14($17)
	sb	$3,20($17)
	sb	$0,21($17)
	sb	$4,22($17)
	sb	$0,28($17)
	sb	$0,29($17)
	sb	$0,30($17)
.L840:
	lw	$4,D_800A374C
	move	$5,$17
	.set	noreorder
	.set	nomacro
	jal	AddPrim
	addu	$4,$4,96
	.set	macro
	.set	reorder

	addu	$2,$17,36
	lw	$31,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,32
	j	$31
	.end	func_80072CD4
.Lfe218:
	.size	 func_80072CD4,.Lfe218-func_80072CD4
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80072E10.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_80072F30
	.type	 func_80072F30,@function
	.ent	func_80072F30
func_80072F30:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	sw	$16,16($sp)
	move	$16,$4
	sw	$17,20($sp)
	move	$17,$5
	sw	$31,24($sp)
	.set	noreorder
	.set	nomacro
	jal	SetTile
	move	$4,$17
	.set	macro
	.set	reorder

	slt	$16,$16,4
	.set	noreorder
	.set	nomacro
	beq	$16,$0,.L843
	li	$5,0x00000001		# 1
	.set	macro
	.set	reorder

	move	$4,$17
	li	$2,0x0000009e		# 158
	sb	$2,4($17)
	li	$2,0x00000064		# 100
	sb	$2,5($17)
	.set	noreorder
	.set	nomacro
	j	.L845
	sb	$0,6($17)
	.set	macro
	.set	reorder

.L843:
	move	$4,$17
	move	$5,$0
	li	$2,0x00000028		# 40
	sb	$2,4($17)
	sb	$2,5($17)
	li	$2,0x00000018		# 24
	sb	$2,6($17)
.L845:
	jal	SetSemiTrans
	lw	$4,D_800A374C
	move	$5,$17
	.set	noreorder
	.set	nomacro
	jal	AddPrim
	addu	$4,$4,92
	.set	macro
	.set	reorder

	addu	$2,$17,16
	lw	$31,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,32
	j	$31
	.end	func_80072F30
.Lfe219:
	.size	 func_80072F30,.Lfe219-func_80072F30
	.align	2
	.globl	func_80072FCC
	.type	 func_80072FCC,@function
	.ent	func_80072FCC
func_80072FCC:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$16,16($sp)
	move	$16,$5
	sw	$31,20($sp)
	.set	noreorder
	.set	nomacro
	jal	SetTile
	move	$4,$16
	.set	macro
	.set	reorder

	lh	$2,D_800A3580
	#nop
	slt	$2,$2,4
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L847
	li	$5,0x00000001		# 1
	.set	macro
	.set	reorder

	move	$4,$16
	li	$2,0x00000046		# 70
	sb	$2,4($16)
	li	$2,0x00000024		# 36
	sb	$2,5($16)
	li	$2,0x0000000a		# 10
	.set	noreorder
	.set	nomacro
	j	.L849
	sb	$2,6($16)
	.set	macro
	.set	reorder

.L847:
	move	$4,$16
	move	$5,$0
	sb	$0,4($16)
	sb	$0,5($16)
	sb	$0,6($16)
.L849:
	jal	SetSemiTrans
	lw	$4,D_800A374C
	move	$5,$16
	.set	noreorder
	.set	nomacro
	jal	AddPrim
	addu	$4,$4,92
	.set	macro
	.set	reorder

	addu	$2,$16,16
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80072FCC
.Lfe220:
	.size	 func_80072FCC,.Lfe220-func_80072FCC
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80073060.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80073200.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8007352C.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80073728.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80073C78.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_80074220
	.type	 func_80074220,@function
	.ent	func_80074220
func_80074220:
	.frame	$sp,96,$31		# vars= 48, regs= 6/0, args= 24, extra= 0
	.mask	0x801f0000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,96
	sw	$20,88($sp)
	move	$20,$4
	sw	$31,92($sp)
	sw	$19,84($sp)
	sw	$18,80($sp)
	sw	$17,76($sp)
	.set	noreorder
	.set	nomacro
	bne	$5,$0,.L852
	sw	$16,72($sp)
	.set	macro
	.set	reorder

	lw	$16,20($20)
	.set	noreorder
	.set	nomacro
	jal	SetTile
	move	$4,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_80069A30
	move	$4,$16
	.set	macro
	.set	reorder

	move	$4,$16
	li	$5,0x00000001		# 1
	li	$2,0x0000003f		# 63
	sh	$2,8($16)
	li	$2,0x00000030		# 48
	sh	$2,10($16)
	li	$2,0x00000202		# 514
	sh	$2,12($16)
	li	$2,0x000000b0		# 176
	.set	noreorder
	.set	nomacro
	jal	SetSemiTrans
	sh	$2,14($16)
	.set	macro
	.set	reorder

	move	$5,$16
	lw	$4,D_800A374C
	addu	$16,$16,16
	.set	noreorder
	.set	nomacro
	jal	AddPrim
	addu	$4,$4,120
	.set	macro
	.set	reorder

	sw	$16,20($20)
.L852:
	li	$2,0x0000001f		# 31
	sw	$2,44($sp)
	sb	$0,64($sp)
	sw	$0,40($sp)
	lw	$2,0($20)
	#nop
	lw	$18,56($2)
	move	$17,$0
	sw	$0,48($sp)
	sw	$0,52($sp)
	move	$16,$18
.L853:
	addu	$4,$sp,24
	lw	$2,0($16)
	addu	$16,$16,4
	sw	$2,24($sp)
	addu	$2,$2,12
	sw	$2,28($sp)
	lw	$2,16($20)
	addu	$17,$17,1
	.set	noreorder
	.set	nomacro
	jal	func_8007352C
	sw	$2,32($sp)
	.set	macro
	.set	reorder

	sw	$2,16($20)
	slt	$2,$17,3
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L853
	move	$5,$0
	.set	macro
	.set	reorder

	lw	$4,0($18)
	.set	noreorder
	.set	nomacro
	jal	func_8006E480
	sw	$4,24($sp)
	.set	macro
	.set	reorder

	li	$5,0x00000001		# 1
	move	$6,$0
	sw	$0,16($sp)
	lw	$4,24($20)
	.set	noreorder
	.set	nomacro
	jal	SetDrawMode
	move	$7,$2
	.set	macro
	.set	reorder

	lw	$4,D_800A374C
	lw	$5,24($20)
	.set	noreorder
	.set	nomacro
	jal	AddPrim
	addu	$4,$4,124
	.set	macro
	.set	reorder

	lw	$16,8($20)
	lw	$2,24($20)
	move	$4,$16
	addu	$2,$2,12
	.set	noreorder
	.set	nomacro
	jal	SetPolyF4
	sw	$2,24($20)
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_80069A8C
	move	$4,$16
	.set	macro
	.set	reorder

	move	$4,$16
	move	$5,$0
	li	$2,0x000000b9		# 185
	li	$19,0x00000122		# 290
	li	$18,0x000000ef		# 239
	sh	$0,8($16)
	sh	$2,10($16)
	sh	$19,12($16)
	sh	$0,14($16)
	sh	$0,16($16)
	sh	$18,18($16)
	sh	$19,20($16)
	.set	noreorder
	.set	nomacro
	jal	SetSemiTrans
	sh	$18,22($16)
	.set	macro
	.set	reorder

	move	$5,$16
	lw	$4,D_800A374C
	addu	$16,$16,24
	.set	noreorder
	.set	nomacro
	jal	AddPrim
	addu	$4,$4,128
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	SetPolyF4
	move	$4,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_80069A8C
	move	$4,$16
	.set	macro
	.set	reorder

	move	$4,$16
	move	$5,$0
	li	$17,0x0000015e		# 350
	li	$2,0x0000027f		# 639
	sh	$2,12($16)
	sh	$2,20($16)
	li	$2,0x00000036		# 54
	sh	$17,8($16)
	sh	$0,10($16)
	sh	$0,14($16)
	sh	$17,16($16)
	sh	$18,18($16)
	.set	noreorder
	.set	nomacro
	jal	SetSemiTrans
	sh	$2,22($16)
	.set	macro
	.set	reorder

	move	$5,$16
	lw	$4,D_800A374C
	addu	$16,$16,24
	.set	noreorder
	.set	nomacro
	jal	AddPrim
	addu	$4,$4,128
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	SetPolyF4
	move	$4,$16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_80069A8C
	move	$4,$16
	.set	macro
	.set	reorder

	move	$4,$16
	move	$5,$0
	sh	$19,8($16)
	sh	$0,10($16)
	sh	$17,12($16)
	sh	$0,14($16)
	sh	$19,16($16)
	sh	$18,18($16)
	sh	$17,20($16)
	.set	noreorder
	.set	nomacro
	jal	SetSemiTrans
	sh	$18,22($16)
	.set	macro
	.set	reorder

	move	$5,$16
	lw	$4,D_800A374C
	addu	$16,$16,24
	.set	noreorder
	.set	nomacro
	jal	AddPrim
	addu	$4,$4,128
	.set	macro
	.set	reorder

	sw	$16,8($20)
	lw	$31,92($sp)
	lw	$20,88($sp)
	lw	$19,84($sp)
	lw	$18,80($sp)
	lw	$17,76($sp)
	lw	$16,72($sp)
	addu	$sp,$sp,96
	j	$31
	.end	func_80074220
.Lfe221:
	.size	 func_80074220,.Lfe221-func_80074220
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80074488.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_800747D8.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80074B18.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_80074D2C
	.type	 func_80074D2C,@function
	.ent	func_80074D2C
func_80074D2C:
	.frame	$sp,88,$31		# vars= 48, regs= 3/0, args= 24, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,88
	sw	$16,72($sp)
	move	$16,$4
	sw	$17,76($sp)
	li	$17,0x0000000c		# 12
	sw	$31,80($sp)
	sw	$0,40($sp)
	sb	$0,64($sp)
	lw	$2,0($16)
	sll	$6,$6,16
	lw	$2,28($2)
	sra	$6,$6,14
	addu	$6,$6,$2
	sll	$2,$5,4
	subu	$2,$2,$5
	lw	$3,0($6)
	sll	$2,$2,4
	sw	$2,48($sp)
	sw	$0,52($sp)
	sw	$3,24($sp)
	addu	$3,$3,12
	.set	noreorder
	.set	nomacro
	beq	$5,$0,.L858
	sw	$3,28($sp)
	.set	macro
	.set	reorder

	li	$17,0x00000016		# 22
.L858:
	sw	$17,44($sp)
	lw	$2,16($16)
	addu	$4,$sp,24
	.set	noreorder
	.set	nomacro
	jal	func_8007352C
	sw	$2,32($sp)
	.set	macro
	.set	reorder

	sw	$2,16($16)
	lw	$4,24($sp)
	.set	noreorder
	.set	nomacro
	jal	func_8006E480
	move	$5,$0
	.set	macro
	.set	reorder

	li	$5,0x00000001		# 1
	move	$6,$0
	sw	$0,16($sp)
	lw	$4,24($16)
	.set	noreorder
	.set	nomacro
	jal	SetDrawMode
	move	$7,$2
	.set	macro
	.set	reorder

	sll	$4,$17,2
	lw	$2,D_800A374C
	lw	$5,24($16)
	.set	noreorder
	.set	nomacro
	jal	AddPrim
	addu	$4,$2,$4
	.set	macro
	.set	reorder

	lw	$2,24($16)
	#nop
	addu	$2,$2,12
	sw	$2,24($16)
	lw	$31,80($sp)
	lw	$17,76($sp)
	lw	$16,72($sp)
	addu	$sp,$sp,88
	j	$31
	.end	func_80074D2C
.Lfe222:
	.size	 func_80074D2C,.Lfe222-func_80074D2C
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80074E08.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8007526C.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_800753D8.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_80075670
	.type	 func_80075670,@function
	.ent	func_80075670
func_80075670:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	lw	$3,D_800A36A0
	subu	$sp,$sp,24
	sw	$31,20($sp)
	sw	$16,16($sp)
	sw	$4,24($sp)
	lw	$2,16($3)
	#nop
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L859
	move	$16,$5
	.set	macro
	.set	reorder

	addu	$4,$sp,24
	sll	$2,$16,2
	addu	$6,$2,64
	addu	$6,$3,$6
	la	$7,D_800A35D0
	.set	noreorder
	.set	nomacro
	jal	func_800692C0
	addu	$7,$2,$7
	.set	macro
	.set	reorder

	sra	$2,$2,16
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L861
	move	$4,$0
	.set	macro
	.set	reorder

	lw	$3,D_800A36A0
	#nop
	sh	$0,52($3)
	addu	$3,$3,$16
	lbu	$2,104($3)
	#nop
	addu	$2,$2,1
	sb	$2,104($3)
	lw	$3,D_800A36A0
	li	$5,0x0000007f		# 127
	addu	$3,$3,$16
	lbu	$2,104($3)
	li	$6,0x0000007f		# 127
	andi	$2,$2,0x0001
	.set	noreorder
	.set	nomacro
	jal	func_8005C650
	sb	$2,104($3)
	.set	macro
	.set	reorder

.L861:
	sll	$2,$16,1
	lw	$5,D_800A36A0
	sll	$4,$16,4
	addu	$3,$5,$16
	lbu	$3,104($3)
	addu	$2,$2,$5
	sh	$3,60($2)
	li	$2,0x00000040		# 64
	lw	$3,24($sp)
	sll	$2,$2,$4
	and	$2,$3,$2
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L862
	li	$7,0x00000001		# 1
	.set	macro
	.set	reorder

	move	$4,$0
	li	$6,0x00000002		# 2
.L866:
	sll	$2,$4,16
	addu	$3,$4,1
	move	$4,$3
	sra	$2,$2,15
	addu	$2,$2,$5
	sll	$3,$3,16
	sra	$3,$3,16
	slt	$3,$3,2
	sh	$0,56($2)
	sh	$7,16($2)
	.set	noreorder
	.set	nomacro
	bne	$3,$0,.L866
	sh	$6,24($2)
	.set	macro
	.set	reorder

	li	$4,0x00000001		# 1
	li	$5,0x0000007f		# 127
	li	$6,0x0000007f		# 127
	addu	$3,$16,1
	lw	$7,D_800A36A0
	andi	$3,$3,0x0001
	addu	$2,$7,$16
	lbu	$2,104($2)
	addu	$7,$7,$3
	addu	$2,$2,1
	andi	$2,$2,0x0001
	.set	noreorder
	.set	nomacro
	j	.L878
	sb	$2,104($7)
	.set	macro
	.set	reorder

.L862:
	li	$2,0x00000010		# 16
	sll	$2,$2,$4
	and	$2,$3,$2
	beq	$2,$0,.L859
	.set	noreorder
	.set	nomacro
	bne	$16,$0,.L870
	addu	$2,$5,20
	.set	macro
	.set	reorder

	addu	$2,$5,22
.L870:
	lh	$3,0($2)
	li	$2,0x00000001		# 1
	.set	noreorder
	.set	nomacro
	bne	$3,$2,.L871
	li	$4,0x00000004		# 4
	.set	macro
	.set	reorder

	move	$4,$0
	li	$6,0x00000003		# 3
.L875:
	sll	$2,$4,16
	addu	$3,$4,1
	move	$4,$3
	sra	$2,$2,15
	addu	$2,$2,$5
	sll	$3,$3,16
	sra	$3,$3,16
	slt	$3,$3,2
	sh	$0,56($2)
	sh	$6,16($2)
	.set	noreorder
	.set	nomacro
	bne	$3,$0,.L875
	sh	$0,24($2)
	.set	macro
	.set	reorder

	li	$4,0x00000002		# 2
.L871:
	li	$5,0x0000007f		# 127
	li	$6,0x0000007f		# 127
.L878:
	jal	func_8005C650
.L859:
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80075670
.Lfe223:
	.size	 func_80075670,.Lfe223-func_80075670
	.align	2
	.globl	func_80075830
	.type	 func_80075830,@function
	.ent	func_80075830
func_80075830:
	.frame	$sp,80,$31		# vars= 48, regs= 4/0, args= 16, extra= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	lw	$2,D_800A36A0
	subu	$sp,$sp,80
	sw	$18,72($sp)
	move	$18,$4
	sw	$16,64($sp)
	move	$16,$5
	sw	$31,76($sp)
	sw	$17,68($sp)
	sw	$7,32($sp)
	lhu	$4,52($2)
	move	$17,$6
	andi	$4,$4,0x001f
	sll	$4,$4,7
	.set	noreorder
	.set	nomacro
	jal	rsin
	addu	$4,$4,511
	.set	macro
	.set	reorder

	sll	$3,$2,1
	addu	$3,$3,$2
	sll	$3,$3,4
	sra	$3,$3,12
	addu	$3,$3,-64
	sb	$3,59($sp)
	sb	$3,58($sp)
	sb	$3,57($sp)
	lw	$2,0($18)
	#nop
	lw	$2,20($2)
	#nop
	lw	$2,84($2)
	#nop
	sw	$2,16($sp)
	addu	$2,$2,12
	sw	$2,20($sp)
	slt	$2,$16,10
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L881
	li	$2,0x66660000		# 1717960704
	.set	macro
	.set	reorder

	ori	$2,$2,0x6667
	mult	$16,$2
	sra	$2,$16,31
	mfhi	$8
	#nop
	#nop
	sra	$3,$8,1
	subu	$3,$3,$2
	move	$5,$3
	sll	$2,$3,2
	addu	$2,$2,$3
	.set	noreorder
	.set	nomacro
	j	.L882
	subu	$6,$16,$2
	.set	macro
	.set	reorder

.L881:
	ori	$2,$2,0x6667
	addu	$4,$16,-10
	mult	$4,$2
	sra	$2,$4,31
	mfhi	$8
	#nop
	#nop
	sra	$3,$8,1
	subu	$3,$3,$2
	move	$5,$3
	sll	$2,$3,2
	addu	$2,$2,$3
	subu	$6,$4,$2
.L882:
	lw	$3,D_800A36A0
	sll	$2,$17,1
	addu	$4,$2,$3
	sll	$2,$5,16
	lh	$3,28($4)
	sra	$2,$2,16
	.set	noreorder
	.set	nomacro
	bne	$3,$2,.L883
	sll	$2,$6,16
	.set	macro
	.set	reorder

	lh	$3,32($4)
	sra	$2,$2,16
	.set	noreorder
	.set	nomacro
	bne	$3,$2,.L883
	li	$2,0x00000001		# 1
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L884
	sb	$2,56($sp)
	.set	macro
	.set	reorder

.L883:
	sb	$0,56($sp)
.L884:
	sll	$4,$17,4
	subu	$4,$4,$17
	sll	$4,$4,4
	sll	$3,$5,16
	sra	$3,$3,16
	sll	$2,$3,1
	addu	$2,$2,$3
	sll	$2,$2,3
	addu	$2,$2,$3
	sll	$2,$2,2
	addu	$4,$4,$2
	sll	$2,$6,16
	sra	$2,$2,12
	sw	$4,40($sp)
	.set	noreorder
	.set	nomacro
	beq	$17,$0,.L885
	sw	$2,44($sp)
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L887
	li	$2,0x00000013		# 19
	.set	macro
	.set	reorder

.L885:
	li	$2,0x00000009		# 9
.L887:
	sw	$2,36($sp)
	lw	$2,16($18)
	addu	$4,$sp,16
	.set	noreorder
	.set	nomacro
	jal	func_8007352C
	sw	$2,24($sp)
	.set	macro
	.set	reorder

	sw	$2,16($18)
	lw	$31,76($sp)
	lw	$18,72($sp)
	lw	$17,68($sp)
	lw	$16,64($sp)
	addu	$sp,$sp,80
	j	$31
	.end	func_80075830
.Lfe224:
	.size	 func_80075830,.Lfe224-func_80075830
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_800759D0.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80075F80.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8007636C.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_800768DC.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80076D74.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_80076FF8
	.type	 func_80076FF8,@function
	.ent	func_80076FF8
func_80076FF8:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$16,16($sp)
	move	$16,$4
	sw	$31,20($sp)
	lw	$5,20($16)
	jal	func_8006920C
	lw	$5,24($16)
	.set	noreorder
	.set	nomacro
	jal	func_8006920C
	move	$4,$16
	.set	macro
	.set	reorder

	lw	$5,28($16)
	.set	noreorder
	.set	nomacro
	jal	func_8006920C
	move	$4,$16
	.set	macro
	.set	reorder

	lw	$5,32($16)
	.set	noreorder
	.set	nomacro
	jal	func_8006920C
	move	$4,$16
	.set	macro
	.set	reorder

	lw	$5,36($16)
	.set	noreorder
	.set	nomacro
	jal	func_8006920C
	move	$4,$16
	.set	macro
	.set	reorder

	lw	$5,40($16)
	.set	noreorder
	.set	nomacro
	jal	func_8006920C
	move	$4,$16
	.set	macro
	.set	reorder

	lw	$5,44($16)
	.set	noreorder
	.set	nomacro
	jal	func_8006920C
	move	$4,$16
	.set	macro
	.set	reorder

	lw	$5,48($16)
	.set	noreorder
	.set	nomacro
	jal	func_8006920C
	move	$4,$16
	.set	macro
	.set	reorder

	lw	$5,52($16)
	.set	noreorder
	.set	nomacro
	jal	func_8006920C
	move	$4,$16
	.set	macro
	.set	reorder

	lw	$5,56($16)
	.set	noreorder
	.set	nomacro
	jal	func_8006920C
	move	$4,$16
	.set	macro
	.set	reorder

	lw	$2,4($16)
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80076FF8
.Lfe225:
	.size	 func_80076FF8,.Lfe225-func_80076FF8
	.align	2
	.globl	func_80077098
	.type	 func_80077098,@function
	.ent	func_80077098
func_80077098:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	sll	$2,$4,1
	addu	$2,$2,$4
	sll	$2,$2,2
	subu	$2,$2,$4
	lw	$3,D_800A35D8
	sll	$2,$2,2
	.set	noreorder
	.set	nomacro
	j	$31
	addu	$2,$3,$2
	.set	macro
	.set	reorder

	.end	func_80077098
.Lfe226:
	.size	 func_80077098,.Lfe226-func_80077098
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_800770B8.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80077374.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_80077724
	.type	 func_80077724,@function
	.ent	func_80077724
func_80077724:
	.frame	$sp,64,$31		# vars= 40, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,64
	sw	$16,56($sp)
	move	$16,$5
	lw	$3,D_800A36AC
	lw	$5,D_800A36A0
	la	$4,D_800F7438
	sw	$31,60($sp)
	andi	$3,$3,0x0001
	sll	$2,$3,7
	addu	$2,$2,$3
	sll	$2,$2,3
	addu	$2,$2,$3
	sll	$2,$2,4
	lw	$3,48($5)
	addu	$2,$2,$4
	sw	$2,36($5)
	lhu	$2,52($5)
	addu	$3,$3,1
	andi	$4,$3,0x0001
	addu	$2,$2,1
	sh	$2,52($5)
	.set	noreorder
	.set	nomacro
	jal	func_80077098
	sw	$3,48($5)
	.set	macro
	.set	reorder

	lw	$3,D_800A36A0
	#nop
	lw	$4,4($3)
	sw	$2,44($3)
	sw	$4,16($sp)
	lw	$3,0($2)
	#nop
	sw	$3,20($sp)
	lw	$3,4($2)
	#nop
	sw	$3,24($sp)
	lw	$3,8($2)
	#nop
	sw	$3,28($sp)
	lw	$3,16($2)
	#nop
	sw	$3,32($sp)
	lw	$3,12($2)
	#nop
	sw	$3,36($sp)
	lw	$3,20($2)
	#nop
	sw	$3,40($sp)
	lw	$3,24($2)
	#nop
	sw	$3,44($sp)
	lw	$3,28($2)
	addu	$5,$sp,16
	sw	$3,48($sp)
	lw	$2,32($2)
	move	$4,$16
	.set	noreorder
	.set	nomacro
	jal	func_80077374
	sw	$2,52($sp)
	.set	macro
	.set	reorder

	lw	$31,60($sp)
	lw	$16,56($sp)
	addu	$sp,$sp,64
	j	$31
	.end	func_80077724
.Lfe227:
	.size	 func_80077724,.Lfe227-func_80077724
	.align	2
	.globl	func_80077820
	.type	 func_80077820,@function
	.ent	func_80077820
func_80077820:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	la	$5,D_8009BD24
	sw	$31,16($sp)
	jal	func_80068F70
	li	$4,0x00000001		# 1
	move	$5,$0
	move	$6,$0
	.set	noreorder
	.set	nomacro
	jal	disp_SetFramebufferMode
	move	$7,$0
	.set	macro
	.set	reorder

	sw	$0,D_800A35E4
	.set	noreorder
	lw	$31,16($sp)
	li	$2,0x00000001		# 1
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80077820
.Lfe228:
	.size	 func_80077820,.Lfe228-func_80077820
	.align	2
	.globl	func_80077860
	.type	 func_80077860,@function
	.ent	func_80077860
func_80077860:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	jal	func_80069250
	li	$3,0x00000001		# 1
	.set	noreorder
	.set	nomacro
	bne	$2,$3,.L894
	move	$2,$0
	.set	macro
	.set	reorder

	sw	$0,D_800A35E4
	li	$2,0x00000001		# 1
.L894:
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80077860
.Lfe229:
	.size	 func_80077860,.Lfe229-func_80077860
	.align	2
	.globl	func_80077894
	.type	 func_80077894,@function
	.ent	func_80077894
func_80077894:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$16,16($sp)
	sw	$31,20($sp)
	.set	noreorder
	.set	nomacro
	jal	func_800693CC
	move	$16,$0
	.set	macro
	.set	reorder

	move	$5,$2
	.set	noreorder
	.set	nomacro
	bltz	$5,.L896
	li	$2,-16			# 0xfffffff0
	.set	macro
	.set	reorder

	la	$4,D_8009BD38
	li	$16,0x00000001		# 1
	lw	$3,0($4)
	sw	$0,D_800A35E4
	and	$3,$3,$2
	andi	$2,$5,0x000f
	or	$3,$3,$2
	.set	noreorder
	.set	nomacro
	j	.L897
	sw	$3,0($4)
	.set	macro
	.set	reorder

.L896:
	li	$2,-2			# 0xfffffffe
	.set	noreorder
	.set	nomacro
	bne	$5,$2,.L899
	move	$2,$16
	.set	macro
	.set	reorder

	li	$16,-1			# 0xffffffff
.L897:
	move	$2,$16
.L899:
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80077894
.Lfe230:
	.size	 func_80077894,.Lfe230-func_80077894
	.align	2
	.globl	func_80077904
	.type	 func_80077904,@function
	.ent	func_80077904
func_80077904:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$2,D_8009BD38
	sw	$0,D_800A35E4
	andi	$2,$2,0x000f
	sll	$2,$2,1
	lbu	$3,D_8009BD59($2)
	#nop
	sw	$3,D_800A35E0
	lbu	$2,D_8009BD58($2)
	j	$31
	.end	func_80077904
.Lfe231:
	.size	 func_80077904,.Lfe231-func_80077904
	.align	2
	.globl	func_80077940
	.type	 func_80077940,@function
	.ent	func_80077940
func_80077940:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	li	$2,0x003f0000		# 4128768
	ori	$2,$2,0xf000
	andi	$3,$4,0x03ff
	and	$2,$4,$2
	srl	$2,$2,2
	addu	$3,$3,$2
	li	$2,0x01000000		# 16777216
	and	$2,$4,$2
	srl	$2,$2,4
	addu	$3,$3,$2
	li	$2,0x04000000		# 67108864
	and	$4,$4,$2
	srl	$4,$4,5
	addu	$3,$3,$4
	sw	$3,D_800A35E8
	j	$31
	.end	func_80077940
.Lfe232:
	.size	 func_80077940,.Lfe232-func_80077940
	.align	2
	.globl	func_80077984
	.type	 func_80077984,@function
	.ent	func_80077984
func_80077984:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	lw	$5,D_800A35E0
	lw	$7,D_800A35E8
	la	$6,D_8009BD24
	sw	$31,16($sp)
	jal	func_8006E534
	li	$4,0x00000001		# 1
	move	$5,$0
	move	$6,$0
	.set	noreorder
	.set	nomacro
	jal	disp_SetFramebufferMode
	move	$7,$0
	.set	macro
	.set	reorder

	.set	noreorder
	lw	$31,16($sp)
	li	$2,0x00000001		# 1
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80077984
.Lfe233:
	.size	 func_80077984,.Lfe233-func_80077984
	.align	2
	.globl	func_800779C8
	.type	 func_800779C8,@function
	.ent	func_800779C8
func_800779C8:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,20($sp)
	.set	noreorder
	.set	nomacro
	jal	func_8006EACC
	sw	$16,16($sp)
	.set	macro
	.set	reorder

	move	$16,$2
	.set	noreorder
	.set	nomacro
	beq	$16,$0,.L905
	move	$2,$16
	.set	macro
	.set	reorder

	jal	func_8005B6FC
	move	$2,$16
.L905:
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_800779C8
.Lfe234:
	.size	 func_800779C8,.Lfe234-func_800779C8
	.align	2
	.globl	func_80077A04
	.type	 func_80077A04,@function
	.ent	func_80077A04
func_80077A04:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	sw	$0,D_800A35E4
	jal	func_8006D74C
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80077A04
.Lfe235:
	.size	 func_80077A04,.Lfe235-func_80077A04
	.align	2
	.globl	func_80077A28
	.type	 func_80077A28,@function
	.ent	func_80077A28
func_80077A28:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	li	$4,0x00000001		# 1
	move	$5,$0
	move	$6,$0
	sw	$31,16($sp)
	sw	$0,D_800A35E4
	.set	noreorder
	.set	nomacro
	jal	disp_SetFramebufferMode
	move	$7,$0
	.set	macro
	.set	reorder

	jal	func_8006D7FC
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80077A28
.Lfe236:
	.size	 func_80077A28,.Lfe236-func_80077A28
	.align	2
	.globl	func_80077A60
	.type	 func_80077A60,@function
	.ent	func_80077A60
func_80077A60:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	jal	func_8006E068
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80077A60
.Lfe237:
	.size	 func_80077A60,.Lfe237-func_80077A60
	.align	2
	.globl	func_80077A80
	.type	 func_80077A80,@function
	.ent	func_80077A80
func_80077A80:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	lw	$6,D_800A35E8
	la	$5,D_8009BD24
	sw	$31,16($sp)
	jal	func_800770B8
	li	$4,0x00000001		# 1
	move	$5,$0
	move	$6,$0
	.set	noreorder
	.set	nomacro
	jal	disp_SetFramebufferMode
	move	$7,$0
	.set	macro
	.set	reorder

	.set	noreorder
	lw	$31,16($sp)
	li	$2,0x00000001		# 1
	j	$31
	addu	$sp,$sp,24
	.set	reorder
	.end	func_80077A80
.Lfe238:
	.size	 func_80077A80,.Lfe238-func_80077A80
	.align	2
	.globl	func_80077AC0
	.type	 func_80077AC0,@function
	.ent	func_80077AC0
func_80077AC0:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	jal	func_80077724
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80077AC0
.Lfe239:
	.size	 func_80077AC0,.Lfe239-func_80077AC0
	.align	2
	.globl	func_80077AE0
	.type	 func_80077AE0,@function
	.ent	func_80077AE0
func_80077AE0:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	jal	func_8006E10C
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80077AE0
.Lfe240:
	.size	 func_80077AE0,.Lfe240-func_80077AE0
	.align	2
	.globl	func_80077B00
	.type	 func_80077B00,@function
	.ent	func_80077B00
func_80077B00:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	jal	func_8006E2A8
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80077B00
.Lfe241:
	.size	 func_80077B00,.Lfe241-func_80077B00
	.align	2
	.globl	func_80077B20
	.type	 func_80077B20,@function
	.ent	func_80077B20
func_80077B20:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	li	$2,0x00000001		# 1
	sw	$2,D_800A35E4
	j	$31
	.end	func_80077B20
.Lfe242:
	.size	 func_80077B20,.Lfe242-func_80077B20
	.ident	"GCC: (GNU) 2.7.2"
