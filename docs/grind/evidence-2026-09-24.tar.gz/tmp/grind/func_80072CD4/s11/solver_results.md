# s11 sched_solver run log (transcribed verbatim from the four perturb.py invocations)

Provenance: `tools/sched_solver/extract.py text1b` reported `parity=True funcs=474
(pass1=237 pass2=237) blocks=1656`, run TWICE — once with
`memory/grind/func_80072CD4/rejected/xblock_sched1_hoist.c` applied to src/text1b.c
(picks=13564) and once with `memory/grind/func_80072CD4/candidate.c` applied (picks=13566).
`sim` order printed by perturb.py is the schedule_block PICK order = the REVERSE of emission
order (schedule_block builds the block bottom-up and prepends each pick).
Driver scripts: run_perturb.sh / run_perturb2.sh / run_perturb3.sh / run_perturb4.sh /
run_perturb5.sh in this directory. Block/UID maps: dump2.py.

## A. XBLOCK chassis (13/78), pass 1, block 2 = then-arm
UID map (luid order == source order): 42 `li 0xC3` · 44 `sb 5` · 47 `li 0x1E` · 49 `sb 6` ·
52 `li 0xC8` · 54 `sb 0xD` · 57 `li 0x32` (into the cross-block pseudo) · 59 jump.
Our pick order: `[59, 54, 52, 49, 47, 44, 42, 57]` -> emission `[57, 42, 44, 47, 49, 52, 54, 59]`
(the li is HOISTED to the arm top; target emits it last, in the branch delay slot).
Goal (pick space) `59,57,54,52,49,47,44,42`:

    --atoms luid,luid_move --depth 2   ->  NO perturbation reaches the goal at this depth
    (all atoms) --depth 2              ->  5 vectors, ALL of the same shape:
        add_dep 57 <- 44 (true/data) + cost 44 := 2
        add_dep 57 <- 44 (true/data) + cost 44 := 3
        add_dep 57 <- 44 (true/data) + cost 44 := 12
        add_dep 57 <- 49 (true/data) + cost 49 := 2
        add_dep 57 <- 49 (true/data) + cost 49 := 3
Weakened goal (only "57 emitted last", 6 --goal-before clauses), all atoms, depth 2 -> 8 vectors,
every one still an `add_dep 57 <- <store>` paired with a `cost <store> := 2|3|12`.

## B. XBLOCK chassis, pass 1, block 3 = else-arm
UIDs 65/67/70/72/75/77 = the three li/sb pairs, 80 = `li 0x46` into the pseudo; no jump (fallthrough).
Our pick order `[77, 75, 72, 70, 67, 65, 80]` -> emission `[80, 65, 67, 70, 72, 75, 77]` (same hoist).
Goal `80,77,75,72,70,67,65`: `--atoms luid,luid_move --depth 2` -> NO perturbation.
Weak goal (80 emitted last), all atoms, depth 2 -> 7 vectors, all
`add_dep 80 <- {67|72|77} (true/data) + cost {67|72|77} := 2|3|12`.

## C. XBLOCK chassis, pass 2, block 4 = merge block (15 insns)
UIDs: 85 `sb v1,4` · 88 `sb v1,0xC` · 91 `sb v0,0xE` · 94 `li 0xFC` · 96 `sb 0x14` · 99/101 ·
104/106 · 109/111 · 114 `sb zero,0x16` · 117 `li 0xA` · 119 `sb 0x1E` · 121 jump.
Our pick `[121,119,114,91,88,85,117,111,109,106,104,101,99,96,94]` -> emission
`[94,96,99,101,104,106,109,111,117,85,88,91,114,119,121]` (85/88/91 SUNK to the block tail;
target emits them at the head).
Goal (pick space) `121,119,114,117,111,109,106,104,101,99,96,94,91,88,85`:

    --atoms luid,luid_move --depth 2   ->  NO perturbation reaches the goal at this depth
    (all atoms)          --depth 2     ->  NO perturbation reaches the goal at this depth
Weak goal (85/88/91 emitted before 94), all atoms, depth 2 -> 10 vectors, every one
`add_dep 94 <- {85|88|91|114} (true/data) + cost <that store> := 2|3|12`.

## D. FLOOR-4 chassis (candidate.c, 4/79), pass 2, block 4 = merge block (14 insns)
UIDs: 89 `sb v1,4` · 92 `sb v1,0xC` · 95 `li 0xFC` · 97 `sb 0x14` · 100/102 · 105/107 · 110/112 ·
115 `sb zero,0x16` · 118 `li 0xA` · 120 `sb 0x1E` · 122 jump.  (`sb v0,0xE` is NOT in this block:
it is written per-arm and jump2 cross-jumps it to the merge label head after sched2.)
Our pick `[122,120,115,92,89,118,112,110,107,105,102,100,97,95]`.
Goal `122,120,115,118,112,110,107,105,102,100,97,95,92,89` (89/92 at the block head),
all atoms, depth 2 -> **6 vectors, a DIFFERENT shape from A/B/C**:

        add_dep 92 <- 89 (true/data)          + add_dep 95 <- 92 (true/data)
        add_dep 92 <- 89 (true/data)          + add_dep 95 <- 92 (anti-output kind 14)
        add_dep 92 <- 89 (anti-output kind 14)+ add_dep 95 <- 92 (true/data)
        add_dep 92 <- 89 (anti-output kind 14)+ add_dep 95 <- 92 (anti-output kind 14)
        add_dep 95 <- 89 (true/data)          + add_dep 95 <- 92 (true/data)
        add_dep 95 <- 89 (true/data)          + add_dep 95 <- 92 (anti-output kind 14)
Weak goal (89/92 before 95), all atoms, depth 2 -> 8 vectors of the same two-add_dep shape.
No `cost` half is required here, and no vector at depth 1 exists in any of A-D.
