import re,sys,io
src='src/text1b.c'
body=open(sys.argv[1],encoding='utf-8').read()
# strip leading block comment(s) from body file
body=re.sub(r'^\s*/\*.*?\*/\s*','',body,count=1,flags=re.S)
txt=open(src,encoding='utf-8',newline='').read()
pat_inc='INCLUDE_ASM("asm/funcs", func_80072CD4);\n'
m=re.search(r's32 func_80072CD4\(s32 arg0, GameObj \*arg1\) \{.*?\n\}\n', txt, flags=re.S)
new=body if body.endswith('\n') else body+'\n'
if pat_inc in txt:
    txt=txt.replace(pat_inc,new,1)
elif m:
    txt=txt[:m.start()]+new+txt[m.end():]
else:
    sys.exit('anchor not found')
open(src,'w',encoding='utf-8',newline='').write(txt)
print('applied',sys.argv[1],len(new.splitlines()),'lines')
