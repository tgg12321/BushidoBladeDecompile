# s2 structural sweep — func_80042ED8 (all: sandbox --disable all)

| # | form | score | insns b/t | notes |
|---|------|-------|-----------|-------|
| 0 | committed t0-t3 partial-read-ahead (baseline) | 0 | 14/14 | judge-flagged form |
| A | 1-temp 3 sequential swaps (natural) | 12 | 14/14 | Judge's demanded negative — serialized by WAR on the single temp |
| B | 3-temp one-per-swap | 13 | 13/14 | scheduler fills target's nop; loses an insn |
| C | 4-temp, natural-index read order [1],[2],[5],[6], same tail as committed | 0 | 14/14 | BYTE-IDENTICAL — kills "read order is load-bearing" hypothesis |
| D | 3 saves + mem-to-mem swaps (compiler temps) | 13 | 13/14 | fills the nop |
| G | 3 saves ([2],[1],[5]) + per-swap via one scratch t | 0 | 14/14 | BYTE-IDENTICAL |
| G'| G with index-ordered saves [1],[2],[5]  ← FINAL | 0 | 14/14 | BYTE-IDENTICAL, verified check_bytes.sh |

Byte verification: check_bytes.sh extracts the function from
tmp/sandbox/func_80042ED8/text1a_c.o via objdump and word-compares against
asm/funcs/func_80042ED8.s (14/14 OK on C, G, G').

Final form (in src/text1a_c.c): save one side of all three pairs (y=[1],
x=[2], z=[5]), then complete each swap through one scratch t in pair order.
Only the grouped saves are matching-staging (annotated FAKE per 2026-07-06
ALLOWED list); everything else is the natural per-swap order. The reused
scratch reproduces target's $a2 triple-reuse; the grouped saves keep x/y/z
live across the swaps ($a1/$v1/$v0) and preserve the unfilled nop.
