import re, pathlib, collections
addrs = collections.defaultdict(set)   # addr -> set of sources
pat = re.compile(r'jtbl_([0-9A-Fa-f]{8})')
for p in list(pathlib.Path('asm').rglob('*.s')) + list(pathlib.Path('src').glob('*.c')) + [pathlib.Path('undefined_syms_auto.txt'), pathlib.Path('symbol_addrs.txt'), pathlib.Path('named_syms.txt')]:
    try: t = p.read_text(errors='ignore')
    except Exception: continue
    for m in pat.finditer(t):
        addrs[int(m.group(1),16)].add(str(p))
mod = collections.Counter()
four = []
for a in sorted(addrs):
    mod[a % 8] += 1
    if a % 8 == 4: four.append(a)
print('distinct jtbl symbols:', len(addrs))
print('addr mod 8 histogram:', dict(mod))
print('4-mod-8 tables (%d):' % len(four))
for a in four:
    srcs = sorted(s for s in addrs[a] if not s.startswith('undefined') and 'syms' not in s)
    print('  0x%08X  %s' % (a, ', '.join(srcs[:4])))
