#!/bin/bash
set -eo pipefail
cd "$(dirname "$0")/../../../.."
OUT=tmp/grind/func_8001F938/s12
CPP="mipsel-linux-gnu-cpp"
CPP_FLAGS="-Iinclude -undef -Wall -lang-c -fno-builtin"
CPP_DEFS="-Dmips -D__GNUC__=2 -D__OPTIMIZE__ -D__mips__ -D__mips -Dpsx -D__psx__ -D__psx"
$CPP $CPP_FLAGS $CPP_DEFS src/code6cac.c > $OUT/code6cac.i 2>$OUT/cpp.err
echo "cpp lines: $(wc -l < $OUT/code6cac.i)"
tools/gcc-2.7.2/build/cc1 -O2 -G0 -funsigned-char -quiet -mcpu=3000 -mips1 -mno-abicalls -fno-builtin -w -mel < $OUT/code6cac.i > $OUT/openport.s 2>$OUT/openport.err || echo "openport cc1 rc=$?"
tools/cc1psx_wrapper.sh -O2 -G0 -funsigned-char -quiet -mcpu=3000 -mips1 -w < $OUT/code6cac.i > $OUT/cc1psx.s 2>$OUT/cc1psx.err || echo "cc1psx rc=$?"
for f in openport cc1psx; do
  echo "=== $f: $(wc -l < $OUT/$f.s) lines ==="
done
