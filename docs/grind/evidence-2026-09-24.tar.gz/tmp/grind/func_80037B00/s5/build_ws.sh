#!/bin/bash
# Build permuter workspace for func_80037B00 using the mar_perm_workspace.sh pattern:
# full-TU compile so codegen context is preserved, region-extract the target func,
# assemble alone. Base target from asm/funcs/func_80037B00.s + r3k prelude.
set -e
cd /mnt/c/Users/Trenton/Desktop/"Bushido Blade 2 Decompile"

WS=tmp/grind/func_80037B00/s5/perm_ws
mkdir -p "$WS"

# --- Preprocess src/code6cac_c.c to get base.c (fully expanded C source) ------
mipsel-linux-gnu-cpp -Iinclude -undef -Wall -lang-c -fno-builtin \
    -Dmips -D__GNUC__=2 -D__OPTIMIZE__ -D__mips__ -D__mips -Dpsx -D__psx__ \
    -D__psx -D_PSYQ -D__EXTENSIONS__ -D_MIPSEL -D_LANGUAGE_C -DLANGUAGE_C \
    src/code6cac_c.c -o "$WS/base.c"

# --- settings.toml -------------------------------------------------------------
cat > "$WS/settings.toml" <<'EOF'
func_name = "func_80037B00"
compiler_type = "gcc"

[weight_overrides]
perm_inline = 0.0
EOF

# --- compile.sh (mar_perm3 pattern: full-TU compile + region extract) ---------
cat > "$WS/compile.sh" <<'EOF'
#!/bin/bash
set -e
cd "/mnt/c/Users/Trenton/Desktop/Bushido Blade 2 Decompile"
IN="$1"
OUT="$3"
TMPS=$(mktemp /tmp/f80037b00XXXXXX.s)
trap "rm -f $TMPS $TMPS.fn.s" EXIT
tools/gcc-2.7.2/build/cc1 -O2 -G0 -funsigned-char -quiet -mcpu=3000 \
    -mips1 -mno-abicalls -fno-builtin -w "$IN" -o /dev/stdout 2>/dev/null \
  | python3 tools/prologue_fix.py \
  | python3 tools/maspsx/maspsx.py --expand-div --aspsx-version=2.34 \
      --sdata-syms=sdata_syms.txt --sdata-funcs=sdata_funcs.txt \
      --sdata-exclude=sdata_exclude.txt --expand-lb \
      --expand-lb-funcs=expand_lb_funcs.txt --multu-funcs=multu_funcs.txt \
      --expand-dest-funcs=expand_dest_funcs.txt \
      --label-nop-funcs=maspsx_label_nop_funcs.txt \
  | python3 tools/fix_lwl.py \
  | python3 tools/multu_pad.py --funcs multu_pad_funcs.txt > "$TMPS"
awk '
/^[[:space:]]*\.globl[[:space:]]+func_80037B00$/ {p=1}
p {print}
p && /^[[:space:]]*\.size[[:space:]]+func_80037B00/ {exit}
' "$TMPS" > "$TMPS.fn.s"
cat > /tmp/f80037b00_prelude.s <<'PRE'
.set noat
.set noreorder
PRE
cat /tmp/f80037b00_prelude.s "$TMPS.fn.s" \
  | mipsel-linux-gnu-as -Iinclude -march=r3000 -mtune=r3000 \
      -no-pad-sections -O1 -G0 -o "$OUT"
EOF
chmod +x "$WS/compile.sh"

# --- target.o from asm/funcs/func_80037B00.s + r3k prelude --------------------
sed 's/^.set gp=64$//' tools/decomp-permuter/prelude.inc > "$WS/prelude_r3k.inc"
cat "$WS/prelude_r3k.inc" asm/funcs/func_80037B00.s > "$WS/target.s"
mipsel-linux-gnu-as -Iinclude -march=r3000 -mtune=r3000 -no-pad-sections \
    -O1 -G0 -o "$WS/target.o" "$WS/target.s"

# --- Sanity: compile base + diff against target -------------------------------
bash "$WS/compile.sh" "$WS/base.c" -o "$WS/base.o"
f() {
  mipsel-linux-gnu-objdump -d "$1" | awk '/<func_80037B00>:/{p=1;next} /^[0-9a-f]+ </{p=0} p' \
    | sed 's/^[^\t]*\t[^\t]*\t//' | sed 's/0x[0-9a-f]*//g' | grep -v '^$'
}
f "$WS/base.o"   > /tmp/f80037b00_base.txt
f "$WS/target.o" > /tmp/f80037b00_tgt.txt
echo "base insns: $(wc -l < /tmp/f80037b00_base.txt)  target: $(wc -l < /tmp/f80037b00_tgt.txt)"
diff /tmp/f80037b00_base.txt /tmp/f80037b00_tgt.txt | head -40
