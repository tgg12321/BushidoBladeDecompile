import re, subprocess, collections

out = subprocess.run(['mipsel-linux-gnu-objdump', '-d', '--disassemble=func_80037B00',
                      'tmp/sandbox/func_80037B00/code6cac_c.o'],
                     capture_output=True, text=True).stdout
ours = []
for ln in out.splitlines():
    m = re.match(r'\s*[0-9a-f]+:\s+[0-9a-f ]{8,}\t(.*)', ln)
    if m:
        ours.append(m.group(1).split(';')[0].strip())

tgt = []
for ln in open('asm/funcs/func_80037B00.s'):
    m = re.match(r'\s*/\*[^*]*\*/\s+(\S+)\s*(.*)', ln)
    if m:
        tgt.append((m.group(1) + ' ' + m.group(2)).strip())

REGS = r'\b(zero|at|v[01]|a[0-3]|t[0-9]|s[0-7]|k[01]|gp|sp|fp|ra)\b'


def blank(i):
    i = i.replace('$', '')
    i = re.sub(r'<[^>]*>', '', i)
    i = re.sub(r'%\w+\([^)]*\)', 'S', i)
    i = re.sub(REGS, 'R', i)
    i = re.sub(r'\b[0-9a-fA-Fx]+\b', 'K', i)
    i = re.sub(r'\.L\w+|\bD_\w+|\bfunc_\w+', 'S', i)
    i = i.replace('S', 'K')
    i = re.sub(r'[\s,]+', ' ', i).strip()
    i = re.sub(r'^move R R$', 'addu R R R', i)
    i = re.sub(r'^li R K$', 'addiu R R K', i)
    return i


co = collections.Counter(blank(x) for x in ours)
ct = collections.Counter(blank(x) for x in tgt)
print("ours n=", len(ours), " tgt n=", len(tgt))
print("--- only in TARGET ---")
for k, v in (ct - co).items():
    print(f"  +{v}  {k}")
print("--- only in OURS ---")
for k, v in (co - ct).items():
    print(f"  +{v}  {k}")

print("--- ORDERED (ours | tgt) ---")
for i,(a,b) in enumerate(zip(ours,tgt)):
    ba,bb=blank(a),blank(b)
    print(('   ' if ba==bb else 'XX '), f'{i:2d}', f'{a:28s}', '|', b)
