# s42 solver report — get_alarm (func_8007DC9C), axis B

## Inputs
- src/display.c with memory/grind/get_alarm/candidate.c applied in place of the
  `INCLUDE_ASM("asm/funcs", get_alarm);` line. `sandbox get_alarm --disable all` = **9**
  (target_insns 91, build_insns 90, rules_dropped 0, cheat_asm_stripped 147). Chassis-current.
- `python3 tools/sched_solver/extract.py display` -> parity=True, 140 funcs, 598 blocks,
  3264 picks. Model copied to tmp/grind/get_alarm/s42/display.sched.json.
- `bash tools/sched_solver/mkasm.sh display` -> tmp/sched_map/display.hon.s
  (our get_alarm body copied to tmp/grind/get_alarm/s42/get_alarm.hon.s).

## The residual, stated exactly (block 2, pass 2 UIDs)
Our sched2 emitted order, first printf region:
  36, 54, 43, 38, 60, 45, 56, 47, 58, 52, 64, 66, 62, 68
TARGET's order (read off asm/funcs/get_alarm.s 0x8007DCEC..0x8007DD38):
  36, 60, 38, 43, 54, 45, 56, 47, 58, 52, 64, 66, 62, 68

UID legend (pass 2):
  36 = lw stat_ptr (D_8009BF48)      luid 0  pri 1
  54 = lw madr_ptr (D_8009BF4C)      luid 1  pri 1
  38 = lw 0(stat_ptr)  DEAD READ     luid 2  pri 2
  60 = la fmt (&g_str_gpu_timeout)   luid 4  pri 2  unit -1
  43 = lw D_8009BF78                 luid 9  pri 1
  45 = lw D_8009BF7C                 luid 6  pri 2
  56/58 = *madr + sw 16($sp); 47 = subu; 52/66 = chcr; 64 = *stat -> $a2; 62 = andi; 68 = call

The ONLY difference is the position of 60 (the format-string `la`): slot 4 for us,
slot 1 for target, with 54/43/38 shifting one slot each. Everything after 45 is identical.
So axis B is a ONE-INSN move, not an 8-op cluster of independent misorderings.

## The solver verdict (exhaustive single-atom search)
    python3 tools/sched_solver/perturb.py tmp/sched_solver_work/display.sched.json \
        --func get_alarm --pass 2 --block 2 \
        --goal-before 38:60 --goal-before 43:60 --goal-before 54:60 --depth 1 --max 40

  searching 4391 single atoms
  1 vector(s) reach the goal:
    del_dep 60 <- 38

EXACTLY ONE atom out of 4391 reaches target's relative order, and it is **not a LUID
atom**: it is the deletion of the dependence edge 38 -> 60. In pass 2 (post-reload) that
edge is an OUTPUT dependence on the hard register `$a0`: greg seats the dead
`*g_gpu_stat_reg` read's pseudo in `$4`, and 60 (`la $4,&g_str_gpu_timeout`) writes the
same hard register, so sched2 cannot lift 60 above 38. Target seats the same dead read in
`$v0` (`lw $v0,0($v1)` @ 0x8007DCFC), so in target's compile the edge does not exist and
the `la` is free to float to slot 1.

No `luid` / `luid_move` atom reaches the goal at depth 1: statement reordering alone
cannot produce target's order while the $a0 output dependence stands.

## Re-attribution (this is the session's finding)
Sessions s6 / s33 / s34 attributed axis B to a **sched1 priority difference** driven by a
volatile-MEM anti-dependence (dead read pri 2 vs fmt pri 1) and concluded "raising fmt's
priority is structurally impossible". That is true of pass 1 but it is **not what fixes the
final byte order**. In pass 2 the dead read and the fmt `la` have the SAME priority (2) —
the flip is decided by the hard-register output dependence created by register allocation.
Axis B is therefore an **RA seat residual, not a scheduler tie**: the decidable question is
"what pure-C form makes local-alloc/greg seat the dead volatile read in $v0 instead of $a0?"
That surface has never been probed in 41 sessions.

## Tooling note (banked for the pipeline, not just this function)
`tools/ra_solver/inverse_compose.py classify display get_alarm` is INAPPLICABLE to an
INCLUDE_ASM-routed function: it falls back to the text-stream classifier and needs
`tmp/inverse_work/display.tgt.s`, which post-migration carries OUR bytes, not target's.
`sched_solver` got a `--target-object` escape for exactly this (owner ruling 2026-08-25);
`ra_solver` has no equivalent. Any future ra_solver work on get_alarm must first build
build/src/display.o from the INCLUDE_ASM state (target bytes) and derive the goal from the
object, or teach inverse_compose the same --target-object path.

## Spellings measured this session (all pure ordinary C, no constructs)
| form | score |
|---|---|
| v1 `(void)*g_gpu_stat_reg;` bare discarded volatile read (no dead local) | **9** (ties floor, strictly cleaner C -> promoted to candidate.c) |
| v2 discarded read spelled as a comma expression inside the printf arg list | 12 (worse) |
| v3 `que` staged before the bare read, printf takes `que` | 12 (worse) |
