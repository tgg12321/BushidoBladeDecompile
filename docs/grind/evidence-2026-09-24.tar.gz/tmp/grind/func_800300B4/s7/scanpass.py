import re, pathlib, sys
D = pathlib.Path("tmp/grind/func_800300B4/dumps")
# find the func's insn span in each dump and report HImode mem addresses
for p in sorted(D.glob("code6cac_b.*")):
    if p.suffix in (".s",):
        continue
    txt = p.read_text(errors="replace")
    # locate func_800300B4 region: search for the string in the dump
    i = txt.find("func_800300B4")
    if i < 0:
        continue
    seg = txt[i:i + 200000]
    # cut at next function label
    m = re.search(r"\n;; Function (?!func_800300B4)", seg[10:])
    if m:
        seg = seg[:m.start() + 10]
    hits = re.findall(r"\(mem:HI [^\n]*", seg)
    print("---", p.name, "len", len(seg), "HImode mems:", len(hits))
    for h in hits[:8]:
        print("   ", h[:160])
