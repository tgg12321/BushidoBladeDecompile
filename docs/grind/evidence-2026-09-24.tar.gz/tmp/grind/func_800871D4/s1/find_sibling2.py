import re, pathlib
# broader: lhu <r>, ...; nop; andi any, <r>, 0xFFFF -- any function
pat = re.compile(r'lhu\s+\$(\w+),.*\n\s*/\*[^\n]*\*/\s*nop\s*\n\s*/\*[^\n]*\*/\s*andi\s+\$\w+,\s*\$\1,\s*0xFFFF', re.M)
matches = []
for p in pathlib.Path('asm/funcs').glob('*.s'):
    t = p.read_text(errors='replace')
    if pat.search(t):
        matches.append(p.stem)
print(len(matches), 'total functions with the pattern')
for m in matches: print(' ', m)
