typedef unsigned char u8;
typedef signed short s16;
typedef unsigned short u16;
typedef signed int s32;
typedef unsigned int u32;

extern u8 D_80106A73;
extern s32 D_80106A58;
extern s32 *func_80077D00(void);

void func_80035280(void) {
    s32 *p;
    u8 *f;
    u8 *src;
    u8 *base;
    s32 i;
    s32 flags;

    p = func_80077D00();
    i = 0;
    f = &D_80106A73;
    src = f - 3;
    flags = p[8];
    flags = (flags & ~1) | (src[3] & 1);
    p[8] = flags;
    flags = (flags & ~2) | (src[3] & 2);
    p[8] = flags;
    flags = (flags & ~4) | (src[3] & 4);
    p[8] = flags;
    for (; i < 3; i++) {
        ((u8 *)p + i)[0x17] = *src;
        ((u8 *)p + i)[0x1D] = *src;
        src++;
    }
    base = (u8 *)&D_80106A58;
    for (i = 0; i < 3; i++) {
        u8 mn;
        u8 sc;
        u8 hs;
        s32 t;

        mn = *(s32 *)(base + i * 8 + 4) / 1800;
        ((u8 *)p)[i * 4 + 0x21] = mn;
        sc = (*(s32 *)(base + i * 8 + 4) / 30) % 60;
        ((u8 *)p)[i * 4 + 0x22] = sc;
        hs = (*(s32 *)(base + i * 8 + 4) % 30) * 100 / 30;
        ((u8 *)p)[i * 4 + 0x23] = hs;
        t = base[i * 8];
        ((u8 *)p)[i * 4 + 0x24] = t;
    }
}
