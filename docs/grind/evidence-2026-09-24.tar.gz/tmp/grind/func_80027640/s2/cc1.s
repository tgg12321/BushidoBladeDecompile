	.file	1 "src/code6cac_b.c"

 # GNU C 2.7.2 [AL 1.1, MM 40] GNU MIPS/ELF compiled by GNU C

 # Cc1 defaults:
 # -mgas

 # Cc1 arguments (-G value = 0, Cpu = 3000, ISA = 1):
 # -O2 -G0 -funsigned-char -quiet -mcpu=3000 -mips1 -mno-abicalls -fno-builtin
 # -w -mel

	.version	"01.01"
gcc2_compiled.:
 #APP
	.include "include/macro.inc"

	.section .rodata
    .include "asm/rodata/jtbl_8001042C.s"
.section .text
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80026DA4.s"
    .set reorder
    .set at

 #NO_APP
	.text
	.align	2
	.globl	func_800272FC
	.type	 func_800272FC,@function
	.ent	func_800272FC
func_800272FC:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	.set	noreorder
	.set	nomacro
	bgez	$4,.L7
	slt	$2,$4,2561
	.set	macro
	.set	reorder

	subu	$4,$0,$4
	slt	$2,$4,2561
.L7:
	beq	$2,$0,.L3
	slt	$2,$4,1536
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L6
	li	$3,0x00000002		# 2
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L6
	li	$3,0x00000001		# 1
	.set	macro
	.set	reorder

.L3:
	move	$3,$0
.L6:
	.set	noreorder
	.set	nomacro
	j	$31
	move	$2,$3
	.set	macro
	.set	reorder

	.end	func_800272FC
.Lfe1:
	.size	 func_800272FC,.Lfe1-func_800272FC
	.align	2
	.globl	func_80027334
	.type	 func_80027334,@function
	.ent	func_80027334
func_80027334:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	li	$2,0x000003f5		# 1013
	sh	$2,60($4)
	li	$2,0x000002b6		# 694
	sh	$2,62($4)
	li	$2,0x0000077a		# 1914
	sh	$2,64($4)
	li	$2,0x00000bee		# 3054
	sh	$2,66($4)
	li	$2,0x0000008c		# 140
	sh	$2,68($4)
	li	$2,0x00000227		# 551
	sh	$2,70($4)
	li	$2,0x000008a0		# 2208
	sh	$2,78($4)
	li	$2,0x00000f0e		# 3854
	sh	$2,80($4)
	li	$2,0x00000bcd		# 3021
	sh	$0,72($4)
	sh	$0,74($4)
	sh	$0,76($4)
	.set	noreorder
	.set	nomacro
	j	$31
	sh	$2,82($4)
	.set	macro
	.set	reorder

	.end	func_80027334
.Lfe2:
	.size	 func_80027334,.Lfe2-func_80027334
	.align	2
	.globl	func_8002738C
	.type	 func_8002738C,@function
	.ent	func_8002738C
func_8002738C:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lh	$2,D_800A38DC
	#nop
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L9
	sltu	$2,$5,22
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L9
	sll	$2,$5,2
	.set	macro
	.set	reorder

	lw	$2,.L34($2)
	#nop
	j	$2
.section	.rodata
	.align	3
	.align	2
.L34:
	.word	.L17
	.word	.L17
	.word	.L17
	.word	.L17
	.word	.L17
	.word	.L17
	.word	.L21
	.word	.L21
	.word	.L21
	.word	.L21
	.word	.L25
	.word	.L25
	.word	.L25
	.word	.L25
	.word	.L29
	.word	.L29
	.word	.L29
	.word	.L29
	.word	.L33
	.word	.L33
	.word	.L33
	.word	.L33
	.text
.L17:
	lbu	$2,D_800A376A($4)
	.set	noreorder
	.set	nomacro
	j	.L36
	ori	$2,$2,0x0010
	.set	macro
	.set	reorder

.L21:
	lbu	$2,D_800A376A($4)
	.set	noreorder
	.set	nomacro
	j	.L36
	ori	$2,$2,0x0001
	.set	macro
	.set	reorder

.L25:
	lbu	$2,D_800A376A($4)
	.set	noreorder
	.set	nomacro
	j	.L36
	ori	$2,$2,0x0002
	.set	macro
	.set	reorder

.L29:
	lbu	$2,D_800A376A($4)
	.set	noreorder
	.set	nomacro
	j	.L36
	ori	$2,$2,0x0004
	.set	macro
	.set	reorder

.L33:
	lbu	$2,D_800A376A($4)
	#nop
	ori	$2,$2,0x0008
.L36:
	sb	$2,D_800A376A($4)
.L9:
	j	$31
	.end	func_8002738C
.Lfe3:
	.size	 func_8002738C,.Lfe3-func_8002738C
	.align	2
	.globl	func_80027438
	.type	 func_80027438,@function
	.ent	func_80027438
func_80027438:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lh	$3,D_800A38DC
	li	$2,0x00000005		# 5
	.set	noreorder
	.set	nomacro
	beq	$3,$2,.L37
	sltu	$2,$5,22
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L37
	sll	$2,$5,2
	.set	macro
	.set	reorder

	lw	$2,.L63($2)
	#nop
	j	$2
.section	.rodata
	.align	3
	.align	2
.L63:
	.word	.L46
	.word	.L46
	.word	.L46
	.word	.L46
	.word	.L46
	.word	.L46
	.word	.L50
	.word	.L50
	.word	.L50
	.word	.L50
	.word	.L54
	.word	.L54
	.word	.L54
	.word	.L54
	.word	.L62
	.word	.L62
	.word	.L62
	.word	.L62
	.word	.L62
	.word	.L62
	.word	.L62
	.word	.L62
	.text
.L46:
	lhu	$2,626($4)
	#nop
	addu	$2,$2,$6
	.set	noreorder
	.set	nomacro
	j	.L37
	sh	$2,626($4)
	.set	macro
	.set	reorder

.L50:
	sh	$0,620($4)
	sh	$0,144($4)
	.set	noreorder
	.set	nomacro
	j	.L37
	sh	$0,138($4)
	.set	macro
	.set	reorder

.L54:
	lhu	$2,624($4)
	#nop
	addu	$2,$2,$6
	.set	noreorder
	.set	nomacro
	j	.L37
	sh	$2,624($4)
	.set	macro
	.set	reorder

.L62:
	lhu	$2,622($4)
	#nop
	addu	$2,$2,$6
	sh	$2,622($4)
.L37:
	j	$31
	.end	func_80027438
.Lfe4:
	.size	 func_80027438,.Lfe4-func_80027438
	.align	2
	.globl	func_800274BC
	.type	 func_800274BC,@function
	.ent	func_800274BC
func_800274BC:
	.frame	$sp,8,$31		# vars= 8, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	move	$6,$4
	lw	$2,0($6)
	#nop
	mult	$2,$2
	mflo	$4
	#nop
	lw	$2,4($6)
	#nop
	mult	$2,$2
	mflo	$3
	#nop
	lw	$2,8($6)
	#nop
	mult	$2,$2
	addu	$2,$4,$3
	mflo	$8
	#nop
	#nop
	addu	$4,$2,$8
	sltu	$2,$4,1024
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L66
	subu	$sp,$sp,8
	.set	macro
	.set	reorder

	lbu	$2,D_8008D118($4)
	.set	noreorder
	.set	nomacro
	j	.L67
	srl	$4,$2,3
	.set	macro
	.set	reorder

.L66:
 #APP
	addu   $t4, $4, $zero
mtc2   $t4, $30
nop
nop
addu   $t4, $sp, $zero
swc2   $31, 0($t4)

 #NO_APP
	lw	$3,0($sp)
	li	$2,-2			# 0xfffffffe
	and	$2,$3,$2
	li	$3,0x00000016		# 22
	subu	$3,$3,$2
	srl	$2,$4,$3
	srl	$3,$3,1
	lbu	$4,D_8008D118($2)
	li	$2,0x00000013		# 19
	subu	$2,$2,$3
	sll	$4,$4,16
	srl	$4,$4,$2
.L67:
	lw	$2,0($6)
	#nop
	subu	$2,$0,$2
	sll	$2,$2,12
	div	$2,$2,$4
	sh	$2,0($5)
	lw	$2,4($6)
	#nop
	subu	$2,$0,$2
	sll	$2,$2,12
	div	$2,$2,$4
	sh	$2,2($5)
	lw	$2,8($6)
	#nop
	subu	$2,$0,$2
	sll	$2,$2,12
	div	$2,$2,$4
	sh	$2,4($5)
	addu	$sp,$sp,8
	j	$31
	.end	func_800274BC
.Lfe5:
	.size	 func_800274BC,.Lfe5-func_800274BC
	.align	2
	.globl	func_80027640
	.type	 func_80027640,@function
	.ent	func_80027640
func_80027640:
	.frame	$sp,64,$31		# vars= 32, regs= 4/0, args= 16, extra= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,64
	sw	$17,52($sp)
	move	$17,$4
	sw	$31,60($sp)
	sw	$18,56($sp)
	sw	$16,48($sp)
	lh	$18,4($17)
	jal	stage_GetDataPtr
	lbu	$3,844($17)
	move	$4,$2
	sltu	$2,$3,64
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L69
	addu	$2,$3,1
	.set	macro
	.set	reorder

	sb	$2,844($17)
.L69:
	lbu	$2,844($17)
	li	$3,0x0000003c		# 60
	addu	$2,$2,-1
	sll	$2,$2,2
	subu	$7,$3,$2
	slt	$2,$7,10
	beq	$2,$0,.L70
	li	$7,0x0000000a		# 10
.L70:
	lh	$3,D_800A36A4
	li	$2,0x00000003		# 3
	.set	noreorder
	.set	nomacro
	bne	$3,$2,.L71
	sll	$2,$3,1
	.set	macro
	.set	reorder

	lw	$2,0($17)
	#nop
	lw	$2,244($2)
	#nop
	slt	$2,$2,1001
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L72
	li	$3,0x00002ee0		# 12000
	.set	macro
	.set	reorder

	li	$3,-10000			# 0xffffd8f0
.L72:
	sw	$3,32($sp)
	lw	$2,0($17)
	#nop
	lw	$2,252($2)
	#nop
	.set	noreorder
	.set	nomacro
	blez	$2,.L73
	li	$6,0x00001770		# 6000
	.set	macro
	.set	reorder

	li	$6,-6000			# 0xffffe890
.L73:
	mult	$3,$7
	li	$4,0x00000064		# 100
	sw	$6,40($sp)
	mflo	$3
	#nop
	lw	$2,244($17)
	subu	$4,$4,$7
	mult	$2,$4
	li	$5,0x51eb0000		# 1374355456
	mflo	$9
	#nop
	ori	$5,$5,0x851f
	addu	$3,$3,$9
	mult	$3,$5
	mfhi	$2
	#nop
	#nop
	mult	$6,$7
	sra	$3,$3,31
	sra	$2,$2,5
	subu	$2,$2,$3
	sw	$2,16($sp)
	mflo	$6
	#nop
	lw	$2,252($17)
	#nop
	mult	$2,$4
	mflo	$3
	#nop
	#nop
	addu	$3,$6,$3
	mult	$3,$5
	sra	$3,$3,31
	mfhi	$9
	#nop
	#nop
	sra	$2,$9,5
	.set	noreorder
	.set	nomacro
	j	.L75
	subu	$2,$2,$3
	.set	macro
	.set	reorder

.L71:
	addu	$2,$2,$3
	sll	$2,$2,2
	sll	$3,$18,1
	addu	$3,$3,$18
	addu	$2,$2,$3
	sll	$2,$2,1
	addu	$4,$4,$2
	lh	$2,0($4)
	#nop
	sw	$2,16($sp)
	lh	$2,4($4)
.L75:
	sw	$2,24($sp)
	lw	$4,16($sp)
	lw	$2,244($17)
	#nop
	subu	$4,$4,$2
	lw	$2,24($sp)
	sw	$4,16($sp)
	lw	$3,252($17)
	#nop
	subu	$2,$2,$3
	sw	$2,24($sp)
	lw	$2,244($17)
	#nop
	addu	$2,$2,$4
	sw	$2,244($17)
	lw	$2,252($17)
	lw	$3,24($sp)
	#nop
	addu	$2,$2,$3
	sw	$2,252($17)
	lw	$2,216($17)
	lw	$3,16($sp)
	#nop
	addu	$2,$2,$3
	sw	$2,216($17)
	lw	$2,224($17)
	lw	$3,24($sp)
	#nop
	addu	$2,$2,$3
	sw	$2,224($17)
	lw	$2,184($17)
	lw	$3,16($sp)
	addu	$16,$17,94
	addu	$2,$2,$3
	sw	$2,184($17)
	lw	$5,24($sp)
	lw	$2,192($17)
	lw	$3,80($17)
	move	$6,$16
	sw	$0,260($17)
	sw	$0,264($17)
	sw	$0,268($17)
	sw	$0,308($17)
	sw	$0,312($17)
	sw	$0,316($17)
	addu	$2,$2,$5
	sw	$2,192($17)
	lhu	$5,0($3)
	.set	noreorder
	.set	nomacro
	jal	func_80021424
	move	$4,$17
	.set	macro
	.set	reorder

	move	$4,$17
	lhu	$5,58($2)
	.set	noreorder
	.set	nomacro
	jal	func_80021424
	move	$6,$16
	.set	macro
	.set	reorder

	move	$4,$18
	lh	$6,94($17)
	.set	noreorder
	.set	nomacro
	jal	func_80021A98
	move	$5,$2
	.set	macro
	.set	reorder

	li	$5,0x00000030		# 48
	addu	$6,$17,244
	lh	$4,4($17)
	.set	noreorder
	.set	nomacro
	jal	func_80032854
	move	$7,$0
	.set	macro
	.set	reorder

	lw	$31,60($sp)
	lw	$18,56($sp)
	lw	$17,52($sp)
	lw	$16,48($sp)
	addu	$sp,$sp,64
	j	$31
	.end	func_80027640
.Lfe6:
	.size	 func_80027640,.Lfe6-func_80027640
	.align	2
	.globl	func_800278C0
	.type	 func_800278C0,@function
	.ent	func_800278C0
func_800278C0:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	move	$8,$5
	move	$5,$6
	lw	$6,40($sp)
	lw	$3,44($sp)
	li	$2,0x00000001		# 1
	.set	noreorder
	.set	nomacro
	beq	$4,$2,.L76
	sw	$31,16($sp)
	.set	macro
	.set	reorder

	beq	$3,$0,.L78
	lw	$2,0($8)
	.set	noreorder
	.set	nomacro
	j	.L83
	li	$5,0x0000002b		# 43
	.set	macro
	.set	reorder

.L78:
	lw	$3,0($8)
	#nop
	lh	$4,134($3)
	lh	$2,142($3)
	#nop
	bne	$4,$2,.L79
	lh	$4,4($3)
	.set	noreorder
	.set	nomacro
	j	.L84
	li	$5,0x00000028		# 40
	.set	macro
	.set	reorder

.L79:
	lh	$2,136($3)
	#nop
	bne	$4,$2,.L80
	beq	$7,$0,.L80
	lh	$4,4($3)
	.set	noreorder
	.set	nomacro
	j	.L84
	li	$5,0x00000027		# 39
	.set	macro
	.set	reorder

.L80:
	.set	noreorder
	.set	nomacro
	bne	$5,$0,.L81
	slt	$2,$5,6
	.set	macro
	.set	reorder

	lw	$2,0($8)
	.set	noreorder
	.set	nomacro
	j	.L83
	li	$5,0x00000022		# 34
	.set	macro
	.set	reorder

.L81:
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L82
	li	$5,0x00000023		# 35
	.set	macro
	.set	reorder

	lw	$2,0($8)
	j	.L83
.L82:
	lw	$2,0($8)
	li	$5,0x00000024		# 36
.L83:
	lh	$4,4($2)
.L84:
	.set	noreorder
	.set	nomacro
	jal	func_80032854
	move	$7,$0
	.set	macro
	.set	reorder

.L76:
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_800278C0
.Lfe7:
	.size	 func_800278C0,.Lfe7-func_800278C0
	.align	2
	.globl	func_8002798C
	.type	 func_8002798C,@function
	.ent	func_8002798C
func_8002798C:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lhu	$3,106($4)
	li	$2,0x00000006		# 6
	.set	noreorder
	.set	nomacro
	beq	$3,$2,.L88
	move	$5,$0
	.set	macro
	.set	reorder

	li	$2,0x00000025		# 37
	.set	noreorder
	.set	nomacro
	beq	$3,$2,.L88
	li	$2,0x00000033		# 51
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	beq	$3,$2,.L88
	li	$2,0x00000004		# 4
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	beq	$3,$2,.L88
	li	$2,0x00000014		# 20
	.set	macro
	.set	reorder

	beq	$3,$2,.L88
	lh	$3,64($4)
	lbu	$2,165($4)
	#nop
	slt	$2,$3,$2
	bne	$2,$0,.L88
	lbu	$2,166($4)
	#nop
	slt	$2,$2,$3
	beq	$2,$0,.L91
.L88:
	lh	$3,136($4)
	li	$2,-1			# 0xffffffff
	beq	$3,$2,.L93
	lhu	$4,106($4)
	li	$2,0x0000000f		# 15
	andi	$3,$4,0xffff
	beq	$3,$2,.L91
	addu	$2,$4,-28
	sltu	$2,$2,2
	bne	$2,$0,.L91
	addu	$2,$4,-30
	sltu	$2,$2,2
	bne	$2,$0,.L91
	addu	$2,$4,-32
	sltu	$2,$2,2
	bne	$2,$0,.L91
	li	$2,0x0000002b		# 43
	bne	$3,$2,.L93
.L91:
	li	$5,0x00000001		# 1
.L93:
	.set	noreorder
	.set	nomacro
	j	$31
	move	$2,$5
	.set	macro
	.set	reorder

	.end	func_8002798C
.Lfe8:
	.size	 func_8002798C,.Lfe8-func_8002798C
	.align	2
	.globl	func_80027A58
	.type	 func_80027A58,@function
	.ent	func_80027A58
func_80027A58:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$16,16($sp)
	move	$16,$4
	sw	$31,20($sp)
	lh	$3,134($16)
	lh	$2,136($16)
	#nop
	bne	$3,$2,.L100
	lh	$2,138($16)
	#nop
	beq	$2,$0,.L100
	jal	func_8002798C
	beq	$2,$0,.L100
	lh	$4,4($16)
	jal	game_GetPlayerData
	lw	$5,76($2)
	move	$4,$16
	.set	noreorder
	.set	nomacro
	jal	func_80030900
	addu	$5,$5,20
	.set	macro
	.set	reorder

	lhu	$2,132($16)
	sh	$0,138($16)
	sh	$2,134($16)
.L100:
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80027A58
.Lfe9:
	.size	 func_80027A58,.Lfe9-func_80027A58
 #APP
	.section .rodata
    .include "asm/rodata/jtbl_80010548.s"
.section .text
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80027AD8.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_800283D0
	.type	 func_800283D0,@function
	.ent	func_800283D0
func_800283D0:
	.frame	$sp,56,$31		# vars= 8, regs= 8/0, args= 16, extra= 0
	.mask	0x807f0000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,56
	sw	$16,24($sp)
	move	$16,$4
	sw	$18,32($sp)
	move	$18,$5
	sw	$22,48($sp)
	li	$6,0x00000004		# 4
	sw	$31,52($sp)
	sw	$21,44($sp)
	sw	$20,40($sp)
	sw	$19,36($sp)
	sw	$17,28($sp)
	lhu	$5,106($16)
	lw	$20,0($16)
	andi	$3,$5,0xffff
	.set	noreorder
	.set	nomacro
	beq	$3,$6,.L105
	li	$22,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$4,0x00000014		# 20
	.set	noreorder
	.set	nomacro
	beq	$3,$4,.L146
	li	$2,0x00000001		# 1
	.set	macro
	.set	reorder

	lhu	$2,106($20)
	#nop
	beq	$2,$6,.L105
	.set	noreorder
	.set	nomacro
	beq	$2,$4,.L105
	li	$2,0x00000013		# 19
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	beq	$3,$2,.L109
	addu	$2,$5,-25
	.set	macro
	.set	reorder

	sltu	$2,$2,2
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L147
	move	$17,$0
	.set	macro
	.set	reorder

	li	$2,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	beq	$3,$2,.L147
	li	$2,0x00000026		# 38
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	beq	$3,$2,.L147
	li	$2,0x0000001b		# 27
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	beq	$3,$2,.L147
	li	$2,0x00000015		# 21
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	beq	$3,$2,.L147
	li	$2,0x00000025		# 37
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	beq	$3,$2,.L147
	li	$2,0x0000002c		# 44
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	beq	$3,$2,.L147
	li	$2,0x0000000c		# 12
	.set	macro
	.set	reorder

	beq	$3,$2,.L147
.L105:
	.set	noreorder
	.set	nomacro
	j	.L146
	li	$2,0x00000001		# 1
	.set	macro
	.set	reorder

.L109:
	move	$17,$0
.L147:
	lh	$3,D_800A3824
	lh	$2,4($16)
	lh	$4,4($20)
	sra	$2,$3,$2
	andi	$5,$2,0x0001
	sra	$3,$3,$4
	lh	$2,140($16)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L112
	andi	$21,$3,0x0001
	.set	macro
	.set	reorder

	sltu	$17,$5,1
.L112:
	.set	noreorder
	.set	nomacro
	beq	$17,$0,.L116
	li	$2,0x0000001d		# 29
	.set	macro
	.set	reorder

	lh	$3,12($16)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$3,$2,.L117
	li	$2,0x0000000e		# 14
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	beq	$3,$2,.L146
	move	$2,$22
	.set	macro
	.set	reorder

.L116:
	sll	$2,$21,1
	addu	$2,$2,$20
	lh	$3,648($2)
	#nop
	.set	noreorder
	.set	nomacro
	bne	$3,$0,.L118
	sll	$2,$5,1
	.set	macro
	.set	reorder

	addu	$2,$2,$16
	lh	$2,648($2)
	#nop
	blez	$2,.L117
	.set	noreorder
	.set	nomacro
	bne	$17,$0,.L122
	li	$2,0x00000019		# 25
	.set	macro
	.set	reorder

.L121:
	li	$2,0x0000000b		# 11
.L122:
	sh	$2,646($16)
.L148:
	li	$5,0x00000001		# 1
	move	$6,$18
	lh	$4,4($16)
	.set	noreorder
	.set	nomacro
	jal	func_80032854
	move	$7,$0
	.set	macro
	.set	reorder

	li	$5,0x00000025		# 37
	move	$6,$18
	lh	$4,4($16)
	.set	noreorder
	.set	nomacro
	jal	func_80032854
	move	$7,$0
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L146
	move	$2,$22
	.set	macro
	.set	reorder

.L118:
	addu	$19,$2,$16
	lh	$2,648($19)
	#nop
	.set	noreorder
	.set	nomacro
	bne	$2,$3,.L124
	slt	$2,$3,$2
	.set	macro
	.set	reorder

	li	$5,0x00000001		# 1
	move	$6,$18
	lh	$4,4($16)
	.set	noreorder
	.set	nomacro
	jal	func_80032854
	move	$7,$0
	.set	macro
	.set	reorder

	li	$5,0x00000025		# 37
	move	$6,$18
	lh	$4,4($16)
	.set	noreorder
	.set	nomacro
	jal	func_80032854
	move	$7,$0
	.set	macro
	.set	reorder

	lh	$3,648($19)
	li	$2,0x00000005		# 5
	bne	$3,$2,.L129
	lhu	$2,14($16)
	#nop
	addu	$2,$2,-6
	sltu	$2,$2,2
	bne	$2,$0,.L131
	lhu	$2,14($20)
	#nop
	addu	$2,$2,-6
	sltu	$2,$2,2
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L130
	li	$2,0x00000001		# 1
	.set	macro
	.set	reorder

.L131:
	.set	noreorder
	.set	nomacro
	bne	$17,$0,.L134
	li	$2,0x00000019		# 25
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L134
	li	$2,0x0000000b		# 11
	.set	macro
	.set	reorder

.L130:
	sh	$2,D_800A38A8
	li	$2,-1			# 0xffffffff
	sh	$2,D_800A3876
	.set	noreorder
	.set	nomacro
	j	.L146
	move	$2,$22
	.set	macro
	.set	reorder

.L129:
	.set	noreorder
	.set	nomacro
	bne	$17,$0,.L134
	li	$2,0x00000019		# 25
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L134
	li	$2,0x0000000b		# 11
	.set	macro
	.set	reorder

.L124:
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L137
	li	$5,0x00000026		# 38
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	beq	$17,$0,.L121
	li	$2,0x00000019		# 25
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L148
	sh	$2,646($16)
	.set	macro
	.set	reorder

.L137:
	move	$6,$18
	lh	$4,4($16)
	.set	noreorder
	.set	nomacro
	jal	func_80032854
	move	$7,$0
	.set	macro
	.set	reorder

	li	$5,0x0000002d		# 45
	move	$6,$18
	lh	$4,4($16)
	.set	noreorder
	.set	nomacro
	jal	func_80032854
	move	$7,$0
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	bne	$17,$0,.L134
	li	$2,0x0000001a		# 26
	.set	macro
	.set	reorder

	sll	$4,$21,4
	lh	$3,458($16)
	addu	$4,$20,$4
	subu	$3,$0,$3
	addu	$2,$3,1024
	andi	$2,$2,0x0fff
	sll	$2,$2,1
	lh	$5,Judge($2)
	lw	$2,276($4)
	#nop
	mult	$5,$2
	andi	$3,$3,0x0fff
	sll	$3,$3,1
	lh	$3,Judge($3)
	mflo	$6
	#nop
	lw	$2,284($4)
	#nop
	mult	$3,$2
	lw	$4,280($4)
	#nop
	move	$5,$4
	mflo	$3
	#nop
	#nop
	addu	$2,$6,$3
	.set	noreorder
	.set	nomacro
	bgez	$4,.L140
	sra	$3,$2,12
	.set	macro
	.set	reorder

	subu	$5,$0,$4
.L140:
	.set	noreorder
	.set	nomacro
	bgez	$3,.L141
	move	$2,$3
	.set	macro
	.set	reorder

	subu	$2,$0,$3
.L141:
	slt	$2,$2,$5
	beq	$2,$0,.L142
	.set	noreorder
	.set	nomacro
	blez	$4,.L134
	li	$2,0x00000014		# 20
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L134
	li	$2,0x00000013		# 19
	.set	macro
	.set	reorder

.L142:
	.set	noreorder
	.set	nomacro
	bgtz	$3,.L134
	li	$2,0x00000015		# 21
	.set	macro
	.set	reorder

	li	$2,0x00000016		# 22
.L134:
	sh	$2,646($16)
.L117:
	move	$2,$22
.L146:
	lw	$31,52($sp)
	lw	$22,48($sp)
	lw	$21,44($sp)
	lw	$20,40($sp)
	lw	$19,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,56
	j	$31
	.end	func_800283D0
.Lfe10:
	.size	 func_800283D0,.Lfe10-func_800283D0
	.align	2
	.globl	func_8002872C
	.type	 func_8002872C,@function
	.ent	func_8002872C
func_8002872C:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, extra= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	sw	$18,24($sp)
	move	$18,$0
	sw	$17,20($sp)
	move	$17,$0
	sw	$31,28($sp)
	sw	$16,16($sp)
.L150:
	la	$2,D_80101EC8
	addu	$16,$17,$2
	lh	$5,12($16)
	li	$2,0x0000001b		# 27
	bne	$5,$2,.L154
	lh	$2,70($16)
	#nop
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L154
	li	$2,0x0000000b		# 11
	.set	macro
	.set	reorder

	lhu	$6,106($16)
	#nop
	bne	$6,$2,.L154
	lh	$3,64($16)
	lbu	$2,167($16)
	#nop
	bne	$3,$2,.L154
	lw	$2,0($16)
	#nop
	lhu	$4,106($2)
	li	$2,0x00000026		# 38
	andi	$3,$4,0xffff
	beq	$3,$2,.L159
	.set	noreorder
	.set	nomacro
	beq	$3,$5,.L159
	li	$2,0x00000002		# 2
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	beq	$3,$2,.L159
	li	$2,0x00000015		# 21
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	beq	$3,$2,.L159
	addu	$2,$4,-36
	.set	macro
	.set	reorder

	sltu	$2,$2,2
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L159
	li	$2,0x00000008		# 8
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	beq	$3,$2,.L159
	addu	$2,$4,-34
	.set	macro
	.set	reorder

	sltu	$2,$2,2
	bne	$2,$0,.L159
	.set	noreorder
	.set	nomacro
	beq	$3,$0,.L159
	li	$2,0x00000010		# 16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	beq	$3,$2,.L159
	li	$2,0x00000013		# 19
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	beq	$3,$2,.L159
	addu	$2,$4,-48
	.set	macro
	.set	reorder

	sltu	$2,$2,2
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L159
	li	$2,0x0000001a		# 26
	.set	macro
	.set	reorder

	beq	$3,$2,.L159
	.set	noreorder
	.set	nomacro
	beq	$3,$6,.L159
	li	$2,0x00000012		# 18
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	beq	$3,$2,.L159
	li	$2,0x0000002a		# 42
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	beq	$3,$2,.L159
	li	$2,0x0000000c		# 12
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	beq	$3,$2,.L159
	li	$2,0x00000019		# 25
	.set	macro
	.set	reorder

	bne	$3,$2,.L154
.L159:
	lw	$2,D_800A387C
	lw	$3,D_800A3134
	#nop
	slt	$2,$2,$3
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L154
	li	$2,0x0000001c		# 28
	.set	macro
	.set	reorder

	lw	$3,0($16)
	#nop
	sh	$2,646($3)
	lw	$4,0($16)
	jal	func_80027A58
	lw	$4,0($16)
	#nop
	lhu	$3,106($4)
	li	$2,0x00000025		# 37
	bne	$3,$2,.L154
	lhu	$2,132($4)
	#nop
	sh	$2,134($4)
.L154:
	addu	$18,$18,1
	slt	$2,$18,2
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L150
	addu	$17,$17,1100
	.set	macro
	.set	reorder

	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,32
	j	$31
	.end	func_8002872C
.Lfe11:
	.size	 func_8002872C,.Lfe11-func_8002872C
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_800288C8.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_8002906C
	.type	 func_8002906C,@function
	.ent	func_8002906C
func_8002906C:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	jal	snd_GetSeId
	move	$3,$2
	lh	$2,0($3)
	#nop
	beq	$2,$0,.L181
.L182:
	sh	$0,2($3)
	addu	$3,$3,16
	lh	$2,0($3)
	#nop
	bne	$2,$0,.L182
.L181:
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_8002906C
.Lfe12:
	.size	 func_8002906C,.Lfe12-func_8002906C
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_800290B8.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80029454.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8002A458.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8002AB08.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_8002BC68
	.type	 func_8002BC68,@function
	.ent	func_8002BC68
func_8002BC68:
	.frame	$sp,8,$31		# vars= 8, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$3,D_80101FA0
	lw	$2,D_801023EC
	#nop
	subu	$7,$3,$2
	mult	$7,$7
	move	$5,$4
	lw	$3,D_80101FA8
	lw	$2,D_801023F4
	mflo	$4
	#nop
	subu	$9,$3,$2
	mult	$9,$9
	subu	$sp,$sp,8
	la	$10,D_80101EC8
	mflo	$3
	#nop
	#nop
	addu	$4,$4,$3
	sltu	$2,$4,1024
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L185
	addu	$11,$10,1100
	.set	macro
	.set	reorder

	lbu	$2,D_8008D118($4)
	.set	noreorder
	.set	nomacro
	j	.L186
	srl	$8,$2,3
	.set	macro
	.set	reorder

.L185:
 #APP
	addu   $t4, $4, $zero
mtc2   $t4, $30
nop
nop
addu   $t4, $sp, $zero
swc2   $31, 0($t4)

 #NO_APP
	lw	$3,0($sp)
	li	$2,-2			# 0xfffffffe
	and	$2,$3,$2
	li	$3,0x00000016		# 22
	subu	$3,$3,$2
	srl	$2,$4,$3
	srl	$3,$3,1
	lbu	$4,D_8008D118($2)
	li	$2,0x00000013		# 19
	subu	$2,$2,$3
	sll	$4,$4,16
	srl	$8,$4,$2
.L186:
	slt	$2,$8,$5
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L187
	li	$4,0x51eb0000		# 1374355456
	.set	macro
	.set	reorder

	ori	$4,$4,0x851f
	subu	$3,$5,$8
	sll	$2,$3,2
	addu	$2,$2,$3
	sll	$2,$2,4
	mult	$2,$4
	sra	$2,$2,31
	mfhi	$24
	#nop
	#nop
	sra	$3,$24,5
	.set	noreorder
	.set	nomacro
	j	.L188
	subu	$4,$3,$2
	.set	macro
	.set	reorder

.L187:
	subu	$3,$5,$8
	.set	noreorder
	.set	nomacro
	bgez	$3,.L188
	sra	$4,$3,4
	.set	macro
	.set	reorder

	addu	$3,$3,15
	sra	$4,$3,4
.L188:
	mult	$7,$4
	mflo	$3
	#nop
	addu	$2,$5,-100
	div	$6,$3,$2
	mult	$9,$4
	mflo	$3
	#nop
	#nop
	div	$5,$3,$2
	subu	$3,$0,$4
	mult	$7,$3
	mflo	$4
	#nop
	#nop
	div	$4,$4,$2
	mult	$9,$3
	mflo	$3
	#nop
	#nop
	div	$2,$3,$2
	sw	$6,308($10)
	sw	$5,316($10)
	sw	$4,308($11)
	sw	$2,316($11)
	move	$2,$8
	addu	$sp,$sp,8
	j	$31
	.end	func_8002BC68
.Lfe13:
	.size	 func_8002BC68,.Lfe13-func_8002BC68
	.align	2
	.globl	func_8002BEA0
	.type	 func_8002BEA0,@function
	.ent	func_8002BEA0
func_8002BEA0:
	.frame	$sp,8,$31		# vars= 8, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$3,D_80101FBC
	lw	$2,D_80102408
	#nop
	subu	$7,$3,$2
	mult	$7,$7
	lw	$3,D_80101FC4
	lw	$2,D_80102410
	mflo	$4
	#nop
	subu	$9,$3,$2
	mult	$9,$9
	subu	$sp,$sp,8
	la	$10,D_80101EC8
	mflo	$3
	#nop
	#nop
	addu	$4,$4,$3
	sltu	$2,$4,1024
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L191
	addu	$11,$10,1100
	.set	macro
	.set	reorder

	lbu	$2,D_8008D118($4)
	.set	noreorder
	.set	nomacro
	j	.L192
	srl	$8,$2,3
	.set	macro
	.set	reorder

.L191:
 #APP
	addu   $t4, $4, $zero
mtc2   $t4, $30
nop
nop
addu   $t4, $sp, $zero
swc2   $31, 0($t4)

 #NO_APP
	lw	$3,0($sp)
	li	$2,-2			# 0xfffffffe
	and	$2,$3,$2
	li	$3,0x00000016		# 22
	subu	$3,$3,$2
	srl	$2,$4,$3
	srl	$3,$3,1
	lbu	$4,D_8008D118($2)
	li	$2,0x00000013		# 19
	subu	$2,$2,$3
	sll	$4,$4,16
	srl	$8,$4,$2
.L192:
	slt	$2,$8,1100
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L193
	li	$4,0x51eb0000		# 1374355456
	.set	macro
	.set	reorder

	ori	$4,$4,0x851f
	li	$3,0x0000044c		# 1100
	subu	$3,$3,$8
	sll	$2,$3,2
	addu	$2,$2,$3
	sll	$2,$2,4
	mult	$2,$4
	sra	$2,$2,31
	mfhi	$24
	#nop
	#nop
	sra	$3,$24,5
	.set	noreorder
	.set	nomacro
	j	.L194
	subu	$4,$3,$2
	.set	macro
	.set	reorder

.L193:
	li	$2,0x0000044c		# 1100
	subu	$2,$2,$8
	.set	noreorder
	.set	nomacro
	bgez	$2,.L194
	sra	$4,$2,4
	.set	macro
	.set	reorder

	addu	$2,$2,15
	sra	$4,$2,4
.L194:
	mult	$7,$4
	mflo	$3
	#nop
	li	$2,0x000003e8		# 1000
	div	$6,$3,$2
	mult	$9,$4
	mflo	$3
	#nop
	#nop
	div	$5,$3,$2
	subu	$3,$0,$4
	mult	$7,$3
	mflo	$4
	#nop
	#nop
	div	$4,$4,$2
	mult	$9,$3
	mflo	$3
	#nop
	#nop
	div	$2,$3,$2
	sw	$6,308($10)
	sw	$5,316($10)
	sw	$4,308($11)
	sw	$2,316($11)
	addu	$2,$8,-1100
	addu	$sp,$sp,8
	j	$31
	.end	func_8002BEA0
.Lfe14:
	.size	 func_8002BEA0,.Lfe14-func_8002BEA0
	.align	2
	.globl	func_8002C0DC
	.type	 func_8002C0DC,@function
	.ent	func_8002C0DC
func_8002C0DC:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, extra= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	lw	$4,D_800A371C
	subu	$sp,$sp,32
	sw	$17,20($sp)
	move	$17,$0
	sw	$16,16($sp)
	la	$16,D_80101EC8
	sw	$31,28($sp)
	.set	noreorder
	.set	nomacro
	jal	func_8002BC68
	sw	$18,24($sp)
	.set	macro
	.set	reorder

	move	$18,$2
.L200:
	addu	$17,$17,1
	lw	$2,0($16)
	lw	$4,216($16)
	lw	$5,224($16)
	lw	$3,216($2)
	lw	$2,224($2)
	subu	$4,$3,$4
	.set	noreorder
	.set	nomacro
	jal	ratan2
	subu	$5,$2,$5
	.set	macro
	.set	reorder

	move	$4,$16
	.set	noreorder
	.set	nomacro
	jal	func_8001F860
	move	$5,$2
	.set	macro
	.set	reorder

	slt	$2,$17,2
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L200
	addu	$16,$16,1100
	.set	macro
	.set	reorder

	lh	$3,D_800A38AE
	lh	$4,D_800A376E
	sll	$2,$3,4
	addu	$2,$2,$3
	sll	$2,$2,2
	addu	$2,$2,$3
	sll	$2,$2,2
	subu	$2,$2,$3
	sll	$2,$2,2
	la	$3,D_80101EC8
	.set	noreorder
	.set	nomacro
	bne	$4,$0,.L202
	addu	$16,$2,$3
	.set	macro
	.set	reorder

	lbu	$3,D_800A3758
	li	$2,0x000000ff		# 255
	bne	$3,$2,.L202
	lbu	$3,170($16)
	lh	$2,64($16)
	#nop
	bne	$3,$2,.L202
	.set	noreorder
	.set	nomacro
	jal	func_8002AB08
	li	$4,0x00000001		# 1
	.set	macro
	.set	reorder

.L202:
	lh	$3,64($16)
	lbu	$2,D_800A38E8
	#nop
	slt	$2,$3,$2
	bne	$2,$0,.L196
	lbu	$2,170($16)
	#nop
	slt	$2,$3,$2
	beq	$2,$0,.L196
	lw	$2,D_800A371C
	#nop
	addu	$2,$2,200
	slt	$2,$2,$18
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L196
	li	$2,0x00000004		# 4
	.set	macro
	.set	reorder

	lw	$3,0($16)
	sh	$2,646($16)
	li	$2,0x00000005		# 5
	sh	$2,646($3)
.L196:
	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,32
	j	$31
	.end	func_8002C0DC
.Lfe15:
	.size	 func_8002C0DC,.Lfe15-func_8002C0DC
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8002C22C.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8002C61C.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8002CA8C.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8002CD58.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_8002D320
	.type	 func_8002D320,@function
	.ent	func_8002D320
func_8002D320:
	.frame	$sp,8,$31		# vars= 8, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	subu	$sp,$sp,8
	lw	$8,24($sp)
	bne	$4,$0,.L209
	lw	$3,96($5)
	lw	$2,0($6)
	lw	$3,0($3)
	#nop
	subu	$2,$2,$3
	lw	$3,96($5)
	sh	$2,248($5)
	lw	$2,4($6)
	lw	$3,4($3)
	#nop
	subu	$2,$2,$3
	lw	$3,96($5)
	sh	$2,250($5)
	lw	$2,8($6)
	lw	$3,8($3)
	#nop
	subu	$2,$2,$3
	sh	$2,252($5)
	addu	$2,$5,248
 #APP
	addu $t4, $2, $zero
lwc2 $0, 0($t4)
lwc2 $1, 4($t4)
nop
nop
.word 0x4A486012
 #NO_APP
	addu	$2,$5,256
 #APP
	addu $t4, $2, $zero
swc2 $25, 0($t4)
swc2 $26, 4($t4)
swc2 $27, 8($t4)
 #NO_APP
.L209:
	lw	$4,256($5)
	subu	$6,$0,$7
	slt	$2,$4,$6
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L227
	move	$2,$0
	.set	macro
	.set	reorder

	slt	$2,$7,$4
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L227
	move	$2,$0
	.set	macro
	.set	reorder

	lw	$3,260($5)
	#nop
	slt	$2,$3,$6
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L227
	move	$2,$0
	.set	macro
	.set	reorder

	slt	$2,$7,$3
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L227
	move	$2,$0
	.set	macro
	.set	reorder

	mult	$4,$4
	mflo	$2
	#nop
	#nop
	mult	$3,$3
	mflo	$3
	#nop
	#nop
	addu	$4,$2,$3
	slt	$2,$8,$4
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L227
	move	$2,$0
	.set	macro
	.set	reorder

	subu	$4,$8,$4
	sltu	$2,$4,1024
	beq	$2,$0,.L215
	lbu	$2,D_8008D118($4)
	.set	noreorder
	.set	nomacro
	j	.L216
	srl	$4,$2,3
	.set	macro
	.set	reorder

.L215:
	.set	noreorder
	.set	nomacro
	bltz	$4,.L217
	move	$3,$0
	.set	macro
	.set	reorder

 #APP
	addu $t4, $4, $zero
mtc2 $t4, $30
nop
nop
addu $t4, $sp, $zero
swc2 $31, 0($t4)
 #NO_APP
	lw	$3,0($sp)
.L217:
	li	$2,-2			# 0xfffffffe
	and	$2,$3,$2
	li	$3,0x00000016		# 22
	subu	$3,$3,$2
	srl	$2,$4,$3
	lbu	$4,D_8008D118($2)
	srl	$3,$3,1
	li	$2,0x00000013		# 19
	subu	$2,$2,$3
	sll	$4,$4,16
	srl	$4,$4,$2
.L216:
	move	$7,$0
	lw	$3,176($5)
	#nop
	.set	noreorder
	.set	nomacro
	bgez	$3,.L218
	move	$6,$0
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L219
	move	$6,$3
	.set	macro
	.set	reorder

.L218:
	slt	$2,$6,$3
	beq	$2,$0,.L219
	move	$7,$3
.L219:
	lw	$3,192($5)
	#nop
	slt	$2,$3,$6
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L221
	slt	$2,$7,$3
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L222
	move	$6,$3
	.set	macro
	.set	reorder

.L221:
	beq	$2,$0,.L222
	move	$7,$3
.L222:
	lw	$5,264($5)
	#nop
	subu	$2,$5,$4
	slt	$2,$7,$2
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L227
	move	$2,$0
	.set	macro
	.set	reorder

	addu	$2,$5,$4
	slt	$2,$2,$6
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L227
	move	$2,$0
	.set	macro
	.set	reorder

	li	$2,0x00000001		# 1
.L227:
	addu	$sp,$sp,8
	j	$31
	.end	func_8002D320
.Lfe16:
	.size	 func_8002D320,.Lfe16-func_8002D320
	.align	2
	.globl	func_8002D518
	.type	 func_8002D518,@function
	.ent	func_8002D518
func_8002D518:
	.frame	$sp,8,$31		# vars= 8, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	move	$9,$5
	lw	$5,0($6)
	lw	$3,0($7)
	#nop
	slt	$2,$5,$3
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L230
	subu	$sp,$sp,8
	.set	macro
	.set	reorder

	subu	$2,$0,$4
	slt	$2,$3,$2
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L250
	move	$2,$0
	.set	macro
	.set	reorder

	slt	$2,$4,$5
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L233
	move	$2,$0
	.set	macro
	.set	reorder

	j	.L250
.L230:
	subu	$2,$0,$4
	slt	$2,$5,$2
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L250
	move	$2,$0
	.set	macro
	.set	reorder

	slt	$2,$4,$3
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L250
	move	$2,$0
	.set	macro
	.set	reorder

.L233:
	lw	$5,4($6)
	lw	$3,4($7)
	#nop
	slt	$2,$5,$3
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L237
	subu	$2,$0,$4
	.set	macro
	.set	reorder

	slt	$2,$3,$2
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L250
	move	$2,$0
	.set	macro
	.set	reorder

	slt	$2,$4,$5
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L240
	move	$2,$0
	.set	macro
	.set	reorder

	j	.L250
.L237:
	slt	$2,$5,$2
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L250
	move	$2,$0
	.set	macro
	.set	reorder

	slt	$2,$4,$3
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L250
	move	$2,$0
	.set	macro
	.set	reorder

.L240:
	lw	$4,0($7)
	lw	$5,0($6)
	#nop
	subu	$4,$4,$5
	mult	$4,$4
	lw	$2,4($7)
	lw	$3,4($6)
	mflo	$8
	#nop
	subu	$2,$2,$3
	mult	$2,$2
	mflo	$6
	#nop
	#nop
	mult	$4,$5
	mflo	$4
	#nop
	#nop
	mult	$2,$3
	mflo	$11
	#nop
	#nop
	mult	$5,$5
	mflo	$5
	#nop
	#nop
	mult	$3,$3
	addu	$2,$4,$11
	mflo	$3
	#nop
	sll	$7,$2,1
	sra	$2,$7,9
	mult	$2,$2
	addu	$2,$5,$3
	subu	$2,$2,$9
	sra	$2,$2,9
	addu	$5,$8,$6
	mflo	$4
	#nop
	sra	$3,$5,9
	sll	$2,$2,2
	mult	$3,$2
	mflo	$3
	#nop
	#nop
	subu	$6,$4,$3
	.set	noreorder
	.set	nomacro
	bgez	$6,.L244
	sltu	$2,$6,1024
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L250
	move	$2,$0
	.set	macro
	.set	reorder

.L244:
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L246
	move	$4,$6
	.set	macro
	.set	reorder

	lbu	$2,D_8008D118($6)
	.set	noreorder
	.set	nomacro
	j	.L247
	srl	$6,$2,3
	.set	macro
	.set	reorder

.L246:
	.set	noreorder
	.set	nomacro
	bltz	$6,.L248
	move	$3,$0
	.set	macro
	.set	reorder

 #APP
	addu   $t4, $4, $zero
mtc2   $t4, $30
nop
nop
addu   $t4, $sp, $zero
swc2   $31, 0($t4)

 #NO_APP
	lw	$3,0($sp)
.L248:
	li	$2,-2			# 0xfffffffe
	and	$2,$3,$2
	li	$3,0x00000016		# 22
	subu	$3,$3,$2
	srl	$2,$4,$3
	lbu	$4,D_8008D118($2)
	srl	$3,$3,1
	li	$2,0x00000013		# 19
	subu	$2,$2,$3
	sll	$4,$4,16
	srl	$6,$4,$2
.L247:
	sll	$6,$6,9
	subu	$2,$0,$7
	addu	$4,$2,$6
	sll	$4,$4,8
	sll	$3,$5,1
	div	$4,$4,$3
	subu	$2,$2,$6
	sll	$2,$2,8
	div	$3,$2,$3
	.set	noreorder
	.set	nomacro
	bltz	$4,.L249
	move	$5,$0
	.set	macro
	.set	reorder

	slt	$5,$3,257
.L249:
	move	$2,$5
.L250:
	addu	$sp,$sp,8
	j	$31
	.end	func_8002D518
.Lfe17:
	.size	 func_8002D518,.Lfe17-func_8002D518
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8002D780.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8002DAD0.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8002DE20.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8002E6B0.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8002E838.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_8002EA24
	.type	 func_8002EA24,@function
	.ent	func_8002EA24
func_8002EA24:
	.frame	$sp,8,$31		# vars= 8, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	move	$8,$4
	lw	$3,96($8)
	lw	$2,0($5)
	lw	$3,0($3)
	#nop
	subu	$2,$2,$3
	lw	$3,96($8)
	sh	$2,248($8)
	lw	$2,4($5)
	lw	$3,4($3)
	#nop
	subu	$2,$2,$3
	lw	$3,96($8)
	sh	$2,250($8)
	lw	$2,8($5)
	lw	$3,8($3)
	subu	$sp,$sp,8
	subu	$2,$2,$3
	sh	$2,252($8)
	addu	$2,$8,248
 #APP
	addu $t4, $2, $zero
lwc2 $0, 0($t4)
lwc2 $1, 4($t4)
nop
nop
.word 0x4A486012
 #NO_APP
	addu	$2,$8,256
 #APP
	addu $t4, $2, $zero
swc2 $25, 0($t4)
swc2 $26, 4($t4)
swc2 $27, 8($t4)
 #NO_APP
	lw	$5,256($8)
	subu	$9,$0,$6
	slt	$2,$5,$9
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L268
	move	$2,$0
	.set	macro
	.set	reorder

	slt	$2,$6,$5
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L268
	move	$2,$0
	.set	macro
	.set	reorder

	lw	$3,260($8)
	#nop
	slt	$2,$3,$9
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L268
	move	$2,$0
	.set	macro
	.set	reorder

	slt	$2,$6,$3
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L268
	move	$2,$0
	.set	macro
	.set	reorder

	mult	$5,$5
	mflo	$2
	#nop
	#nop
	mult	$3,$3
	mflo	$3
	#nop
	#nop
	addu	$4,$2,$3
	slt	$2,$7,$4
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L268
	move	$2,$0
	.set	macro
	.set	reorder

	subu	$4,$7,$4
	sltu	$2,$4,1024
	beq	$2,$0,.L260
	lbu	$2,D_8008D118($4)
	.set	noreorder
	.set	nomacro
	j	.L261
	srl	$4,$2,3
	.set	macro
	.set	reorder

.L260:
	.set	noreorder
	.set	nomacro
	bltz	$4,.L263
	move	$3,$0
	.set	macro
	.set	reorder

 #APP
	addu $t4, $4, $zero
mtc2 $t4, $30
nop
nop
addu $t4, $sp, $zero
swc2 $31, 0($t4)
 #NO_APP
	lw	$3,0($sp)
.L263:
	li	$2,-2			# 0xfffffffe
	and	$2,$3,$2
	li	$3,0x00000016		# 22
	subu	$3,$3,$2
	srl	$2,$4,$3
	lbu	$4,D_8008D118($2)
	srl	$3,$3,1
	li	$2,0x00000013		# 19
	subu	$2,$2,$3
	sll	$4,$4,16
	srl	$4,$4,$2
.L261:
	move	$5,$0
	lw	$2,176($8)
	#nop
	.set	noreorder
	.set	nomacro
	bgez	$2,.L264
	move	$6,$0
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L265
	move	$6,$2
	.set	macro
	.set	reorder

.L264:
	move	$5,$2
.L265:
	lw	$3,264($8)
	#nop
	subu	$2,$3,$4
	slt	$2,$5,$2
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L268
	move	$2,$0
	.set	macro
	.set	reorder

	addu	$2,$3,$4
	slt	$2,$2,$6
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L268
	move	$2,$0
	.set	macro
	.set	reorder

	li	$2,0x00000001		# 1
.L268:
	addu	$sp,$sp,8
	j	$31
	.end	func_8002EA24
.Lfe18:
	.size	 func_8002EA24,.Lfe18-func_8002EA24
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8002EBDC.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_8002EECC
	.type	 func_8002EECC,@function
	.ent	func_8002EECC
func_8002EECC:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lh	$10,10($4)
	lh	$9,14($4)
	#nop
	mult	$10,$9
	lh	$8,8($4)
	mflo	$2
	#nop
	lh	$7,16($4)
	#nop
	mult	$8,$7
	mflo	$3
	#nop
	#nop
	subu	$6,$2,$3
	lh	$3,0($4)
	sra	$2,$6,12
	mult	$3,$2
	mflo	$11
	#nop
	lh	$3,2($4)
	#nop
	mult	$3,$7
	mflo	$7
	#nop
	lh	$2,4($4)
	#nop
	mult	$2,$9
	mflo	$13
	#nop
	#nop
	mult	$2,$8
	mflo	$9
	#nop
	#nop
	mult	$3,$10
	subu	$2,$7,$13
	mflo	$8
	#nop
	lh	$3,6($4)
	sra	$2,$2,12
	mult	$3,$2
	subu	$2,$9,$8
	mflo	$7
	#nop
	lh	$3,12($4)
	sra	$2,$2,12
	mult	$3,$2
	addu	$3,$11,$7
	mflo	$2
	#nop
	#nop
	addu	$3,$3,$2
	sra	$3,$3,12
	div	$6,$6,$3
	sh	$6,0($5)
	lh	$6,2($4)
	lh	$2,16($4)
	#nop
	mult	$6,$2
	lh	$6,4($4)
	mflo	$7
	#nop
	lh	$2,14($4)
	#nop
	mult	$6,$2
	mflo	$2
	#nop
	#nop
	subu	$2,$7,$2
	div	$2,$2,$3
	sh	$2,2($5)
	lh	$6,4($4)
	lh	$2,8($4)
	#nop
	mult	$6,$2
	lh	$6,2($4)
	mflo	$7
	#nop
	lh	$2,10($4)
	#nop
	mult	$6,$2
	mflo	$2
	#nop
	#nop
	subu	$2,$7,$2
	div	$2,$2,$3
	sh	$2,4($5)
	lh	$6,6($4)
	lh	$2,16($4)
	#nop
	mult	$6,$2
	lh	$6,10($4)
	mflo	$7
	#nop
	lh	$2,12($4)
	#nop
	mult	$6,$2
	mflo	$2
	#nop
	#nop
	subu	$2,$7,$2
	div	$2,$2,$3
	sh	$2,6($5)
	lh	$6,4($4)
	lh	$2,12($4)
	#nop
	mult	$6,$2
	lh	$6,0($4)
	mflo	$7
	#nop
	lh	$2,16($4)
	#nop
	mult	$6,$2
	mflo	$2
	#nop
	#nop
	subu	$2,$7,$2
	div	$2,$2,$3
	sh	$2,8($5)
	lh	$6,0($4)
	lh	$2,10($4)
	#nop
	mult	$6,$2
	lh	$6,4($4)
	mflo	$7
	#nop
	lh	$2,6($4)
	#nop
	mult	$6,$2
	mflo	$2
	#nop
	#nop
	subu	$2,$7,$2
	div	$2,$2,$3
	sh	$2,10($5)
	lh	$6,8($4)
	lh	$2,12($4)
	#nop
	mult	$6,$2
	lh	$6,6($4)
	mflo	$7
	#nop
	lh	$2,14($4)
	#nop
	mult	$6,$2
	mflo	$2
	#nop
	#nop
	subu	$2,$7,$2
	div	$2,$2,$3
	sh	$2,12($5)
	lh	$6,0($4)
	lh	$2,14($4)
	#nop
	mult	$6,$2
	lh	$6,2($4)
	mflo	$7
	#nop
	lh	$2,12($4)
	#nop
	mult	$6,$2
	mflo	$2
	#nop
	#nop
	subu	$2,$7,$2
	div	$2,$2,$3
	sh	$2,14($5)
	lh	$6,2($4)
	lh	$2,6($4)
	#nop
	mult	$6,$2
	lh	$6,0($4)
	mflo	$7
	#nop
	lh	$2,8($4)
	#nop
	mult	$6,$2
	mflo	$2
	#nop
	#nop
	subu	$2,$7,$2
	div	$2,$2,$3
	.set	noreorder
	.set	nomacro
	j	$31
	sh	$2,16($5)
	.set	macro
	.set	reorder

	.end	func_8002EECC
.Lfe19:
	.size	 func_8002EECC,.Lfe19-func_8002EECC
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8002F2D0.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8002F770.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_8002FC80
	.type	 func_8002FC80,@function
	.ent	func_8002FC80
func_8002FC80:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	lw	$2,0($5)
	lw	$3,0($4)
	#nop
	subu	$2,$2,$3
	sw	$2,528483168
	lw	$2,4($5)
	lw	$3,4($4)
	#nop
	subu	$2,$2,$3
	sw	$2,528483172
	lw	$2,8($5)
	lw	$3,8($4)
	#nop
	subu	$2,$2,$3
	sw	$2,528483176
	lw	$2,0($6)
	lw	$3,0($4)
	#nop
	subu	$2,$2,$3
	sw	$2,528483184
	lw	$2,4($6)
	lw	$3,4($4)
	#nop
	subu	$2,$2,$3
	sw	$2,528483188
	lw	$2,8($6)
	lw	$3,8($4)
	li	$7,0x1f800360		# 528483168
	subu	$2,$2,$3
	sw	$2,528483192
 #APP
	move   $12, $7
lw     $13, 0($12)
lw     $14, 4($12)
ctc2   $13, $0
lw     $15, 8($12)
ctc2   $14, $2
ctc2   $15, $4

 #NO_APP
	li	$7,0x1f800370		# 528483184
 #APP
	move   $12, $7
lwc2   $11, 8($12)
lwc2   $9, 0($12)
lwc2   $10, 4($12)
nop
nop

	.word 0x4B70000C
 #NO_APP
	li	$2,0x1f800000		# 528482304
	ori	$2,$2,0x0380
 #APP
	move   $12, $2
swc2   $25, 0($12)
swc2   $26, 4($12)
swc2   $27, 8($12)

 #NO_APP
	lw	$4,0($2)
	lw	$5,528483208
	jal	ratan2
	lw	$3,528483204
	#nop
	blez	$3,.L271
	addu	$2,$2,2048
.L271:
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_8002FC80
.Lfe20:
	.size	 func_8002FC80,.Lfe20-func_8002FC80
	.align	2
	.globl	func_8002FDB0
	.type	 func_8002FDB0,@function
	.ent	func_8002FDB0
func_8002FDB0:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lh	$3,4($4)
	#nop
	sll	$2,$3,5
	addu	$2,$2,$3
	sll	$2,$2,3
	lw	$3,528482496($2)
	lw	$4,528482484($2)
	#nop
	subu	$3,$3,$4
	sw	$3,528483168
	lw	$3,528482500($2)
	lw	$4,528482488($2)
	#nop
	subu	$3,$3,$4
	sw	$3,528483172
	lw	$3,528482504($2)
	lw	$4,528482492($2)
	#nop
	subu	$3,$3,$4
	sw	$3,528483176
	lw	$3,528482508($2)
	lw	$4,528482484($2)
	#nop
	subu	$3,$3,$4
	sw	$3,528483184
	lw	$3,528482512($2)
	lw	$4,528482488($2)
	#nop
	subu	$3,$3,$4
	sw	$3,528483188
	lw	$3,528482516($2)
	lw	$2,528482492($2)
	li	$5,0x1f800360		# 528483168
	subu	$3,$3,$2
	sw	$3,528483192
 #APP
	move   $12, $5
lw     $13, 0($12)
lw     $14, 4($12)
ctc2   $13, $0
lw     $15, 8($12)
ctc2   $14, $2
ctc2   $15, $4

 #NO_APP
	li	$5,0x1f800370		# 528483184
 #APP
	move   $12, $5
lwc2   $11, 8($12)
lwc2   $9, 0($12)
lwc2   $10, 4($12)
nop
nop

	.word 0x4B70000C
 #NO_APP
	li	$5,0x1f800380		# 528483200
 #APP
	move   $12, $5
swc2   $25, 0($12)
swc2   $26, 4($12)
swc2   $27, 8($12)

 #NO_APP
	lw	$2,528483204
	.set	noreorder
	.set	nomacro
	j	$31
	slt	$2,$0,$2
	.set	macro
	.set	reorder

	.end	func_8002FDB0
.Lfe21:
	.size	 func_8002FDB0,.Lfe21-func_8002FDB0
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_8002FF20.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_800300B4.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_80030208
	.type	 func_80030208,@function
	.ent	func_80030208
func_80030208:
	.frame	$sp,56,$31		# vars= 8, regs= 7/0, args= 16, extra= 0
	.mask	0x803f0000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,56
	sw	$20,40($sp)
	la	$20,D_80106A78
	sw	$21,44($sp)
	move	$21,$0
	sw	$19,36($sp)
	addu	$19,$20,10
	sw	$31,48($sp)
	sw	$18,32($sp)
	sw	$17,28($sp)
	sw	$16,24($sp)
.L274:
	lh	$3,-8($19)
	li	$2,-1			# 0xffffffff
	.set	noreorder
	.set	nomacro
	beq	$3,$2,.L276
	move	$4,$3
	.set	macro
	.set	reorder

	lbu	$2,-2($19)
	#nop
	beq	$2,$0,.L277
	.set	noreorder
	.set	nomacro
	jal	func_800300B4
	move	$4,$20
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L286
	addu	$21,$21,1
	.set	macro
	.set	reorder

.L277:
	lh	$2,0($20)
	#nop
	slt	$2,$2,2
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L276
	addu	$2,$4,-18
	.set	macro
	.set	reorder

	lbu	$18,D_8008EB80($3)
	andi	$2,$2,0xffff
	sltu	$2,$2,12
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L280
	li	$2,0x0000000e		# 14
	.set	macro
	.set	reorder

	lbu	$18,1($19)
	.set	noreorder
	.set	nomacro
	j	.L287
	move	$4,$18
	.set	macro
	.set	reorder

.L280:
	.set	noreorder
	.set	nomacro
	bne	$3,$2,.L287
	move	$4,$18
	.set	macro
	.set	reorder

	lbu	$3,-5($19)
	li	$2,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	bne	$3,$2,.L288
	li	$5,0x00000001		# 1
	.set	macro
	.set	reorder

	addu	$18,$18,3
	move	$4,$18
.L287:
	li	$5,0x00000001		# 1
.L288:
	addu	$17,$20,44
	move	$6,$17
	addu	$16,$20,84
	.set	noreorder
	.set	nomacro
	jal	func_80049718
	move	$7,$16
	.set	macro
	.set	reorder

	lbu	$4,0($19)
	move	$5,$18
	move	$6,$17
	.set	noreorder
	.set	nomacro
	jal	func_800393C8
	move	$7,$16
	.set	macro
	.set	reorder

.L276:
	addu	$21,$21,1
.L286:
	addu	$19,$19,100
	slt	$2,$21,12
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L274
	addu	$20,$20,100
	.set	macro
	.set	reorder

	lw	$31,48($sp)
	lw	$21,44($sp)
	lw	$20,40($sp)
	lw	$19,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,56
	j	$31
	.end	func_80030208
.Lfe22:
	.size	 func_80030208,.Lfe22-func_80030208
	.align	2
	.globl	cpu_get_dist
	.type	 cpu_get_dist,@function
	.ent	cpu_get_dist
cpu_get_dist:
	.frame	$sp,32,$31		# vars= 8, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	sw	$16,24($sp)
	move	$16,$4
	sw	$31,28($sp)
	lh	$4,0($5)
	lh	$5,4($5)
	jal	ratan2
	addu	$3,$2,1024
	andi	$3,$3,0x0fff
	sll	$3,$3,1
	lh	$5,Judge($3)
	lw	$3,68($16)
	#nop
	mult	$3,$5
	andi	$2,$2,0x0fff
	sll	$2,$2,1
	lh	$4,Judge($2)
	mflo	$7
	#nop
	lw	$2,76($16)
	#nop
	mult	$2,$4
	mflo	$9
	#nop
	subu	$3,$0,$3
	mult	$3,$4
	mflo	$6
	#nop
	#nop
	mult	$2,$5
	mflo	$2
	#nop
	addu	$3,$7,$9
	sra	$3,$3,12
	mult	$3,$5
	addu	$2,$6,$2
	mflo	$7
	#nop
	sra	$2,$2,12
	subu	$2,$0,$2
	mult	$2,$4
	mflo	$9
	#nop
	#nop
	mult	$3,$4
	mflo	$6
	#nop
	#nop
	mult	$2,$5
	lw	$3,72($16)
	subu	$2,$7,$9
	sra	$2,$2,15
	sw	$2,68($16)
	mflo	$4
	#nop
	#nop
	addu	$2,$6,$4
	sra	$2,$2,15
	.set	noreorder
	.set	nomacro
	bgez	$3,.L291
	sw	$2,76($16)
	.set	macro
	.set	reorder

	addu	$3,$3,3
.L291:
	sra	$2,$3,2
	sw	$2,72($16)
	lw	$31,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,32
	j	$31
	.end	cpu_get_dist
.Lfe23:
	.size	 cpu_get_dist,.Lfe23-cpu_get_dist
	.align	2
	.globl	func_8003043C
	.type	 func_8003043C,@function
	.ent	func_8003043C
func_8003043C:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	move	$4,$0
	li	$6,-1			# 0xffffffff
	li	$5,0x000000ff		# 255
	move	$3,$0
.L296:
	sh	$6,D_80106A7A($3)
	sb	$5,D_80106A82($3)
	addu	$4,$4,1
	slt	$2,$4,12
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L296
	addu	$3,$3,100
	.set	macro
	.set	reorder

	j	$31
	.end	func_8003043C
.Lfe24:
	.size	 func_8003043C,.Lfe24-func_8003043C
	.align	2
	.globl	func_8003047C
	.type	 func_8003047C,@function
	.ent	func_8003047C
func_8003047C:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	sh	$0,816($4)
	move	$5,$0
	la	$8,D_8008E338
	li	$7,-1			# 0xffffffff
	move	$6,$4
.L301:
	lh	$2,10($4)
	#nop
	sll	$3,$2,2
	addu	$3,$3,$2
	addu	$3,$3,$8
	addu	$3,$3,$5
	lbu	$2,0($3)
	#nop
	sll	$2,$2,24
	sra	$2,$2,24
	sh	$2,818($6)
	sll	$2,$2,16
	sra	$2,$2,16
	beq	$2,$7,.L304
	lhu	$2,816($4)
	#nop
	addu	$2,$2,1
	sh	$2,816($4)
.L304:
	addu	$5,$5,1
	slt	$2,$5,5
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L301
	addu	$6,$6,2
	.set	macro
	.set	reorder

	lh	$3,10($4)
	#nop
	sll	$2,$3,2
	addu	$2,$2,$3
	lh	$3,4($4)
	lbu	$2,D_8008E338($2)
	#nop
	sb	$2,D_800A36F2($3)
	j	$31
	.end	func_8003047C
.Lfe25:
	.size	 func_8003047C,.Lfe25-func_8003047C
	.align	2
	.globl	func_80030524
	.type	 func_80030524,@function
	.ent	func_80030524
func_80030524:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	move	$5,$0
	li	$6,-1			# 0xffffffff
	la	$3,D_80106A7A
	move	$4,$0
.L307:
	lh	$2,0($3)
	#nop
	beq	$2,$6,.L310
	lbu	$2,D_80106A80($4)
	#nop
	beq	$2,$0,.L310
	sh	$6,0($3)
.L310:
	addu	$3,$3,100
	addu	$5,$5,1
	slt	$2,$5,12
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L307
	addu	$4,$4,100
	.set	macro
	.set	reorder

	j	$31
	.end	func_80030524
.Lfe26:
	.size	 func_80030524,.Lfe26-func_80030524
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80030580.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_800307D0
	.type	 func_800307D0,@function
	.ent	func_800307D0
func_800307D0:
	.frame	$sp,40,$31		# vars= 0, regs= 5/0, args= 16, extra= 0
	.mask	0x800f0000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	sw	$16,16($sp)
	move	$16,$4
	sw	$31,32($sp)
	sw	$19,28($sp)
	sw	$18,24($sp)
	sw	$17,20($sp)
	lh	$2,816($16)
	#nop
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L314
	slt	$2,$2,2
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L325
	li	$2,-1			# 0xffffffff
	.set	macro
	.set	reorder

.L314:
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L316
	move	$17,$0
	.set	macro
	.set	reorder

	lh	$3,136($16)
	li	$2,-1			# 0xffffffff
	.set	noreorder
	.set	nomacro
	beq	$3,$2,.L327
	sll	$2,$17,1
	.set	macro
	.set	reorder

	lh	$2,818($16)
	lh	$3,20($16)
	#nop
	xor	$2,$2,$3
	sltu	$17,$2,1
.L316:
	sll	$2,$17,1
.L327:
	addu	$18,$2,$16
	lh	$19,818($18)
	move	$4,$16
	.set	noreorder
	.set	nomacro
	jal	func_80030580
	move	$5,$19
	.set	macro
	.set	reorder

	move	$4,$17
	lh	$3,816($16)
	#nop
	addu	$3,$3,-1
	slt	$3,$4,$3
	.set	noreorder
	.set	nomacro
	beq	$3,$0,.L319
	move	$6,$2
	.set	macro
	.set	reorder

	move	$3,$18
.L321:
	lhu	$2,820($3)
	addu	$4,$4,1
	sh	$2,818($3)
	lh	$2,816($16)
	#nop
	addu	$2,$2,-1
	slt	$2,$4,$2
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L321
	addu	$3,$3,2
	.set	macro
	.set	reorder

.L319:
	lhu	$2,816($16)
	#nop
	addu	$2,$2,-1
	sh	$2,816($16)
	lh	$3,2($6)
	li	$2,0x0000000e		# 14
	.set	noreorder
	.set	nomacro
	bne	$3,$2,.L323
	li	$5,0x0000002a		# 42
	.set	macro
	.set	reorder

	li	$5,0x0000002f		# 47
	addu	$6,$6,44
	lbu	$4,D_800A36F2
	move	$7,$0
	.set	noreorder
	.set	nomacro
	j	.L326
	xori	$4,$4,0x000e
	.set	macro
	.set	reorder

.L323:
	addu	$6,$6,44
	lbu	$4,D_800A36F2
	move	$7,$0
	xor	$4,$3,$4
.L326:
	.set	noreorder
	.set	nomacro
	jal	func_80032854
	sltu	$4,$0,$4
	.set	macro
	.set	reorder

	move	$2,$19
.L325:
	lw	$31,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,40
	j	$31
	.end	func_800307D0
.Lfe27:
	.size	 func_800307D0,.Lfe27-func_800307D0
	.align	2
	.globl	func_80030900
	.type	 func_80030900,@function
	.ent	func_80030900
func_80030900:
	.frame	$sp,40,$31		# vars= 8, regs= 4/0, args= 16, extra= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	sw	$18,32($sp)
	move	$18,$4
	sw	$16,24($sp)
	move	$16,$5
	sw	$31,36($sp)
	sw	$17,28($sp)
	lh	$5,818($18)
	jal	func_80030580
	move	$17,$2
	sb	$0,4($17)
	lw	$2,0($16)
	lw	$3,4($16)
	lw	$4,8($16)
	sw	$2,44($17)
	sw	$3,48($17)
	sw	$4,52($17)
	jal	rng_Next
	andi	$2,$2,0x00ff
	addu	$2,$2,-128
	.set	noreorder
	.set	nomacro
	jal	rng_Next
	sw	$2,68($17)
	.set	macro
	.set	reorder

	andi	$2,$2,0x003f
	subu	$2,$0,$2
	addu	$2,$2,-128
	.set	noreorder
	.set	nomacro
	jal	rng_Next
	sw	$2,72($17)
	.set	macro
	.set	reorder

	andi	$2,$2,0x00ff
	addu	$2,$2,-128
	.set	noreorder
	.set	nomacro
	jal	rng_Next
	sw	$2,76($17)
	.set	macro
	.set	reorder

	move	$3,$2
	andi	$2,$3,0x1000
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L329
	andi	$2,$3,0x03ff
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L336
	addu	$2,$2,512
	.set	macro
	.set	reorder

.L329:
	subu	$2,$0,$2
	addu	$2,$2,-512
.L336:
	.set	noreorder
	.set	nomacro
	jal	rng_Next
	sh	$2,92($17)
	.set	macro
	.set	reorder

	andi	$2,$2,0x07ff
	addu	$2,$2,-1024
	sh	$2,94($17)
	li	$2,0x00000001		# 1
	sh	$0,96($17)
	sb	$2,7($17)
	lh	$2,816($18)
	#nop
	addu	$2,$2,-1
	.set	noreorder
	.set	nomacro
	blez	$2,.L332
	move	$4,$0
	.set	macro
	.set	reorder

	move	$3,$18
.L334:
	lhu	$2,820($3)
	addu	$4,$4,1
	sh	$2,818($3)
	lh	$2,816($18)
	#nop
	addu	$2,$2,-1
	slt	$2,$4,$2
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L334
	addu	$3,$3,2
	.set	macro
	.set	reorder

.L332:
	lhu	$2,816($18)
	#nop
	addu	$2,$2,-1
	sh	$2,816($18)
	lw	$31,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,40
	j	$31
	.end	func_80030900
.Lfe28:
	.size	 func_80030900,.Lfe28-func_80030900
	.align	2
	.globl	cpu_set_move_command_and_dir
	.type	 cpu_set_move_command_and_dir,@function
	.ent	cpu_set_move_command_and_dir
cpu_set_move_command_and_dir:
	.frame	$sp,32,$31		# vars= 0, regs= 4/0, args= 16, extra= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	sw	$18,24($sp)
	move	$18,$4
	sw	$16,16($sp)
	move	$16,$6
	sw	$31,28($sp)
	.set	noreorder
	.set	nomacro
	jal	func_80030580
	sw	$17,20($sp)
	.set	macro
	.set	reorder

	move	$17,$2
	sb	$0,4($17)
	lw	$2,0($16)
	lw	$3,4($16)
	lw	$4,8($16)
	sw	$2,44($17)
	sw	$3,48($17)
	sw	$4,52($17)
	jal	rng_Next
	andi	$2,$2,0x00ff
	addu	$2,$2,-128
	.set	noreorder
	.set	nomacro
	jal	rng_Next
	sw	$2,68($17)
	.set	macro
	.set	reorder

	andi	$2,$2,0x003f
	subu	$2,$0,$2
	addu	$2,$2,-128
	.set	noreorder
	.set	nomacro
	jal	rng_Next
	sw	$2,72($17)
	.set	macro
	.set	reorder

	andi	$2,$2,0x00ff
	addu	$2,$2,-128
	.set	noreorder
	.set	nomacro
	jal	rng_Next
	sw	$2,76($17)
	.set	macro
	.set	reorder

	move	$3,$2
	andi	$2,$3,0x1000
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L338
	andi	$2,$3,0x03ff
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L340
	addu	$2,$2,512
	.set	macro
	.set	reorder

.L338:
	subu	$2,$0,$2
	addu	$2,$2,-512
.L340:
	.set	noreorder
	.set	nomacro
	jal	rng_Next
	sh	$2,92($17)
	.set	macro
	.set	reorder

	andi	$2,$2,0x07ff
	addu	$2,$2,-1024
	sh	$2,94($17)
	li	$2,0x00000001		# 1
	sh	$0,96($17)
	sb	$2,7($17)
	lhu	$2,18($18)
	#nop
	sb	$2,11($17)
	lw	$31,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,32
	j	$31
	.end	cpu_set_move_command_and_dir
.Lfe29:
	.size	 cpu_set_move_command_and_dir,.Lfe29-cpu_set_move_command_and_dir
	.align	2
	.globl	func_80030B10
	.type	 func_80030B10,@function
	.ent	func_80030B10
func_80030B10:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lh	$6,816($4)
	li	$2,0x0000000c		# 12
	.set	noreorder
	.set	nomacro
	bne	$6,$2,.L342
	li	$2,-1			# 0xffffffff
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L352
	move	$2,$0
	.set	macro
	.set	reorder

.L342:
	lh	$3,136($4)
	#nop
	beq	$3,$2,.L344
	lh	$2,20($4)
	#nop
	bne	$5,$2,.L344
	.set	noreorder
	.set	nomacro
	blez	$6,.L346
	sll	$2,$6,1
	.set	macro
	.set	reorder

	addu	$3,$2,$4
.L347:
	lhu	$2,816($3)
	addu	$6,$6,-1
	sh	$2,818($3)
	.set	noreorder
	.set	nomacro
	bgtz	$6,.L347
	addu	$3,$3,-2
	.set	macro
	.set	reorder

.L346:
	lhu	$2,816($4)
	sh	$5,818($4)
	addu	$2,$2,1
	.set	noreorder
	.set	nomacro
	j	.L351
	sh	$2,816($4)
	.set	macro
	.set	reorder

.L344:
	lhu	$2,816($4)
	#nop
	addu	$3,$2,1
	sll	$2,$2,16
	sra	$2,$2,15
	addu	$2,$2,$4
	sh	$3,816($4)
	sh	$5,818($2)
.L351:
	li	$2,0x00000001		# 1
.L352:
	j	$31
	.end	func_80030B10
.Lfe30:
	.size	 func_80030B10,.Lfe30-func_80030B10
	.align	2
	.globl	func_80030BA8
	.type	 func_80030BA8,@function
	.ent	func_80030BA8
func_80030BA8:
	.frame	$sp,40,$31		# vars= 0, regs= 5/0, args= 16, extra= 0
	.mask	0x800f0000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	sw	$17,20($sp)
	move	$17,$4
	move	$6,$0
	sw	$19,28($sp)
	li	$19,-1			# 0xffffffff
	sw	$16,16($sp)
	la	$16,D_80106A7A
	sw	$31,32($sp)
	sw	$18,24($sp)
.L354:
	lhu	$3,0($16)
	#nop
	addu	$2,$3,-18
	sltu	$2,$2,12
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L356
	sll	$2,$3,16
	.set	macro
	.set	reorder

	sra	$5,$2,16
	beq	$5,$19,.L356
	lw	$2,78($16)
	#nop
	bne	$2,$0,.L356
	lw	$3,188($17)
	lw	$4,46($16)
	addu	$2,$3,-100
	slt	$2,$2,$4
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L356
	addu	$2,$3,100
	.set	macro
	.set	reorder

	slt	$2,$4,$2
	beq	$2,$0,.L356
	lw	$2,244($17)
	lw	$3,42($16)
	#nop
	subu	$2,$2,$3
	mult	$2,$2
	lw	$2,252($17)
	lw	$3,50($16)
	mflo	$4
	#nop
	subu	$2,$2,$3
	mult	$2,$2
	li	$3,0x000f0000		# 983040
	ori	$3,$3,0x423f
	mflo	$9
	#nop
	#nop
	addu	$2,$4,$9
	slt	$3,$3,$2
	.set	noreorder
	.set	nomacro
	bne	$3,$0,.L362
	addu	$6,$6,1
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_80030B10
	move	$4,$17
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L366
	li	$2,0x0000000e		# 14
	.set	macro
	.set	reorder

	lh	$18,0($16)
	#nop
	.set	noreorder
	.set	nomacro
	bne	$18,$2,.L364
	sh	$19,0($16)
	.set	macro
	.set	reorder

	li	$5,0x0000002f		# 47
	addu	$6,$17,244
	lbu	$4,D_800A36F2
	move	$7,$0
	xori	$4,$4,0x000e
	.set	noreorder
	.set	nomacro
	j	.L368
	sltu	$4,$0,$4
	.set	macro
	.set	reorder

.L364:
	lh	$4,4($17)
	li	$5,0x00000011		# 17
	addu	$6,$17,244
	move	$7,$0
.L368:
	jal	func_80032854
	.set	noreorder
	.set	nomacro
	j	.L367
	move	$2,$18
	.set	macro
	.set	reorder

.L356:
	addu	$6,$6,1
.L362:
	slt	$2,$6,12
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L354
	addu	$16,$16,100
	.set	macro
	.set	reorder

.L366:
	li	$2,-1			# 0xffffffff
.L367:
	lw	$31,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,40
	j	$31
	.end	func_80030BA8
.Lfe31:
	.size	 func_80030BA8,.Lfe31-func_80030BA8
	.align	2
	.globl	func_80030D04
	.type	 func_80030D04,@function
	.ent	func_80030D04
func_80030D04:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	move	$4,$0
	li	$5,-1			# 0xffffffff
	la	$3,D_80106A7A
.L370:
	lhu	$2,0($3)
	#nop
	addu	$2,$2,-18
	sltu	$2,$2,12
	beq	$2,$0,.L373
	sh	$5,0($3)
.L373:
	addu	$4,$4,1
	slt	$2,$4,12
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L370
	addu	$3,$3,100
	.set	macro
	.set	reorder

	j	$31
	.end	func_80030D04
.Lfe32:
	.size	 func_80030D04,.Lfe32-func_80030D04
	.align	2
	.globl	func_80030D48
	.type	 func_80030D48,@function
	.ent	func_80030D48
func_80030D48:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_80030D48
.Lfe33:
	.size	 func_80030D48,.Lfe33-func_80030D48
	.align	2
	.globl	func_80030D50
	.type	 func_80030D50,@function
	.ent	func_80030D50
func_80030D50:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	subu	$4,$4,$5
	andi	$4,$4,0x0fff
	slt	$2,$4,2048
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L378
	mult	$4,$6
	.set	macro
	.set	reorder

	addu	$4,$4,-4096
	mult	$4,$6
.L378:
	mflo	$3
	#nop
	#nop
	sra	$2,$3,12
	.set	noreorder
	.set	nomacro
	j	$31
	addu	$2,$5,$2
	.set	macro
	.set	reorder

	.end	func_80030D50
.Lfe34:
	.size	 func_80030D50,.Lfe34-func_80030D50
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80030D7C.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80031890.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80031B24.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_80032040
	.type	 func_80032040,@function
	.ent	func_80032040
func_80032040:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	li	$2,0x00000084		# 132
.L383:
	sb	$0,D_80104E88($2)
	addu	$2,$2,-44
	bgez	$2,.L383
	j	$31
	.end	func_80032040
.Lfe35:
	.size	 func_80032040,.Lfe35-func_80032040
	.align	2
	.globl	func_80032064
	.type	 func_80032064,@function
	.ent	func_80032064
func_80032064:
	.frame	$sp,40,$31		# vars= 16, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	move	$6,$4
	move	$7,$5
	li	$5,0x00000050		# 80
	li	$8,-200			# 0xffffff38
	move	$3,$0
	la	$4,D_80104E88
	sw	$31,36($sp)
	sw	$16,32($sp)
.L389:
	move	$16,$4
	lbu	$2,0($16)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L396
	li	$2,0x00000004		# 4
	.set	macro
	.set	reorder

	addu	$3,$3,1
	slt	$2,$3,4
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L389
	addu	$4,$16,44
	.set	macro
	.set	reorder

	li	$2,0x00000004		# 4
.L396:
	.set	noreorder
	.set	nomacro
	bne	$3,$2,.L392
	li	$2,0x00000001		# 1
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L395
	move	$2,$0
	.set	macro
	.set	reorder

.L392:
	sb	$7,0($16)
	sb	$2,1($16)
	sb	$0,2($16)
	lhu	$2,4($6)
	#nop
	sb	$2,3($16)
	lw	$2,244($6)
	#nop
	sw	$2,4($16)
	lh	$3,26($6)
	#nop
	bgez	$3,.L393
	addu	$3,$3,31
.L393:
	lw	$2,188($6)
	sra	$3,$3,5
	subu	$2,$2,$3
	sw	$2,8($16)
	lw	$2,252($6)
	#nop
	sw	$2,12($16)
	lhu	$2,458($6)
	#nop
	andi	$2,$2,0x0fff
	sll	$2,$2,1
	lh	$2,Judge($2)
	#nop
	mult	$2,$5
	sw	$8,32($16)
	mflo	$9
	#nop
	#nop
	sra	$2,$9,12
	sw	$2,28($16)
	lh	$2,458($6)
	#nop
	addu	$2,$2,1024
	andi	$2,$2,0x0fff
	sll	$2,$2,1
	lh	$2,Judge($2)
	#nop
	mult	$2,$5
	mflo	$9
	#nop
	#nop
	sra	$2,$9,12
	sw	$2,36($16)
	lw	$2,4($16)
	lw	$3,8($16)
	lw	$4,12($16)
	sw	$2,16($16)
	sw	$3,20($16)
	sw	$4,24($16)
	lw	$2,188($6)
	li	$5,0x0000000d		# 13
	sw	$2,40($16)
	lhu	$2,458($6)
	#nop
	sh	$2,18($sp)
	li	$2,0x00000001		# 1
	lbu	$4,178($6)
	.set	noreorder
	.set	nomacro
	bne	$7,$2,.L394
	addu	$3,$16,4
	.set	macro
	.set	reorder

	li	$5,0x0000000c		# 12
.L394:
	move	$6,$3
	.set	noreorder
	.set	nomacro
	jal	func_80032854
	addu	$7,$sp,16
	.set	macro
	.set	reorder

	move	$2,$16
.L395:
	lw	$31,36($sp)
	lw	$16,32($sp)
	addu	$sp,$sp,40
	j	$31
	.end	func_80032064
.Lfe36:
	.size	 func_80032064,.Lfe36-func_80032064
	.align	2
	.globl	func_800321E8
	.type	 func_800321E8,@function
	.ent	func_800321E8
func_800321E8:
	.frame	$sp,48,$31		# vars= 0, regs= 5/0, args= 24, extra= 0
	.mask	0x800f0000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,48
	sw	$17,28($sp)
	li	$17,0x1f800000		# 528482304
	ori	$17,$17,0x02b8
	sw	$18,32($sp)
	la	$18,D_80104E88
	sw	$19,36($sp)
	move	$19,$0
	sw	$16,24($sp)
	addu	$16,$18,4
	sw	$31,40($sp)
.L398:
	lbu	$2,0($18)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L401
	addu	$6,$17,16
	.set	macro
	.set	reorder

	lbu	$2,-2($16)
	addu	$7,$17,48
	addu	$2,$2,1
	sb	$2,-2($16)
	lw	$2,0($16)
	lw	$3,4($16)
	lw	$4,8($16)
	sw	$2,12($16)
	sw	$3,16($16)
	sw	$4,20($16)
	lw	$2,28($16)
	lw	$3,0($16)
	lw	$4,24($16)
	addu	$2,$2,13
	addu	$3,$3,$4
	sw	$2,28($16)
	sw	$3,0($17)
	lw	$2,4($16)
	lw	$3,28($16)
	move	$5,$17
	addu	$2,$2,$3
	sw	$2,4($17)
	lw	$3,8($16)
	lw	$4,32($16)
	addu	$2,$17,56
	sw	$2,16($sp)
	addu	$3,$3,$4
	move	$4,$16
	.set	noreorder
	.set	nomacro
	jal	func_8005344C
	sw	$3,8($17)
	.set	macro
	.set	reorder

	bne	$2,$0,.L403
	lw	$3,4($16)
	lw	$2,36($16)
	#nop
	slt	$2,$2,$3
	beq	$2,$0,.L402
.L403:
	.set	noreorder
	.set	nomacro
	j	.L401
	sb	$0,0($18)
	.set	macro
	.set	reorder

.L402:
	lw	$2,0($17)
	lw	$3,4($17)
	lw	$4,8($17)
	sw	$2,0($16)
	sw	$3,4($16)
	sw	$4,8($16)
.L401:
	addu	$19,$19,1
	addu	$16,$16,44
	slt	$2,$19,4
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L398
	addu	$18,$18,44
	.set	macro
	.set	reorder

	lw	$31,40($sp)
	lw	$19,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,48
	j	$31
	.end	func_800321E8
.Lfe37:
	.size	 func_800321E8,.Lfe37-func_800321E8
	.align	2
	.globl	func_80032314
	.type	 func_80032314,@function
	.ent	func_80032314
func_80032314:
	.frame	$sp,8,$31		# vars= 8, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	subu	$sp,$sp,8
	la	$8,D_80104E88
	move	$9,$0
	addu	$7,$8,2
.L407:
	lbu	$2,0($8)
	#nop
	beq	$2,$0,.L409
	lbu	$3,1($7)
	#nop
	sltu	$3,$3,1
	sll	$2,$3,4
	addu	$2,$2,$3
	sll	$2,$2,2
	addu	$2,$2,$3
	sll	$2,$2,2
	subu	$2,$2,$3
	sll	$2,$2,2
	la	$3,D_80101EC8
	addu	$6,$2,$3
	lhu	$3,106($6)
	li	$2,0x00000004		# 4
	andi	$4,$3,0xffff
	.set	noreorder
	.set	nomacro
	beq	$4,$2,.L409
	li	$2,0x00000014		# 20
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	beq	$4,$2,.L409
	li	$2,0x0000000f		# 15
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	beq	$4,$2,.L409
	addu	$2,$3,-28
	.set	macro
	.set	reorder

	sltu	$2,$2,2
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L409
	addu	$2,$3,-30
	.set	macro
	.set	reorder

	sltu	$2,$2,2
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L409
	addu	$2,$3,-32
	.set	macro
	.set	reorder

	sltu	$2,$2,2
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L409
	li	$2,0x00000011		# 17
	.set	macro
	.set	reorder

	beq	$4,$2,.L409
	lw	$2,244($6)
	lw	$3,2($7)
	#nop
	subu	$2,$2,$3
	mult	$2,$2
	lw	$2,248($6)
	lw	$3,6($7)
	mflo	$5
	#nop
	subu	$2,$2,$3
	mult	$2,$2
	lw	$3,10($7)
	lw	$2,252($6)
	mflo	$4
	#nop
	subu	$2,$2,$3
	mult	$2,$2
	addu	$2,$5,$4
	mflo	$3
	#nop
	#nop
	addu	$4,$2,$3
	sltu	$2,$4,1024
	beq	$2,$0,.L420
	lbu	$2,D_8008D118($4)
	.set	noreorder
	.set	nomacro
	j	.L421
	srl	$4,$2,3
	.set	macro
	.set	reorder

.L420:
	.set	noreorder
	.set	nomacro
	bltz	$4,.L422
	move	$3,$0
	.set	macro
	.set	reorder

 #APP
	addu   $t4, $4, $zero
mtc2   $t4, $30
nop
nop
addu   $t4, $sp, $zero
swc2   $31, 0($t4)

 #NO_APP
	lw	$3,0($sp)
.L422:
	li	$2,-2			# 0xfffffffe
	and	$2,$3,$2
	li	$3,0x00000016		# 22
	subu	$3,$3,$2
	srl	$2,$4,$3
	lbu	$4,D_8008D118($2)
	srl	$3,$3,1
	li	$2,0x00000013		# 19
	subu	$2,$2,$3
	sll	$4,$4,16
	srl	$4,$4,$2
.L421:
	lbu	$3,0($7)
	#nop
	sll	$2,$3,4
	subu	$2,$2,$3
	sll	$2,$2,1
	addu	$2,$2,500
	sltu	$2,$4,$2
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L409
	li	$2,0x00000005		# 5
	.set	macro
	.set	reorder

	sh	$2,646($6)
	sb	$0,0($8)
.L409:
	addu	$9,$9,1
	addu	$7,$7,44
	slt	$2,$9,4
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L407
	addu	$8,$8,44
	.set	macro
	.set	reorder

	addu	$sp,$sp,8
	j	$31
	.end	func_80032314
.Lfe38:
	.size	 func_80032314,.Lfe38-func_80032314
	.align	2
	.globl	func_800324D0
	.type	 func_800324D0,@function
	.ent	func_800324D0
func_800324D0:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$3,88($4)
	li	$2,0x000000ff		# 255
	sb	$2,161($4)
	sb	$2,163($4)
	sb	$2,162($4)
	sb	$2,164($4)
	sb	$0,170($4)
	sb	$0,167($4)
	sb	$0,168($4)
	sb	$0,165($4)
	sb	$2,166($4)
	sb	$2,171($4)
	sb	$2,172($4)
	lbu	$2,4($3)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L428
	addu	$3,$3,5
	.set	macro
	.set	reorder

	li	$8,0x000000ff		# 255
	la	$7,.L447
.L429:
	andi	$6,$2,0x00ff
	.set	noreorder
	.set	nomacro
	bne	$6,$8,.L430
	sltu	$2,$6,128
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L431
	addu	$3,$3,6
	.set	macro
	.set	reorder

.L430:
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L432
	addu	$6,$6,-128
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L431
	addu	$3,$3,1
	.set	macro
	.set	reorder

.L432:
	lbu	$5,0($3)
	sltu	$2,$6,12
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L431
	addu	$3,$3,1
	.set	macro
	.set	reorder

	sll	$2,$6,2
	addu	$2,$2,$7
	lw	$2,0($2)
	#nop
	j	$2
.section	.rodata
	.align	3
	.align	2
.L447:
	.word	.L435
	.word	.L436
	.word	.L437
	.word	.L438
	.word	.L439
	.word	.L440
	.word	.L441
	.word	.L442
	.word	.L443
	.word	.L444
	.word	.L445
	.word	.L446
	.text
.L435:
	.set	noreorder
	.set	nomacro
	j	.L431
	sb	$5,161($4)
	.set	macro
	.set	reorder

.L436:
	.set	noreorder
	.set	nomacro
	j	.L431
	sb	$5,163($4)
	.set	macro
	.set	reorder

.L437:
	.set	noreorder
	.set	nomacro
	j	.L431
	sb	$5,167($4)
	.set	macro
	.set	reorder

.L438:
	.set	noreorder
	.set	nomacro
	j	.L431
	sb	$5,168($4)
	.set	macro
	.set	reorder

.L439:
	.set	noreorder
	.set	nomacro
	j	.L431
	sb	$5,169($4)
	.set	macro
	.set	reorder

.L440:
	.set	noreorder
	.set	nomacro
	j	.L431
	sb	$5,165($4)
	.set	macro
	.set	reorder

.L441:
	.set	noreorder
	.set	nomacro
	j	.L431
	sb	$5,166($4)
	.set	macro
	.set	reorder

.L442:
	.set	noreorder
	.set	nomacro
	j	.L431
	sb	$5,162($4)
	.set	macro
	.set	reorder

.L443:
	.set	noreorder
	.set	nomacro
	j	.L431
	sb	$5,164($4)
	.set	macro
	.set	reorder

.L444:
	.set	noreorder
	.set	nomacro
	j	.L431
	sb	$5,170($4)
	.set	macro
	.set	reorder

.L445:
	.set	noreorder
	.set	nomacro
	j	.L431
	sb	$5,171($4)
	.set	macro
	.set	reorder

.L446:
	sb	$5,172($4)
.L431:
	lbu	$2,0($3)
	#nop
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L429
	addu	$3,$3,1
	.set	macro
	.set	reorder

.L428:
	j	$31
	.end	func_800324D0
.Lfe39:
	.size	 func_800324D0,.Lfe39-func_800324D0
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_800325E0.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_80032854
	.type	 func_80032854,@function
	.ent	func_80032854
func_80032854:
	.frame	$sp,48,$31		# vars= 0, regs= 7/0, args= 16, extra= 0
	.mask	0x803f0000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,48
	sw	$19,28($sp)
	move	$19,$4
	sw	$18,24($sp)
	move	$18,$5
	sw	$17,20($sp)
	move	$17,$6
	sw	$21,36($sp)
	move	$21,$7
	lh	$3,D_800A38DC
	li	$2,0x00000003		# 3
	sw	$31,40($sp)
	sw	$20,32($sp)
	.set	noreorder
	.set	nomacro
	bne	$3,$2,.L451
	sw	$16,16($sp)
	.set	macro
	.set	reorder

	li	$2,0x00000001		# 1
	.set	noreorder
	.set	nomacro
	bne	$19,$2,.L497
	sll	$2,$19,2
	.set	macro
	.set	reorder

	addu	$2,$18,-34
	sltu	$2,$2,2
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L498
	move	$20,$0
	.set	macro
	.set	reorder

	addu	$2,$18,-36
	sltu	$2,$2,2
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L453
	move	$16,$0
	.set	macro
	.set	reorder

	addu	$2,$18,-38
	sltu	$2,$2,2
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L453
	addu	$2,$18,-40
	.set	macro
	.set	reorder

	sltu	$2,$2,2
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L497
	sll	$2,$19,2
	.set	macro
	.set	reorder

.L498:
	.set	noreorder
	.set	nomacro
	j	.L453
	move	$16,$0
	.set	macro
	.set	reorder

.L451:
	sll	$2,$19,2
.L497:
	addu	$2,$2,$19
	sll	$16,$2,3
	li	$20,0x00000028		# 40
.L453:
	lh	$3,D_800A38DC
	li	$2,0x00000003		# 3
	.set	noreorder
	.set	nomacro
	bne	$3,$2,.L499
	move	$4,$19
	.set	macro
	.set	reorder

	li	$2,0x00000001		# 1
	.set	noreorder
	.set	nomacro
	bne	$19,$2,.L500
	move	$5,$18
	.set	macro
	.set	reorder

	addu	$2,$18,-45
	sltu	$2,$2,2
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L501
	move	$6,$17
	.set	macro
	.set	reorder

	lbu	$2,D_800A384C
	#nop
	sll	$2,$2,2
	lw	$2,D_8008EBCC($2)
	#nop
	addu	$16,$16,$2
	move	$4,$19
.L499:
	move	$5,$18
.L500:
	move	$6,$17
.L501:
	.set	noreorder
	.set	nomacro
	jal	func_800395B4
	move	$7,$21
	.set	macro
	.set	reorder

	addu	$5,$18,-1
	sltu	$2,$5,50
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L455
	sll	$2,$5,2
	.set	macro
	.set	reorder

	lw	$2,.L493($2)
	#nop
	j	$2
.section	.rodata
	.align	3
	.align	2
.L493:
	.word	.L462
	.word	.L460
	.word	.L459
	.word	.L456
	.word	.L463
	.word	.L464
	.word	.L465
	.word	.L466
	.word	.L467
	.word	.L468
	.word	.L469
	.word	.L470
	.word	.L471
	.word	.L472
	.word	.L461
	.word	.L455
	.word	.L473
	.word	.L474
	.word	.L455
	.word	.L455
	.word	.L455
	.word	.L455
	.word	.L455
	.word	.L455
	.word	.L455
	.word	.L455
	.word	.L455
	.word	.L455
	.word	.L455
	.word	.L455
	.word	.L455
	.word	.L455
	.word	.L475
	.word	.L476
	.word	.L477
	.word	.L478
	.word	.L479
	.word	.L480
	.word	.L481
	.word	.L482
	.word	.L483
	.word	.L484
	.word	.L485
	.word	.L486
	.word	.L487
	.word	.L488
	.word	.L489
	.word	.L490
	.word	.L491
	.word	.L492
	.text
.L456:
	lh	$3,D_800A38DC
	li	$2,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	bne	$3,$2,.L502
	li	$2,0x00000005		# 5
	.set	macro
	.set	reorder

	lbu	$2,D_800A389A
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L495
	li	$2,0x00000005		# 5
	.set	macro
	.set	reorder

.L502:
	.set	noreorder
	.set	nomacro
	bne	$3,$2,.L458
	move	$4,$17
	.set	macro
	.set	reorder

.L495:
	.set	noreorder
	.set	nomacro
	jal	func_800617C8
	move	$4,$17
	.set	macro
	.set	reorder

	j	.L455
.L458:
	.set	noreorder
	.set	nomacro
	jal	func_800618B4
	move	$5,$21
	.set	macro
	.set	reorder

	j	.L455
.L459:
	.set	noreorder
	.set	nomacro
	jal	func_80061250
	move	$4,$17
	.set	macro
	.set	reorder

	j	.L455
.L460:
	move	$4,$17
	.set	noreorder
	.set	nomacro
	jal	func_80061658
	move	$5,$19
	.set	macro
	.set	reorder

	j	.L455
.L461:
	move	$4,$17
	.set	noreorder
	.set	nomacro
	jal	func_80061710
	move	$5,$19
	.set	macro
	.set	reorder

	j	.L455
.L462:
	.set	noreorder
	.set	nomacro
	jal	func_8006156C
	move	$4,$17
	.set	macro
	.set	reorder

	j	.L455
.L463:
	li	$4,0x0000003c		# 60
	.set	noreorder
	.set	nomacro
	jal	func_800325E0
	move	$5,$17
	.set	macro
	.set	reorder

	addu	$4,$20,60
	.set	noreorder
	.set	nomacro
	jal	func_800325E0
	move	$5,$17
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_8006133C
	move	$4,$17
	.set	macro
	.set	reorder

	sh	$2,D_800A3910
	j	.L455
.L464:
	li	$4,0x0000003c		# 60
	.set	noreorder
	.set	nomacro
	jal	func_800325E0
	move	$5,$17
	.set	macro
	.set	reorder

	addu	$4,$20,60
	.set	noreorder
	.set	nomacro
	jal	func_800325E0
	move	$5,$17
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_800613C8
	move	$4,$17
	.set	macro
	.set	reorder

	sh	$2,D_800A3910
	j	.L455
.L465:
	li	$4,0x0000003c		# 60
	.set	noreorder
	.set	nomacro
	jal	func_800325E0
	move	$5,$17
	.set	macro
	.set	reorder

	addu	$4,$20,60
	.set	noreorder
	.set	nomacro
	jal	func_800325E0
	move	$5,$17
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_80061454
	move	$4,$17
	.set	macro
	.set	reorder

	sh	$2,D_800A3910
	j	.L455
.L466:
	li	$4,0x0000003c		# 60
	.set	noreorder
	.set	nomacro
	jal	func_800325E0
	move	$5,$17
	.set	macro
	.set	reorder

	addu	$4,$20,60
	.set	noreorder
	.set	nomacro
	jal	func_800325E0
	move	$5,$17
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_800614E0
	move	$4,$17
	.set	macro
	.set	reorder

	sh	$2,D_800A3910
	j	.L455
.L467:
	.set	noreorder
	.set	nomacro
	jal	func_800619A4
	move	$4,$17
	.set	macro
	.set	reorder

	j	.L455
.L468:
	.set	noreorder
	.set	nomacro
	jal	func_800619F0
	move	$4,$17
	.set	macro
	.set	reorder

	j	.L455
.L469:
	addu	$4,$16,49
	.set	noreorder
	.set	nomacro
	jal	func_800325E0
	move	$5,$17
	.set	macro
	.set	reorder

	move	$4,$17
	.set	noreorder
	.set	nomacro
	jal	func_800611A4
	move	$5,$21
	.set	macro
	.set	reorder

	j	.L455
.L470:
	li	$4,0x00000078		# 120
	.set	noreorder
	.set	nomacro
	jal	func_800325E0
	move	$5,$17
	.set	macro
	.set	reorder

	lh	$5,2($21)
	.set	noreorder
	.set	nomacro
	jal	func_80061C00
	move	$4,$17
	.set	macro
	.set	reorder

	j	.L455
.L471:
	li	$4,0x00000079		# 121
	.set	noreorder
	.set	nomacro
	jal	func_800325E0
	move	$5,$17
	.set	macro
	.set	reorder

	lh	$5,2($21)
	.set	noreorder
	.set	nomacro
	jal	func_80061D74
	move	$4,$17
	.set	macro
	.set	reorder

	j	.L455
.L472:
	addu	$4,$16,34
	.set	noreorder
	.set	nomacro
	jal	func_800325E0
	move	$5,$17
	.set	macro
	.set	reorder

	move	$4,$17
	.set	noreorder
	.set	nomacro
	jal	func_80061ACC
	move	$5,$21
	.set	macro
	.set	reorder

	j	.L455
.L473:
	.set	noreorder
	.set	nomacro
	j	.L496
	addu	$4,$16,57
	.set	macro
	.set	reorder

.L474:
	.set	noreorder
	.set	nomacro
	jal	func_80061EC0
	move	$4,$17
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L496
	addu	$4,$16,34
	.set	macro
	.set	reorder

.L475:
	.set	noreorder
	.set	nomacro
	j	.L496
	li	$4,0x0000007a		# 122
	.set	macro
	.set	reorder

.L476:
	.set	noreorder
	.set	nomacro
	j	.L496
	addu	$4,$16,53
	.set	macro
	.set	reorder

.L477:
	.set	noreorder
	.set	nomacro
	j	.L496
	addu	$4,$16,53
	.set	macro
	.set	reorder

.L478:
	.set	noreorder
	.set	nomacro
	j	.L496
	addu	$4,$16,52
	.set	macro
	.set	reorder

.L479:
	.set	noreorder
	.set	nomacro
	j	.L496
	addu	$4,$16,58
	.set	macro
	.set	reorder

.L480:
	.set	noreorder
	.set	nomacro
	j	.L496
	addu	$4,$16,59
	.set	macro
	.set	reorder

.L481:
	.set	noreorder
	.set	nomacro
	j	.L496
	addu	$4,$16,34
	.set	macro
	.set	reorder

.L482:
	.set	noreorder
	.set	nomacro
	j	.L496
	addu	$4,$16,62
	.set	macro
	.set	reorder

.L483:
	.set	noreorder
	.set	nomacro
	j	.L496
	addu	$4,$16,64
	.set	macro
	.set	reorder

.L484:
	.set	noreorder
	.set	nomacro
	j	.L496
	addu	$4,$16,33
	.set	macro
	.set	reorder

.L485:
	.set	noreorder
	.set	nomacro
	j	.L496
	addu	$4,$16,34
	.set	macro
	.set	reorder

.L486:
	.set	noreorder
	.set	nomacro
	j	.L496
	addu	$4,$16,35
	.set	macro
	.set	reorder

.L487:
	.set	noreorder
	.set	nomacro
	j	.L496
	addu	$4,$16,41
	.set	macro
	.set	reorder

.L488:
	.set	noreorder
	.set	nomacro
	j	.L496
	addu	$4,$16,43
	.set	macro
	.set	reorder

.L489:
	.set	noreorder
	.set	nomacro
	j	.L496
	addu	$4,$16,34
	.set	macro
	.set	reorder

.L490:
	.set	noreorder
	.set	nomacro
	j	.L496
	addu	$4,$16,34
	.set	macro
	.set	reorder

.L491:
	.set	noreorder
	.set	nomacro
	j	.L496
	addu	$4,$16,50
	.set	macro
	.set	reorder

.L492:
	addu	$4,$16,51
.L496:
	.set	noreorder
	.set	nomacro
	jal	func_800325E0
	move	$5,$17
	.set	macro
	.set	reorder

.L455:
	lw	$31,40($sp)
	lw	$21,36($sp)
	lw	$20,32($sp)
	lw	$19,28($sp)
	lw	$18,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,48
	j	$31
	.end	func_80032854
.Lfe40:
	.size	 func_80032854,.Lfe40-func_80032854
 #APP
	.section .rodata
    .include "asm/rodata/jtbl_80010698.s"
.section .text
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80032C50.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	cpu_check_same_dir_timer
	.type	 cpu_check_same_dir_timer,@function
	.ent	cpu_check_same_dir_timer
cpu_check_same_dir_timer:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, extra= 0
	.mask	0x80030000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,32
	sw	$17,20($sp)
	move	$17,$4
	sw	$31,24($sp)
	sw	$16,16($sp)
	lw	$2,88($17)
	#nop
	lbu	$5,4($2)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$5,$0,.L503
	addu	$16,$2,5
	.set	macro
	.set	reorder

.L506:
	andi	$5,$5,0x00ff
	li	$2,0x000000ff		# 255
	.set	noreorder
	.set	nomacro
	bne	$5,$2,.L507
	sltu	$2,$5,128
	.set	macro
	.set	reorder

	lbu	$2,1($16)
	lbu	$3,0($16)
	lbu	$4,2($16)
	sll	$2,$2,8
	or	$3,$3,$2
	sll	$4,$4,16
	or	$3,$3,$4
	lbu	$2,3($16)
	lh	$4,10($17)
	sll	$2,$2,24
	or	$3,$3,$2
	li	$2,0x00000001		# 1
	sll	$2,$2,$4
	and	$3,$3,$2
	beq	$3,$0,.L508
	.set	noreorder
	.set	nomacro
	j	.L510
	addu	$16,$16,4
	.set	macro
	.set	reorder

.L508:
	.set	noreorder
	.set	nomacro
	j	.L510
	addu	$16,$16,6
	.set	macro
	.set	reorder

.L507:
	beq	$2,$0,.L514
	lbu	$2,0($16)
	lh	$3,64($17)
	andi	$2,$2,0x00ff
	.set	noreorder
	.set	nomacro
	bne	$2,$3,.L515
	addu	$16,$16,1
	.set	macro
	.set	reorder

	move	$4,$17
	.set	noreorder
	.set	nomacro
	jal	func_80032C50
	addu	$5,$5,-1
	.set	macro
	.set	reorder

	j	.L510
.L515:
	slt	$2,$3,$2
	bne	$2,$0,.L503
	j	.L510
.L514:
	addu	$16,$16,1
.L510:
	lbu	$5,0($16)
	#nop
	.set	noreorder
	.set	nomacro
	bne	$5,$0,.L506
	addu	$16,$16,1
	.set	macro
	.set	reorder

.L503:
	lw	$31,24($sp)
	lw	$17,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,32
	j	$31
	.end	cpu_check_same_dir_timer
.Lfe41:
	.size	 cpu_check_same_dir_timer,.Lfe41-cpu_check_same_dir_timer
	.align	2
	.globl	func_80033498
	.type	 func_80033498,@function
	.ent	func_80033498
func_80033498:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lhu	$2,D_800A36A4
	#nop
	addu	$2,$2,-2
	sll	$2,$2,16
	sra	$3,$2,16
	sltu	$2,$3,23
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L527
	sll	$2,$3,2
	.set	macro
	.set	reorder

	lw	$2,.L528($2)
	#nop
	j	$2
.section	.rodata
	.align	3
	.align	2
.L528:
	.word	.L521
	.word	.L527
	.word	.L522
	.word	.L527
	.word	.L527
	.word	.L523
	.word	.L524
	.word	.L527
	.word	.L527
	.word	.L527
	.word	.L527
	.word	.L527
	.word	.L527
	.word	.L527
	.word	.L527
	.word	.L527
	.word	.L525
	.word	.L527
	.word	.L527
	.word	.L527
	.word	.L527
	.word	.L527
	.word	.L526
	.text
.L521:
	.set	noreorder
	.set	nomacro
	j	.L529
	move	$2,$0
	.set	macro
	.set	reorder

.L522:
	.set	noreorder
	.set	nomacro
	j	.L529
	li	$2,0x00000001		# 1
	.set	macro
	.set	reorder

.L523:
	.set	noreorder
	.set	nomacro
	j	.L529
	li	$2,0x00000002		# 2
	.set	macro
	.set	reorder

.L524:
	.set	noreorder
	.set	nomacro
	j	.L529
	li	$2,0x00000003		# 3
	.set	macro
	.set	reorder

.L525:
	.set	noreorder
	.set	nomacro
	j	.L529
	li	$2,0x00000004		# 4
	.set	macro
	.set	reorder

.L526:
	.set	noreorder
	.set	nomacro
	j	.L529
	li	$2,0x00000005		# 5
	.set	macro
	.set	reorder

.L527:
	li	$2,0x000000ff		# 255
.L529:
	j	$31
	.end	func_80033498
.Lfe42:
	.size	 func_80033498,.Lfe42-func_80033498
	.align	2
	.globl	func_80033510
	.type	 func_80033510,@function
	.ent	func_80033510
func_80033510:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	li	$2,0x00000003		# 3
	la	$3,D_800A3756
.L531:
	sh	$0,0($3)
	addu	$2,$2,-1
	.set	noreorder
	.set	nomacro
	bgez	$2,.L531
	addu	$3,$3,-2
	.set	macro
	.set	reorder

	li	$2,0x00000005		# 5
	la	$3,D_800A391D
.L535:
	sb	$0,0($3)
	addu	$2,$2,-1
	.set	noreorder
	.set	nomacro
	bgez	$2,.L535
	addu	$3,$3,-1
	.set	macro
	.set	reorder

	j	$31
	.end	func_80033510
.Lfe43:
	.size	 func_80033510,.Lfe43-func_80033510
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80033550.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_800335D8.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_80033898
	.type	 func_80033898,@function
	.ent	func_80033898
func_80033898:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	jal	gpu_EnableDisplay
	li	$2,0x00000003		# 3
	sw	$0,D_800A37B8
	sh	$2,D_800A3834
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80033898
.Lfe44:
	.size	 func_80033898,.Lfe44-func_80033898
	.align	2
	.globl	func_800338CC
	.type	 func_800338CC,@function
	.ent	func_800338CC
func_800338CC:
	.frame	$sp,40,$31		# vars= 8, regs= 4/0, args= 16, extra= 0
	.mask	0x80070000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,40
	li	$4,0x003e0000		# 4063232
	ori	$4,$4,0xf3df
	sw	$18,32($sp)
	move	$18,$0
	sw	$17,28($sp)
	move	$17,$0
	li	$6,0x00000001		# 1
	lb	$2,D_8010277C
	la	$5,D_801077B0
	sw	$31,36($sp)
	sw	$16,24($sp)
	lbu	$3,D_8008D538($2)
	li	$2,0x00000001		# 1
	sll	$2,$2,$3
	nor	$2,$0,$2
	lw	$3,D_80106A50
	and	$2,$2,$4
	and	$3,$3,$2
	sll	$2,$6,$17
.L571:
	and	$2,$3,$2
	beq	$2,$0,.L544
	sb	$17,0($5)
	addu	$5,$5,1
	addu	$18,$18,1
.L544:
	addu	$17,$17,1
	slt	$2,$17,27
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L571
	sll	$2,$6,$17
	.set	macro
	.set	reorder

	move	$17,$0
.L546:
	.set	noreorder
	.set	nomacro
	jal	rand
	addu	$17,$17,1
	.set	macro
	.set	reorder

	rem	$16,$2,$18
	jal	rand
	rem	$3,$2,$18
	lbu	$4,D_801077B0($16)
	lbu	$2,D_801077B0($3)
	#nop
	sb	$2,D_801077B0($16)
	slt	$2,$17,108
	sb	$4,D_801077B0($3)
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L546
	li	$2,0x00010000		# 65536
	.set	macro
	.set	reorder

	lw	$4,D_80106A50
	ori	$2,$2,0x0020
	and	$2,$4,$2
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L550
	andi	$3,$4,0x0020
	.set	macro
	.set	reorder

	li	$2,0x00010000		# 65536
	and	$2,$4,$2
	sw	$3,16($sp)
	.set	noreorder
	.set	nomacro
	bne	$3,$0,.L551
	sw	$2,20($sp)
	.set	macro
	.set	reorder

	sw	$2,16($sp)
	.set	noreorder
	.set	nomacro
	j	.L552
	sw	$0,20($sp)
	.set	macro
	.set	reorder

.L551:
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L572
	slt	$2,$18,11
	.set	macro
	.set	reorder

	jal	rand
	andi	$2,$2,0x0001
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L572
	slt	$2,$18,11
	.set	macro
	.set	reorder

	lw	$2,20($sp)
	lw	$3,16($sp)
	sw	$2,16($sp)
	sw	$3,20($sp)
.L552:
	slt	$2,$18,11
.L572:
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L555
	move	$17,$18
	.set	macro
	.set	reorder

.L556:
	lbu	$2,D_801077AF($17)
	#nop
	sb	$2,D_801077B0($17)
	addu	$17,$17,-1
	slt	$2,$17,11
	beq	$2,$0,.L556
	lw	$2,16($sp)
	#nop
	andi	$2,$2,0x0020
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L560
	li	$3,0x00000010		# 16
	.set	macro
	.set	reorder

	li	$3,0x00000005		# 5
.L560:
	sb	$3,D_801077BA
	j	.L561
.L555:
	lw	$2,16($sp)
	#nop
	andi	$2,$2,0x0020
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L562
	li	$3,0x00000010		# 16
	.set	macro
	.set	reorder

	li	$3,0x00000005		# 5
.L562:
	sb	$3,D_801077B0($18)
.L561:
	lw	$4,20($sp)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$4,$0,.L550
	addu	$18,$18,1
	.set	macro
	.set	reorder

	la	$2,D_801077B0
	addu	$5,$18,$2
	addu	$18,$18,1
	andi	$2,$4,0x0020
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L564
	li	$3,0x00000010		# 16
	.set	macro
	.set	reorder

	li	$3,0x00000005		# 5
.L564:
	sb	$3,0($5)
.L550:
	lb	$2,D_8010277C
	#nop
	lbu	$2,D_8008D538($2)
	#nop
	lbu	$2,D_8008D9EC($2)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L565
	li	$3,0x04000000		# 67108864
	.set	macro
	.set	reorder

	lw	$2,D_80106A50
	#nop
	and	$2,$2,$3
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L570
	li	$2,0x0000001a		# 26
	.set	macro
	.set	reorder

	j	.L567
.L565:
	lw	$2,D_80106A50
	li	$3,0x01000000		# 16777216
	and	$2,$2,$3
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L570
	li	$2,0x00000018		# 24
	.set	macro
	.set	reorder

.L567:
	sb	$2,D_801077B0($18)
	addu	$18,$18,1
.L570:
	sb	$18,D_800A391F
	sb	$0,D_800A3783
	sb	$0,D_800A37BC
	lw	$31,36($sp)
	lw	$18,32($sp)
	lw	$17,28($sp)
	lw	$16,24($sp)
	addu	$sp,$sp,40
	j	$31
	.end	func_800338CC
.Lfe45:
	.size	 func_800338CC,.Lfe45-func_800338CC
	.align	2
	.globl	func_80033BC0
	.type	 func_80033BC0,@function
	.ent	func_80033BC0
func_80033BC0:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lbu	$4,D_800A3783
	lbu	$2,D_800A391F
	andi	$3,$4,0x00ff
	.set	noreorder
	.set	nomacro
	bne	$3,$2,.L574
	addu	$2,$4,1
	.set	macro
	.set	reorder

	li	$2,0x000000ff		# 255
	sb	$2,D_800A3768
	li	$2,0x00000014		# 20
	sb	$0,D_800A36A8
	.set	noreorder
	.set	nomacro
	bne	$3,$2,.L575
	li	$2,0x00000020		# 32
	.set	macro
	.set	reorder

	lh	$2,D_80101ED2
	#nop
	lbu	$2,D_8008D9EC($2)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L576
	li	$3,0x00000002		# 2
	.set	macro
	.set	reorder

	li	$3,0x00000003		# 3
.L576:
	li	$2,0x00000012		# 18
	sb	$3,D_800A38A4
	sh	$2,D_800A3834
	j	.L578
.L575:
	sh	$2,D_800A3834
	j	.L578
.L574:
	sb	$0,D_800A376B
	sb	$2,D_800A3783
	lbu	$5,D_801077B0($3)
	#nop
	andi	$4,$5,0x00ff
	lbu	$2,D_8008D55C($4)
	#nop
	sb	$2,D_8010277D
	li	$2,0x00000005		# 5
	.set	noreorder
	.set	nomacro
	bne	$4,$2,.L579
	li	$2,0x00000010		# 16
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L585
	li	$2,0x00000006		# 6
	.set	macro
	.set	reorder

.L579:
	.set	noreorder
	.set	nomacro
	beq	$4,$2,.L585
	li	$2,0x00000007		# 7
	.set	macro
	.set	reorder

	lbu	$2,D_800A37BC
	#nop
	addu	$3,$2,1
	andi	$2,$2,0x00ff
	sb	$3,D_800A37BC
	lbu	$2,D_8008E748($2)
	li	$3,0x00000004		# 4
	sb	$2,D_8010277F
	sll	$2,$2,24
	sra	$2,$2,24
	.set	noreorder
	.set	nomacro
	bne	$2,$3,.L586
	li	$2,0x00000800		# 2048
	.set	macro
	.set	reorder

	lbu	$2,D_8008D9EC($4)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L580
	li	$2,0x00000005		# 5
	.set	macro
	.set	reorder

.L585:
	sb	$2,D_8010277F
.L580:
	li	$2,0x00000800		# 2048
.L586:
	sh	$2,D_8010277A
	andi	$2,$5,0x00ff
	lbu	$2,D_8008E75C($2)
	sh	$0,D_800A3834
	sh	$2,D_800A36A4
.L578:
	j	$31
	.end	func_80033BC0
.Lfe46:
	.size	 func_80033BC0,.Lfe46-func_80033BC0
	.align	2
	.globl	func_80033D38
	.type	 func_80033D38,@function
	.ent	func_80033D38
func_80033D38:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	la	$9,D_80106A50
	li	$7,0x00000003		# 3
	lw	$4,D_800A3858
	addu	$3,$7,-1
.L600:
	sll	$2,$3,3
	addu	$2,$9,$2
	lw	$2,12($2)
	#nop
	slt	$2,$2,$4
	bne	$2,$0,.L589
	move	$7,$3
	.set	noreorder
	.set	nomacro
	bgtz	$7,.L600
	addu	$3,$7,-1
	.set	macro
	.set	reorder

.L589:
	sb	$7,D_800A38E9
	slt	$2,$7,3
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L594
	slt	$2,$7,2
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L596
	li	$8,0x00000002		# 2
	.set	macro
	.set	reorder

	addu	$6,$9,16
.L598:
	lw	$2,0($6)
	lw	$3,4($6)
	sw	$2,8($6)
	sw	$3,12($6)
	addu	$8,$8,-1
	slt	$2,$7,$8
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L598
	addu	$6,$6,-8
	.set	macro
	.set	reorder

.L596:
	sll	$3,$7,3
	lhu	$2,D_80101ED2
	addu	$3,$9,$3
	sb	$2,8($3)
	lhu	$2,D_80101ED6
	#nop
	sb	$2,9($3)
	lw	$2,D_800A3858
	#nop
	sw	$2,12($3)
.L594:
	j	$31
	.end	func_80033D38
.Lfe47:
	.size	 func_80033D38,.Lfe47-func_80033D38
	.align	2
	.globl	func_80033DF4
	.type	 func_80033DF4,@function
	.ent	func_80033DF4
func_80033DF4:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	lbu	$3,D_800A38E2
	li	$2,0x00000064		# 100
	andi	$5,$3,0x00ff
	.set	noreorder
	.set	nomacro
	bne	$5,$2,.L602
	sw	$31,16($sp)
	.set	macro
	.set	reorder

	lw	$2,D_800A3858
	sb	$0,D_800A36F0
	sb	$0,D_800A3781
	slt	$2,$2,27001
	beq	$2,$0,.L603
	lb	$2,D_8010277C
	#nop
	lbu	$2,D_8008D538($2)
	#nop
	lbu	$2,D_8008D9EC($2)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L604
	li	$5,0x00000020		# 32
	.set	macro
	.set	reorder

	li	$5,0x00010000		# 65536
.L604:
	la	$4,D_80106A50
	lw	$3,0($4)
	#nop
	and	$2,$3,$5
	sltu	$2,$2,1
	or	$3,$3,$5
	sb	$2,D_800A36F0
	sw	$3,0($4)
.L603:
	lw	$2,D_800A380C
	#nop
	bne	$2,$0,.L605
	lb	$2,D_8010277C
	#nop
	lbu	$2,D_8008D538($2)
	#nop
	lbu	$2,D_8008D9EC($2)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L606
	li	$5,0x01000000		# 16777216
	.set	macro
	.set	reorder

	li	$5,0x04000000		# 67108864
.L606:
	la	$4,D_80106A50
	lw	$3,0($4)
	#nop
	and	$2,$3,$5
	sltu	$2,$2,1
	or	$3,$3,$5
	sb	$2,D_800A3781
	sw	$3,0($4)
.L605:
	jal	func_80033D38
	li	$2,0x00000004		# 4
	sh	$2,D_800A3834
	.set	noreorder
	.set	nomacro
	j	.L608
	move	$2,$0
	.set	macro
	.set	reorder

.L602:
	addu	$2,$3,1
	sll	$5,$5,2
	sb	$2,D_800A38E2
	la	$2,cpu_practice_honmokuroku_data_tbl
	addu	$5,$5,$2
	sb	$0,D_800A376B
	lbu	$6,0($5)
	lb	$2,D_8010277C
	sb	$6,D_800A384C
	lbu	$2,D_8008D538($2)
	la	$3,D_8008EC24
	lbu	$2,D_8008D9EC($2)
	andi	$6,$6,0x00ff
	sltu	$2,$2,1
	sll	$4,$2,2
	addu	$4,$4,$2
	addu	$3,$4,$3
	addu	$3,$3,$6
	lbu	$2,0($3)
	#nop
	sb	$2,D_800A38DE
	lbu	$2,1($5)
	#nop
	sb	$2,D_800A38EC
	lbu	$2,2($5)
	#nop
	sb	$2,D_800A38ED
	lbu	$2,3($5)
	#nop
	sb	$2,D_800A38EE
	la	$2,D_8008E908
	addu	$4,$4,$2
	addu	$4,$4,$6
	lbu	$3,0($4)
	li	$2,0x00000001		# 1
	sb	$3,D_8010277D
.L608:
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_80033DF4
.Lfe48:
	.size	 func_80033DF4,.Lfe48-func_80033DF4
	.align	2
	.globl	func_80033FE4
	.type	 func_80033FE4,@function
	.ent	func_80033FE4
func_80033FE4:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lbu	$2,D_800A36F0
	#nop
	beq	$2,$0,.L610
	lh	$2,D_80101ED2
	#nop
	lbu	$2,D_8008D9EC($2)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L611
	li	$3,0x00000006		# 6
	.set	macro
	.set	reorder

	li	$3,0x00000007		# 7
.L611:
	sb	$3,D_800A38A4
	.set	noreorder
	.set	nomacro
	j	.L616
	li	$2,0x00000012		# 18
	.set	macro
	.set	reorder

.L610:
	lbu	$2,D_800A3781
	#nop
	beq	$2,$0,.L612
	lh	$2,D_80101ED2
	#nop
	lbu	$2,D_8008D9EC($2)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L613
	li	$3,0x00000008		# 8
	.set	macro
	.set	reorder

	li	$3,0x00000009		# 9
.L613:
	sb	$3,D_800A38A4
	.set	noreorder
	.set	nomacro
	j	.L616
	li	$2,0x00000012		# 18
	.set	macro
	.set	reorder

.L612:
	lbu	$2,D_800A38E9
	#nop
	sltu	$2,$2,3
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L616
	li	$2,0x0000001a		# 26
	.set	macro
	.set	reorder

	li	$2,0x00000008		# 8
.L616:
	sh	$2,D_800A3834
	j	$31
	.end	func_80033FE4
.Lfe49:
	.size	 func_80033FE4,.Lfe49-func_80033FE4
	.align	2
	.globl	func_800340A0
	.type	 func_800340A0,@function
	.ent	func_800340A0
func_800340A0:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lbu	$6,D_800A3898
	lbu	$2,D_800A37F8
	andi	$4,$6,0x00ff
	beq	$4,$2,.L630
	lbu	$5,D_800A3899
	#nop
	andi	$3,$5,0x00ff
	.set	noreorder
	.set	nomacro
	bne	$3,$2,.L620
	sltu	$2,$3,$4
	.set	macro
	.set	reorder

	lbu	$3,D_800A3874
	.set	noreorder
	.set	nomacro
	j	.L631
	li	$2,0x00000001		# 1
	.set	macro
	.set	reorder

.L620:
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L622
	sltu	$2,$4,$3
	.set	macro
	.set	reorder

.L630:
	lbu	$2,D_800A3874
	#nop
	sb	$0,D_800A377C($2)
	j	.L619
.L622:
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L624
	li	$2,0x00000001		# 1
	.set	macro
	.set	reorder

	lbu	$3,D_800A3874
	j	.L631
.L624:
	lbu	$4,D_800A38AA
	lbu	$3,D_800A38AB
	#nop
	sltu	$2,$4,$3
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L626
	addu	$2,$6,1
	.set	macro
	.set	reorder

	lbu	$3,D_800A3874
	sb	$2,D_800A3898
	sb	$0,D_800A377C($3)
	j	.L619
.L626:
	sltu	$2,$3,$4
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L628
	addu	$2,$5,1
	.set	macro
	.set	reorder

	lbu	$3,D_800A3874
	sb	$2,D_800A3899
	.set	noreorder
	.set	nomacro
	j	.L631
	li	$2,0x00000001		# 1
	.set	macro
	.set	reorder

.L628:
	lbu	$3,D_800A3874
	li	$2,0x00000002		# 2
.L631:
	sb	$2,D_800A377C($3)
.L619:
	lbu	$2,D_800A3874
	lbu	$3,D_800A3898
	sll	$2,$2,1
	sb	$3,D_800F65F8($2)
	lbu	$2,D_800A3874
	lbu	$3,D_800A3899
	sll	$2,$2,1
	sb	$3,D_800F65F9($2)
	lbu	$2,D_800A3874
	#nop
	addu	$2,$2,1
	sb	$2,D_800A3874
	j	$31
	.end	func_800340A0
.Lfe50:
	.size	 func_800340A0,.Lfe50-func_800340A0
	.align	2
	.globl	func_80034200
	.type	 func_80034200,@function
	.ent	func_80034200
func_80034200:
	.frame	$sp,8,$31		# vars= 8, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	subu	$sp,$sp,8
	move	$6,$0
	move	$7,$0
	lbu	$3,D_800A389B
	li	$2,0x0000000a		# 10
	sb	$2,g_disp_enable
	.set	noreorder
	.set	nomacro
	blez	$3,.L633
	move	$4,$0
	.set	macro
	.set	reorder

	lbu	$11,D_800A3874
	li	$10,0x00000003		# 3
	la	$5,D_800F65F8
.L634:
	slt	$9,$7,$11
	move	$3,$5
	addu	$8,$5,2
.L637:
	beq	$9,$0,.L640
	lbu	$2,0($3)
	.set	noreorder
	.set	nomacro
	j	.L644
	sll	$2,$2,$6
	.set	macro
	.set	reorder

.L640:
	sll	$2,$10,$6
.L644:
	or	$4,$4,$2
	addu	$3,$3,1
	slt	$2,$3,$8
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L637
	addu	$6,$6,2
	.set	macro
	.set	reorder

	lbu	$2,D_800A389B
	addu	$7,$7,1
	slt	$2,$7,$2
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L634
	addu	$5,$5,2
	.set	macro
	.set	reorder

.L633:
	sw	$4,D_800A3784
	addu	$sp,$sp,8
	j	$31
	.end	func_80034200
.Lfe51:
	.size	 func_80034200,.Lfe51-func_80034200
	.align	2
	.globl	func_800342A0
	.type	 func_800342A0,@function
	.ent	func_800342A0
func_800342A0:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	jal	func_80034200
	lbu	$3,D_800A3874
	lbu	$2,D_800A389B
	#nop
	.set	noreorder
	.set	nomacro
	bne	$3,$2,.L646
	move	$3,$0
	.set	macro
	.set	reorder

	li	$2,0x000000ff		# 255
	sb	$2,g_disp_enable
	li	$2,0x00000014		# 20
	sb	$0,g_disp_fade
	sh	$2,D_800A3834
	j	.L647
.L646:
	la	$5,D_801027A0
	la	$4,D_801027D8
	li	$2,0x00000050		# 80
	sw	$0,D_800A38F4
	sb	$0,D_800A3899
	sb	$0,D_800A3898
	sb	$0,D_800A38AB
	sb	$0,D_800A38AA
	sb	$0,D_800A3816
	sb	$2,D_800A391E
	sb	$0,D_800A381E
	sb	$0,D_800A37E1
	sb	$0,D_800A36E8
	sb	$0,D_800A38B8
	sb	$0,D_800A3920
.L648:
	lbu	$2,D_800A3874
	#nop
	sll	$2,$2,1
	addu	$2,$2,$5
	addu	$2,$2,$3
	lbu	$2,0($2)
	#nop
	sb	$2,D_8010277C($3)
	lbu	$2,D_800A3874
	#nop
	sll	$2,$2,1
	addu	$2,$2,$4
	addu	$2,$2,$3
	lbu	$2,0($2)
	#nop
	sb	$2,D_8010277E($3)
	addu	$3,$3,1
	slt	$2,$3,2
	bne	$2,$0,.L648
	jal	gpu_InitDisplay
	jal	func_800372C0
	sh	$0,D_800A3834
.L647:
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_800342A0
.Lfe52:
	.size	 func_800342A0,.Lfe52-func_800342A0
	.align	2
	.globl	func_800343F0
	.type	 func_800343F0,@function
	.ent	func_800343F0
func_800343F0:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	move	$4,$0
	lbu	$6,D_80102785
	lbu	$3,D_80102786
	lbu	$2,D_80102784
	lb	$7,D_80102787
	sw	$31,16($sp)
	sh	$0,D_800A36F6
	sll	$6,$6,24
	sra	$6,$6,24
	sll	$3,$3,24
	sra	$3,$3,24
	sll	$2,$2,24
	sra	$2,$2,24
	sh	$6,D_800A38DC
	sh	$3,D_800A38BA
	sw	$7,D_800A3140
	sh	$2,D_800A36A4
	.set	noreorder
	.set	nomacro
	jal	player_SetCharId
	move	$5,$0
	.set	macro
	.set	reorder

	li	$4,0x00000001		# 1
	.set	noreorder
	.set	nomacro
	jal	player_SetCharId
	move	$5,$0
	.set	macro
	.set	reorder

	li	$2,0x00000002		# 2
	sb	$0,D_800A376A
	sb	$0,D_800A376B
	sw	$0,D_800A380C
	sb	$2,D_800A38D4
	sb	$0,D_800A37D3
	sb	$0,D_800A37D2
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_800343F0
.Lfe53:
	.size	 func_800343F0,.Lfe53-func_800343F0
 #APP
	.section .rodata
    .include "asm/rodata/jtbl_8001084C.s"
.section .text
 #NO_APP
	.align	2
	.globl	func_800344B4
	.type	 func_800344B4,@function
	.ent	func_800344B4
func_800344B4:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, extra= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,20($sp)
	.set	noreorder
	.set	nomacro
	jal	func_800343F0
	sw	$16,16($sp)
	.set	macro
	.set	reorder

	lh	$3,D_800A38DC
	#nop
	sltu	$2,$3,7
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L652
	sll	$2,$3,2
	.set	macro
	.set	reorder

	lw	$2,.L668($2)
	#nop
	j	$2
.section	.rodata
	.align	3
	.align	2
.L668:
	.word	.L655
	.word	.L656
	.word	.L661
	.word	.L657
	.word	.L667
	.word	.L658
	.word	.L653
	.text
.L653:
	lw	$3,D_800A38A0
	li	$2,0x00000001		# 1
	sb	$2,D_80102786
	sb	$2,D_800A3768
	sh	$0,D_800A3834
	sltu	$3,$0,$3
	sh	$3,D_800A36F6
	j	.L654
.L655:
	lb	$2,D_8010277C
	#nop
	lbu	$4,D_8008D538($2)
	jal	func_8003B20C
	sb	$0,D_8010277D
	jal	func_8003B5A4
	.set	noreorder
	.set	nomacro
	jal	func_8005509C
	li	$4,0x00000001		# 1
	.set	macro
	.set	reorder

	j	.L654
.L656:
	li	$16,0x00000001		# 1
	sb	$16,D_80102781
	jal	func_800338CC
	sb	$16,D_800A3768
	jal	func_80033BC0
	j	.L654
.L657:
	li	$16,0x00000001		# 1
	li	$2,0x00000022		# 34
	sb	$16,D_80102781
	sb	$0,D_8010277F
	sb	$0,D_8010277E
	sb	$0,D_800A38E2
	sb	$0,D_800A38E0
	sw	$0,D_800A3858
	sb	$0,D_800A3728
	sh	$2,D_800A36A4
	jal	func_80033DF4
	sb	$16,D_800A3768
	j	.L652
.L658:
	lbu	$2,D_800A38E1
	#nop
	andi	$2,$2,0x0001
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L659
	li	$3,0x00000020		# 32
	.set	macro
	.set	reorder

	li	$3,0x00000021		# 33
.L659:
	sh	$3,D_800A36A4
	sb	$0,D_800A3874
	jal	gpu_EnableDisplay
	jal	file_LoadOverlay
	jal	func_800342A0
	j	.L654
.L661:
	lbu	$3,D_800A389A
	#nop
	sltu	$2,$3,1
	sll	$2,$2,1
	sb	$2,D_800A3713
	.set	noreorder
	.set	nomacro
	beq	$3,$0,.L662
	li	$4,0x00000023		# 35
	.set	macro
	.set	reorder

	li	$4,0x00000024		# 36
.L662:
	li	$2,0x00000001		# 1
	sh	$4,D_800A36A4
	sb	$2,D_80102781
	bne	$3,$0,.L652
	lb	$2,D_8010277C
	#nop
	lbu	$2,D_8008D538($2)
	#nop
	lbu	$2,D_8008D9EC($2)
	#nop
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L665
	li	$3,0x0000001d		# 29
	.set	macro
	.set	reorder

	li	$3,0x0000000e		# 14
.L665:
	sb	$3,D_8010277D
	j	.L652
.L667:
	li	$2,0x00000001		# 1
	sb	$2,D_800A3768
.L652:
	sh	$0,D_800A3834
.L654:
	lb	$2,D_80102781
	#nop
	beq	$2,$0,.L670
	.set	noreorder
	.set	nomacro
	jal	func_8005509C
	li	$4,0x00000001		# 1
	.set	macro
	.set	reorder

.L670:
	lw	$31,20($sp)
	lw	$16,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_800344B4
.Lfe54:
	.size	 func_800344B4,.Lfe54-func_800344B4
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80034708.s"
    .set reorder
    .set at

	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80034F88.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_8003504C
	.type	 func_8003504C,@function
	.ent	func_8003504C
func_8003504C:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, extra= 0
	.mask	0x80000000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,24
	sw	$31,16($sp)
	jal	func_80077D00
	move	$7,$0
	li	$10,0x00000005		# 5
	li	$9,0x00000014		# 20
	move	$11,$2
	move	$6,$11
	la	$8,D_80102785
	addu	$5,$8,-9
.L672:
	lbu	$2,0($6)
	#nop
	lbu	$3,D_8008D55C($2)
	#nop
	addu	$2,$3,-3
	sltu	$2,$2,2
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L676
	sb	$3,0($5)
	.set	macro
	.set	reorder

	sll	$2,$3,24
	sra	$4,$2,24
	.set	noreorder
	.set	nomacro
	beq	$4,$10,.L676
	addu	$2,$3,-18
	.set	macro
	.set	reorder

	sltu	$2,$2,2
	bne	$2,$0,.L676
	bne	$4,$9,.L675
.L676:
	lb	$2,0($8)
	#nop
	bne	$2,$0,.L675
	lbu	$2,0($5)
	#nop
	addu	$2,$2,-3
	sb	$2,0($5)
.L675:
	lbu	$2,1($6)
	addu	$6,$6,10
	sb	$0,D_80102780($7)
	sb	$2,D_8010277E($7)
	addu	$7,$7,1
	slt	$2,$7,2
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L672
	addu	$5,$5,1
	.set	macro
	.set	reorder

	lw	$2,20($11)
	lb	$3,D_80102785
	srl	$2,$2,4
	andi	$2,$2,0x003f
	sb	$2,D_80102784
	lw	$2,32($11)
	sh	$0,D_800A36F6
	srl	$2,$2,3
	andi	$2,$2,0x0001
	sb	$2,D_80102786
	li	$2,0x00000002		# 2
	.set	noreorder
	.set	nomacro
	bne	$3,$2,.L679
	li	$2,0x00000005		# 5
	.set	macro
	.set	reorder

	lw	$2,20($11)
	lw	$3,20($11)
	srl	$2,$2,17
	andi	$2,$2,0x0001
	srl	$3,$3,18
	andi	$3,$3,0x0007
	sb	$2,D_800A389A
	sb	$3,D_800A3788
	j	.L680
.L679:
	bne	$3,$2,.L680
	lw	$2,20($11)
	lw	$3,20($11)
	srl	$2,$2,10
	andi	$2,$2,0x0003
	addu	$2,$2,3
	srl	$3,$3,12
	andi	$3,$3,0x0003
	sb	$2,D_800A389B
	lw	$2,20($11)
	lbu	$3,D_8008EC30($3)
	andi	$2,$2,0x4000
	sb	$3,D_800A36CC
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L682
	li	$4,0x00000001		# 1
	.set	macro
	.set	reorder

	li	$4,0x00000002		# 2
.L682:
	move	$8,$0
	la	$10,D_801027D8
	lw	$2,20($11)
	la	$9,D_801027A0
	sb	$4,D_800A37F8
	srl	$2,$2,15
	andi	$2,$2,0x0003
	sb	$2,D_800A38E1
.L683:
	move	$7,$0
	move	$6,$10
	move	$5,$9
	sll	$4,$8,1
.L686:
	addu	$3,$11,$4
	lbu	$2,0($3)
	addu	$4,$4,10
	lbu	$2,D_8008D55C($2)
	addu	$7,$7,1
	sb	$2,0($5)
	lbu	$2,1($3)
	addu	$5,$5,1
	sb	$2,0($6)
	slt	$2,$7,2
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L686
	addu	$6,$6,1
	.set	macro
	.set	reorder

	addu	$10,$10,2
	addu	$8,$8,1
	slt	$2,$8,5
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L683
	addu	$9,$9,2
	.set	macro
	.set	reorder

.L680:
	jal	func_800344B4
	lw	$31,16($sp)
	addu	$sp,$sp,24
	j	$31
	.end	func_8003504C
.Lfe55:
	.size	 func_8003504C,.Lfe55-func_8003504C
 #APP
	.section .text
    .set noat
    .set noreorder
    .include "asm/funcs/func_80035280.s"
    .set reorder
    .set at

 #NO_APP
	.align	2
	.globl	func_80035430
	.type	 func_80035430,@function
	.ent	func_80035430
func_80035430:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	j	$31
	.end	func_80035430
.Lfe56:
	.size	 func_80035430,.Lfe56-func_80035430
	.ident	"GCC: (GNU) 2.7.2"
