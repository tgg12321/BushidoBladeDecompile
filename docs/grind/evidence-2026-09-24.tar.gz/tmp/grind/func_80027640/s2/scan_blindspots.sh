#!/bin/bash
# Project-wide census of maspsx's .L-label load-delay blind spot.
set -e
cd "$(dirname "$0")/../../../.."
S=tmp/grind/func_80027640/s2
mkdir -p $S/stock
CPP_FLAGS="-Iinclude -undef -Wall -lang-c -fno-builtin"
CPP_DEFS="-Dmips -D__GNUC__=2 -D__OPTIMIZE__ -D__mips__ -D__mips -Dpsx -D__psx__ -D__psx -D_PSYQ -D__EXTENSIONS__ -D_MIPSEL -D_LANGUAGE_C -DLANGUAGE_C"
CC_BASE="-O2 -funsigned-char -quiet -mcpu=3000 -mips1 -mno-abicalls -fno-builtin -w -mel"
M_BASE="--expand-div --aspsx-version=2.34 --sdata-syms=sdata_syms.txt --sdata-funcs=sdata_funcs.txt --sdata-exclude=sdata_exclude.txt --expand-lb --expand-lb-funcs=expand_lb_funcs.txt --multu-funcs=multu_funcs.txt --expand-dest-funcs=expand_dest_funcs.txt --label-nop-funcs=maspsx_label_nop_funcs.txt"
for f in src/*.c; do
  b=$(basename $f .c)
  case "$b" in
    text1a_pre|text1a_post) CC="-G8 $CC_BASE"; M="$M_BASE";;
    *) CC="-G0 $CC_BASE"; M="$M_BASE";;
  esac
  case "$b" in code6cac_b) M="$M --expand-lb";; esac
  mipsel-linux-gnu-cpp $CPP_FLAGS $CPP_DEFS $f 2>/dev/null \
    | tools/gcc-2.7.2/build/cc1 $CC 2>/dev/null \
    | python3 tools/prologue_fix.py \
    | python3 tools/maspsx/maspsx.py $M > $S/stock/$b.s 2>/dev/null || { echo "SKIP $b"; continue; }
done
echo "== blind-spot sites (maspsx saw a .L label as the next instruction after a load):"
grep -Hn "DEBUG: '\.L" $S/stock/*.s | wc -l
grep -Hn "DEBUG: '\.L" $S/stock/*.s | sed 's/:.*DEBUG/ DEBUG/' | head -60
