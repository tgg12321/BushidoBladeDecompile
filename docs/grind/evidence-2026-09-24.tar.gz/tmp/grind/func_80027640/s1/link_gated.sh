#!/bin/bash
# Full-link SHA1 proof in tmp/: copy the oracle-matching build/ tree, swap in the
# gated code6cac_b.o (built by build_gated.sh with the scratch label-nop list),
# relink with a path-rewritten copy of bb2.ld, objcopy + make_psexe, sha1sum.
# Touches NOTHING outside tmp/.
set -e
cd "$(dirname "$0")/../../../.."
S=tmp/grind/func_80027640/s1
G=$S/buildg
rm -rf $G
cp -r build $G
cp $S/gated.o $G/src/code6cac_b.o
sed "s#build/#$G/#g" bb2.ld > $S/bb2_gated.ld
grep -c "$G/" $S/bb2_gated.ld
mipsel-linux-gnu-ld -nostdlib --no-check-sections -Map $G/bb2.map -T $S/bb2_gated.ld \
  -T undefined_funcs_auto.txt -T undefined_syms_auto.txt -T named_syms.txt -o $G/bb2.elf
mipsel-linux-gnu-objcopy -O binary -j .main $G/bb2.elf $G/bb2.bin
python3 tools/make_psexe.py disc/SLUS_006.63 $G/bb2.bin $G/bb2.exe
echo "oracle:  62efab4f73f992798c43e8c730aa43baa10bb4fa"
sha1sum $G/bb2.exe
