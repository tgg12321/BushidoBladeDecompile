#!/bin/bash
# Byte proof for func_80027640 WITHOUT touching maspsx_label_nop_funcs.txt:
# reproduce the Makefile pipeline for code6cac_b with a SCRATCH copy of the
# label-nop gate list that adds func_80027640, assemble to tmp/, and diff the
# function's instruction stream against asm/funcs/func_80027640.s.
set -e
cd "$(dirname "$0")/../../../.."
S=tmp/grind/func_80027640/s2
cp maspsx_label_nop_funcs.txt $S/label_nop_scratch.txt
echo func_80027640 >> $S/label_nop_scratch.txt
CC_FLAGS="-O2 -G0 -funsigned-char -quiet -mcpu=3000 -mips1 -mno-abicalls -fno-builtin -w -mel"
CPP_FLAGS="-Iinclude -undef -Wall -lang-c -fno-builtin"
CPP_DEFS="-Dmips -D__GNUC__=2 -D__OPTIMIZE__ -D__mips__ -D__mips -Dpsx -D__psx__ -D__psx -D_PSYQ -D__EXTENSIONS__ -D_MIPSEL -D_LANGUAGE_C -DLANGUAGE_C"
MASPSX_FLAGS="--expand-div --aspsx-version=2.34 --sdata-syms=sdata_syms.txt --sdata-funcs=sdata_funcs.txt --sdata-exclude=sdata_exclude.txt --expand-lb --expand-lb-funcs=expand_lb_funcs.txt --multu-funcs=multu_funcs.txt --expand-dest-funcs=expand_dest_funcs.txt --label-nop-funcs=maspsx_label_nop_funcs.txt --expand-lb"
AS_FLAGS="-Iinclude -march=r3000 -mtune=r3000 -no-pad-sections -O1 -G0"
mipsel-linux-gnu-cpp $CPP_FLAGS $CPP_DEFS src/code6cac_b.c \
  | tools/gcc-2.7.2/build/cc1 $CC_FLAGS \
  | python3 tools/prologue_fix.py \
  | python3 tools/maspsx/maspsx.py $MASPSX_FLAGS \
  | sed "s/\.align\t3/.align\t2/" \
  | python3 tools/multu_pad.py --funcs multu_pad_funcs.txt \
  > $S/ungated.s
mipsel-linux-gnu-as $AS_FLAGS -o $S/ungated.o $S/ungated.s
echo "== gated object built: $S/ungated.o"
python3 $S/tdiff.py $S/ungated.o > $S/ungated_diff.txt 2>&1 || true
echo "== diff lines (excluding objdump alias spellings):"
grep -n '^[-+]' $S/ungated_diff.txt | grep -v 'move\|^[0-9]*:[-+]li \|addu\|addiu\|^[0-9]*:[-+]ori a1' || echo "(none)"
echo "== nop context:"
grep -n -B2 -A2 '^[-+]nop' $S/ungated_diff.txt || echo "(no nop diffs)"
echo "== insn count in gated object:"
mipsel-linux-gnu-objdump -d $S/ungated.o | awk '/<func_80027640>:/{f=1;next} /^[0-9a-f]+ </{f=0} f&&/^ /{n++} END{print n}'
