import sys,re
src=open('src/code6cac_b.c',newline='').read()
body=open(sys.argv[1]).read()
m=re.search(r'INCLUDE_ASM\("asm/funcs", func_80027640\);\n', src)
if m:
    src=src[:m.start()]+body+src[m.end():]
else:
    # replace existing body: from 'void func_80027640' to the kengo comment
    s=src.index('void func_80027640(')
    e=src.index('/* kengo:HIGH  |  nm_cpu/cpu_side_move_dir')
    src=src[:s]+body+src[e:]
open('src/code6cac_b.c','w',newline='\n').write(src)
