#!/usr/bin/env python3
"""Sweep 30 for func_800645B0 (grind session 9, STRUCTURAL modality).

Target of the sweep: session-8 frontier item 1 -- the "sum side" of H39.

The SB chassis (control WA, 1 / 78) has EVERY property right except one
instruction: index 20, target `addu $s0,$s1,$s0` vs build `addu $s0,$s0,$s1`.
H24 established why: the sum is written back into `idx` (which is what gives
`idx` its second set and therefore denies sched.c's birthing_insn_p lift at the
loop top), so expand_binop is called with `target == op1` and optabs.c:411-421
clause 2 swaps the operands unconditionally.

This sweep attacks the swap CONDITION rather than the destination: keep the sum
landing in `idx`, but make the PLUS's second operand a different pseudo that
merely holds the same value, so neither optabs clause fires (clause 1 needs
`op0` to be a non-REG; `idx2` is a REG, so it cannot fire either).  If the extra
copy insn is then folded away for free by cse1/combine/regmove, the emitted
insn is `(set idx (plus idx2 <copy>))` -- the target's operand order -- while
reg_n_sets[idx] stays 2.  That closes the SB residual at zero cost.

If instead the copy survives as a real `move`, the family costs one instruction
(79 against a 78-insn target) and the whole "sum side" of H39 is dead.

  WA -- SB control.
  WB -- fresh local `k`, copied immediately before the sum.
  WC -- the copy staged through `val` (the const-1 carrier, dead at this point;
        sanctioned variable reuse rather than a new declaration).
  WD -- fresh local `k`, copied BEFORE the `idx2` shift (different LUID order).
  WE -- fresh local `k`, copied before the `rand()` call (crosses the call, so
        the copy cannot be sunk and both values are live across the jal).
  WF -- `k` declared in an inner block scope at the point of use.
  WG -- the copy spelled as the halfword index's own source
        (`k = idx; idx2 = k << 1; idx = idx2 + k;`) so `k` has two real reads
        and `idx`'s remaining read count drops.
  WH -- `last` (already live-dead across the sum) used as the copy carrier.
"""
import json
import subprocess
import sys

SRC = "src/text1b.c"
START = "s32 func_800645B0(void) {"
END = 'INCLUDE_ASM("asm/funcs", func_800646E8);'

I = " " * 16
NL = chr(10)
STORES = (
    I + '*((s32 *)(((s32)(&D_800F0D78)) + (idx << 2))) = '
        '(((s32 *)D_800A347C)[0] + (last & 0xFF)) - 0x7F;\n'
    + I + '*((s32 *)(((s32)(&D_800F0D7C)) + (idx << 2))) = '
        '(((s32 *)D_800A347C)[1] + (rand() & 0xFF)) - 0x7F;\n'
    + I + '*((s32 *)(((s32)(&videoDec)) + (idx << 2))) = '
        '(((s32 *)D_800A347C)[2] + (rand() & 0xFF)) - 0x7F;\n')
TAIL = (I + 'last = rand();\n'
        + I + 'val = D_800A3444;\n'
        + I + '*((s16 *)(((s32)(&D_800F0BCC)) + idx2)) = last & 7;\n'
        + I + 'val = val | mask;\n'
        + I + 'D_800A3444 = val;\n'
        + I + 'break;\n')

DECLS = ("    s32 i;\n    s32 j;\n    s32 idx;\n    s32 idx2;\n"
         "    s32 mask;\n    s32 val;\n    s32 last;\n")
DECLS_K = DECLS + "    s32 k;\n"


def shell(decls, head):
    return (START + "\n" + decls
            + "    D_800F10EC = 1;\n"
            + "    for (i = 0; i < 0xF; i += 4) {\n"
            + "        for (j = 0; j < 4; j++) {\n"
            + "            idx = i + j;\n"
            + "            val = 1;\n"
            + "            mask = val << idx;\n"
            + "            if (!(D_800A3444 & mask)) {\n"
            + head + STORES + TAIL
            + "            }\n        }\n    }\n"
            + "    return 1;\n}\n")


HEADS = {
    "XA": (DECLS,
           I + "idx2 = idx << 1;" + NL + I + "last = rand();" + NL
           + I + "idx = idx2 + (idx2 >> 1);" + NL),
    "XB": (DECLS,
           I + "idx2 = idx << 1;" + NL + I + "last = rand();" + NL
           + I + "idx = idx2 + (idx2 / 2);" + NL),
    "XC": (DECLS,
           I + "idx2 = idx << 1;" + NL + I + "last = rand();" + NL
           + I + "idx = idx2 + (s32)(((u32)idx2) >> 1);" + NL),
    "XD": (DECLS,
           I + "idx2 = idx << 1;" + NL + I + "last = rand();" + NL
           + I + "idx = (idx << 1) + idx2 - idx2 + idx2;" + NL),
}

VARIANTS = {n: shell(d, h) for n, (d, h) in HEADS.items()}


def main():
    orig = open(SRC, encoding="utf-8", newline="").read()
    i0, i1 = orig.index(START), orig.index(END)
    results = {}
    try:
        for name in (sys.argv[1:] or list(VARIANTS)):
            open(SRC, "w", encoding="utf-8", newline="").write(
                orig[:i0] + VARIANTS[name] + orig[i1:])
            p = subprocess.run([sys.executable, "-m", "engine.cli", "sandbox",
                                "func_800645B0", "--disable", "all"],
                               capture_output=True, text=True)
            try:
                d = json.loads(p.stdout[p.stdout.index("{"):])
                results[name] = (d.get("score"), d.get("build_insns"))
            except Exception:
                results[name] = ("ERR", p.stdout[-300:] + p.stderr[-400:])
            print(name, results[name], flush=True)
    finally:
        open(SRC, "w", encoding="utf-8", newline="").write(orig)
    print(json.dumps(results, default=str))


if __name__ == "__main__":
    main()
