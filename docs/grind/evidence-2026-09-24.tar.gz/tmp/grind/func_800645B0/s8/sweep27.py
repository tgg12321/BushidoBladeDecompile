#!/usr/bin/env python3
"""Sweep 27 for func_800645B0 (grind session 8, REDERIVE modality).

All variants sit on the session-7 "JD" chassis (index arithmetic written
INLINE, no idx2 / wid locals; 3 / 78, residual = the three loop-top points).

  JD  -- control.
  NA  -- session-8 frontier item 0, literal form: a second set of `idx` at the
         TOP of the OUTER loop body (before the inner `for`), with the inner
         loop still recomputing `idx = i + j;`.
  NB  -- same at the outer-loop TAIL.
  NC  -- the maintained-index shape whose PREHEADER set cannot constant-fold:
         `j` is initialised once before the outer loop and reset at the OUTER
         loop tail, so `idx = i + j;` in the preheader sees `j` with two
         reaching definitions and must be emitted as a real `addu`.
  ND  -- route the HALFWORD offset (k*2) through `idx` and re-derive the word
         byte offset from it (`((idx << 1) + idx) << 1` == k*12), so the second
         set of `idx` is genuinely used and cannot be folded away.
"""
import json
import subprocess
import sys

SRC = "src/text1b.c"
START = "s32 func_800645B0(void) {"
END = 'INCLUDE_ASM("asm/funcs", func_800646E8);'

I = " " * 16
SYMS = ("D_800F0D78", "D_800F0D7C", "videoDec")
W = (I + "*((s32 *)(((s32)(&%s)) + %s)) = "
     "(((s32 *)D_800A347C)[%d] + (%s & 0xFF)) - 0x7F;\n")
OFF = "((((idx << 1) + idx)) << 2)"
OFF_H = "((((idx << 1) + idx)) << 1)"   # k*12 when idx already holds k*2


def wst(off, first="last"):
    return (W % (SYMS[0], off, 0, first)
            + W % (SYMS[1], off, 1, "rand()")
            + W % (SYMS[2], off, 2, "rand()"))


def hst(off, val="last & 7"):
    return I + "*((s16 *)(((s32)(&D_800F0BCC)) + %s)) = %s;\n" % (off, val)


MID = I + "last = rand();\n" + I + "val = D_800A3444;\n"
TAIL = (I + "val = val | mask;\n" + I + "D_800A3444 = val;\n"
        + I + "break;\n")
D6 = ("    s32 i;\n    s32 j;\n    s32 idx;\n    s32 mask;\n"
      "    s32 val;\n    s32 last;\n")
PRE = "    D_800F10EC = 1;\n"
TOP = ("            idx = i + j;\n"
       "            val = 1;\n            mask = val << idx;\n")
ARM = I + "last = rand();\n" + wst(OFF) + MID + hst("(idx << 1)") + TAIL


def shell(decls, pre, outer_pre, top, arm, outer_post=""):
    return (START + "\n" + decls + pre
            + "    for (i = 0; i < 0xF; i += 4) {\n" + outer_pre
            + "        for (j = 0; j < 4; j++) {\n" + top
            + "            if (!(D_800A3444 & mask)) {\n" + arm
            + "            }\n        }\n" + outer_post + "    }\n"
            + "    return 1;\n}\n")


# NC: hand-written shell (do/while inner loop, j maintained across groups).
NC = (START + "\n" + D6
      + "    j = 0;\n" + PRE
      + "    for (i = 0; i < 0xF; i += 4) {\n"
      + "        idx = i + j;\n"
      + "        do {\n"
      + "            val = 1;\n            mask = val << idx;\n"
      + "            if (!(D_800A3444 & mask)) {\n" + ARM
      + "            }\n"
      + "            j += 1;\n"
      + "            idx = i + j;\n"
      + "        } while (j < 4);\n"
      + "        j = 0;\n"
      + "    }\n    return 1;\n}\n")

ARM_ND = (I + "last = rand();\n" + I + "idx = idx << 1;\n"
          + wst(OFF_H) + MID + hst("idx") + TAIL)

VARIANTS = {
    "JD": shell(D6, PRE, "", TOP, ARM),
    "NA": shell(D6, PRE, "        idx = i;\n", TOP, ARM),
    "NB": shell(D6, PRE, "", TOP, ARM, outer_post="        idx = i;\n"),
    "NC": NC,
    "ND": shell(D6, PRE, "", TOP, ARM_ND),
}


def main():
    orig = open(SRC, encoding="utf-8", newline="").read()
    i0, i1 = orig.index(START), orig.index(END)
    results = {}
    try:
        for name in (sys.argv[1:] or list(VARIANTS)):
            open(SRC, "w", encoding="utf-8", newline="").write(
                orig[:i0] + VARIANTS[name] + orig[i1:])
            p = subprocess.run([sys.executable, "-m", "engine.cli", "sandbox",
                                "func_800645B0", "--disable", "all"],
                               capture_output=True, text=True)
            try:
                d = json.loads(p.stdout[p.stdout.index("{"):])
                results[name] = (d.get("score"), d.get("build_insns"))
            except Exception:
                results[name] = ("ERR", p.stdout[-300:] + p.stderr[-400:])
            print(name, results[name], flush=True)
    finally:
        open(SRC, "w", encoding="utf-8", newline="").write(orig)
    print(json.dumps(results, default=str))


if __name__ == "__main__":
    main()
