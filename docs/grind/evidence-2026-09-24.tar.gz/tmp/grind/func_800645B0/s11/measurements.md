# s11 (escalation, 2026-08-20) — or-tree-shape-shift carve-out measured on today's chassis

All scores from `& tools/wteng.ps1 main sandbox func_800645B0 --disable all`
(honest sandbox, rules_dropped 1, cheat_asm_stripped 262), SB chassis body
(memory/grind/func_800645B0/candidate.c) applied to src/text1b.c.

| # | form | score | insns |
|---|------|-------|-------|
| 0 | SB control (`idx = i + j;` … `idx = idx2 + idx;`) | 1 | 78/78 |
| 1 | *3 sum swapped: `idx = idx + idx2;` | 1 | 78/78 — byte-identical to control (H24 re-confirmed: both C orders canonicalize at RTL expansion; the target's `addu $s0,$s1,$s0` order is unreachable when the sum's destination pseudo is `idx`) |
| 2 | loop-top sum swapped: `idx = j + i;` | 3 | 78/78 — strictly worse (flips the already-target-matching loop-top addu operand order, +2 points) |

Application-surface census for the 2026-08-20 or-tree-shape-shift carve-out
(single justified target-matching operand order/grouping in an
associative+commutative expression):
- 2-term `+` expressions: `i + j` (order already target's; swap measured +2)
  and `idx2 + idx` (order inert — RTL-expansion invariant, H24/optabs.c
  target==op1 swap clause; no C order produces the target's order).
- `val | mask`: 2-term, not in the residual (bytes already match there).
- `val << idx`: shift — not commutative, out of family scope.
- 3+-term associative+commutative expressions: NONE exist in the function
  (store RHSs contain a subtraction), so the parenthesization/grouping
  sub-axis has NO application surface.

Conclusion: the carve-out family has zero committable move on this function.
The unpark premise ("sole remaining lever is in this family") is measured
FALSE — the family's whole axis was and remains inert here.

Gate (a) fresh run (this session):
  tools/scan_hand_coded.py --single func_800645B0
  -> HAND_CODED: tier=LOW score=0/8, "no strong hand-coded indicators"
  (S1 0 multu pairs, S2 none, S6 none — all three STRONG signals negative.)
