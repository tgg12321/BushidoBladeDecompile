#!/bin/bash
# Build a decomp-permuter workspace for func_800645B0 (text1b.c).
# Full-TU compile (correct codegen context) + per-function asm extraction so the
# permuter metric is the real per-function diff (same pattern as
# tools/mar_perm_workspace.sh).
set -e
cd /mnt/c/Users/Trenton/Desktop/"Bushido Blade 2 Decompile"
WS=tmp/grind/func_800645B0/s4/ws
FUNC=func_800645B0
mkdir -p "$WS"

CPP_FLAGS="-Iinclude -undef -Wall -lang-c -fno-builtin"
CPP_DEFS="-Dmips -D__GNUC__=2 -D__OPTIMIZE__ -D__mips__ -D__mips -Dpsx -D__psx__ -D__psx -D_PSYQ -D__EXTENSIONS__ -D_MIPSEL -D_LANGUAGE_C -DLANGUAGE_C"
mipsel-linux-gnu-cpp $CPP_FLAGS $CPP_DEFS src/text1b.c > "$WS/base.c"

cat > "$WS/settings.toml" <<EOF
func_name = "$FUNC"
compiler_type = "gcc"
EOF

cat > "$WS/compile.sh" <<'EOF'
#!/bin/bash
set -e
cd /mnt/c/Users/Trenton/Desktop/"Bushido Blade 2 Decompile"
IN="$1"
OUT="$3"
FUNC=func_800645B0
TMPS=$(mktemp /tmp/t1bXXXXXX.s)
trap "rm -f $TMPS $TMPS.fn.s" EXIT
tools/gcc-2.7.2/build/cc1 -O2 -G0 -funsigned-char -quiet -mcpu=3000 \
    -mips1 -mno-abicalls -fno-builtin -w -mel "$IN" -o /dev/stdout 2>/dev/null \
  | python3 tools/prologue_fix.py \
  | python3 tools/maspsx/maspsx.py --expand-div --aspsx-version=2.34 \
      --sdata-syms=sdata_syms.txt --sdata-funcs=sdata_funcs.txt \
      --sdata-exclude=sdata_exclude.txt --expand-lb \
      --expand-lb-funcs=expand_lb_funcs.txt --multu-funcs=multu_funcs.txt \
      --expand-dest-funcs=expand_dest_funcs.txt \
      --label-nop-funcs=maspsx_label_nop_funcs.txt \
  | python3 tools/multu_pad.py --funcs multu_pad_funcs.txt > "$TMPS"
awk -v f="$FUNC" '
$0 ~ ("^[ 	]*\.ent[ 	]+" f "$") {p=1}
$0 ~ ("^" f ":$") {p=1}
p {print}
p && $0 ~ ("^[ 	]*\.end[ 	]+" f "$") {exit}
' "$TMPS" > "$TMPS.fn.s"
cat "$TMPS.fn.s" \
  | mipsel-linux-gnu-as -Iinclude -march=r3000 -mtune=r3000 \
      -no-pad-sections -O1 -G0 -o "$OUT"
EOF
chmod +x "$WS/compile.sh"

sed 's/^.set gp=64$//' tools/decomp-permuter/prelude.inc > "$WS/prelude_r3k.inc"
cat "$WS/prelude_r3k.inc" asm/funcs/$FUNC.s > "$WS/target.s"
mipsel-linux-gnu-as -Iinclude -march=r3000 -mtune=r3000 -no-pad-sections \
  -O1 -G0 -o "$WS/target.o" "$WS/target.s"

bash "$WS/compile.sh" "$WS/base.c" -o "$WS/base.o"
f() {
  mipsel-linux-gnu-objdump -d "$1" | awk -v f="$FUNC" '$0 ~ ("<" f ">:"){p=1;next} /^[0-9a-f]+ </{p=0} p' \
    | sed 's/^[^\t]*\t[^\t]*\t//' | sed 's/0x[0-9a-f]*//g' | grep -v '^$'
}
f "$WS/base.o" > /tmp/p4_base.txt
f "$WS/target.o" > /tmp/p4_tgt.txt
echo "base insns: $(wc -l < /tmp/p4_base.txt)  target: $(wc -l < /tmp/p4_tgt.txt)"
diff /tmp/p4_base.txt /tmp/p4_tgt.txt | head -20
