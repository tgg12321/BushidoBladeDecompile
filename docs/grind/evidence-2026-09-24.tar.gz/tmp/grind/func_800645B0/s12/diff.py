import subprocess, re
def norm(t):
    t=t.replace('$','').replace(', ',',').strip()
    t=re.sub(r'\s+',' ',t)
    m=t.split(' ',1)
    op=m[0]; rest=m[1] if len(m)>1 else ''
    if op in ('j','b','bnez','beqz','bne','beq','blez','bgtz','bltz','bgez','jal'):
        parts=rest.split(',')
        parts[-1]='L'
        rest=','.join(parts)
    rest=re.sub(r'%\w+\([^)]*\)','S',rest)
    rest=re.sub(r'\b0x([0-9a-f]+)\b',lambda m:str(int(m.group(1),16)),rest)
    rest=re.sub(r'\b(\d+)\b',lambda m:str(int(m.group(1))),rest)
    rest=re.sub(r'(-?\w+)\(',r'X(',rest)
    if op=='lui': rest=rest.split(',')[0]+',X'
    if op=='li': op,rest='addiu', rest.split(',')[0]+',zero,'+rest.split(',')[1]
    if op=='move': op,rest='addu', rest+',zero'
    if op=='nop': op,rest='sll','zero,zero,0'
    return op+' '+rest
out=subprocess.run(['mipsel-linux-gnu-objdump','-d','--no-show-raw-insn','tmp/sandbox/func_800645B0/text1b.o'],capture_output=True,text=True).stdout
ours=[];on=False
for l in out.splitlines():
    m=re.match(r'^[0-9a-f]+ <(\S+)>:',l)
    if m: on=(m.group(1)=='func_800645B0'); continue
    if on and re.match(r'^\s+[0-9a-f]+:',l):
        ours.append(norm(l.split(':',1)[1].strip()))
tgt=[]
for l in open('asm/funcs/func_800645B0.s'):
    l=l.strip()
    if l.startswith('/*') and '*/' in l:
        b=l.split('*/',1)[1].strip()
        if b: tgt.append(norm(b))
print('ours',len(ours),'tgt',len(tgt))
n=0
for i in range(max(len(ours),len(tgt))):
    a=ours[i] if i<len(ours) else '--'; b=tgt[i] if i<len(tgt) else '--'
    if a!=b:
        n+=1; print(i,'OURS:',a,'|| TGT:',b)
print('diffs',n)
