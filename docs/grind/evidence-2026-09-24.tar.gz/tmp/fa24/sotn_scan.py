import re,os,sys,collections
root='tmp/sotn-decomp/src'
assign=re.compile(r'^\s*(\w+)\s*=\s*(-?(?:0x[0-9A-Fa-f]+|\d+));\s*(//.*|/\*.*)?$')
store=re.compile(r'^\s*[^=;]*(?:\*|->|\[|\.)[^=;]*=\s*(\w+);')
hits=[]
for dp,_,fs in os.walk(root):
    for f in fs:
        if not f.endswith('.c'): continue
        p=os.path.join(dp,f)
        L=open(p,errors='ignore').read().split('\n')
        # track per-function by brace depth reset at top-level
        per=collections.defaultdict(list)
        fstart=0
        depth=0
        for i,l in enumerate(L):
            if depth==0 and '{' in l: fstart=i
            m=assign.match(l)
            if m and i+1<len(L):
                s=store.match(L[i+1])
                if s and s.group(1)==m.group(1):
                    per[(fstart,m.group(1))].append((i+1,m.group(2)))
            depth+=l.count('{')-l.count('}')
        for (fs_,v),lst in per.items():
            vals={x[1] for x in lst}
            if len(lst)>=int(os.environ.get("MINN","2")) and len(vals)>=int(os.environ.get("MINV","2")):
                hits.append((p,v,lst))
for p,v,lst in hits:
    print(p.replace('tmp/sotn-decomp/',''),v,[(a,b) for a,b in lst][:8])
print(len(hits),file=sys.stderr)
