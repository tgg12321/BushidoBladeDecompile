#!/usr/bin/env python3
"""Enumerate the widened cop2 materialize-then-copy cluster (owner ruling 2026-09-01).

Idiom: `addu $tN, $rX, $zero` (any copy source) whose next 6 lines contain a
cop2 transfer (mtc2/ctc2/lwc2/swc2/mfc2/cfc2) referencing $tN. Band filter:
function address 0x80010000-0x8003FFFF. Reports each function with its idiom
sites, the copy SOURCE class ($aN = already covered by 2026-08-17; other =
newly covered by the widening), and handwritten-tag presence nearby.
"""
import re, sys
from pathlib import Path

FUNCS = Path("asm/funcs")
COPY = re.compile(r"addu\s+(\$t\d),\s+(\$\w+),\s+\$zero")
COP2 = re.compile(r"(mtc2|ctc2|lwc2|swc2|mfc2|cfc2)\b")

rows = []
for f in sorted(FUNCS.glob("func_*.s")) + sorted(FUNCS.glob("*.s")):
    m = re.match(r"func_(800[0-9A-Fa-f]{5})", f.stem)
    if m:
        addr = int(m.group(1), 16)
        if not (0x80010000 <= addr <= 0x8003FFFF):
            continue
    else:
        continue  # named funcs handled separately if needed; band scan is addr-keyed
    lines = f.read_text(errors="replace").splitlines()
    sites = []
    for i, ln in enumerate(lines):
        cm = COPY.search(ln)
        if not cm:
            continue
        dest, src = cm.group(1), cm.group(2)
        window = lines[i + 1 : i + 7]
        hit = None
        for w in window:
            if COP2.search(w) and (dest in w or re.search(r"(mtc2|ctc2)\s+\$t\d", w)):
                hit = w.strip()
                break
        if hit:
            tagged = any("handwritten" in w for w in window) or "handwritten" in ln
            sites.append((i + 1, dest, src, hit[:60], tagged))
    if sites:
        new = [s for s in sites if not re.match(r"\$a[0-3]$", s[2])]
        rows.append((f.stem, sites, bool(new)))

print(f"{'function':<16} sites  new-under-widening  details")
for name, sites, has_new in rows:
    det = "; ".join(f"L{l} {d}<-{s}{'*' if t else ''}" for l, d, s, _, t in sites)
    print(f"{name:<16} {len(sites):>5}  {'YES' if has_new else 'no ':>3}               {det}")
print(f"\ntotal functions with idiom in band: {len(rows)}")
print(f"newly covered by widening (any non-$aN-source site): {sum(1 for _,_,n in rows if n)}")
print("(* = handwritten tag within the site window)")
for name, sites, has_new in rows:
    if has_new:
        print("NEW:", name, [f"{d}<-{s}" for _, d, s, _, _ in sites if not re.match(r"\$a[0-3]$", s)])
