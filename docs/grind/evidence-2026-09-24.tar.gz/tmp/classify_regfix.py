import json, re, csv, os, collections

ROOT = r"C:\Users\Trenton\Desktop\Bushido Blade 2 Decompile"
def P(*a): return os.path.join(ROOT, *a)

RULE_RE = re.compile(r'^([A-Za-z_][A-Za-z0-9_]*)\s*:\s*(.*)$')
QUOTED = re.compile(r'"((?:[^"\\]|\\.)*)"')

BRANCH = {'beq','bne','beqz','bnez','bgez','bltz','blez','bgtz','b','j','jal','jr','bgezal','bltzal'}
LOADSTORE = {'lw','sw','lh','sh','lhu','lb','sb','lbu','lwl','lwr','swl','swr','lwc2','swc2'}
MNEM = re.compile(r'^\s*\.?([a-z][a-z0-9_.]*)\b')

def unesc(s):
    s = s.replace('\\t',' ').replace('\\s+',' ').replace('\\s',' ')
    s = s.replace('\\$','$').replace('\\(','(').replace('\\)',')')
    s = s.replace('\\.','.').replace('\\+','+').replace('\\d','#')
    return s

def mnem(s):
    m = MNEM.match(s)
    if not m: return None
    t = m.group(1)
    return t

REG = re.compile(r'\$(?:[a-z0-9]+)')
NUM = re.compile(r'(?<![\w$])(-?(?:0x[0-9a-fA-F]+|\d+))')

def regs(s): return REG.findall(s)
def nums(s): return NUM.findall(s)

MOVE_INSERT = re.compile(r'addu\s+\$[a-z0-9]+\s*,\s*\$(?:0|zero|[a-z0-9]+)\s*,\s*\$(?:zero|0|[a-z0-9]+)')

def classify_insert(payload):
    p = unesc(payload)
    lines = [l for l in re.split(r'\\n|\n', p) if l.strip()]
    if len(lines) >= 8:
        return 'splice-large-asm'
    if lines and all(mnem(l) == 'nop' for l in lines):
        return 'nop-scheduling-insert'
    if any(MOVE_INSERT.search(l) for l in lines):
        return 'lost-codegen-move-insert'
    if len(lines) > 1:
        return 'multi-insn-insert'
    joined = ' '.join(lines)
    m = mnem(joined)
    if m in BRANCH: return 'branch-insert'
    if m in LOADSTORE: return 'loadstore-insert'
    return 'instruction-injection-insert'

def classify_subst(pat, rep):
    a, b = unesc(pat), unesc(rep)
    ma, mb = mnem(a), mnem(b)
    ra, rb = regs(a), regs(b)
    na, nb = nums(a), nums(b)
    has_label = ('.L' in a) or ('.L' in b)
    if 'handwritten' in b or (mb and mb[:4] in ('ctc2','cfc2','mtc2','mfc2')) or (ma and ma[:4] in ('ctc2','cfc2','mtc2','mfc2')):
        return 'gte-cop2-respell'
    if ma == 'nop' and mb and mb != 'nop':
        return 'lost-codegen-nop-fill'
    if mb == 'nop' and ma and ma != 'nop':
        return 'instruction-suppress-to-nop'
    if has_label or ma in BRANCH or mb in BRANCH:
        return 'branch-label-retarget'
    if '$sp' in a or '$sp' in b or '$29' in a or '$29' in b:
        if na != nb:
            return 'frame-stack-offset'
        return 'frame-reg-rename'
    if re.search(r'0x1[fF]80', b):
        return 'scratchpad-abs-address'
    if ('%hi' in b or '%lo' in b or '%gp_rel' in b) and not ('%hi' in a or '%lo' in a or '%gp_rel' in a):
        return 'symbol-reference-rewrite'
    if ma and mb and ma != mb:
        wide = {'lw','lh','lhu','lb','lbu','sw','sh','sb','sll','srl','sra','sllv','srlv','srav','andi','and'}
        if ma in wide and mb in wide:
            return 'width-sign-opcode-change'
        return 'opcode-change'
    if ra and rb and sorted(ra) == sorted(rb) and ra != rb:
        return 'operand-order-swap'
    if ra != rb and na == nb:
        return 'register-rename'
    if ra == rb and na != nb:
        return 'memory-displacement'
    if ra != rb and na != nb:
        return 'register+displacement'
    return 'other-subst'

FAMILY_RECIPE = {
 'register-rename': ('register-alloc-pure-c', 'COVERED'),
 'frame-reg-rename': ('register-alloc-pure-c', 'COVERED'),
 'operand-order-swap': ('compare-operand-order-register', 'COVERED'),
 'register-swap-range': ('register-alloc-pure-c', 'COVERED'),
 'reorder-scheduling': ('loop-exit-work-inside-loop-sched-fence', 'COVERED'),
 'fill-delay-slot': ('hoist-call-arg-local-flips-jal-delay', 'COVERED'),
 'nop-scheduling-insert': ('maspsx-label-nop-gate', 'COVERED'),
 'lost-codegen-move-insert': ('shared-end-label', 'COVERED-FORBIDDEN'),
 'lost-codegen-nop-fill': ('shared-end-label', 'COVERED-FORBIDDEN'),
 'instruction-suppress-to-nop': ('dead-store-fake-exception', 'PARTIAL'),
 'width-sign-opcode-change': ('halfword-index-srl-sra', 'COVERED'),
 'opcode-change': ('proven-spelling-class-reconstruction', 'PARTIAL'),
 'memory-displacement': ('defeat-combine-symbol-fold', 'PARTIAL'),
 'register+displacement': ('register-alloc-pure-c', 'PARTIAL'),
 'frame-stack-offset': ('phantom-slot-frame-lever', 'COVERED'),
 'branch-label-retarget': ('switch-vs-ifchain-branch-sense', 'PARTIAL'),
 'symbol-reference-rewrite': ('defeat-combine-symbol-fold', 'PARTIAL'),
 'branch-insert': ('switch-vs-ifchain-branch-sense', 'PARTIAL'),
 'loadstore-insert': ('store-before-jal', 'PARTIAL'),
 'instruction-injection-insert': ('lost-codegen-insert-cheat', 'COVERED-FORBIDDEN'),
 'multi-insn-insert': ('OPEN', 'OPEN'),
 'splice-large-asm': ('OPEN', 'OPEN'),
 'delete-instruction': ('store-const-reload-cse', 'PARTIAL'),
 'delete-range': ('OPEN', 'OPEN'),
 'whole-body-asm-replace': ('canonical-asm-authorization-recipe', 'OPEN-CANONICAL'),
 'label-rename': ('global-label-drift-sibling-cheat', 'PARTIAL'),
 'label-insert': ('jtbl-rodata-split-infrastructure', 'PARTIAL'),
 'gte-cop2-respell': ('gte-3x3', 'COVERED'),
 'scratchpad-abs-address': ('scratchpad-gte', 'COVERED'),
 'subst-multi': ('register-alloc-pure-c', 'PARTIAL'),
 'other-subst': ('OPEN', 'OPEN'),
 'other': ('OPEN', 'OPEN'),
}

rows = []
for fname in ('regfix.txt', 'regfix_stage2.txt', 'asmfix.txt'):
    path = P(fname)
    if not os.path.exists(path): continue
    with open(path, 'r', encoding='utf-8', errors='replace') as fh:
        for ln, line in enumerate(fh, 1):
            s = line.strip()
            if not s or s.startswith('#'): continue
            m = RULE_RE.match(s)
            if not m: continue
            func, rest = m.group(1), m.group(2).strip()
            if not rest: continue
            verb = rest.split()[0]
            q = QUOTED.findall(rest)
            if verb == 'subst':
                fam = classify_subst(q[0] if q else '', q[1] if len(q) > 1 else '')
            elif verb == 'subst_multi':
                fam = 'subst-multi'
            elif verb in ('insert', 'insert_after', 'insert_before'):
                fam = classify_insert(q[-1] if q else rest)
                if verb == 'insert_before' and q and re.search(r'\\\.end', q[0]):
                    fam = 'whole-body-asm-replace'
            elif verb == 'insert_label':
                fam = 'label-insert'
            elif verb == 'delete':
                fam = 'delete-instruction'
            elif verb == 'delete_between':
                fam = 'whole-body-asm-replace' if '.frame' in rest and '.end' in rest else 'delete-range'
            elif verb == 'reorder':
                fam = 'reorder-scheduling'
            elif verb == 'replace_with_asmfile':
                fam = 'whole-body-asm-replace'
            elif verb == 'rename':
                fam = 'label-rename'
            elif verb == 'replace_first':
                fam = 'branch-label-retarget'
            elif verb == 'splice':
                fam = 'splice-large-asm'
            elif verb == 'fill_delay':
                fam = 'fill-delay-slot'
            elif verb.startswith('$'):
                verb = 'swap'
                fam = 'register-swap-range'
            else:
                fam = 'other'
            slug, cov = FAMILY_RECIPE.get(fam, ('OPEN','OPEN'))
            rows.append(dict(func=func, src=fname, line_no=ln, verb=verb, family=fam,
                             recipe=slug, coverage=cov, text=s[:200]))

qd = json.load(open(P('engine','queue.json')))
qmap = {it['func']: it for it in qd['items']}

for r in rows:
    q = qmap.get(r['func'])
    r['file'] = q['file'] if q else 'UNKNOWN'
    r['distance'] = q['distance'] if q else ''
    r['status'] = q['status'] if q else 'not-in-queue'
    r['verdict'] = q['verdict'] if q else ''

with open(P('tmp','regfix_rules_classified.csv'), 'w', newline='', encoding='utf-8') as fh:
    w = csv.DictWriter(fh, fieldnames=['func','file','src','line_no','verb','family','recipe','coverage','distance','status','verdict','text'])
    w.writeheader()
    for r in rows: w.writerow(r)

fam_counts = collections.Counter(r['family'] for r in rows)
verb_counts = collections.Counter(r['verb'] for r in rows)
per_func = collections.defaultdict(list)
for r in rows: per_func[r['func']].append(r)

print('TOTAL RULES', len(rows))
print('FUNCS', len(per_func))
print()
for f,c in fam_counts.most_common():
    slug, cov = FAMILY_RECIPE.get(f, ('?','?'))
    print('%5d  %-30s %-18s %s' % (c, f, cov, slug))
print()
print(dict(verb_counts))
print('COVERAGE', dict(collections.Counter(r['coverage'] for r in rows)))
print('QUEUE ITEMS', len(qmap), 'counts', qd.get('counts'))
missing = sorted(set(r['func'] for r in rows if r['file']=='UNKNOWN'))
print('NOT IN QUEUE (%d):' % len(missing), missing)
json.dump(rows, open(P('tmp','_rows.json'),'w'))
