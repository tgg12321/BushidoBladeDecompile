#!/bin/bash
set -uo pipefail
cd "/mnt/c/Users/Trenton/Desktop/Bushido Blade 2 Decompile"
T=tmp/fx
echo "### occurrences of 'mov \$0x4a,%edi' (arg=code 0x4a) inside simplify_rtx"
for t in shipped mixed; do
  printf "%-8s %s\n" $t "$(grep -c '\$0x4a,%edi' $T/dis.$t.txt)"
done
echo
echo "### occurrences of 'call .* <gen_binary>'"
for t in shipped mixed; do printf "%-8s %s\n" $t "$(grep -c '<gen_binary>' $T/dis.$t.txt)"; done
echo
echo "### occurrences of '<nonzero_bits>'"
for t in shipped mixed; do printf "%-8s %s\n" $t "$(grep -c '<nonzero_bits>' $T/dis.$t.txt)"; done
echo
echo "### occurrences of 'test   %eax,%ebx'"
for t in shipped mixed; do printf "%-8s %s\n" $t "$(grep -c 'test   %e..,%e..' $T/dis.$t.txt)"; done
echo
echo "### 'shl \$0x3,%eax' / cmp \$0x20 pattern"
for t in shipped mixed; do printf "%-8s shl=%s\n" $t "$(grep -c 'shl    \$0x3,%eax' $T/dis.$t.txt)"; done
echo
echo "### RTX code numbering from rtl.def"
awk '/^DEF_RTL_EXPR/{printf "%d %s\n", n, $0; n++}' tools/gcc-2.7.2/rtl.def | sed 's/DEF_RTL_EXPR(\([A-Z_0-9]*\).*/\1/' | awk '{printf "%3d 0x%02x %s\n", $1, $1, $2}' | sed -n '1,200p'
