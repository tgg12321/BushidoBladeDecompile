import json, re, collections

root = r"C:\Users\Trenton\Desktop\Bushido Blade 2 Decompile"

rules = []
for line in open(root + r"\asmfix.txt", encoding="utf-8"):
    m = re.match(r'^([A-Za-z_]\w*):\s+(\S+)', line)
    if m:
        rules.append((m.group(1), m.group(2)))

print("total rule lines:", len(rules))
by_verb = collections.Counter(v for _, v in rules)
print("by verb:", dict(by_verb))

funcs = collections.defaultdict(list)
for f, v in rules:
    funcs[f].append(v)
print("distinct functions:", len(funcs))

# canonical list
canon = set()
for line in open(root + r"\inline_asm_canonical.txt", encoding="utf-8"):
    line = line.strip()
    if line and not line.startswith("#"):
        canon.add(line.split()[0])
print("canonical list size:", len(canon))

# queue
q = json.load(open(root + r"\engine\queue.json", encoding="utf-8"))
items = q if isinstance(q, list) else q.get("items", q.get("functions", []))
qmap = {}
for it in items:
    if isinstance(it, dict):
        name = it.get("func") or it.get("name")
        qmap[name] = (it.get("status"), it.get("verdict"))
print("queue size:", len(qmap))

rwa = sorted(f for f, vs in funcs.items() if all(v == "replace_with_asmfile" for v in vs))
other = sorted(f for f in funcs if f not in rwa)

def flag(f):
    tags = []
    tags.append("CANON" if f in canon else "not-canon")
    if f in qmap:
        tags.append(f"queue:{qmap[f][0]}/{qmap[f][1]}")
    else:
        tags.append("not-in-queue")
    return " ".join(tags)

print("\n=== pure replace_with_asmfile functions (%d) ===" % len(rwa))
cnt = collections.Counter()
for f in rwa:
    k = ("CANON" if f in canon else "not-canon", qmap.get(f, ("absent",))[0])
    cnt[k] += 1
for k, n in sorted(cnt.items()):
    print(" ", k, n)
noncanon_rwa = [f for f in rwa if f not in canon]
print(" non-canonical rwa funcs:", noncanon_rwa)

print("\n=== functions with other verbs (%d) ===" % len(other))
for f in other:
    print(" %-40s %s  [%s]" % (f, ",".join(funcs[f]), flag(f)))
