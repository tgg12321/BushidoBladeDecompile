#!/usr/bin/env python3
"""Assemble verbatim library regions, resolve Sony symbol names via XDEFs+locals,
cross-reference engine/queue.json. Writes regions.json-ish queue_hits.json, symbols.txt."""
import struct, sys, os, json, re, glob

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(os.path.dirname(HERE))
sys.path.insert(0, os.path.join(REPO, "tmp", "closer"))
from psyq_lib import lib_modules, parse_obj

M = json.load(open(os.path.join(HERE, "matches.json")))
taddr = int(M["taddr"], 16)

objs = {}
for libpath in sorted(glob.glob(os.path.join(HERE, "psyq40", "*.LIB"))):
    libname = os.path.basename(libpath)[:-4]
    for modname, objdata in lib_modules(open(libpath, "rb").read()):
        try:
            objs[(libname, modname)] = parse_obj(objdata)
        except Exception:
            pass

def text_sid(o):
    for sid, s in o.sections.items():
        if s["name"] == ".text" and len(s["bytes"]) >= 4:
            return sid
    return None

verb = [r for r in M["results"] if r["status"] == "verbatim"]
unique = [r for r in verb if len(r["vaddrs"]) == 1]
multi = [r for r in verb if len(r["vaddrs"]) > 1]

ivs = [(int(r["vaddrs"][0], 16),
        int(r["vaddrs"][0], 16) + r["words"] * 4, r["lib"], r["mod"], r["words"])
       for r in unique]

def merge(intervals, gap=0x40):
    out = []
    for t in sorted(intervals):
        a, b = t[0], t[1]
        if out and a <= out[-1][1] + gap:
            out[-1][1] = max(out[-1][1], b)
        else:
            out.append([a, b])
    return out

regions = merge(ivs)

def overlaps_unique(a, b):
    return any(a < ub and ua < b for ua, ub, *_ in ivs)

accepted = list(ivs)          # (a,b,lib,mod,words)
placed_multi, ambiguous, subsumed = [], [], []
for _pass in range(3):
    regions_now = merge(accepted)
    placed_any = False
    for r in multi:
        good = []
        for va in r["vaddrs"]:
            a = int(va, 16); b = a + r["words"] * 4
            if any(ra - 0x10 <= a <= rb + 0x10 or ra - 0x10 <= b <= rb + 0x10
                   for ra, rb in regions_now):
                good.append((a, b))
        fresh = [(a, b) for a, b in good if not overlaps_unique(a, b)
                 and not any(a == pa and b == pb and r["lib"] == pl and r["mod"] == pm
                             for pa, pb, pl, pm, _w in accepted)]
        if fresh:
            for a, b in fresh:
                accepted.append((a, b, r["lib"], r["mod"], r["words"]))
                placed_multi.append((r["lib"], r["mod"], "0x%08X" % a, r["words"],
                                     len(r["vaddrs"])))
                placed_any = True
        elif _pass == 2:
            if good:
                subsumed.append((r["lib"], r["mod"], r["words"],
                                 ["0x%08X" % a for a, b in good]))
            elif not any(pm[0] == r["lib"] and pm[1] == r["mod"]
                         for pm in placed_multi):
                ambiguous.append((r["lib"], r["mod"], r["words"], r["vaddrs"]))
    if not placed_any and _pass > 0:
        pass

regions2 = merge(accepted)

# symbol map (xdefs + locals) from unique placements + fresh multi placements
syms = {}   # vaddr -> set of (name, kind)
mod_of = [] # (a,b,lib,mod)
for a, b, lib, mod, w in sorted(set(accepted)):
    mod_of.append((a, b, lib, mod))
    o = objs.get((lib, mod))
    if not o:
        continue
    sid = text_sid(o)
    for nm, sec, off in o.xdefs:
        if sec == sid and a + off < b:
            syms.setdefault(a + off, set()).add(nm)
    for nm, sec, off in o.locals:
        if sec == sid and a + off < b:
            syms.setdefault(a + off, set()).add(nm + " (static)")

with open(os.path.join(HERE, "symbols.txt"), "w") as f:
    for a in sorted(syms):
        f.write("0x%08X %s\n" % (a, " / ".join(sorted(syms[a]))))

# ---- queue cross-reference ----
# global glabel -> vaddr map from asm/funcs
glabels = {}
for p in glob.glob(os.path.join(REPO, "asm", "funcs", "*.s")):
    cur = None
    for line in open(p):
        g = re.match(r"glabel (\w+)", line)
        if g:
            cur = g.group(1); continue
        m = re.search(r"/\* [0-9A-F]+ ([0-9A-F]{8}) [0-9A-F]{8} \*/", line)
        if m and cur:
            glabels.setdefault(cur, int(m.group(1), 16))
            cur = None

mapsyms = {}
for line in open(os.path.join(REPO, "build", "bb2.map"), errors="replace"):
    m = re.match(r"\s+0x([0-9a-fA-F]{8})\s+(\w+)(?:\s*=\s*0x[0-9a-fA-F]+)?\s*$", line)
    if m:
        mapsyms.setdefault(m.group(2), int(m.group(1), 16))

def asm_addr(fn):
    if fn in glabels:
        return glabels[fn]
    if fn in mapsyms:
        return mapsyms[fn]
    m = re.match(r"(?:D|jtbl)_([0-9A-Fa-f]{8})$", fn)
    if m:
        return int(m.group(1), 16)
    return None

q = json.load(open(os.path.join(REPO, "engine", "queue.json")))
hits, unresolved = [], []
for it in q["items"]:
    fn = it["func"]
    m = re.match(r"func_([0-9A-Fa-f]{8})$", fn)
    addr = int(m.group(1), 16) if m else asm_addr(fn)
    if addr is None:
        unresolved.append(fn); continue
    for a, b, lib, mod in mod_of:
        if a <= addr < b:
            cands = [(sa, syms[sa]) for sa in syms if a <= sa <= addr]
            if cands:
                sa, names = max(cands)
                sony = "/".join(sorted(names)) + \
                       ("" if sa == addr else "+0x%x" % (addr - sa))
            else:
                sony = "%s.text+0x%x" % (mod, addr - a)
            hits.append(dict(func=fn, file=it.get("file"), status=it.get("status"),
                             distance=it.get("distance"), addr="0x%08X" % addr,
                             lib=lib, mod=mod, sony=sony))
            break

json.dump(dict(regions=[["0x%08X" % a, "0x%08X" % b, b - a] for a, b in regions2],
               modules=[["0x%08X" % a, "0x%08X" % b, lib, mod] for a, b, lib, mod in mod_of],
               placed_multi=placed_multi, subsumed=subsumed, ambiguous=ambiguous,
               queue_hits=hits, unresolved=unresolved),
          open(os.path.join(HERE, "queue_hits.json"), "w"), indent=1)

print("regions (merged, gap<=0x40):")
total = 0
for a, b in regions2:
    total += b - a
    print("  0x%08X..0x%08X (%d bytes)" % (a, b, b - a))
print("total library bytes:", total)
print("unique modules:", len(ivs), " fresh multi placements:", len(placed_multi),
      " subsumed:", len(subsumed), " ambiguous:", len(ambiguous))
for x in ambiguous:
    print("  AMBIG", x)
for x in placed_multi:
    print("  MULTI-PLACED", x)
print("queue items in library regions:", len(hits),
      "(active:", sum(1 for h in hits if h["status"] == "active"), ")")
for h in hits:
    print("  %-18s %-9s %-7s %s -> %s/%s  %s" % (h["func"], h["file"], h["status"],
          h["addr"], h["lib"], h["mod"], h["sony"]))
print("unresolved queue funcs:", len(unresolved))
if unresolved:
    print(" ", unresolved[:20])
