import json, sys
from pathlib import Path

def blk(model_path, func, passno, b):
    m = json.loads(Path(model_path).read_text())
    for f in m["funcs"]:
        if f["func"] == func and f["pass"] == passno:
            for x in f["blocks"]:
                if x["b"] == b:
                    return x
    return None

A = blk(sys.argv[1], "gnd_init_80041688", 1, 18)   # on-main (Phase 4)
B = blk(sys.argv[2], "gnd_init_80041688", 1, 18)   # honest
if A is None or B is None:
    print("block missing:", A is None, B is None); sys.exit(1)

def norm(x):
    return {
        "n_insns": x["n_insns"],
        "nodes": {k: {kk: vv for kk, vv in v.items() if kk in
                      ("luid", "unit", "icost", "code", "pri", "ref", "grp")}
                  for k, v in x["nodes"].items() if not v.get("extern")},
        "deps": {k: sorted(map(tuple, v)) for k, v in x["deps"].items()},
        "ready0": list(x["ready0"]),
        "picks": [p["insn"] for p in x["picks"]],
        "clocks": [p["clock"] for p in x["picks"]],
    }

na, nb = norm(A), norm(B)
same = True
for key in ("n_insns", "ready0", "picks", "clocks"):
    if na[key] != nb[key]:
        same = False
        print(f"DIFF {key}:\n  on-main: {na[key]}\n  honest : {nb[key]}")
    else:
        print(f"same {key}: {na[key] if key != 'n_insns' else na[key]}")
if na["deps"] != nb["deps"]:
    same = False
    print("DIFF deps:")
    for k in sorted(set(na["deps"]) | set(nb["deps"]), key=int):
        if na["deps"].get(k) != nb["deps"].get(k):
            print(f"  uid {k}: on-main={na['deps'].get(k)} honest={nb['deps'].get(k)}")
else:
    print(f"same deps ({len(na['deps'])} entries)")
if na["nodes"] != nb["nodes"]:
    same = False
    print("DIFF nodes:")
    for k in sorted(set(na["nodes"]) | set(nb["nodes"]), key=int):
        if na["nodes"].get(k) != nb["nodes"].get(k):
            print(f"  uid {k}: on-main={na['nodes'].get(k)}\n           honest ={nb['nodes'].get(k)}")
else:
    print(f"same nodes ({len(na['nodes'])} entries)")
print("\nBLOCK-18 MODEL IDENTICAL" if same else "\nBLOCK-18 MODEL DIFFERS")
