"""Re-extract the sched model for text1a from a SPECIFIED source, then diff
block 18 of gnd_init_80041688 against the Phase 4 (on-main) model."""
import json, subprocess, sys
from pathlib import Path
sys.path.insert(0, "tools/sched_solver")
import extract as E

ROOT = Path(".").resolve()
SRC = sys.argv[1]                      # source file to compile
OUT = Path(sys.argv[2])                # model json to write

def preprocess_override(stem):
    E.WORK.mkdir(parents=True, exist_ok=True)
    ifile = E.WORK / f"{stem}.honest.i"
    subprocess.run(f'{E.CPP} "{SRC}" > "{ifile}"', shell=True, cwd=ROOT,
                   check=True, stderr=subprocess.DEVNULL)
    return ifile

E.preprocess = preprocess_override
sys.argv = ["extract", "text1a", "--out", str(OUT), "--skip-parity"]
E.main()
