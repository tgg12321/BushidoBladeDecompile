#!/usr/bin/env python3
"""Cross-reference engine/queue.json against the libscan library census.

ANALYSIS ONLY. Writes tmp/campaign2/xref.json + XREF-REPORT.md.
"""
import csv
import json
import os
import re
import subprocess
import sys
from collections import Counter, defaultdict

REPO = "/mnt/c/Users/Trenton/Desktop/Bushido Blade 2 Decompile"
SOTN = "/mnt/c/Users/Trenton/Desktop/sotn-decomp"
OUT = os.path.join(REPO, "tmp/campaign2")

# ---------------------------------------------------------------- address map
ADDR_RE = re.compile(r"^\s*/\*\s*[0-9A-Fa-f]+\s+([0-9A-Fa-f]{8})\s")


def build_addr_map():
    """name -> 0xADDR, from asm/funcs/*.s (glabel + first instruction address)."""
    m = {}
    d = os.path.join(REPO, "asm/funcs")
    for fn in os.listdir(d):
        if not fn.endswith(".s"):
            continue
        with open(os.path.join(d, fn), encoding="utf-8", errors="replace") as f:
            name = None
            for line in f:
                if name is None:
                    mm = re.match(r"^glabel\s+(\S+)", line)
                    if mm:
                        name = mm.group(1)
                    continue
                am = ADDR_RE.match(line)
                if am:
                    m[name] = "0x" + am.group(1).upper()
                    break
    # fallback 1: the master name census (address-keyed), which covers
    # functions already decompiled out of the asm split
    census = os.path.join(REPO, "docs/naming/function-names.csv")
    if os.path.exists(census):
        with open(census, encoding="utf-8", errors="replace") as f:
            for rec in csv.DictReader(f):
                a = (rec.get("address") or "").strip()
                if not a.lower().startswith("0x"):
                    continue
                a = "0x" + a[2:].upper()
                for col in ("current_name", "glabel", "proposed_name"):
                    nm = (rec.get(col) or "").strip()
                    if nm and nm not in m:
                        m[nm] = a
    # fallback 2: symbol files, for functions with no asm/funcs/*.s (already
    # fully decompiled and dropped from the asm split)
    sym_re = re.compile(r"^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*0x([0-9A-Fa-f]{8})\s*;")
    for fn in ("named_syms.txt", "symbol_addrs.txt"):
        p = os.path.join(REPO, fn)
        if not os.path.exists(p):
            continue
        for line in open(p, encoding="utf-8", errors="replace"):
            mm = sym_re.match(line)
            if mm and mm.group(1) not in m:
                m[mm.group(1)] = "0x" + mm.group(2).upper()
    return m


# ---------------------------------------------------------------- SOTN index
SKIP_KW = {"if", "for", "while", "switch", "return", "sizeof", "do", "else"}
FUNC_DEF = re.compile(r"^[A-Za-z_][A-Za-z0-9_ \t\*,\(\)]*?\b([A-Za-z_][A-Za-z0-9_]*)\s*\(")


def index_sotn():
    """symbol -> list of (relpath, line, span_lines, has_inline_asm)."""
    idx = defaultdict(list)
    if not os.path.isdir(SOTN):
        return idx, False
    roots = [
        "src/main/psxsdk",
        "src/pc/psxsdk",
        "include/psxsdk",
        "include",
    ]
    for root in roots:
        base = os.path.join(SOTN, root)
        if not os.path.isdir(base):
            continue
        for dirpath, _dirs, files in os.walk(base):
            for fn in files:
                if not fn.endswith((".c", ".h")):
                    continue
                p = os.path.join(dirpath, fn)
                rel = os.path.relpath(p, SOTN).replace("\\", "/")
                try:
                    lines = open(p, encoding="utf-8", errors="replace").read().split("\n")
                except OSError:
                    continue
                # find top-level function definitions: line starts at col 0,
                # contains '(', ends with '{' on that or next line
                for i, ln in enumerate(lines):
                    if not ln or ln[0] in " \t#/*}":
                        continue
                    if "(" not in ln:
                        continue
                    mm = FUNC_DEF.match(ln)
                    if not mm:
                        continue
                    sym = mm.group(1)
                    if sym in SKIP_KW:
                        continue
                    # definition (brace on this line or the next non-empty)
                    tail = ln
                    j = i
                    while j + 1 < len(lines) and "{" not in tail and ";" not in tail:
                        j += 1
                        tail += lines[j]
                    if "{" not in tail:
                        continue
                    # measure body span by brace balance
                    depth = 0
                    end = j
                    started = False
                    for k in range(i, min(len(lines), i + 400)):
                        depth += lines[k].count("{") - lines[k].count("}")
                        if "{" in lines[k]:
                            started = True
                        if started and depth <= 0:
                            end = k
                            break
                    body = "\n".join(lines[i:end + 1])
                    has_asm = "__asm__" in body or "asm volatile" in body or "asm(" in body
                    idx[sym].append(
                        {
                            "file": rel,
                            "line_start": i + 1,
                            "line_end": end + 1,
                            "lines": end - i + 1,
                            "has_inline_asm": has_asm,
                            "is_header": fn.endswith(".h"),
                            # src/pc is SOTN's modern re-implementation for the PC
                            # port, NOT a decompiled PSX body -- never a BODY source.
                            "is_pc_reimpl": rel.startswith("src/pc/"),
                        }
                    )
    return idx, True


# ---------------------------------------------------------------- main
def main():
    os.makedirs(OUT, exist_ok=True)
    queue = json.load(open(os.path.join(REPO, "engine/queue.json"), encoding="utf-8"))
    items = queue["items"]

    manifest = list(
        csv.DictReader(
            open(os.path.join(REPO, "docs/naming/libscan/rename_manifest.csv"), encoding="utf-8")
        )
    )
    by_addr = {r["addr"].upper().replace("0X", "0x"): r for r in manifest}
    libsyms = json.load(
        open(os.path.join(REPO, "docs/naming/libscan/libsyms.json"), encoding="utf-8")
    )
    libsyms = {k.upper().replace("0X", "0x"): v for k, v in libsyms.items()}

    addr_map = build_addr_map()
    sotn_idx, sotn_found = index_sotn()

    # confidence tiers: which classifications are dispositive identity claims
    IDENTITY = {
        "CONTRADICTED",
        "CONTRADICTED_ALIAS",
        "FILL",
        "CONFIRM",
        "RESOLVED_RELOC_TARGET",
        "RESOLVED_LAYOUT",
        "RELOC_CHAIN_ID",
    }
    LOCAL_ONLY = {"MODULE_LOCAL_STATIC", "IN_SPAN_NO_SYMBOL"}
    REJECTED = {"REJECTED_UNREACHABLE", "AMBIGUOUS"}

    global AMBIGUOUS_NAME_ADDRS
    AMBIGUOUS_NAME_ADDRS = {"motion_Close": ["0x8001D904", "0x8001D998"]}

    rows = []
    unresolved = []
    for it in items:
        func = it["func"]
        addr = addr_map.get(func)
        note_extra = None
        if addr is None:
            # `motion_Close` is a duplicated Kengo-derived name (two distinct
            # BB2 addresses, docs/naming/reset-wave-dryrun.json). Neither is in
            # a library span, so the census verdict is unambiguous either way.
            cands = AMBIGUOUS_NAME_ADDRS.get(func)
            if cands:
                note_extra = (
                    "ambiguous name -> %s; none in a census module span"
                    % ", ".join(cands)
                    if not any(c in by_addr for c in cands)
                    else "ambiguous name -> %s; SOME land in a module span - resolve by hand"
                    % ", ".join(cands)
                )
            unresolved.append(func)
        row = {
            "func": func,
            "addr": addr,
            "file": it.get("file"),
            "status": it.get("status"),
            "park_reason": it.get("park_reason"),
            "verdict": it.get("verdict"),
            "distance": it.get("distance"),
            "rules": it.get("rules"),
            "census_matched": False,
            "classification": None,
            "lib": None,
            "module": None,
            "mod_start": None,
            "sony_name": None,
            "all_sony_names": None,
            "identity_tier": None,
            "census_note": None,
            "reference": [],
            "reference_status": "none",
            "ledger": None,
            "wip": None,
            "addr_note": note_extra,
        }
        mrow = by_addr.get(addr) if addr else None
        if mrow:
            cls = mrow["classification"]
            row["census_matched"] = cls not in REJECTED
            row["classification"] = cls
            row["lib"] = mrow["lib"]
            row["module"] = mrow["mod"] if "mod" in mrow else mrow.get("module")
            row["mod_start"] = mrow.get("mod_start")
            row["all_sony_names"] = mrow.get("all_sony_names")
            note = (mrow.get("note") or "").strip()
            row["census_note"] = note[:400] or None
            proposed = (mrow.get("proposed_name") or "").strip()
            # the naming wave may already have applied the Sony name to the glabel
            sony = proposed or None
            if not sony:
                syms = libsyms.get(addr, [])
                xdefs = [s for s in syms if s.get("kind") == "xdef"]
                if xdefs:
                    sony = xdefs[0]["name"]
                elif syms:
                    sony = syms[0]["name"]
            if not sony and (mrow.get("all_sony_names") or "").strip():
                cands = mrow["all_sony_names"].split(";")
                if len(cands) == 1:
                    sony = cands[0]
            if not sony and cls in IDENTITY:
                sony = func  # already renamed by the wave
            row["sony_name"] = sony
            if cls in IDENTITY:
                row["identity_tier"] = "EXPORTED_XDEF"
            elif cls in LOCAL_ONLY:
                row["identity_tier"] = "MODULE_LOCAL_STATIC"
            else:
                row["identity_tier"] = "REJECTED"

        # ledger / WIP material
        g = os.path.join(REPO, "memory/grind", func)
        w = os.path.join(REPO, "memory/wip", func)
        if os.path.isdir(g):
            row["ledger"] = sorted(os.listdir(g))[:20]
        if os.path.isdir(w):
            row["wip"] = sorted(os.listdir(w))[:20]

        # reference C lookup
        if row["census_matched"]:
            names = []
            if row["sony_name"]:
                names.append(row["sony_name"])
            if func not in names:
                names.append(func)
            for cand in (row["all_sony_names"] or "").split(";"):
                cand = cand.strip()
                if cand and cand not in names:
                    names.append(cand)
            # a hit whose sotn path is under the SAME library the census
            # names is independent corroboration of the identity claim
            libdir = "src/main/psxsdk/%s/" % (row["lib"] or "").lower()
            hits = []
            for n in names:
                for h in sotn_idx.get(n, []):
                    hh = dict(h)
                    hh["symbol"] = n
                    hh["module_agrees"] = hh["file"].startswith(libdir)
                    hits.append(hh)
            # prefer decompiled PSX bodies (src/main) over the src/pc
            # re-implementation, same-library files over cross-library
            # name collisions, and real .c definitions over header inlines
            hits.sort(
                key=lambda h: (
                    h["is_header"],
                    h["is_pc_reimpl"],
                    not h["module_agrees"],
                    -h["lines"],
                )
            )
            row["reference"] = hits[:4]
            body = [h for h in hits if not h["is_header"] and not h["is_pc_reimpl"]]
            if body:
                row["reference_status"] = (
                    "ASM_BODY" if all(h["has_inline_asm"] for h in body) else "C_BODY"
                )
            elif any(h["is_pc_reimpl"] for h in hits):
                row["reference_status"] = "PC_REIMPL_ONLY"
            elif hits:
                row["reference_status"] = "HEADER_ONLY"
        rows.append(row)

    payload = {
        "generated_by": "tmp/campaign2/xref.py",
        "queue_generated_at": queue.get("generated_at"),
        "oracle_sha1": queue.get("oracle_sha1"),
        "sotn_tree": SOTN if sotn_found else None,
        "sotn_found": sotn_found,
        "queue_total": len(items),
        "unresolved_addresses": unresolved,
        "rows": rows,
    }
    with open(os.path.join(OUT, "xref.json"), "w", encoding="utf-8", newline="\n") as f:
        json.dump(payload, f, indent=1)
        f.write("\n")

    # ------------------------------------------------------------ report
    matched = [r for r in rows if r["census_matched"]]
    exported = [r for r in matched if r["identity_tier"] == "EXPORTED_XDEF"]
    local = [r for r in matched if r["identity_tier"] == "MODULE_LOCAL_STATIC"]
    ready = [
        r
        for r in exported
        if r["reference_status"] == "C_BODY" and r["status"] == "active"
    ]
    ready.sort(key=lambda r: (r["distance"], r["func"]))

    L = []
    A = L.append
    A("# Queue x library-census cross-reference")
    A("")
    A(f"Generated by `tmp/campaign2/xref.py` from `engine/queue.json` "
      f"(generated_at `{queue.get('generated_at')}`), `docs/naming/libscan/*`, "
      f"and the local SOTN tree at `{SOTN}`.")
    A("")
    A("**Analysis only** — no src edits, builds, engine commands, or commits.")
    A("")
    A("## Counts")
    A("")
    A("| bucket | count |")
    A("|---|---|")
    A(f"| queue items total | {len(rows)} |")
    A(f"| active | {sum(1 for r in rows if r['status']=='active')} |")
    A(f"| parked | {sum(1 for r in rows if r['status']=='parked')} |")
    A(f"| census-matched (in a bit-verbatim module span) | {len(matched)} |")
    A(f"| &nbsp;&nbsp;of those: EXPORTED_XDEF (a named Sony function) | {len(exported)} |")
    A(f"| &nbsp;&nbsp;of those: MODULE_LOCAL_STATIC (no exported name) | {len(local)} |")
    A(f"| census-matched WITH a published C body in sotn-decomp | "
      f"{sum(1 for r in matched if r['reference_status']=='C_BODY')} |")
    A(f"| measurement-ready (exported + C body + active) | {len(ready)} |")
    A(f"| queue names whose address could not be resolved | {len(unresolved)} |")
    A("")

    A("## Census-matched items by library")
    A("")
    A("| lib | matched | exported | with C reference |")
    A("|---|---|---|---|")
    libs = sorted({r["lib"] for r in matched})
    for lib in libs:
        sub = [r for r in matched if r["lib"] == lib]
        A(f"| {lib} | {len(sub)} | "
          f"{sum(1 for r in sub if r['identity_tier']=='EXPORTED_XDEF')} | "
          f"{sum(1 for r in sub if r['reference_status']=='C_BODY')} |")
    A("")

    A("## Measurement-ready candidates (ranked by distance ascending)")
    A("")
    A("Exported Sony symbol + an existing compiled-C body in sotn-decomp + still active in the queue.")
    A("Reference C is a **LEAD requiring measurement**, never an assumed match "
      "([[psyq-reference-c-version-skew]]): BB2 links PsyQ 3.5-era modules, SOTN's tree is a "
      "different library version, so a reference body is a starting shape, not an answer.")
    A("")
    A("`lib agrees` = the sotn file sits under the same library directory the census names, i.e. "
      "the reference and the census independently agree on which library this is.")
    A("")
    A("| # | func | addr | dist | rules | verdict | lib/module | Sony sym | reference file | lines | lib agrees |")
    A("|---|---|---|---|---|---|---|---|---|---|---|")
    for i, r in enumerate(ready, 1):
        ref = next((h for h in r["reference"] if not h["is_header"]), None)
        A(f"| {i} | `{r['func']}` | {r['addr']} | {r['distance']} | {r['rules']} | "
          f"{r['verdict']} | {r['lib']}/{r['module']} | `{r['sony_name']}` | "
          f"`{ref['file']}:{ref['line_start']}-{ref['line_end']}` | {ref['lines']} | "
          f"{'yes' if ref['module_agrees'] else 'NO'} |")
    A("")

    A("## Exported census matches with NO published C body")
    A("")
    A("| func | addr | dist | rules | status | lib/module | Sony sym | ref status |")
    A("|---|---|---|---|---|---|---|---|")
    for r in sorted(
        [r for r in exported if r["reference_status"] != "C_BODY"],
        key=lambda r: r["distance"],
    ):
        A(f"| `{r['func']}` | {r['addr']} | {r['distance']} | {r['rules']} | {r['status']} | "
          f"{r['lib']}/{r['module']} | `{r['sony_name']}` | {r['reference_status']} |")
    A("")

    A("## MODULE_LOCAL_STATIC census matches")
    A("")
    A("Inside a bit-verbatim module span, but the OBJ entry is a module-local static rather than an "
      "XDEF, so there is no *exported* name.")
    A("")
    A("The census records the module-local OBJ name as a NOTE, not a naming proposal — a local name "
      "is not an exported claim ([[names-require-evidence]]), so these must NOT be renamed. But for "
      "*reference harvesting* the OBJ name is exactly the lookup key: sotn-decomp decompiled the same "
      "statics under the same names inside the same module file. Where `lib agrees` is yes, the "
      "census module and the sotn file independently agree, which is the same corroboration the "
      "exported rows get.")
    A("")
    A("| # | func | addr | dist | rules | status | lib/module | OBJ-local name | reference file | lines | lib agrees |")
    A("|---|---|---|---|---|---|---|---|---|---|---|")
    local_ranked = sorted(
        local, key=lambda r: (r["reference_status"] != "C_BODY", r["distance"])
    )
    for i, r in enumerate(local_ranked, 1):
        ref = next(
            (h for h in r["reference"] if not h["is_header"] and not h["is_pc_reimpl"]), None
        )
        refs = (
            f"`{ref['file']}:{ref['line_start']}-{ref['line_end']}` | {ref['lines']} | "
            f"{'yes' if ref['module_agrees'] else 'NO'}"
            if ref
            else "— | — | —"
        )
        A(f"| {i} | `{r['func']}` | {r['addr']} | {r['distance']} | {r['rules']} | {r['status']} | "
          f"{r['lib']}/{r['module']} | `{r['sony_name']}` | {refs} |")
    A("")

    parked_ref = [
        r for r in matched if r["status"] == "parked" and r["reference_status"] == "C_BODY"
    ]
    if parked_ref:
        A("## Parked census-matched items that DO have reference C")
        A("")
        A("Flagged for a re-check, not asserted as a wrong call. Each of these was parked "
          "OWNER-ACCEPTED INCOMPLETE with a park reason that cites *no SOTN precedent* — but each "
          "has a decompiled SOTN body for the same library function. The park gate's "
          "\"no SOTN precedent\" almost certainly refers to precedent for the disputed **idiom / "
          "technique**, not to the absence of a reference body, so these are not contradictions on "
          "their face. They are worth re-reading precisely because a reference body is a different "
          "kind of evidence than an idiom precedent, and the reference existing was not part of the "
          "record at park time.")
        A("")
        A("| func | addr | dist | rules | lib/module | reference | park reason |")
        A("|---|---|---|---|---|---|---|")
        for r in sorted(parked_ref, key=lambda r: r["distance"]):
            ref = next(
                (h for h in r["reference"] if not h["is_header"] and not h["is_pc_reimpl"]), None
            )
            reason = (r.get("park_reason") or "").replace("|", "/").replace("\n", " ")
            A(f"| `{r['func']}` | {r['addr']} | {r['distance']} | {r['rules']} | "
              f"{r['lib']}/{r['module']} | `{ref['file']}:{ref['line_start']}-{ref['line_end']}` | "
              f"{reason[:230]} |")
        A("")

    A("## Census / queue disagreements and cautions")
    A("")
    dis = [r for r in rows if r["classification"] in REJECTED]
    if dis:
        for r in dis:
            A(f"- `{r['func']}` ({r['addr']}) — census classification "
              f"**{r['classification']}**; candidates `{r['all_sony_names']}`. "
              f"NOT an identity claim; treat as BB2's own code.")
    else:
        A("- No queue item falls in a census-REJECTED span.")
    A("")
    if unresolved:
        A(f"- {len(unresolved)} queue name(s) had no unique address:")
        for u in unresolved:
            note = next((r["addr_note"] for r in rows if r["func"] == u), None)
            A(f"  - `{u}` — {note or 'no address found in asm/funcs, the name census, or the symbol files'}")
        A("")
    A("- The 2026-08-07 `manifest_report.md` listed 26 queue collisions under the OLD "
      "`func_XXXXXXXX` names. The naming wave has since been applied, so many of those items now "
      "appear in the queue under their Sony names (`MoveImage`, `CdControl`, `prnt`, `sprintf`, …). "
      "Every row in this report is keyed on ADDRESS, so it is immune to that skew — but note that a "
      "future rename would change these pipeline keys again ([[naming-wave-tool]]).")
    A("- splat-derived `D_`/`func_` names carry zero evidence "
      "([[splat-symbol-names-are-not-evidence]]); only census rows count as identity claims here.")
    A("")

    A("## Existing ledger / WIP material on census-matched items")
    A("")
    A("| func | ledger (memory/grind) | wip (memory/wip) |")
    A("|---|---|---|")
    any_mat = False
    for r in matched:
        if r["ledger"] or r["wip"]:
            any_mat = True
            A(f"| `{r['func']}` | {len(r['ledger'] or [])} file(s) | {len(r['wip'] or [])} file(s) |")
    if not any_mat:
        A("| — | none | none |")
    A("")

    with open(os.path.join(OUT, "XREF-REPORT.md"), "w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(L))

    print("census-matched:", len(matched))
    print("exported:", len(exported), "local:", len(local))
    print("measurement-ready:", len(ready))
    print("unresolved:", len(unresolved), unresolved[:20])
    print("sotn:", sotn_found, len(sotn_idx))
    for r in ready[:10]:
        ref = next((h for h in r["reference"] if not h["is_header"]), None)
        print(" ", r["distance"], r["func"], r["lib"] + "/" + r["module"], r["sony_name"],
              ref["file"] + ":" + str(ref["line_start"]))


if __name__ == "__main__":
    main()
