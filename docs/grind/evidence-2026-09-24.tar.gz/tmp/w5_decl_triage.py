#!/usr/bin/env python3
"""Deliverable 4 — per-function declaration triage for the remaining campaign
targets (waves 5-7).

The helper aborts the WHOLE run on the first contradicting function, so "153
blocked" is a per-TU figure, not a per-function one. This computes the real
per-function outcome by running the conversion decision in isolation for each
target, and buckets what remains:

  AUTO         converts today — no declaration needed, or one already exists
  CORROBORATED needs a declaration; probe arity == m2c_context.h arity, so the
               preserved signature is corroborated by an independent source
  HAND         needs a declaration AND the evidence conflicts, or the function
               may take stack-passed arguments the $a3-ceiling probe cannot see

Stack-arg detection: in MIPS o32 incoming arguments 5+ arrive at 16($sp), 20($sp)
… in the CALLER's frame, so a load from >=16($sp) that is not preceded by a store
to the same slot is a strong hint of a 5+-argument function — exactly the blind
spot that makes the arity probe unsafe on its own.

Writes tmp/w5_decl_triage.json. Read-only: no src/, asmfix or queue changes.
"""
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tools"))

from engine import inlineasm
import resplit_convert as rc

MAP = json.load(open("tmp/resplit_map.json"))
CTX = (ROOT / "include/m2c_context.h").read_text(encoding="utf-8", errors="replace")

DONE_WAVES = {0, 1, 2, 3, 4}
SP_LOAD = re.compile(r'\b(lw|lh|lhu|lb|lbu|lwl|lwr)\s+\$\w+,\s*0x([0-9A-Fa-f]+)\(\$sp\)')
SP_STORE = re.compile(r'\b(sw|sh|sb|swl|swr)\s+\$\w+,\s*0x([0-9A-Fa-f]+)\(\$sp\)')


def m2c_arity(func):
    m = re.search(rf'^\s*[\w \t\*]*\b{re.escape(func)}\s*\(([^)]*)\)\s*;', CTX, re.M)
    if not m:
        return None, None
    args = m.group(1).strip()
    return (0 if args in ("", "void") else args.count(",") + 1), m.group(0).strip()


def maybe_stack_args(func):
    """True if the asm LOADS from >=16($sp) without having stored there first —
    a hint of incoming stack-passed arguments (o32 args 5+)."""
    p = ROOT / f"asm/funcs/{func}.s"
    if not p.exists():
        return False
    stored = set()
    for raw in p.read_text(encoding="utf-8").splitlines():
        line = re.sub(r'/\*.*?\*/', ' ', raw)
        for m in SP_STORE.finditer(line):
            stored.add(int(m.group(2), 16))
        for m in SP_LOAD.finditer(line):
            off = int(m.group(2), 16)
            if off >= 0x10 and off not in stored:
                return True
    return False


rows = []
for stem, t in MAP["tus"].items():
    if t.get("wave") in DONE_WAVES:
        continue
    text = (ROOT / f"src/{stem}.c").read_text(encoding="utf-8")
    for fe in t["funcs"]:
        func = fe["func"]
        probe = rc.asm_arity(func)
        stackn = rc.asm_stack_args(func)
        m2c_n, m2c_decl = m2c_arity(func)
        stack = maybe_stack_args(func)
        try:
            rc.convert_source(text, func)
            outcome, reason = "AUTO", "converts today (no declaration required)"
        except SystemExit as e:
            outcome, reason = "BLOCKED", str(e).splitlines()[0]
        if outcome == "BLOCKED":
            if m2c_n is not None and m2c_n == probe and not stack:
                bucket = "CORROBORATED"
            else:
                bucket = "HAND"
        else:
            bucket = "AUTO" if not stack else "AUTO (stack-arg hint, no decl needed)"
        rows.append({
            "func": func, "file": stem, "wave": t.get("wave"),
            "outcome": outcome, "bucket": bucket,
            "probe_arity": probe, "m2c_arity": m2c_n, "m2c_decl": m2c_decl,
            "maybe_stack_args": stack, "stack_args": stackn,
            "canonical": fe["canonical_authorized"],
            "stub_class": fe["stub_class"], "reason": reason,
        })

Path("tmp/w5_decl_triage.json").write_text(json.dumps(rows, indent=2), encoding="utf-8")

from collections import Counter
print(f"remaining campaign targets (waves 5-7): {len(rows)}\n")
print("outcome:", dict(Counter(r["outcome"] for r in rows)))
print("bucket :", dict(Counter(r["bucket"] for r in rows)))
print(f"\ncanonical-authorized among them: {sum(1 for r in rows if r['canonical'])}")
print(f"stack-arg hint (probe ceiling risk): {sum(1 for r in rows if r['maybe_stack_args'])}")

print("\n=== BLOCKED, needing hand verification ===")
for r in rows:
    if r["bucket"] == "HAND":
        print(f"  {r['file']:12s} w{r['wave']} {r['func']:34s} "
              f"probe={r['probe_arity']} m2c={r['m2c_arity']} "
              f"stack={r['maybe_stack_args']}")
        print(f"      m2c: {r['m2c_decl'] or '(none)'}")

print("\n=== BLOCKED, corroborated by m2c (adoptable) ===")
for r in rows:
    if r["bucket"] == "CORROBORATED":
        print(f"  {r['file']:12s} w{r['wave']} {r['func']:34s} "
              f"arity={r['probe_arity']}  {r['m2c_decl']}")
print("\nwrote tmp/w5_decl_triage.json")
