#!/usr/bin/env python3
"""orphan_census.py [files...] -- compile each src TU with -da, and for every
function report vars= plus any combine-orphaned pseudo (bare USE insn) and the
RTL shape of that pseudo's defining insn in the flow dump."""
import os, re, subprocess, sys, glob, shutil

ROOT = os.getcwd()
WORK = "tmp/orph"
CPP = ("mipsel-linux-gnu-cpp -Iinclude -undef -lang-c -fno-builtin -Dmips "
       "-D__GNUC__=2 -D__OPTIMIZE__ -D__mips__ -D__mips -Dpsx -D__psx__ -D__psx "
       "-D_PSYQ -D__EXTENSIONS__ -D_MIPSEL -D_LANGUAGE_C -DLANGUAGE_C ")
CC1 = ("../../tools/gcc-2.7.2/build/cc1 -O2 -G0 -funsigned-char -quiet -mcpu=3000 "
       "-mips1 -mno-abicalls -fno-builtin -w -mel -da base.c -o base.s")
USE_RE = re.compile(r"^\(insn \d+ \d+ \d+ \(use \(reg:\w+ (\d+)\)\)", re.M)


def split_funcs(path):
    out = {}
    if not os.path.exists(path):
        return out
    for p in re.split(r"\n;; Function ", open(path).read())[1:]:
        out[p.split("\n", 1)[0].strip()] = p
    return out


files = sys.argv[1:] or sorted(glob.glob("src/*.c"))
shutil.rmtree(WORK, ignore_errors=True)
os.makedirs(WORK, exist_ok=True)
total = 0
for f in files:
    for old in glob.glob(WORK + "/base.c.*"):
        os.remove(old)
    r = subprocess.run(CPP + f, shell=True, capture_output=True, text=True)
    open(WORK + "/base.c", "w").write(r.stdout)
    subprocess.run(CC1, shell=True, cwd=WORK, capture_output=True, text=True)
    asm = open(WORK + "/base.s").read() if os.path.exists(WORK + "/base.s") else ""
    frames, cur = {}, None
    for ln in asm.splitlines():
        m = re.match(r"\t\.ent\t(\S+)", ln)
        if m:
            cur = m.group(1); continue
        m = re.search(r"\.frame\t\$sp,(\d+),\$31\s+# vars= (\d+)", ln)
        if m and cur:
            frames[cur] = (int(m.group(1)), int(m.group(2))); cur = None
    comb = split_funcs(WORK + "/base.c.combine")
    flow = split_funcs(WORK + "/base.c.flow")
    for fn, seg in comb.items():
        uses = USE_RE.findall(seg)
        if not uses:
            continue
        fr, v = frames.get(fn, (-1, -1))
        for u in uses:
            shape = "?"
            for b in re.split(r"\n\n+", flow.get(fn, "")):
                if re.search(r"^\(insn \d+ \d+ \d+ \(set \(reg[^\n]*[: ]%s\)" % u, b, re.M):
                    shape = " ".join(b.split())[:150]
                    break
            total += 1
            print("%-16s %-26s frame=%-5d vars=%-4d pseudo=%-4s %s"
                  % (os.path.basename(f), fn, fr, v, u, shape), flush=True)
print("## total orphan pseudos: %d over %d files" % (total, len(files)))
