# -*- coding: utf-8 -*-
import json,re,os,collections
root=r"C:/Users/Trenton/Desktop/Bushido Blade 2 Decompile"
rows=json.load(open(os.path.join(root,"tmp/killed_rows.json"),encoding='utf-8'))
seen=set(); keep=[]
for fn,base,f,ln,txt in rows:
    t=re.sub(r"\s+"," ",txt).strip()
    t=re.sub(r"^\*\*|\*\*$","",t)
    if len(t)<45: continue
    if t.lower().startswith(("artifacts:","banked ","see ","full log")): continue
    key=(fn,t[:110].lower())
    if key in seen: continue
    seen.add(key)
    if len(t)>230: t=t[:227].rstrip()+"..."
    keep.append((fn,base,f,ln,t))
keep.sort(key=lambda r:(r[0],r[3]))
byfunc=collections.OrderedDict()
for r in keep: byfunc.setdefault(r[0],[]).append(r)
out=[]
out.append("# KILLED_INDEX — cross-function graveyard of measured-dead levers")
out.append("")
out.append("Mechanically extracted from the `## KILLED` / `verdict: KILLED` sections of every")
out.append("`memory/grind/<func>/hypotheses.md`, `memory/wip/<func>/hypotheses.md` and `notes.md`")
out.append("in the tree (generator: `tmp/killed_index.py` + `tmp/mk_killed.py`; read-only sweep).")
out.append("")
out.append("**Contract:** before proposing a lever on ANY function, grep this file for the lever")
out.append("name. A hit means the lever was already MEASURED dead somewhere — read the cited")
out.append("ledger line before spending a session re-deriving it. A hit on a DIFFERENT function")
out.append("is a warning, not a verdict: kills are often mechanism-class (RA/sched/CSE walls that")
out.append("recur across the file), but some are shape-specific.")
out.append("")
out.append("Format: `- lever/finding  [<func>/<file>:<line>]`")
out.append("")
out.append("Totals: %d kills across %d functions." % (len(keep), len(byfunc)))
out.append("")
for fn,rs in byfunc.items():
    out.append("## %s  (%d)" % (fn,len(rs)))
    for (_,base,f,ln,t) in rs:
        out.append("- %s  [memory/%s/%s/%s:%d]" % (t,base,fn,f,ln))
    out.append("")
open(os.path.join(root,"tmp/staged_rules/KILLED_INDEX.md"),"w",encoding='utf-8').write("\n".join(out))
print("kept",len(keep),"funcs",len(byfunc))
