#!/usr/bin/env python3
"""Read-only survey: every `load; <label>; consumer` site in the TARGET asm.

The maspsx .L-label blind spot (maspsx-label-nop-gate) drops the load-delay nop
when a label sits between a load and its consumer. maspsx_label_nop_funcs.txt
re-enables it per function. The rule's endgame (maspsx-gate-lists.md item 1)
allows globalizing the fix once index-anchored regfix rules are gone -- they are
(regfix.txt/asmfix.txt ABSENT since 2026-08-25) -- but ONLY after confirming the
1998 assembler behaved uniformly.

Falsifier: any site where the target LACKS the nop. Those would prove ASPSX did
NOT always insert it, and a global fix would corrupt them.

Read-only. Touches nothing.
"""
import re, sys, glob, os, json
from collections import defaultdict

LOADS = {'lw','lh','lhu','lb','lbu','lwl','lwr','lwc1','lwc2','ldc1','ldc2','ll'}
STORES = {'sw','sh','sb','swl','swr','swc1','swc2','sdc1','sdc2','sc'}
BRANCHES = {'beq','bne','beqz','bnez','blez','bgtz','bltz','bgez','bltzal','bgezal',
            'beql','bnel','blezl','bgtzl','bltzl','bgezl','b','j','jr','jal','jalr'}

INSN = re.compile(r'^\s*/\*\s*[0-9A-Fa-f]+\s+([0-9A-Fa-f]+)\s+[0-9A-Fa-f]+\s*\*/(\s+)(\S+)\s*(.*?)\s*$')
LABEL = re.compile(r'^\s*(\.?L[0-9A-Fa-f_]+|\w+):\s*$')
REG = re.compile(r'\$(\w+)')

def regs(s):
    return REG.findall(s)

def sources(mnem, ops):
    """Registers READ by this instruction."""
    if not ops:
        return []
    parts = [p.strip() for p in ops.split(',')]
    if mnem in BRANCHES:
        return regs(ops)
    if mnem in STORES:
        return regs(ops)          # value reg AND base reg are both read
    if mnem in LOADS:
        # first operand is dest; base register inside parens is read
        m = re.search(r'\(([^)]*)\)', ops)
        return regs(m.group(1)) if m else []
    # generic ALU: first operand is dest, rest are sources
    return regs(','.join(parts[1:])) if len(parts) > 1 else []

def dest(mnem, ops):
    if not ops:
        return None
    if mnem in BRANCHES or mnem in STORES:
        return None
    parts = [p.strip() for p in ops.split(',')]
    r = regs(parts[0])
    return r[0] if r else None

def main():
    has_nop, lacks_nop = [], []
    delayslot_skipped = 0

    for path in sorted(glob.glob('asm/funcs/*.s')):
        func = os.path.basename(path)[:-2]
        try:
            lines = open(path, 'r', encoding='utf-8', errors='replace').read().split('\n')
        except OSError:
            continue

        # Build an ordered stream: ('i', indent, mnem, ops, lineno) / ('l', name, lineno)
        stream = []
        for n, ln in enumerate(lines, 1):
            m = INSN.match(ln)
            if m:
                stream.append(('i', m.group(2), m.group(3), m.group(4), n))
                continue
            m = LABEL.match(ln)
            if m:
                stream.append(('l', m.group(1), n))

        for idx, item in enumerate(stream):
            if item[0] != 'i':
                continue
            _, indent, mnem, ops, lineno = item
            if mnem not in LOADS:
                continue
            d = dest(mnem, ops)
            if not d:
                continue
            # a load sitting IN a delay slot is indented one extra space by splat
            if len(indent) > 2:
                delayslot_skipped += 1
                continue
            # must be followed immediately by a label
            if idx + 1 >= len(stream) or stream[idx+1][0] != 'l':
                continue
            label = stream[idx+1][1]
            if idx + 2 >= len(stream) or stream[idx+2][0] != 'i':
                continue
            nxt = stream[idx+2]
            site = dict(func=func, line=lineno, label=label,
                        load=f'{mnem} {ops}', dest=d)
            if nxt[2] == 'nop':
                # nop present -- confirm the instruction after it actually consumes d
                if idx + 3 < len(stream) and stream[idx+3][0] == 'i':
                    c = stream[idx+3]
                    if d in sources(c[2], c[3]):
                        site['consumer'] = f'{c[2]} {c[3]}'
                        has_nop.append(site)
            else:
                if d in sources(nxt[2], nxt[3]):
                    site['consumer'] = f'{nxt[2]} {nxt[3]}'
                    lacks_nop.append(site)

    gated = set()
    for ln in open('maspsx_label_nop_funcs.txt', encoding='utf-8'):
        ln = ln.strip()
        if ln and not ln.startswith('#'):
            gated.add(ln)

    print('=' * 72)
    print('TARGET-ASM SURVEY: load -> label -> consumer sites')
    print('=' * 72)
    print(f'functions scanned      : {len(glob.glob("asm/funcs/*.s"))}')
    print(f'sites WITH nop         : {len(has_nop)}   (consistent with uniform ASPSX)')
    print(f'sites WITHOUT nop      : {len(lacks_nop)}   <-- FALSIFIERS')
    print(f'delay-slot loads skipped: {delayslot_skipped}')
    print()

    fns_has = defaultdict(int)
    for s in has_nop:
        fns_has[s['func']] += 1
    print(f'--- {len(fns_has)} distinct functions have >=1 nop-present site ---')
    print(f'    of these, currently gated: {len(set(fns_has) & gated)} / {len(gated)} listed')
    ungated = sorted(set(fns_has) - gated)
    print(f'    UNGATED but nop-present  : {len(ungated)}')
    for f in ungated[:40]:
        print(f'      {f} ({fns_has[f]} site(s))')
    if len(ungated) > 40:
        print(f'      ... +{len(ungated)-40} more')
    print()

    if lacks_nop:
        print('!!! FALSIFIERS -- target lacks the nop at these sites !!!')
        for s in lacks_nop:
            print(f"  {s['func']}:{s['line']}  {s['load']}  |{s['label']}|  {s['consumer']}")
    else:
        print('NO FALSIFIERS FOUND -- every such site in the target carries the nop.')

    json.dump({'has_nop': has_nop, 'lacks_nop': lacks_nop},
              open('tmp/label_nop_survey.json', 'w'), indent=1)
    print('\nfull detail -> tmp/label_nop_survey.json')

main()
