#!/usr/bin/env python3
"""Independent resolver for the data-symbol naming wave (verifier, 2026-09-07).

Written from the OBJ format, NOT a copy of tmp/near_audit/data_web.py. Differences:
  * every placement is re-checked as verbatim against the EXE (reloc words masked) -- a
    misplaced module would resolve garbage addresses;
  * HI16/LO16 pairing: LO16 pairs with the most recent HI16 for the same base symbol
    (rule A); an alternative rule B (most recent HI16 of any symbol) is also run and any
    disagreement is reported;
  * instruction opcodes at each reloc site are checked (HI16 must be lui);
  * the REL26 (jal) relocations are also resolved so the module's function-call web
    provides a second proof the placement is right;
  * results are compared with the manifest row-by-row.
"""
import csv, json, os, re, struct, sys, glob
from collections import defaultdict
REPO = "/mnt/c/Users/Trenton/Desktop/Bushido Blade 2 Decompile"
sys.path.insert(0, os.path.join(REPO, "tmp", "closer"))
from psyq_lib import lib_modules, parse_obj  # noqa

exe = open(os.path.join(REPO, "disc", "SLUS_006.63"), "rb").read()
TEXT_VA = struct.unpack_from("<I", exe, 0x18)[0]
BODY = exe[0x800:]
def word(va): return struct.unpack_from("<I", BODY, va - TEXT_VA)[0]
LO, HI = 0x80078948, 0x8008D070   # library span of the EXE

ACCEPT = {"CONFIRM", "FILL", "CONTRADICTED", "CONTRADICTED_ALIAS", "MODULE_LOCAL_STATIC", "IN_SPAN_NO_SYMBOL"}
placements = {}
for r in csv.DictReader(open(os.path.join(REPO, "docs/naming/libscan/rename_manifest.csv"), encoding="utf-8", errors="replace")):
    if r["classification"] in ACCEPT and r["lib"] != "LIBGS":
        ms = int(r["mod_start"], 16)
        if LO <= ms < HI:
            placements[(r["lib"], r["module"])] = ("40J", ms)
placements[("LIBSND", "SSSTOP")] = ("40U", 0x80085270)
M = json.load(open(os.path.join(REPO, "tmp/libscan/matches.json")))
extra = 0
for r in M["results"]:
    if r.get("status") == "verbatim" and r["lib"] != "LIBGS" and r.get("words", 0) >= 24:
        vas = [int(v, 16) for v in r["vaddrs"] if LO <= int(v, 16) < HI]
        if len(vas) == 1 and (r["lib"], r["mod"]) not in placements:
            placements[(r["lib"], r["mod"])] = ("40J", vas[0]); extra += 1
LIBDIR = {"40J": os.path.join(REPO, "tmp/libscan/psyq40"), "40U": os.path.join(REPO, "tmp/libsnd_hunt/psyq40u")}
print(f"placements: {len(placements)} ({extra} from matches.json single-placement rule)")

EXPR = re.compile(r"^\(?(?:(0x[0-9a-f]+)\+)?sym:(\w+)\)?$")
def sx16(v): return v - 0x10000 if v >= 0x8000 else v

resA = defaultdict(lambda: defaultdict(set))   # name -> addr -> modules (rule A)
resB = defaultdict(lambda: defaultdict(set))   # rule B
offsets = defaultdict(lambda: defaultdict(set))  # name -> off -> modules
opcode_bad = []
verbatim = {}
jal_targets = defaultdict(set)
libcache = {}
missing = []
for (lib, mod), (ver, base) in sorted(placements.items()):
    p = os.path.join(LIBDIR[ver], lib + ".LIB")
    if p not in libcache:
        libcache[p] = dict(lib_modules(open(p, "rb").read()))
    if mod not in libcache[p]:
        missing.append((lib, mod)); continue
    o = parse_obj(libcache[p][mod])
    tsid = next((sid for sid, s in o.sections.items() if s["name"] == ".text"), None)
    if tsid is None:
        continue
    text = o.sections[tsid]["bytes"]
    rl = [x for x in o.relocs if x[0] == tsid]
    # verbatim check with reloc words masked
    masks = {}
    for _, t, roff, e in rl:
        w = roff & ~3
        if t in (82, 84): masks[w] = masks.get(w, 0) | 0xFFFF
        elif t == 74: masks[w] = masks.get(w, 0) | 0x03FFFFFF
        elif t == 16: masks[w] = 0xFFFFFFFF
        else: masks[w] = 0xFFFFFFFF
    bad = 0
    for i in range(0, len(text) - 3, 4):
        a = struct.unpack_from("<I", text, i)[0]
        b = word(base + i)
        mk = ~masks.get(i, 0) & 0xFFFFFFFF
        if (a & mk) != (b & mk): bad += 1
    verbatim[(lib, mod)] = (len(text) // 4, bad)
    tag = f"{lib}/{mod}@0x{base:08X}"
    lastA = {}; lastB = None
    for _, t, roff, e in sorted(rl, key=lambda x: x[2]):
        e2 = re.sub(r"sym:(\d+)", lambda m: "sym:" + str(o.xrefs.get(int(m.group(1)), m.group(1))), e)
        m = EXPR.match(e2)
        if not m:
            continue
        off = int(m.group(1), 16) if m.group(1) else 0
        name = m.group(2)
        w = word(base + roff)
        op = w >> 26
        if t == 82:
            if op != 0x0F: opcode_bad.append((tag, roff, "HI16 not lui", hex(w)))
            lastA[name] = w & 0xFFFF; lastB = (name, w & 0xFFFF)
        elif t == 84:
            if op not in (0x09, 0x0D, 0x20, 0x21, 0x23, 0x24, 0x25, 0x28, 0x29, 0x2B, 0x22, 0x26, 0x2A, 0x2E, 0x31, 0x39, 0x32, 0x3A):
                opcode_bad.append((tag, roff, "LO16 odd opcode", hex(w)))
            lo = sx16(w & 0xFFFF)
            if name in lastA:
                resA[name][((lastA[name] << 16) + lo - off) & 0xFFFFFFFF].add(tag)
                offsets[name][off].add(tag)
            else:
                opcode_bad.append((tag, roff, f"LO16 for {name} with no prior HI16", hex(w)))
            if lastB is not None:
                resB[name][((lastB[1] << 16) + lo - off) & 0xFFFFFFFF].add(tag + ("" if lastB[0] == name else f"(hi of {lastB[0]})"))
        elif t == 74:
            tgt = ((w & 0x03FFFFFF) << 2) | (base & 0xF0000000)
            jal_targets[name].add(tgt - off)

print("missing modules:", missing)
nonverb = {k: v for k, v in verbatim.items() if v[1]}
print("non-verbatim placements (words, mismatches):", nonverb)
print("opcode/pairing anomalies:", len(opcode_bad))
for x in opcode_bad[:40]: print("  ", x)

# registry
SYMS = defaultdict(list)
for f in ("named_syms.txt", "symbol_addrs.txt", "undefined_syms_auto.txt"):
    for ln in open(os.path.join(REPO, f), encoding="utf-8", errors="replace"):
        mm = re.match(r"\s*([A-Za-z_]\w*)\s*=\s*(0x[0-9A-Fa-f]+)", ln)
        if mm: SYMS[int(mm.group(2), 16)].append((mm.group(1), f))
# link map (C-defined objects)
MAP = defaultdict(list)
for ln in open(os.path.join(REPO, "build/bb2.map"), encoding="utf-8", errors="replace"):
    mm = re.match(r"\s*(0x[0-9a-fA-F]{8,16})\s+([A-Za-z_]\w*)\s*$", ln)
    if mm: MAP[int(mm.group(1), 16) & 0xFFFFFFFF].append(mm.group(2))

ambig = {n: {f"0x{a:08X}": sorted(v) for a, v in d.items()} for n, d in resA.items() if len(d) != 1}
print("rule-A ambiguous names:", json.dumps(ambig, indent=1) if ambig else "none")
disagree = {}
for n in resA:
    a = set(resA[n]); b = set(resB.get(n, {}))
    if a != b: disagree[n] = (sorted(f"0x{x:08X}" for x in a), sorted(f"0x{x:08X}" for x in b))
print("rule A vs rule B disagreements:", json.dumps(disagree, indent=1) if disagree else "none")
print("jal-target names with >1 address:", {n: sorted(hex(x) for x in s) for n, s in jal_targets.items() if len(s) > 1} or "none")

# compare with manifest
rows = list(csv.DictReader(open(os.path.join(REPO, "tmp/naming-wave-2026-09/stage/docs/naming/libscan/data_manifest.csv"), encoding="utf-8", errors="replace")))
report = []
for r in rows:
    addr = int(r["addr"], 16); prop = r["proposed_name"]; kind = r["kind"]
    if kind == "base":
        got = resA.get(prop)
        if not got: status = "NOT RESOLVED BY MY RESOLVER"
        elif len(got) != 1: status = "AMBIGUOUS " + ",".join(f"0x{a:08X}" for a in got)
        else:
            a = next(iter(got)); status = ("MATCH" if a == addr else f"MISMATCH resolver=0x{a:08X}") + f" mods={len(got[a])} offs={sorted(hex(o) for o in offsets[prop])}"
        basename, off = prop, 0
    else:
        m = re.match(r"^(.*)_plus_0x([0-9A-Fa-f]+)$", prop)
        basename, off = m.group(1), int(m.group(2), 16)
        got = resA.get(basename)
        if not got or len(got) != 1: status = "BASE UNRESOLVED"
        else:
            a = next(iter(got))
            mods = offsets[basename].get(off, set())
            status = ("MATCH" if a + off == addr else f"MISMATCH base+off=0x{a+off:08X}") + f" refs={len(mods)} by {sorted(mods)}"
    regs = SYMS.get(addr, [])
    regnames = [n for n, _ in regs]
    cur = [c for c in r["current_names"].split(";") if c]
    reg_ok = all(c in regnames or c in MAP.get(addr, []) for c in cur)
    report.append(dict(addr=r["addr"], proposed=prop, kind=kind, resolver=status, current=cur,
                       registry=[f"{n}@{f}" for n, f in regs], linkmap=MAP.get(addr, []), current_all_defined_here=reg_ok,
                       skip=r.get("verdict") == "SKIP"))
json.dump(report, open(os.path.join(REPO, "tmp/naming-wave-2026-09/verify/resolver_rows.json"), "w"), indent=1)
json.dump({n: {f"0x{a:08X}": sorted(v) for a, v in d.items()} for n, d in resA.items()},
          open(os.path.join(REPO, "tmp/naming-wave-2026-09/verify/resolver_all.json"), "w"), indent=1)
for x in report:
    print(f"{x['addr']} {x['proposed']:32s} {x['kind']:6s} {x['resolver']}")
    print(f"      current={x['current']} registry={x['registry']} map={x['linkmap']} all_defined_here={x['current_all_defined_here']}")
print("names resolved total:", len(resA))
