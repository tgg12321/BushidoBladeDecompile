#!/usr/bin/env bash
# post-apply checks: m2c header fix, census regen, integrity audit, residual audit, CRLF check
set -uo pipefail
cd "/mnt/c/Users/Trenton/Desktop/Bushido Blade 2 Decompile"
source .venv/bin/activate
python3 - <<'PY'
import json,re
m=json.load(open('tmp/naming-wave-2026-09/wave_applied.json'))
pairs=[(o,op['new_name']) for op in m['ops'] for o in op['old_names']]
p='include/m2c_context.h'; s=open(p,encoding='utf-8',errors='surrogateescape').read(); n=0
for old,new in pairs:
    s,k=re.subn(r'\b'+re.escape(old)+r'\b',new,s); n+=k
open(p,'w',encoding='utf-8',errors='surrogateescape',newline='\n').write(s); print('m2c_context.h substitutions:',n)
PY
echo "--- census regen"; python3 docs/naming/build_census.py 2>&1 | tail -3
echo "--- integrity"; python3 tools/check_completion_integrity.py 2>&1 | tail -4
echo "--- census dry-run (expect 0 pending RENAME for our rows)"; python3 tools/naming_wave.py --from-census 2>&1 | tail -4
echo "--- residual grep"
grep -rn -w -E 'special_camera_get_rot_dir|rcnt0_AckEvents|pad_file_read_init_80037B90|g_memcard_file_handle_a|g_rcnt0_event_ioe|obj_helper_8005B43C|bios_helper_8003A174' src include named_syms.txt symbol_addrs.txt asm/funcs tools engine --include='*.c' --include='*.h' --include='*.s' --include='*.txt' --include='*.py' --include='*.json' 2>/dev/null | grep -v 'rename_funcs.py' | grep -v '/\*' | head -5
echo "--- CRLF check on changed files"
git diff --name-only | while read -r f; do [ -f "$f" ] && grep -lU $'\r' "$f"; done | head
echo "--- done"
