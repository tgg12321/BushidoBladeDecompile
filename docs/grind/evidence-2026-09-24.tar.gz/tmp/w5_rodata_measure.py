#!/usr/bin/env python3
"""Deliverable 3 — MEASURE what each non-.text emitter's discarded body
contributes to its object today.

asmfix's replace_with_asmfile substitutes only the FUNCTION BLOCK
(`<func>:` .. `.end <func>`). Anything cc1 emitted OUTSIDE that block — a
switch's jump table in .rodata, string literals — is NOT replaced and is still
in the object today. Converting the function to INCLUDE_ASM removes the body
entirely, so those bytes disappear and every later rodata symbol in the object
shifts. That is campaign risk R3.

Builds each TU twice into tmp/ (never build/): as-is, and with the function
converted in memory. Compares per-section sizes. No tracked file is modified.
"""
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tools"))

from engine import inlineasm, pipeline, cheats
import resplit_convert as rc

TARGETS = [("code6cac", "cpu_check_run_attack"),
           ("main", "func_80089F3C"),
           ("main", "SetPacketData")]

WD = Path("tmp/w5_rodata")
WD.mkdir(parents=True, exist_ok=True)


def sections(o_path):
    r = subprocess.run(["mipsel-linux-gnu-objdump", "-h", str(o_path)],
                       capture_output=True, text=True)
    out = {}
    for m in re.finditer(r'^\s*\d+\s+(\S+)\s+([0-9a-f]{8})', r.stdout, re.M):
        out[m.group(1)] = int(m.group(2), 16)
    return out


def build(stem, src_override=None, tag="base"):
    o = WD / f"{stem}.{tag}.o"
    ov = {"src_override": src_override} if src_override else None
    pipeline.build_c_object(stem, str(o), cheat_overrides=ov)
    return o


for stem, func in TARGETS:
    print(f"########## {func}  (src/{stem}.c) ##########")
    base_o = build(stem, None, "base")
    base = sections(base_o)

    text = (ROOT / f"src/{stem}.c").read_text(encoding="utf-8")
    conv, _body = rc.convert_source(text, func)
    ovr = WD / f"{stem}.{func}.c"
    with open(ovr, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(conv)
    conv_o = build(stem, str(ovr), f"conv_{func}")
    after = sections(conv_o)

    for sec in sorted(set(base) | set(after)):
        b, a = base.get(sec, 0), after.get(sec, 0)
        if b != a:
            print(f"    {sec:12s} {b:>8} -> {a:>8}   delta {a - b:+d}")
    if all(base.get(s, 0) == after.get(s, 0) for s in set(base) | set(after)):
        print("    no section-size change")
    print()
