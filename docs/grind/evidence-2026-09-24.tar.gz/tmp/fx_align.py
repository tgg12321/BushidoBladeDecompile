#!/usr/bin/env python3
"""Align shipped vs mixed simplify_rtx disassembly.

Normalisation: self-branch targets become the *instruction index* they land on
(so a uniform code-size shift is invisible), rip-relative and foreign call
targets become their symbol name.
"""
import re, difflib, sys
T = "/mnt/c/Users/Trenton/Desktop/Bushido Blade 2 Decompile/tmp/fx"

def load(tag):
    raw = []
    for ln in open(f"{T}/dis.{tag}.raw"):
        m = re.match(r'\s*([0-9a-f]+):\s+((?:[0-9a-f]{2} )+)\s*(.*)$', ln.rstrip("\n"))
        if not m:
            continue
        raw.append((int(m.group(1), 16), m.group(3).rstrip()))
    addr2idx = {a: i for i, (a, _) in enumerate(raw)}
    out = []
    for a, text in raw:
        n = text
        m = re.search(r'<([A-Za-z_][A-Za-z0-9_.]*)(\+0x[0-9a-f]+)?>', n)
        sym = m.group(1) if m else None
        n = re.sub(r'#.*$', '', n).strip()
        n = re.sub(r'0x[0-9a-f]+\(%rip\)', f'RIP[{sym}]', n)
        m2 = re.match(r'^(\S+)\s+([0-9a-f]+)\s+<([A-Za-z_][A-Za-z0-9_.]*)(\+0x[0-9a-f]+)?>$', text.strip())
        if m2:
            mn, tgt, tsym = m2.group(1), int(m2.group(2), 16), m2.group(3)
            if tsym == 'simplify_rtx':
                n = f"{mn} SELF"
            else:
                n = f"{mn} <{tsym}>"
        out.append((n, f"{a:x}: {text}"))
    return out

A = load("shipped"); B = load("mixed")
an = [x[0] for x in A]; bn = [x[0] for x in B]
sm = difflib.SequenceMatcher(None, an, bn, autojunk=False)
blocks = [op for op in sm.get_opcodes() if op[0] != 'equal']
print(f"shipped={len(an)} mixed={len(bn)}  divergent hunks={len(blocks)}")
CTX = 10
for k, (tag, i1, i2, j1, j2) in enumerate(blocks):
    print(f"\n===== HUNK {k} [{tag}] shipped[{i1}:{i2}] (-{i2-i1}) mixed[{j1}:{j2}] (+{j2-j1}) =====")
    for x in range(max(0, i1-CTX), i1):
        print("     ", A[x][1])
    for x in range(i1, i2):
        print("  -  ", A[x][1], "   ||", A[x][0])
    for x in range(j1, j2):
        print("  +  ", B[x][1], "   ||", B[x][0])
    for x in range(i2, min(len(A), i2+CTX)):
        print("     ", A[x][1])
