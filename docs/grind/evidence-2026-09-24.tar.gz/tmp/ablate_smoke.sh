cd "/mnt/c/Users/Trenton/Desktop/Bushido Blade 2 Decompile" && source .venv/bin/activate
python3 tools/fake_ablate.py --func func_80033550 --file code6cac_b --candidate memory/grind/func_80033550/candidate.c
echo "--- src status:"; git status --short src/
echo "=== CD_sync"
python3 tools/fake_ablate.py --func CD_sync --file system --candidate memory/grind/CD_sync/candidate.c
echo "--- src status:"; git status --short src/
