#!/usr/bin/env python3
"""Pull the canonical-gate's definitive-signal reasons (from build/bb2.elf
objdump) for the 154 census functions. Read-only; no build."""
import json, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from engine import canonical as C

q = json.load(open(ROOT / "engine" / "queue.json"))
targets = [i for i in q["items"]
           if i["status"] == "active" and i["verdict"] in ("ASM-SUSPECT", "ASM-PARTIAL")]
out = {}
for it in targets:
    try:
        v = C.classify(it["func"], distance=it["distance"])
    except Exception as e:
        out[it["func"]] = {"error": str(e)}
        continue
    out[it["func"]] = {
        "verdict": v.get("verdict"),
        "reasons": v.get("reasons", []),
        "asm_insns": v.get("asm_insns", 0),
        "total": v.get("total", 0),
        "regions": v.get("regions", []),
        "hand_coded_tier": v.get("hand_coded_tier"),
    }
json.dump(out, open(ROOT / "tmp" / "gate_reasons.json", "w"), indent=1)
from collections import Counter
print(Counter(tuple(v.get("reasons", [])) for v in out.values()))
print(Counter(v.get("hand_coded_tier") for v in out.values()))
