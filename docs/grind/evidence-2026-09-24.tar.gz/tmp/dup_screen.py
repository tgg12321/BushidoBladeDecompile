#!/usr/bin/env python3
"""Census screen for dup_if_else_arm operative property in SOTN PSX (US) scope.

Property: identical statement as the LAST top-level statement of BOTH arms of an
if/else (unconditional common tail, hoistable below the join).

Scans every .c file belonging to the US PSX build (from config/splat.us.*.yaml
at pin aa53500), at the pin, brace-aware. PSP-only preprocessor regions are
blanked. Survivors get manual verification afterwards.
"""
import re, subprocess, sys, json
from collections import defaultdict

PIN = "aa53500226ee84be763f3e8702b27de06456b3a7"
SOTN = "C:/Users/Trenton/Desktop/sotn-decomp"
INDEX = "C:/Users/Trenton/Desktop/Bushido Blade 2 Decompile/docs/reference/sotn-construct-index.md"

def git_show(path):
    r = subprocess.run(["git", "-C", SOTN, "show", f"{PIN}:{path}"],
                       capture_output=True)
    if r.returncode != 0:
        return None
    return r.stdout.decode("utf-8", errors="replace")

# ---------- 1. index entries ----------
def parse_index():
    lines = open(INDEX, encoding="utf-8").read().splitlines()
    start = next(i for i, l in enumerate(lines) if l.startswith("## Duplicated statement in both if/else arms"))
    entries = []
    for l in lines[start+1:]:
        if l.startswith("## "):
            break
        m = re.match(r"- `([^:`]+):(\d+)` - `(.*?)` - statement", l)
        if m:
            entries.append((m.group(1), int(m.group(2)), m.group(3)))
    return entries

# ---------- 2. PSX file set ----------
def psx_files():
    ls = subprocess.run(["git", "-C", SOTN, "show", f"{PIN}:config/"],
                        capture_output=True, text=True).stdout.split()
    cfgs = [c for c in ls if re.match(r"splat\.us\..*\.yaml$", c)]
    files, unresolved = set(), []
    for cfg in cfgs:
        txt = git_show(f"config/{cfg}")
        sp = re.search(r"src_path:\s*(\S+)", txt).group(1)
        for m in re.finditer(r"\[\s*0x[0-9A-Fa-f]+\s*,\s*c\s*,\s*([^\],\s]+)\s*\]", txt):
            path = f"{sp}/{m.group(1)}.c"
            files.add(path)
    return sorted(files)

# ---------- 3. preprocessing ----------
def strip_comments_strings(text):
    out, i, n = [], 0, len(text)
    while i < n:
        c = text[i]
        if c == "/" and i+1 < n and text[i+1] == "*":
            j = text.find("*/", i+2)
            j = n if j < 0 else j+2
            out.append(re.sub(r"[^\n]", " ", text[i:j])); i = j
        elif c == "/" and i+1 < n and text[i+1] == "/":
            j = text.find("\n", i)
            j = n if j < 0 else j
            out.append(" "*(j-i)); i = j
        elif c in "\"'":
            q, j = c, i+1
            while j < n and text[j] != q:
                if text[j] == "\\": j += 1
                j += 1
            j = min(j+1, n)
            out.append(q + " "*(j-i-2) + (q if j-i >= 2 else "")); i = j
        else:
            out.append(c); i += 1
    return "".join(out)

def blank_psp_regions(lines):
    """Blank PSP-only lines; blank directive lines; return (lines, spans_flag).
    Conditions handled: VERSION_PSP ifdef/ifndef/defined; #if 0. Others kept."""
    PSPPOS = re.compile(r"#\s*if(def)?\s*.*VERSION_PSP|#\s*if\s+defined\s*\(\s*VERSION_PSP")
    NEG = re.compile(r"#\s*ifndef\s+VERSION_PSP|#\s*if\s+!\s*defined\s*\(\s*VERSION_PSP")
    stack = []  # each: 'psp' (blank current branch), 'psx' (keep), 'other'
    out = []
    directive_lines = set()
    for idx, l in enumerate(lines):
        s = l.strip()
        if s.startswith("#"):
            directive_lines.add(idx)
            if re.match(r"#\s*(if|ifdef|ifndef)\b", s):
                if NEG.search(s): stack.append("psx")
                elif PSPPOS.search(s): stack.append("psp")
                elif re.match(r"#\s*if\s+0\b", s): stack.append("psp")
                else: stack.append("other")
            elif re.match(r"#\s*else\b", s) or re.match(r"#\s*elif\b", s):
                if stack:
                    stack[-1] = {"psp": "psx", "psx": "psp"}.get(stack[-1], "other")
            elif re.match(r"#\s*endif\b", s):
                if stack: stack.pop()
            out.append(" "*len(l))
            continue
        if "psp" in stack:
            out.append(" "*len(l))
        else:
            out.append(l)
    return out, directive_lines

# ---------- 4. if/else scanner ----------
KW = re.compile(r"\bif\s*\(")
TRIVIAL = re.compile(r"^(break|continue|return|goto\s+\w+)\s*;?$")

def match_paren(t, i):
    d = 0
    while i < len(t):
        if t[i] == "(": d += 1
        elif t[i] == ")":
            d -= 1
            if d == 0: return i
        i += 1
    return -1

def match_brace(t, i):
    d = 0
    while i < len(t):
        if t[i] == "{": d += 1
        elif t[i] == "}":
            d -= 1
            if d == 0: return i
        i += 1
    return -1

def skip_ws(t, i):
    while i < len(t) and t[i].isspace(): i += 1
    return i

def norm(s):
    return re.sub(r"\s+", " ", s).strip()

def top_level_units(body):
    """Split braced-arm body into top-level statements."""
    units, cur, pd, bd = [], [], 0, 0
    i = 0
    while i < len(body):
        c = body[i]
        cur.append(c)
        if c == "(": pd += 1
        elif c == ")": pd -= 1
        elif c == "{": bd += 1
        elif c == "}":
            bd -= 1
            if bd == 0 and pd == 0:
                # end of a block; check for trailing 'while(...)' (do-while) or 'else'
                j = skip_ws(body, i+1)
                if body[j:j+4] == "else" or (body[j:j+5] == "while" ):
                    pass  # continue same unit
                else:
                    units.append("".join(cur)); cur = []
        elif c == ";" and pd == 0 and bd == 0:
            units.append("".join(cur)); cur = []
        i += 1
    tail = "".join(cur).strip()
    if tail: units.append(tail)
    return [u.strip() for u in units if u.strip()]

def scan_file(path, text):
    text = strip_comments_strings(text)
    lines = text.split("\n")
    lines, _ = blank_psp_regions(lines)
    t = "\n".join(lines)
    hits = []
    for m in KW.finditer(t):
        # ensure 'if' is not part of identifier (KW \b handles) and not 'else if' -> still fine, scanned as its own construct
        p0 = t.index("(", m.end()-1)
        p1 = match_paren(t, p0)
        if p1 < 0: continue
        i = skip_ws(t, p1+1)
        if i >= len(t) or t[i] != "{":
            continue  # single-statement if-arm: cannot hold a multi-stmt tail; if/else single-stmt identical arms would be nonsense (whole arms identical) - note in report
        b1 = match_brace(t, i)
        if b1 < 0: continue
        arm1 = t[i+1:b1]
        j = skip_ws(t, b1+1)
        if t[j:j+4] != "else" or (t[j+4].isalnum() or t[j+4] == "_"):
            continue
        k = skip_ws(t, j+4)
        if t[k:k+2] == "if":
            continue  # else-if chain: inner pair scanned separately
        if t[k] != "{":
            # single-statement else arm
            # find statement end
            e = k
            pd = 0
            while e < len(t):
                if t[e] == "(": pd += 1
                elif t[e] == ")": pd -= 1
                elif t[e] == ";" and pd == 0: break
                e += 1
            arm2_units = [norm(t[k:e+1])]
        else:
            b2 = match_brace(t, k)
            if b2 < 0: continue
            arm2_units = [norm(u) for u in top_level_units(t[k+1:b2])]
        arm1_units = [norm(u) for u in top_level_units(arm1)]
        if not arm1_units or not arm2_units:
            continue
        t1, t2 = arm1_units[-1], arm2_units[-1]
        if t1 == t2:
            line = t[:m.start()].count("\n") + 1
            trivial = bool(TRIVIAL.match(t1))
            whole_arms_equal = arm1_units == arm2_units
            hits.append({"file": path, "line": line, "tail": t1[:200],
                         "trivial": trivial, "arm1_n": len(arm1_units),
                         "arm2_n": len(arm2_units),
                         "whole_arms_equal": whole_arms_equal})
    return hits

def main():
    entries = parse_index()
    files = psx_files()
    print(f"index entries: {len(entries)}", file=sys.stderr)
    entry_files = sorted(set(e[0] for e in entries))
    psx_entry_count = sum(1 for e in entries if e[0] in set(files))
    print(f"psx config files: {len(files)}", file=sys.stderr)

    all_hits, missing = [], []
    for p in files:
        txt = git_show(p)
        if txt is None:
            missing.append(p); continue
        try:
            all_hits.extend(scan_file(p, txt))
        except Exception as ex:
            print(f"ERR {p}: {ex}", file=sys.stderr)
    res = {
        "index_entries": len(entries),
        "index_entry_files": len(entry_files),
        "psx_scope_index_entries": psx_entry_count,
        "psx_files_scanned": len(files) - len(missing),
        "missing_files": missing,
        "hits": all_hits,
    }
    json.dump(res, open("C:/Users/Trenton/Desktop/Bushido Blade 2 Decompile/tmp/dup_screen_out.json", "w"), indent=1)
    strong = [h for h in all_hits if not h["trivial"] and not h["whole_arms_equal"]]
    print(f"total tail-matches: {len(all_hits)}  strong(non-trivial, arms differ elsewhere): {len(strong)}", file=sys.stderr)
    for h in strong[:80]:
        print(f"{h['file']}:{h['line']}  [{h['arm1_n']}/{h['arm2_n']} stmts]  {h['tail']}")

if __name__ == "__main__":
    main()
