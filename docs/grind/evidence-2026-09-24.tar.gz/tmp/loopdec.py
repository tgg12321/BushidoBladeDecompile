import re, sys
tag = sys.argv[1]
func = sys.argv[2]
txt = open('tmp/dump_%s/pre.i.loop' % tag).read()
parts = re.split(r'\n(?=;; Function )', txt)
for sec in parts:
    if sec.startswith(';; Function %s' % func):
        for l in sec.splitlines():
            if re.match(r'^(Loop from|Insn \d+:)', l):
                print(l)
        break
else:
    print('function section not found')
