#!/usr/bin/env python3
"""Supplementary hand-coded-asm signal scan for the ASM-SUSPECT census.

Adds signals scan_hand_coded.py does not compute:
  T1  trapping arithmetic (add/addi/sub/neg without the 'u') -- GCC 2.7.2
      emits addu/addiu/subu/negu exclusively from C. DECISIVE.
  G1  ghost callee-save: `sw $sN,K($sp)` where $sN is never read/written
      by any other instruction in the function. DECISIVE-ish.
  R1  leaf function (no jal/jalr/BIOS-vector jr) that saves $ra. DECISIVE-ish.
  D1  unfilled `jr $ra` delay slot (nop) while non-trivial work precedes.  weak
  C2  cop2/GTE instruction density.
  K1  opcode-signature similarity to an ALREADY-AUTHORIZED canonical function.
  N1  no-frame function (no addiu $sp) that still touches $sN.
"""
from __future__ import annotations
import json, re, sys
from pathlib import Path
from collections import Counter

ROOT = Path(__file__).resolve().parent.parent
ASM = ROOT / "asm" / "funcs"

INSN_RE = re.compile(r"^\s*/\*[^*]*\*/\s*([a-z][a-z0-9.]*)\s*(.*?)\s*$")

TRAP_OPS = {"add", "addi", "sub", "neg"}
CALLEE = {f"s{i}" for i in range(8)}


def parse(path: Path):
    insns = []
    for line in path.read_text(errors="replace").splitlines():
        m = INSN_RE.match(line)
        if m:
            insns.append((m.group(1), m.group(2)))
    return insns


def regs(ops: str):
    return set(re.findall(r"\$(\w+)", ops))


def analyze(name: str):
    p = ASM / f"{name}.s"
    if not p.exists():
        return None
    insns = parse(p)
    n = len(insns)
    sig = {}
    ops_all = [m for m, _ in insns]

    # T1 trapping arithmetic
    trap = [(i, m, o) for i, (m, o) in enumerate(insns) if m in TRAP_OPS]
    sig["T1_trap_arith"] = [f"{m} {o}" for _, m, o in trap]

    # G1 ghost callee-save
    saved = {}
    for i, (m, o) in enumerate(insns):
        mm = re.match(r"^\$(\w+),\s*(-?0x[0-9a-fA-F]+|-?\d+)\(\$sp\)$", o.replace(" ", ""))
        if m == "sw" and mm and mm.group(1) in CALLEE:
            saved.setdefault(mm.group(1), i)
    ghost = []
    for r, si in saved.items():
        used = False
        for i, (m, o) in enumerate(insns):
            if i == si:
                continue
            if m in ("sw", "lw") and re.search(r"\$" + r + r",\s*\S+\(\$sp\)", o):
                continue  # save/restore pair
            if r in regs(o):
                used = True
                break
        if not used:
            ghost.append(r)
    sig["G1_ghost_callee_save"] = ghost

    # R1 leaf + $ra save
    has_call = any(m in ("jal", "jalr") for m in ops_all)
    ra_saved = any(m == "sw" and re.search(r"\$ra,\s*\S+\(\$sp\)", o) for m, o in insns)
    sig["R1_leaf_ra_save"] = bool(ra_saved and not has_call)

    # N1 no frame but uses $sN
    has_frame = any(m == "addiu" and re.match(r"^\$sp,\s*\$sp", o) for m, o in insns)
    uses_s = any((regs(o) & CALLEE) for _, o in insns)
    sig["N1_noframe_uses_s"] = bool(uses_s and not has_frame)

    # D1 unfilled jr $ra delay slot
    unfilled = 0
    for i, (m, o) in enumerate(insns):
        if m == "jr" and o.strip() == "$ra" and i + 1 < n and insns[i + 1][0] == "nop":
            unfilled += 1
    sig["D1_unfilled_jr_ra"] = unfilled

    # C2 cop2/GTE
    gte = sum(1 for m in ops_all if m.startswith(("mtc2", "mfc2", "ctc2", "cfc2", "lwc2", "swc2"))
              or m in ("rtps", "rtpt", "nclip", "avsz3", "avsz4", "mvmva", "gpf", "gpl",
                       "ncds", "ncdt", "ncct", "ncs", "nct", "cc", "cdp", "dpcs", "dpct",
                       "intpl", "sqr", "op"))
    sig["C2_gte_insns"] = gte

    # B1 Marionation/kernel break with a non-GCC code. GCC 2.7.2 MIPS emits
    # `break 0,7` (div-by-zero) and `break 0,6` (overflow) only.
    b1 = []
    for m, o in insns:
        if m == "break":
            mm = re.match(r"^0,\s*(\d+)$", o.strip())
            if mm and int(mm.group(1)) not in (6, 7):
                b1.append(f"break 0,{mm.group(1)}")
    sig["B1_nonstd_break"] = b1

    # X1 duplicated adjacent identical non-nop instruction (hand-coder's
    # latency pad; GCC's CSE/peephole never emits two identical back-to-back
    # ops with the same dest).
    x1 = []
    for i in range(n - 1):
        if insns[i] == insns[i + 1] and insns[i][0] not in ("nop",):
            x1.append(f"{insns[i][0]} {insns[i][1]}")
    sig["X1_dup_adjacent_insn"] = x1

    # E1 store/compute in the `jr $ra` delay slot of a no-frame leaf. Common
    # in GCC too -- recorded as weak context only.
    sig["_n"] = n
    sig["_ops"] = ops_all
    sig["_has_call"] = has_call
    return sig


def opcode_sig(ops):
    return Counter(ops)


def jaccard(a: Counter, b: Counter):
    inter = sum((a & b).values())
    union = sum((a | b).values())
    return inter / union if union else 0.0


def main():
    q = json.load(open(ROOT / "engine" / "queue.json"))
    targets = [i for i in q["items"]
               if i["status"] == "active" and i["verdict"] in ("ASM-SUSPECT", "ASM-PARTIAL")]

    # authorized canonical names
    canon = []
    for line in (ROOT / "inline_asm_canonical.txt").read_text().splitlines():
        line = line.split("#")[0].strip()
        if line:
            canon.append(line)

    canon_sigs = {}
    for c in canon:
        s = analyze(c)
        if s and s["_n"] >= 10:
            canon_sigs[c] = opcode_sig(s["_ops"])

    out = {}
    for it in targets:
        s = analyze(it["func"])
        if s is None:
            out[it["func"]] = {"error": "no asm/funcs file"}
            continue
        mysig = opcode_sig(s["_ops"])
        best = ("", 0.0)
        if s["_n"] >= 10:
            for c, cs in canon_sigs.items():
                j = jaccard(mysig, cs)
                if j > best[1]:
                    best = (c, j)
        rec = {k: v for k, v in s.items() if not k.startswith("_")}
        rec["insns"] = s["_n"]
        rec["has_call"] = s["_has_call"]
        rec["K1_canon_sibling"] = best[0]
        rec["K1_jaccard"] = round(best[1], 3)
        rec["queue"] = {"verdict": it["verdict"], "distance": it["distance"],
                        "rules": it["rules"], "file": it["file"]}
        out[it["func"]] = rec

    json.dump(out, open(ROOT / "tmp" / "supp_signals.json", "w"), indent=1)
    print(f"scanned {len(out)} functions")
    t1 = [k for k, v in out.items() if v.get("T1_trap_arith")]
    g1 = [k for k, v in out.items() if v.get("G1_ghost_callee_save")]
    r1 = [k for k, v in out.items() if v.get("R1_leaf_ra_save")]
    n1 = [k for k, v in out.items() if v.get("N1_noframe_uses_s")]
    print("T1 trapping arith:", len(t1), t1[:20])
    print("G1 ghost saves:", len(g1), g1[:20])
    print("R1 leaf ra save:", len(r1), r1[:20])
    print("N1 noframe uses s:", len(n1), n1[:20])


if __name__ == "__main__":
    main()
