#!/usr/bin/env python3
"""Wave 0 audit: for each named function, classify every `.L...` token appearing in
its asmfix/regfix rules as one of

  SLOT       -- a {lbl#N} function-local slot reference (drift-robust by construction)
  SELF-DEF   -- an address-form label DEFINED inside the same rule's payload text
  CC1-REF    -- a bare `.L<digits>` that must resolve to a label cc1 emitted  <-- the only
                drift-exposed kind

The campaign plan's scan used HARD_L = r'(?<!\{lbl)\.L\d+', which matches the digit
PREFIX of address-form labels (`.L80070D7C` -> `.L80070`), so it reports SELF-DEF
labels as hardcoded. This script distinguishes them.
"""
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
FUNCS = sys.argv[1:] or [
    "func_8002CA8C", "CalcHiraNormal", "func_80056CB8", "func_80070C70",
]

LABEL_TOK = re.compile(r'\.L[0-9A-Za-z_]+')
LABEL_DEF = re.compile(r'(\.L[0-9A-Za-z_]+):')
PURE_NUM = re.compile(r'^\.L\d+$')
RULE = re.compile(r'^([A-Za-z_]\w*)\s*:\s*(\w+)\b')

rows = []
for fname in ("asmfix.txt", "regfix.txt"):
    for lineno, raw in enumerate((ROOT / fname).read_text(encoding="utf-8").splitlines(), 1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        m = RULE.match(line)
        if m and m.group(1) in FUNCS:
            rows.append((fname, lineno, m.group(1), m.group(2), line))

for func in FUNCS:
    mine = [r for r in rows if r[2] == func]
    print(f"\n===== {func} — {len(mine)} rule line(s) =====")
    for fname, lineno, _f, verb, line in mine:
        defined = set(LABEL_DEF.findall(line))
        slots = re.findall(r'\{lbl#(\d+)\}', line)
        toks = sorted(set(LABEL_TOK.findall(line)))
        cc1refs = [t for t in toks if PURE_NUM.match(t) and t not in defined]
        selfdef = [t for t in toks if t in defined]
        other = [t for t in toks if t not in defined and not PURE_NUM.match(t)]
        print(f"  {fname}:{lineno} {verb}")
        if slots:
            print(f"      SLOT     : {['{lbl#%s}' % s for s in slots]}")
        if selfdef:
            print(f"      SELF-DEF : {selfdef}")
        if other:
            print(f"      ADDR-REF : {other}   (address-form, defined in a sibling rule's payload)")
        print(f"      CC1-REF  : {cc1refs if cc1refs else 'NONE'}"
              f"{'   <-- DRIFT-EXPOSED' if cc1refs else ''}")
