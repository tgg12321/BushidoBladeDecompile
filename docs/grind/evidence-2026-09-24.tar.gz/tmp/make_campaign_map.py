import json, os, collections

ROOT = r"C:\Users\Trenton\Desktop\Bushido Blade 2 Decompile"
def P(*a): return os.path.join(ROOT, *a)

rows = json.load(open(P('tmp', '_rows.json')))
qd = json.load(open(P('engine', 'queue.json')))
qmap = {it['func']: it for it in qd['items']}

FAM_NOTE = {
 'register-rename': 'Single-register substitution: same opcode/shape, different allocation. The RA-divergence bulk.',
 'register-swap-range': 'Range-scoped `$X <-> $Y` swap - same RA-divergence family, expressed as a swap.',
 'frame-reg-rename': 'Register rename on a $sp-relative access (save/restore slot).',
 'register+displacement': 'Register AND displacement both change - RA divergence entangled with a frame/struct offset shift.',
 'memory-displacement': 'Displacement-only rewrite (`,24(` -> `,32(`): stack-slot rotation or struct-offset shift.',
 'frame-stack-offset': 'Frame size / $sp slot offset rewrite - target frame differs from ours.',
 'reorder-scheduling': 'Instruction reordering in a range - sched1/sched2 or reorg divergence.',
 'delete-instruction': 'Delete one emitted instruction - our build emits something target does not.',
 'instruction-injection-insert': 'Insert ONE real instruction GCC never emitted (la/addiu/lui/ori/...). Generalization of the lost-codegen cheat.',
 'lost-codegen-move-insert': 'Insert `addu $rN,$rM,$zero` - the named lost-codegen cheat.',
 'lost-codegen-nop-fill': 'subst nop -> real instruction: same cheat, expressed as a nop overwrite.',
 'instruction-suppress-to-nop': 'subst real instruction -> nop: our build emits an instruction target does not.',
 'opcode-change': 'Opcode swapped for a different opcode (non-width): typically a rewritten instruction stream.',
 'width-sign-opcode-change': 'lw/lh/lhu/lb/lbu/sll/srl/sra family swap - width or signedness divergence.',
 'branch-label-retarget': 'Branch target / .L label rewrite - control-flow shape divergence.',
 'operand-order-swap': 'Same registers, swapped operand order (`addu $3,$7,$8` -> `$3,$8,$7`).',
 'gte-cop2-respell': 'cop2/GTE instruction respelling (ctc2/mtc2/cfc2/mfc2).',
 'scratchpad-abs-address': 'Rewrite to a 0x1F80xxxx scratchpad absolute address.',
 'symbol-reference-rewrite': 'Introduce %hi/%lo/%gp_rel symbol reference where our build had none.',
 'loadstore-insert': 'Insert a load or store instruction.',
 'label-insert': 'Insert a label (jump-table / branch-target infrastructure).',
 'label-rename': 'Rename a cc1-generated label to a stable name (infrastructure, not codegen).',
 'nop-scheduling-insert': 'Insert nop(s) - load-delay / scheduling divergence.',
 'splice-large-asm': 'Insert >=8 instructions of literal asm - a body-region splice.',
 'whole-body-asm-replace': 'Replace the entire function body with literal asm (replace_with_asmfile, or delete_between .frame/.end + insert).',
 'delete-range': 'Delete an instruction range by pattern.',
 'multi-insn-insert': 'Insert 2-7 instructions of literal asm.',
 'subst-multi': 'Multi-pattern substitution.',
 'other-subst': 'Substitution that did not fit any pattern.',
 'fill-delay-slot': 'Explicit delay-slot fill directive.',
 'branch-insert': 'Insert a branch instruction.',
}

RECIPE_ASSESS = {
 'COVERED': 'A documented pure-C recipe has retired this family before.',
 'PARTIAL': 'Recipes exist for SOME shapes in this family; the family is heterogeneous, so per-rule triage is needed.',
 'COVERED-FORBIDDEN': 'Named FORBIDDEN cheat family with a documented pure-C replacement recipe. These rules must go; the recipe is known.',
 'OPEN': 'No documented recipe retires this family. Open problem.',
 'OPEN-CANONICAL': 'No pure-C recipe; the disposition is the canonical-asm grant path (STRONG scanner evidence + Judge), not a C lever.',
}

fam_counts = collections.Counter(r['family'] for r in rows)
per_func = collections.defaultdict(list)
for r in rows:
    per_func[r['func']].append(r)

def func_rec(fn):
    rs = per_func[fn]
    q = qmap.get(fn, {})
    fc = collections.Counter(r['family'] for r in rs)
    dom = fc.most_common(3)
    cov = collections.Counter(r['coverage'] for r in rs)
    n = len(rs)
    covered = cov['COVERED'] + cov['COVERED-FORBIDDEN']
    return dict(func=fn, file=q.get('file', '?'), n=n,
                dist=q.get('distance', -1), status=q.get('status', '?'),
                verdict=q.get('verdict', '?'),
                dom=dom, dom1=dom[0][0] if dom else '-',
                cov_pct=round(100.0 * covered / n) if n else 0,
                open_n=cov['OPEN'] + cov['OPEN-CANONICAL'],
                partial_n=cov['PARTIAL'], forbidden_n=cov['COVERED-FORBIDDEN'])

recs = [func_rec(f) for f in per_func]
# order: recipe-covered desc, distance asc
recs.sort(key=lambda r: (-r['cov_pct'], r['dist'] if r['dist'] >= 0 else 9999, r['n']))

# batch clusters: same file + same dominant family
clusters = collections.defaultdict(list)
for r in recs:
    clusters[(r['file'], r['dom1'])].append(r)
clusters = {k: v for k, v in clusters.items() if len(v) >= 2}

out = []
w = out.append
w('# Regfix campaign map')
w('')
w('Generated by `tmp/classify_regfix.py` + `tmp/make_campaign_map.py` (pure text analysis; nothing compiled, nothing committed).')
w('Sources: `regfix.txt`, `regfix_stage2.txt`, `asmfix.txt`; cross-referenced against `engine/queue.json` and `.claude/rules/*.md`.')
w('')
w('## Headline')
w('')
w('| | |')
w('|---|---|')
w('| Active rule lines | **%d** (regfix.txt %d, regfix_stage2.txt %d, asmfix.txt %d) |' % (
    len(rows),
    sum(1 for r in rows if r['src'] == 'regfix.txt'),
    sum(1 for r in rows if r['src'] == 'regfix_stage2.txt'),
    sum(1 for r in rows if r['src'] == 'asmfix.txt')))
w('| Carrier functions | **%d** (all %d present in engine/queue.json) |' % (len(per_func), len(per_func)))
w('| Queue total / active / parked | %d / %d / %d |' % (
    qd['counts']['total'], qd['counts']['by_status']['active'], qd['counts']['by_status']['parked']))
w('| Distinct technique families | %d |' % len(fam_counts))
cov_all = collections.Counter(r['coverage'] for r in rows)
tot = len(rows)
recipe_covered = cov_all['COVERED'] + cov_all['COVERED-FORBIDDEN']
w('| Rules with a documented recipe (COVERED + COVERED-FORBIDDEN) | **%d (%.1f%%)** |' % (recipe_covered, 100.0 * recipe_covered / tot))
w('| Rules with partial recipe coverage | %d (%.1f%%) |' % (cov_all['PARTIAL'], 100.0 * cov_all['PARTIAL'] / tot))
w('| Rules with NO recipe (OPEN / OPEN-CANONICAL) | %d (%.1f%%) |' % (
    cov_all['OPEN'] + cov_all['OPEN-CANONICAL'], 100.0 * (cov_all['OPEN'] + cov_all['OPEN-CANONICAL']) / tot))
w('')
w('Verb distribution: ' + ', '.join('`%s` %d' % (k, v) for k, v in collections.Counter(r['verb'] for r in rows).most_common()))
w('')
w('## 1. Family taxonomy')
w('')
w('| # | Family | Rules | %% | Coverage | Recipe slug | What the rule shape means |')
w('|---:|---|---:|---:|---|---|---|')
for i, (fam, c) in enumerate(fam_counts.most_common(), 1):
    ex = next(r for r in rows if r['family'] == fam)
    w('| %d | `%s` | %d | %.1f%% | %s | `%s` | %s |' % (
        i, fam, c, 100.0 * c / tot, ex['coverage'], ex['recipe'], FAM_NOTE.get(fam, '')))
w('')
w('### Coverage legend')
w('')
for k, v in RECIPE_ASSESS.items():
    w('- **%s** - %s' % (k, v))
w('')
w('## 2. Recipe-coverage assessment per family group')
w('')
w('### 2a. Register-allocation divergence - %d rules (%.0f%% of the file)' % (
    sum(fam_counts[f] for f in ('register-rename', 'register-swap-range', 'frame-reg-rename', 'register+displacement', 'operand-order-swap')),
    100.0 * sum(fam_counts[f] for f in ('register-rename', 'register-swap-range', 'frame-reg-rename', 'register+displacement', 'operand-order-swap')) / tot))
w('')
w('`register-rename` (%d) + `register-swap-range` (%d) + `frame-reg-rename` (%d) + `register+displacement` (%d) + `operand-order-swap` (%d).' % (
    fam_counts['register-rename'], fam_counts['register-swap-range'], fam_counts['frame-reg-rename'],
    fam_counts['register+displacement'], fam_counts['operand-order-swap']))
w('')
w('This is the single dominant fact about regfix.txt: **more than half of all rules are one register substituted for another**.')
w('Recipe coverage is genuinely good here - `.claude/rules/` carries SEVEN distinct pure-C levers that have retired')
w('RA-divergence clusters before:')
w('')
w('- `register-alloc-pure-c` - the Step-0 anomaly diagnosis (`-da` greg dump) + Levers A/B/C; the umbrella recipe.')
w('- `compare-operand-order-register` - `$X <-> $Y` rename over paired comparisons -> reverse the comparison operand order. **Directly targets `operand-order-swap` and a subset of `register-rename`.**')
w('- `call-return-if-result-reuse-v0` - mirror-image rename cluster -> init the if/else result var from the call return.')
w('- `restore-discarded-return-displaces-v0` - `$v0`->`$v1` substitution on a post-call lw/sw pair.')
w('- `drop-param-alias-local` - param->local alias -> drop the alias.')
w('- `exit-path-return-set-cse-join` - shared finish label copy into `$v0`.')
w('- `hoist-shared-arm-computation-defeats-copy-pref` - duplicated `z = x + y` across arms.')
w('- `duplicated-statement-into-arms` - the proven byte-free ref-lift for global-RA priority walls.')
w('')
w('**Assessment: COVERED, but the recipes are diagnostic rather than mechanical.** Each is keyed to a')
w('specific *cluster shape* (mirror-image pair, post-call lw/sw pair, paired comparisons), so the campaign')
w('work is pattern-matching each function\'s rename cluster to the right recipe - not applying one transform en masse.')
w('`register-asm-pins` is explicitly DIAGNOSTIC-ONLY and never committable, so there is no shortcut.')
w('')
w('### 2b. Scheduling / delay-slot divergence - %d rules' % (
    fam_counts['reorder-scheduling'] + fam_counts['nop-scheduling-insert'] + fam_counts['fill-delay-slot']))
w('')
w('`reorder-scheduling` (%d) + `nop-scheduling-insert` (%d) + `fill-delay-slot` (%d).' % (
    fam_counts['reorder-scheduling'], fam_counts['nop-scheduling-insert'], fam_counts['fill-delay-slot']))
w('')
w('Best-covered family in the whole file. The index lists 10 scheduling recipes:')
w('`loop-exit-work-inside-loop-sched-fence`, `loop-note-fixes-delay-slot-steal`, `loop-counter-fills-load-delay`,')
w('`walking-pointer-serializes-parallel-loads`, `hoist-call-arg-local-flips-jal-delay`, `store-before-jal`,')
w('`defer-store-past-later-compute-into-jal-delay`, `switch-break-shared-return-sched-hoist`,')
w('`fake-varargs-explicit-homing`, `split-scalars-hide-aggregate`. Plus `maspsx-label-nop-gate` for the')
w('single-nop-before-a-load-in-a-loop case (a per-function maspsx gate, explicitly "do not park").')
w('')
w('**Assessment: COVERED, highest confidence in the file.** These recipes have measured multi-session provenance.')
w('')
w('### 2c. Frame / stack-slot divergence - %d rules' % (fam_counts['frame-stack-offset'] + fam_counts['memory-displacement']))
w('')
w('`frame-stack-offset` (%d) + `memory-displacement` (%d).' % (fam_counts['frame-stack-offset'], fam_counts['memory-displacement']))
w('')
w('`phantom-slot-frame-lever` (2026-08-04) is the diagnosis recipe: target frame reserves untouched bytes,')
w('with three measured honest producers plus a `.frame vars=` gradient instrument. It closed `func_8003D9A0`')
w('and `func_8003DBE4`. The 2026-08-17/18 owner rulings additionally sanction an unwritten `volatile u32 pad[N]`')
w('leading (and, for `func_8003CF84` only, trailing) local - but that scope is **explicitly three functions**')
w('and does not generalize.')
w('')
w('The `memory-displacement` half is heterogeneous: some rules are pure stack-slot rotation (`CD_datasync`\'s')
w('`,24(` -> `,32(` chain reads as an allocation-order rotation), others are struct-offset shifts that point at')
w('`defeat-combine-symbol-fold` or a header-level type/layout correction.')
w('')
w('**Assessment: frame-stack-offset COVERED (diagnosis recipe + frame census locator); memory-displacement PARTIAL** - needs per-cluster triage to split rotation from layout.')
w('')
w('### 2d. Lost-codegen / instruction injection - %d rules (FORBIDDEN families)' % (
    fam_counts['instruction-injection-insert'] + fam_counts['lost-codegen-nop-fill'] + fam_counts['lost-codegen-move-insert']))
w('')
w('`instruction-injection-insert` (%d) + `lost-codegen-nop-fill` (%d) + `lost-codegen-move-insert` (%d).' % (
    fam_counts['instruction-injection-insert'], fam_counts['lost-codegen-nop-fill'], fam_counts['lost-codegen-move-insert']))
w('')
w('These are the rules `lost-codegen-insert-cheat.md` names outright. That rule documents 29 grandfathered')
w('functions / 39 instructions as of 2026-05-16; **the current count is %d rules across %d functions**, so the population is'
  ' substantially larger than the grandfather list once the generalized shapes are counted:' % (
    fam_counts['instruction-injection-insert'] + fam_counts['lost-codegen-nop-fill'] + fam_counts['lost-codegen-move-insert'],
    len(set(r['func'] for r in rows if r['family'] in ('instruction-injection-insert', 'lost-codegen-nop-fill', 'lost-codegen-move-insert')))))
w('')
w('- `lost-codegen-move-insert` (%d) is the literal named shape (`insert_after "addu $rN,$rM,$zero"`).' % fam_counts['lost-codegen-move-insert'])
w('- `lost-codegen-nop-fill` (%d) is the SAME cheat spelled as `subst "nop" "<real insn>"` - it writes an instruction' % fam_counts['lost-codegen-nop-fill'])
w('  GCC never emitted over a nop slot. The rule file does not name this spelling.')
w('- `instruction-injection-insert` (%d) is the generalized form: a single `la` / `addiu` / `lui` / `ori` the compiler' % fam_counts['instruction-injection-insert'])
w('  did not produce. Same kind as the named cheat, larger payload vocabulary.')
w('')
w('**Assessment: COVERED-FORBIDDEN.** The recipe is `shared-end-label` (restructure per-case `return s2;` to')
w('`goto end; ... end: return s2;`) for the const-prop-ate-it case, which `lost-codegen-insert-cheat.md` says to try FIRST.')
w('That rule also lists five techniques that have measurably NOT worked, which saves re-derivation.')
w('For the `la`/`lui`/`ori` payloads the recipe surface is different - `defeat-combine-symbol-fold` and')
w('`store-const-reload-cse` are the likely levers, but neither has been exercised against this exact shape.')
w('')
w('### 2e. Control-flow shape - %d rules' % (
    fam_counts['branch-label-retarget'] + fam_counts['label-insert'] + fam_counts['label-rename'] + fam_counts['branch-insert']))
w('')
w('`branch-label-retarget` (%d) + `label-insert` (%d) + `label-rename` (%d) + `branch-insert` (%d).' % (
    fam_counts['branch-label-retarget'], fam_counts['label-insert'], fam_counts['label-rename'], fam_counts['branch-insert']))
w('')
w('Recipes: `switch-vs-ifchain-branch-sense` (branch-sense-swap rules on ONE case of a dispatch -> write a real')
w('`switch`), `cross-jump-call-merge` / `cross-jump-store-tail-merge` (target has MORE call sites / `j END` tails),')
w('`shared-end-label` (the inverse), `explicit-rejection-set-defeats-range-fold`.')
w('')
w('`label-rename` (%d rules) is a different thing entirely - it renames cc1-generated `{lbl#N}` slots to stable' % fam_counts['label-rename'])
w('names so sibling rules survive cc1\'s file-global label counter moving. That is rule *infrastructure*, not a')
w('codegen cheat, and it retires automatically when the rules it serves retire. See `global-label-drift-sibling-cheat`.')
w('')
w('**Assessment: PARTIAL.** `switch-vs-ifchain-branch-sense` is narrow (one case of a dispatch). Multi-branch')
w('retarget clusters are not covered by any single recipe.')
w('')
w('### 2f. Width / opcode respelling - %d rules' % (
    fam_counts['width-sign-opcode-change'] + fam_counts['opcode-change'] + fam_counts['instruction-suppress-to-nop'] + fam_counts['delete-instruction']))
w('')
w('`delete-instruction` (%d) + `opcode-change` (%d) + `instruction-suppress-to-nop` (%d) + `width-sign-opcode-change` (%d).' % (
    fam_counts['delete-instruction'], fam_counts['opcode-change'], fam_counts['instruction-suppress-to-nop'], fam_counts['width-sign-opcode-change']))
w('')
w('Width/sign has excellent coverage: `halfword-index-srl-sra`, `u16-global-lhu-lbu-low-byte`,')
w('`narrow-stack-param-subword-offset`, `narrow-byte-args-packed-call`, `bitfield-direction-divergence`,')
w('`header-type-correction-from-use-sites` (four-prong gate). **COVERED.**')
w('')
w('`delete-instruction` and `instruction-suppress-to-nop` are the inverse of lost-codegen: OUR build emits')
w('something target does not. Levers: `store-const-reload-cse` (store-then-reload folded to `li`),')
w('`defeat-licm-hoist-var-reuse`, `hoist-flag-load-defeat-add-combine`, `split-read-defeats-hoist`,')
w('`defeat-combine-symbol-fold`. **PARTIAL** - the recipes exist but selecting one requires knowing WHICH')
w('optimizer pass produced the extra instruction, and a `delete` rule text alone does not say.')
w('')
w('`opcode-change` (%d) is the weakest-covered subgroup. Inspection shows most of these are not single-opcode' % fam_counts['opcode-change'])
w('corrections at all but *whole-region instruction-stream rewrites* expressed one line at a time - e.g.')
w('`func_8003800C` rewrites five consecutive slots (`addu`->`lui`, `addu`->`lui`, `lui`->`ori`, `lui`->`addu`,')
w('`ori`->`addu`), which is a scheduling/spelling rotation of a region, not five independent opcode fixes.')
w('**Treat contiguous `opcode-change` runs as ONE finding, not N.**')
w('')
w('### 2g. No-C-form / canonical territory - %d rules' % (
    fam_counts['whole-body-asm-replace'] + fam_counts['splice-large-asm'] + fam_counts['gte-cop2-respell'] + fam_counts['scratchpad-abs-address'] + fam_counts['multi-insn-insert'] + fam_counts['delete-range']))
w('')
w('`gte-cop2-respell` (%d) and `scratchpad-abs-address` (%d) are covered by `gte-3x3` / `scratchpad-gte` /' % (
    fam_counts['gte-cop2-respell'], fam_counts['scratchpad-abs-address']))
w('`inline-asm-allowed` - cop2 ops have no C analog and inline `__asm__` for them is canonical.')
w('')
w('`whole-body-asm-replace` (%d) and `splice-large-asm` (%d) are the genuinely OPEN territory. These are not' % (
    fam_counts['whole-body-asm-replace'], fam_counts['splice-large-asm']))
w('pure-C problems with an undiscovered lever - they are functions whose entire body (or a large region) is')
w('reproduced from literal rule text. Under `judge-sole-gate` (owner ruling 2026-08-18) their disposition is the')
w('**pipeline canonical-asm grant path**: `tools/scan_hand_coded.py` STRONG (S1/S2/S6) evidence + Judge verdict +')
w('driver-written `inline_asm_canonical.txt` entry + borderline-ledger row. Without STRONG evidence they stay')
w('INCOMPLETE and pure-C search continues. They should NOT be ground as pure-C-lever work until the scanner has run.')
w('')
w('## 3. Per-function rollup')
w('')
w('Ordered by (recipe-covered %% desc, honest distance asc). `Cov%%` = share of the function\'s rules whose family')
w('has a documented recipe (COVERED or COVERED-FORBIDDEN). `Dist` is the honest cheat-free pure-C distance from')
w('`engine/queue.json`.')
w('')
w('| # | Function | File | Rules | Dist | Status | Verdict | Cov%% | Dominant families |')
w('|---:|---|---|---:|---:|---|---|---:|---|')
for i, r in enumerate(recs, 1):
    dom = ', '.join('`%s`x%d' % (f, c) for f, c in r['dom'])
    w('| %d | `%s` | %s | %d | %d | %s | %s | %d%% | %s |' % (
        i, r['func'], r['file'], r['n'], r['dist'], r['status'], r['verdict'], r['cov_pct'], dom))
w('')
w('## 4. Batch clusters (same source file + same dominant family)')
w('')
w('These are the functions where one derived C lever plausibly retires several carriers, because they share a')
w('translation unit (same compilation context, same headers, likely same original author/idiom) AND the same')
w('dominant rule shape.')
w('')
w('| File | Dominant family | Funcs | Total rules | Members (dist) |')
w('|---|---|---:|---:|---|')
cl = sorted(clusters.items(), key=lambda kv: (-len(kv[1]), -sum(x['n'] for x in kv[1])))
for (f, fam), members in cl:
    mem = ', '.join('%s(%d)' % (m['func'], m['dist']) for m in sorted(members, key=lambda m: m['dist']))
    w('| %s | `%s` | %d | %d | %s |' % (f, fam, len(members), sum(m['n'] for m in members), mem))
w('')
w('## 5. Proposed campaign ordering')
w('')
w('The queue is already pre-ordered easiest-first by honest distance and project policy is **no cherry-picking,')
w('no deferral** - the Grinder works the top active item. This map is therefore NOT a proposal to re-order the')
w('queue. It is a *modality* map: for whichever function is on top, it tells you which recipe to reach for first,')
w('and it identifies where a single derivation would pay off across several carriers.')
w('')
w('Ordering rationale, in tiers:')
w('')
w('**Tier 1 - single-family, small-N, recipe-covered, low distance.** One rule shape, one recipe, few rules.')
w('These are where a recipe application either works immediately or fails informatively.')
w('')
w('**Tier 2 - batch clusters.** Functions in the same file sharing a dominant family (section 4). Deriving the')
w('lever once and testing it against every cluster member is strictly better value than one function at a time.')
w('')
w('**Tier 3 - lost-codegen carriers.** FORBIDDEN family, known first-move recipe (`shared-end-label`), and')
w('`lost-codegen-insert-cheat.md` documents five approaches that measurably do NOT work - so failure is cheap.')
w('')
w('**Tier 4 - mixed-family high-rule-count carriers.** Many rules, several families. Expect multi-session work.')
w('')
w('**Tier 5 - whole-body / large-splice carriers.** Run `tools/scan_hand_coded.py --single <func>` FIRST. These')
w('are canonical-asm-grant candidates, not pure-C grinding targets, and grinding them in C before the scanner runs')
w('wastes sessions.')
w('')
tier1 = [r for r in recs if r['cov_pct'] >= 80 and r['n'] <= 25 and r['status'] == 'active']
tier1.sort(key=lambda r: (r['dist'], r['n']))
w('### Tier 1 - top candidates')
w('')
w('| # | Function | File | Rules | Dist | Cov%% | Dominant family | First recipe to try |')
w('|---:|---|---|---:|---:|---:|---|---|')
for i, r in enumerate(tier1[:20], 1):
    rec = next(x['recipe'] for x in per_func[r['func']] if x['family'] == r['dom1'])
    w('| %d | `%s` | %s | %d | %d | %d%% | `%s` | `%s` |' % (
        i, r['func'], r['file'], r['n'], r['dist'], r['cov_pct'], r['dom1'], rec))
w('')

parked = [r for r in recs if r['status'] == 'parked']
parked.sort(key=lambda r: r['dist'])
w('### Parked carriers - the lowest-distance rules in the file are all parked')
w('')
w('%d of the %d carriers are `parked`, and they occupy the ENTIRE low end of the distance range' % (len(parked), len(recs)))
w('(the 15 lowest-distance carriers are parked without exception; the lowest active carrier sits at distance %d).' % min(r['dist'] for r in recs if r['status'] == 'active'))
w('Parks are terminal dispositions, not pending decisions ([[judge-sole-gate]], owner ruling 2026-08-18), so')
w('these are not queue-orderable work - but they are the highest-density recipe-application targets in the file')
w('and worth re-examining as a batch if any park reason has been superseded by a newer recipe.')
w('')
w('| Function | File | Rules | Dist | Cov%% | Dominant families |')
w('|---|---|---:|---:|---:|---|')
for r in parked:
    dom = ', '.join('`%s`x%d' % (f, c) for f, c in r['dom'])
    w('| `%s` | %s | %d | %d | %d%% | %s |' % (r['func'], r['file'], r['n'], r['dist'], r['cov_pct'], dom))
w('')
tier5 = sorted(set(r['func'] for r in rows if r['family'] in ('whole-body-asm-replace', 'splice-large-asm')))
w('### Tier 5 - scanner-first (do NOT grind as pure C before `scan_hand_coded.py`)')
w('')
w('| Function | File | Rules | Dist | Status | Verdict | No-C-form rules |')
w('|---|---|---:|---:|---|---|---:|')
for fn in sorted(tier5, key=lambda f: qmap.get(f, {}).get('distance', 9999)):
    r = next(x for x in recs if x['func'] == fn)
    ncf = sum(1 for x in per_func[fn] if x['family'] in ('whole-body-asm-replace', 'splice-large-asm'))
    w('| `%s` | %s | %d | %d | %s | %s | %d |' % (fn, r['file'], r['n'], r['dist'], r['status'], r['verdict'], ncf))
w('')
w('## 6. Caveats on this classification')
w('')
w('- Families are derived from **rule text only**. A `subst` that renames a register is classified')
w('  `register-rename` regardless of whether the underlying cause is allocation, scheduling, or a layout shift')
w('  that happened to move a register. The taxonomy narrows the search; it does not diagnose.')
w('- Contiguous runs of `opcode-change` / `register-rename` at adjacent indices are usually ONE region rewrite')
w('  counted N times. Rule COUNT overstates finding count, probably by a large factor on the high-N carriers.')
w('- Recipe slugs are the *first* thing to try, chosen by family shape. The technique index is explicit that')
w('  these rules encode measured multi-session findings - read the rule file before grinding, do not re-derive.')
w('- `engine/queue.json` distance is the honest cheat-free pure-C distance with regfix/asmfix disabled and')
w('  cheat-asm stripped, so it is directly comparable across carriers.')
w('')

open(P('tmp', 'regfix_campaign_map.md'), 'w', encoding='utf-8', newline='\n').write('\n'.join(out))
print('wrote tmp/regfix_campaign_map.md', len(out), 'lines')
print('tier1:', len(tier1), 'tier5:', len(tier5), 'clusters:', len(cl))
print()
print('TOP10:')
for r in tier1[:10]:
    print('  %-16s %-10s rules=%-3d dist=%-4d cov=%d%% dom=%s' % (r['func'], r['file'], r['n'], r['dist'], r['cov_pct'], r['dom1']))
