typedef int s32;
extern s32 SPA0, SPA1, SPA2;
void sym6(s32 x,s32 y,s32 z,s32 dx,s32 dy,s32 dz){
  SPA0 = x; SPA1 = y; SPA2 = z;
  SPA0 += dx; SPA1 += dy; SPA2 += dz;
}
extern s32 SPARR[3];
void arr6(s32 x,s32 y,s32 z,s32 dx,s32 dy,s32 dz){
  SPARR[0]=x; SPARR[1]=y; SPARR[2]=z;
  SPARR[0]+=dx; SPARR[1]+=dy; SPARR[2]+=dz;
}
void vol6(s32 x,s32 y,s32 z,s32 dx,s32 dy,s32 dz){
  *(volatile s32*)0x1F800360 = x;
  *(volatile s32*)0x1F800364 = y;
  *(volatile s32*)0x1F800368 = z;
  *(volatile s32*)0x1F800360 = x+dx;
  *(volatile s32*)0x1F800364 = y+dy;
  *(volatile s32*)0x1F800368 = z+dz;
}
