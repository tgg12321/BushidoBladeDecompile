#!/bin/bash
# Probe 2: does an INCLUDE_ASM-style file-scope __asm__ block survive the FULL
# pipeline (cc1|prologue_fix|maspsx|multu_pad|regfix|regfix_stage2|asmfix|as)
# and assemble to the same bytes the asmfix replace_with_asmfile path produces?
cd /mnt/c/Users/Trenton/Desktop/"Bushido Blade 2 Decompile" || exit 1
source .venv/bin/activate 2>/dev/null
D=tmp/probe
CPP="mipsel-linux-gnu-cpp -Iinclude -undef -Wall -lang-c -fno-builtin -Dmips -D__GNUC__=2 -D__OPTIMIZE__ -D__mips__ -D__mips -Dpsx -D__psx__ -D__psx -D_PSYQ -D__EXTENSIONS__ -D_MIPSEL -D_LANGUAGE_C -DLANGUAGE_C"
CC1="tools/gcc-2.7.2/build/cc1 -O2 -G0 -funsigned-char -quiet -mcpu=3000 -mips1 -mno-abicalls -fno-builtin -w -mel"
MASPSX="python3 tools/maspsx/maspsx.py --expand-div --aspsx-version=2.34 --sdata-syms=sdata_syms.txt --sdata-funcs=sdata_funcs.txt --sdata-exclude=sdata_exclude.txt --expand-lb --expand-lb-funcs=expand_lb_funcs.txt --multu-funcs=multu_funcs.txt --expand-dest-funcs=expand_dest_funcs.txt --label-nop-funcs=maspsx_label_nop_funcs.txt"
ASFLAGS="-Iinclude -march=r3000 -mtune=r3000 -no-pad-sections -O1 -G0"

echo "########## A: ambient .set state in the real pipeline stream ##########"
$CPP src/ings2.c 2>/dev/null | $CC1 2>/dev/null | python3 tools/prologue_fix.py 2>/dev/null \
  | $MASPSX 2>/dev/null | grep -n "^\s*\.set\|^\s*\.section\|\.include" | head -20

echo
echo "########## B: INCLUDE_ASM in-place through full pipeline ##########"
cat > $D/q.c <<'EOF'
#define INCLUDE_ASM_USE_MACRO_INC 1
#include "include_asm.h"
int qa(int x) { return x + 1; }
INCLUDE_ASM("asm/funcs", ang_hosei);
int qb(int x) { return x + 2; }
EOF
$CPP $D/q.c 2>/dev/null | $CC1 2>/dev/null | python3 tools/prologue_fix.py 2>/dev/null \
  | $MASPSX 2>/dev/null | python3 tools/multu_pad.py --funcs multu_pad_funcs.txt 2>/dev/null \
  | python3 tools/regfix.py 2>/dev/null | REGFIX_CONFIG=regfix_stage2.txt python3 tools/regfix.py 2>/dev/null \
  | python3 tools/asmfix.py > $D/q.s 2>$D/q.err
echo "stderr:"; head -5 $D/q.err
echo "grep:"; grep -n "include\|\.ent\|\.set\|qa:\|qb:" $D/q.s | head -25
mipsel-linux-gnu-as $ASFLAGS $D/q.s -o $D/q.o && echo "ASSEMBLED OK" || echo "ASSEMBLE FAILED"
mipsel-linux-gnu-objdump -d $D/q.o 2>/dev/null | head -40

echo
echo "########## C: reference — standalone assembly of the same .s ##########"
printf '.include "macro.inc"\n.set noat\n.set noreorder\n.section .text, "ax"\n.include "asm/funcs/ang_hosei.s"\n' > $D/std.s
mipsel-linux-gnu-as $ASFLAGS $D/std.s -o $D/std.o && echo "ASSEMBLED OK" || echo "ASSEMBLE FAILED"
mipsel-linux-gnu-objdump -d $D/std.o 2>/dev/null | head -20
