set -e
cd /mnt/c/Users/Trenton/Desktop/"Bushido Blade 2 Decompile"
source .venv/bin/activate
PYTHONPATH=. python3 - <<'PYEOF'
import shlex, subprocess, sys
from engine import buildconfig as B
print("CC_FLAGS:", B.CC_FLAGS)
cpp=f"{B.CPP} {B.CPP_FLAGS} {B.CPP_DEFS} tmp/probe/p.c"
cc=f"{B.CC1} {B.CC_FLAGS} -o tmp/probe/p.s"
p1=subprocess.run(shlex.split(cpp),capture_output=True,text=True)
p2=subprocess.run(shlex.split(cc),input=p1.stdout,capture_output=True,text=True)
sys.stderr.write((p2.stderr or '')[-800:])
PYEOF
grep -v '^\s*\.' tmp/probe/p.s | sed 's/^\s*//' | grep -v '^$'
