/* Sites B and C: can stock gcc-2.7.2 reach the target `addu` shape in pure C? */
extern int src(void);
extern void sink(int);
extern unsigned char gb;

/* --- SITE B: target  sll $a0,$v0,2 ; addu $a0,$a0,$v0   (x*5) --- */
/* v0: as reconstructed today -- (t<<2) + t in one expression */
int v0(int a, int b) { int t = (unsigned)a < (unsigned)b; return (t << 2) + t; }
/* v1: accumulate into the same variable */
int v1(int a, int b) { int t = (unsigned)a < (unsigned)b; int r = t << 2; r += t; return r; }
/* v2: plain multiply by 5 */
int v2(int a, int b) { int t = (unsigned)a < (unsigned)b; return t * 5; }
/* v3: index arithmetic (the real use: tbl[5*t + i]) */
int v3(int a, int b, int i) { int t = (unsigned)a < (unsigned)b; int k = t << 2; k += t; return k + i; }

/* --- SITE C: target  sll $v1,$v1,8 ; addiu $v1,$v1,0x80 --- */
/* v4: as reconstructed today */
int v4(void) { unsigned char v = gb; return ((int)(v - 1) << 8) + 128; }
/* v5: accumulate into the same variable */
int v5(void) { unsigned char v = gb; int r = (int)(v - 1) << 8; r += 128; return r; }
/* v6: shift and add on one reused variable */
int v6(void) { int r = gb; r -= 1; r <<= 8; r += 128; return r; }
