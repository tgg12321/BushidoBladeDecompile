#!/usr/bin/env python3
"""Replace the u8 D_800A1494/95 externs with the honest volatile CD_intr struct
declaration (libcd bios.c v1.86 `static volatile CD_intr Intr`), casting the
two existing u8* init sites."""
SRC = "src/system.c"
src = open(SRC, "rb").read().decode("utf-8")

old1 = "extern u8 D_800A1494;\nextern u8 D_800A1495;\ns32 cpu_side_move_dir_4"
new1 = ("typedef struct { u8 sync; u8 ready; u8 c; } CD_intr_s;\n"
        "typedef struct { s32 time; s32 count; u8 *name; } CD_alarm_s;\n"
        "extern volatile CD_intr_s D_800A1494; /* libcd `static volatile CD_intr Intr` (IRQ-mutated; memory/closer/libcd-identity.md) */\n"
        "s32 cpu_side_move_dir_4")
assert old1 in src
src = src.replace(old1, new1)

old2 = "  idx_1494 = &D_800A1494;\n  idx_1495 = (u8 *)((u8 *)tbl_125c"
new2 = "  idx_1494 = (u8 *)&D_800A1494;\n  idx_1495 = (u8 *)((u8 *)tbl_125c"
assert old2 in src
src = src.replace(old2, new2)

old3 = "extern u8 D_800A1494;\nextern u8 D_800A1495;\nextern volatile u32 *D_800A14C0;"
new3 = "extern volatile u32 *D_800A14C0;"
assert old3 in src
src = src.replace(old3, new3)

old4 = "    idx_1494 = &D_800A1494;\n    tbl_125c = D_800A125C;"
new4 = "    idx_1494 = (u8 *)&D_800A1494;\n    tbl_125c = D_800A125C;"
assert old4 in src
src = src.replace(old4, new4)

open(SRC, "wb").write(src.encode("utf-8"))
print("struct decl installed")
