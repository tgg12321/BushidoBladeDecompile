typedef int s32;
typedef unsigned short u16;
typedef unsigned int u32;
typedef void (*Callback)(void);

typedef struct {
    u16 interruptsInitialized;
    u16 inInterrupt;
    Callback handlers[11];
    u16 enabledInterruptsMask;
    u16 savedMask;
    int savedPcr;
    s32 buf[12];
    s32 stack[1024];
} intrEnv_t;

struct Callbacks {
    const char *rcsid;
    void *DMACallback;
    void *InterruptCallback;
    void *ResetCallback;
    void *StopCallback;
    void *VSyncCallbacks;
    void *RestartCallback;
    void *intrEnv;
};

static intrEnv_t intrEnv;
static struct Callbacks callbacks;
struct Callbacks *pCallbacks = &callbacks;
static volatile u16 *i_stat = (u16 *)0x1F801070;
static volatile u16 *g_InterruptMask = (u16 *)0x1F801074;
static volatile s32 *d_pcr = (s32 *)0x1F8010F0;

extern void memclr(void *, u32);
extern s32 setjmp(s32 *);
extern void trapIntr(void);
extern void HookEntryInt(s32 *);
extern void *startIntrVSync(void);
extern void *startIntrDMA(void);
extern void _96_remove(void);
extern void ExitCriticalSection(void);

intrEnv_t *startIntr(void) {
    if (intrEnv.interruptsInitialized) {
        return 0;
    }
    *i_stat = *g_InterruptMask = 0;
    *d_pcr = 0x33333333;
    memclr(&intrEnv, sizeof(intrEnv) / sizeof(s32));
    if (setjmp(intrEnv.buf) != 0) {
        trapIntr();
    }
    intrEnv.buf[1] = (s32)&intrEnv.stack[1004];
    HookEntryInt(intrEnv.buf);
    intrEnv.interruptsInitialized = 1;
    pCallbacks->VSyncCallbacks = startIntrVSync();
    pCallbacks->DMACallback = startIntrDMA();
    _96_remove();
    ExitCriticalSection();
    return &intrEnv;
}
