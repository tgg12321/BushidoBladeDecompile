#!/usr/bin/env python3
"""Install the faithful port: insert helpers before marionation_Exec (after the
D_800A147C_2 extern line) and replace the marionation body. Idempotent."""
import sys

SRC = "src/system.c"
HELPERS = open("tmp/marion_faith2/helpers.c", "rb").read().decode("utf-8").replace("\r\n", "\n")
BODY = open(sys.argv[1] if len(sys.argv) > 1 else "tmp/marion_faith2/v1_faithful_port.c",
            "rb").read().decode("utf-8").replace("\r\n", "\n")

src = open(SRC, "rb").read().decode("utf-8")
anchor = 'extern volatile u8 *D_800A147C_2 asm("D_800A147C");\n'
sig = "s32 marionation_Exec(s32 a0, u8 *a1)\n"
end_marker = "/* kengo:HIGH  |  nm_mario/marionation_Exec"

i_anchor = src.index(anchor) + len(anchor)
i_sig = src.index(sig)
i_end = src.index(end_marker)
new = src[:i_anchor] + HELPERS + BODY.rstrip("\n") + "\n" + src[i_end:]
open(SRC, "wb").write(new.encode("utf-8"))
print("installed faithful port (%d helper lines + %d body lines)" %
      (len(HELPERS.split("\n")), len(BODY.split("\n"))))
