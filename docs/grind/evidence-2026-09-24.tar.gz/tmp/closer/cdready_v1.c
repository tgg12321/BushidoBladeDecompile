/* Faithful reconstruction of PsyQ libcd bios.c v1.86 CD_ready (== marionation_Exec)
 * from the sotn-decomp v1.77 source (W3 bracket: C unchanged v1.77->v1.86).
 * Standalone TU probe: does our cc1 + project flags reproduce the 179 target insns
 * from the literal original source shape? */
typedef unsigned char u8;

typedef char Result_t[8];
typedef struct { u8 sync; u8 ready; u8 c; } CD_intr;
typedef struct { int time; int count; char *name; } Alarm_t;

extern volatile Alarm_t Alarm;               /* D_800F19B8/BC/C0 */
extern volatile CD_intr Intr;                /* D_800A1494/95/96 */
extern char *CD_comstr[];                    /* D_800A11DC */
extern char *CD_intstr[8];                   /* D_800A125C */
extern u8 CD_com;                            /* D_800A11D5 */
extern volatile u8 *CD_reg0;                 /* D_800A147C */
extern Result_t D_sync_res;                  /* D_800F19A0 */
extern Result_t D_ready_res;                 /* D_800F19A8 */
extern Result_t D_dataend_res;               /* D_800F19B0 */
extern void (*CD_cbsync)(u8, u8 *);          /* D_800A11B4 */
extern void (*CD_cbready)(u8, u8 *);         /* D_800A11B8 */

extern int VSync(int);                       /* sys_VSync */
extern int CheckCallback(void);              /* sys_GetVblankCount */
extern int getintr(void);                    /* func_80080828 */
extern void CD_flush(void);                  /* cdrom_ClearIrq */
extern int puts(char *);                     /* tslTm2LoadImage_2 */
extern void printf(char *, ...);             /* debug_printf */

static inline void _memcpy(void *_dst, void *_src, int _size) {
    char *pDst = (char *)_dst;
    char *pSrc = (char *)_src;

    if (pDst == 0) {
        return;
    }

    while (_size--) {
        *pDst++ = *pSrc++;
    }
}

static inline void set_alarm(char *name) {
    ((Alarm_t *)&Alarm)->time = VSync(-1) + 960;
    ((Alarm_t *)&Alarm)->count = 0;
    ((Alarm_t *)&Alarm)->name = name;
}

static inline int get_alarm(void) {
    if (((Alarm_t *)&Alarm)->time < VSync(-1) ||
        ((Alarm_t *)&Alarm)->count++ > 0x3C0000) {
        puts("CD timeout: ");
        printf("%s:(%s) Sync=%s, Ready=%s\n", ((Alarm_t *)&Alarm)->name,
               CD_comstr[CD_com],
               CD_intstr[Intr.sync], CD_intstr[Intr.ready]);
        CD_flush();
        return -1;
    }
    return 0;
}

static inline void callback(void) {
    int interrupt;
    u8 temp_s1;

    temp_s1 = *CD_reg0 & 3;

    while (1) {
        interrupt = getintr();
        if (interrupt == 0) {
            break;
        }

        if ((interrupt & 4) && CD_cbready != 0) {
            CD_cbready(Intr.ready, (u8 *)&D_ready_res);
        }
        if ((interrupt & 2) && CD_cbsync != 0) {
            CD_cbsync(Intr.sync, (u8 *)&D_sync_res);
        }
    }
    *CD_reg0 = temp_s1;
}

int CD_ready(int mode, u8 *result) {
    int i;
    int c;
    int ready;

    set_alarm("CD_ready");
    while (1) {
        if (get_alarm()) {
            return -1;
        }
        if (CheckCallback()) {
            callback();
        }
        c = Intr.c;
        if (c != 0) {
            Intr.c = 0;
            _memcpy(result, &D_dataend_res, sizeof(Result_t));
            return c;
        }
        ready = Intr.ready;
        if (ready != 0) {
            Intr.ready = 0;
            _memcpy(result, &D_ready_res, sizeof(Result_t));
            return ready;
        }
        if (mode != 0) {
            return 0;
        }
    }
}
