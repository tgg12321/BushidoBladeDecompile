#!/usr/bin/env python3
"""Are the .text / .rodata CONTENTS identical between the as-is and converted
objects for the three 'non-.text emitter' functions?"""
import hashlib
import subprocess
import sys
from pathlib import Path

PAIRS = [("code6cac", "cpu_check_run_attack"),
         ("main", "func_80089F3C"),
         ("main", "SetPacketData")]
WD = Path("tmp/w5_rodata")


def sec_md5(o, sec):
    out = WD / "x.bin"
    r = subprocess.run(["mipsel-linux-gnu-objcopy", "-O", "binary",
                        f"--only-section={sec}", str(o), str(out)],
                       capture_output=True, text=True)
    if r.returncode != 0 or not out.exists():
        return f"<none: {r.stderr.strip()[:40]}>"
    return hashlib.md5(out.read_bytes()).hexdigest()[:12] + f" ({out.stat().st_size}B)"


for stem, func in PAIRS:
    base = WD / f"{stem}.base.o"
    conv = WD / f"{stem}.conv_{func}.o"
    print(f"{func}  (src/{stem}.c)")
    for sec in (".text", ".rodata", ".data", ".bss"):
        a, b = sec_md5(base, sec), sec_md5(conv, sec)
        same = "IDENTICAL" if a == b else "*** DIFFER ***"
        print(f"    {sec:8s} {same}")
        if a != b:
            print(f"        base {a}\n        conv {b}")
    print()
