typedef struct GameObj GameObj;
# 0 "src/code6cac.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/mipsel-linux-gnu/include/stdc-predef.h" 1 3
# 0 "<command-line>" 2
# 1 "src/code6cac.c"

# 1 "include/common.h" 1




typedef unsigned char u8;
typedef signed char s8;
typedef unsigned short u16;
typedef signed short s16;
typedef unsigned int u32;
typedef signed int s32;
typedef unsigned long long u64;
typedef signed long long s64;

typedef volatile u8 vu8;
typedef volatile s8 vs8;
typedef volatile u16 vu16;
typedef volatile s16 vs16;
typedef volatile u32 vu32;
typedef volatile s32 vs32;
# 3 "src/code6cac.c" 2
# 1 "include/include_asm.h" 1
# 27 "include/include_asm.h"
__asm__(".include \"include/macro.inc\"\n");
# 4 "src/code6cac.c" 2
# 1 "include/gpu.h" 1





# 1 "include/common.h" 1
# 7 "include/gpu.h" 2
# 20 "include/gpu.h"
typedef struct {
    u32 addr : 24;
    u32 len : 8;
} OTag;


extern void (*g_gpu_debug_func)();
extern u8 g_gpu_debug_level;
# 40 "include/gpu.h"
typedef struct GpuDevTable {
               const char *rcsid;
               void (*addque)();
               s32 (*addque2)();
               s32 (*clr)();
               void (*ctl)();
               s32 (*cwb)();
               void (*cwc)();
               s32 (*drs)();
               s32 (*dws)();
               s32 (*exeque)();
               s32 (*getctl)();
               s32 (*otc)();
               s32 (*param)();
               s32 (*reset)();
               u32 (*status)();
               s32 (*sync)();
} GpuDevTable;

extern GpuDevTable *g_gpu_dev_table;
extern s16 g_gpu_disp_x;
extern s16 g_gpu_disp_y;
extern u8 g_gpu_dither;
extern u8 g_gpu_type;


extern void gpu_DisableDisplay(void);
extern void gpu_EnableDisplay(void);
extern void gpu_InitDisplay(void);
# 5 "src/code6cac.c" 2
# 1 "include/sound.h" 1
# 9 "include/sound.h"
extern s32 g_snd_bgm_id;
extern s32 g_snd_se_id;
extern s32 g_snd_volume;


extern void SsSetSerialAttr(s32, s32, s32);
# 6 "src/code6cac.c" 2
# 1 "include/game.h" 1
# 9 "include/game.h"
extern u8 SpecialCam;
extern u8 g_disp_enable;
extern u8 g_disp_fade;
extern s16 g_game_mirror_mode;
extern s16 g_game_p2_ctrl;
extern s32 g_game_timer;
extern s16 g_stage_id;
extern s16 g_stage_variant;
# 7 "src/code6cac.c" 2
# 1 "include/system.h" 1
# 9 "include/system.h"
extern u8 g_file_disc_type;
extern s16 g_file_vram_timer;


extern void ResetCallback(void);
# 8 "src/code6cac.c" 2
# 1 "include/code6cac.h" 1
# 9 "include/code6cac.h"
extern s16 StatusUpBuf;
extern u8 cpu_practice_honmokuroku_data_tbl;
extern u8 g_module_type_tbl;
extern s32 menuDat;
extern s16 single_dojo_yaburi_char_id_tbl;





typedef struct PracticeMenuRec {
    u8 unk_00[0x12];
    s16 unk_12;
    u8 unk_14[0x438];
} PracticeMenuRec;

extern PracticeMenuRec g_practice_menu_table[];


extern s32 D_800100A4;
extern s32 D_800109C8;
extern u8 D_8008D518;
extern u8 D_8008D538;
extern u8 D_8008D55C;
extern u8 D_8008D578;
extern u16 D_8008D59E;
extern u8 D_8008D864;
extern s32 D_8008D86C;
extern s32 D_8008D88C;
extern u8 D_8008D9EC;
extern u8 D_8008DA08;
extern s16 D_8008DA50;
extern s16 D_8008DA94;
extern s16 D_8008DAD8;
extern u8 D_8008DB1C;
extern s16 D_8008E194;
extern s16 D_8008E19E;
extern u8 D_8008E1A1;
extern u8 D_8008E338;
extern u16 D_8008E3C0;
extern u8 D_8008E5A8;
extern u8 D_8008E5CC;
extern u8 D_8008E748;
extern u8 D_8008E75C;
extern u8 D_8008EA44;
extern u8 D_8008EA45;
extern s16 D_8008EAC0;
extern s16 D_8008EB04;
extern s16 D_8008EB06;
extern s16 D_8008EB08;
extern s16 D_8008EB0A;
extern s16 D_8008EB0C;
extern s32 D_8008EB10;
extern s32 D_8008EB14;
extern s32 D_8008EB18;
extern u8 D_8008EB1C;
extern u8 D_8008EB38;
extern s16 D_8008EB54;
extern u8 D_8008EB6C;
extern u8 D_8008EB80;
extern u8 D_8008EB8E;
extern u16 D_8008EBA0;
extern s32 D_8008EBCC;
extern s32 D_8008EBE0;
extern u8 D_8008EBF4;
extern u8 D_8008EBFC;
extern u8 D_8008EBFD;
extern u8 D_8008EC30;
extern u32 D_8008EC38;
extern s16 D_8008F12C;
extern u8 D_8008F13C;
extern u8 D_8008F19C;
extern u8 D_8008F19D;
extern u8 D_8008F1A8[];
extern u8 D_8008F204[];
extern u8 D_800900EC;
extern u8 D_8009016C;
extern u32 D_80090178;
extern u32 D_800905F8;
extern s32 D_80090600;
extern s32 D_80090604;
extern s16 D_80090608;
extern s16 D_800906A4;
extern s32 D_800948C0;
extern u16 D_80094C68;
extern s16 D_800A310C;
extern s32 D_800A3134;
extern s32 D_800A3140;
extern u8 D_800A31DA;
extern u32 D_800A3220;
extern u8 D_800A3670;
extern u8 D_800A3671;
extern s16 D_800A367A;
extern s16 D_800A367C;
extern u8 D_800A3680;
extern s32 D_800A368C;
extern u8 D_800A3690;
extern s32 D_800A369C;
extern s16 D_800A36A4;
extern s32 D_800A36AC;
extern s32 D_800A36B4;
extern u8 D_800A36B9;
extern u8 D_800A36BA;
extern u8 D_800A36BB;
extern s16 D_800A36C2;
extern s32 D_800A36C4;
extern s16 D_800A36C6;
extern u8 D_800A36C8;
extern u16 D_800A36CA;
extern u8 D_800A36CC;
extern s16 D_800A36D2;
extern s32 D_800A36D4;
extern s32 D_800A36D8;
extern u8 D_800A36E8;
extern u8 D_800A36F0;
extern u8 D_800A36F1;
extern u8 D_800A36F2;
extern u8 D_800A36F4;
extern s16 D_800A36F6;
extern u8 D_800A36F9;
extern u8 D_800A36FA;
extern s16 D_800A36FC;
extern u8 D_800A3712;
extern u8 D_800A3713;
extern u8 D_800A3719;
extern u8 D_800A371A;
extern u8 D_800A371B;
extern s32 D_800A371C;
extern u8 D_800A3728;
extern s8 D_800A3748;
extern s16 D_800A3756;
extern u8 D_800A3758;
extern u8 D_800A3764;
extern u8 D_800A3769;
extern u8 D_800A376A;
extern u8 D_800A376B;
extern u8 D_800A376C;
extern s16 D_800A376E;
extern s32 D_800A3778;
extern u8 D_800A377B;
extern u8 D_800A3781;
extern u8 D_800A3783;
extern s32 D_800A3784;
extern u8 D_800A3788;
extern s32 D_800A3794;
extern u8 D_800A37A0;
extern s32 D_800A37A4;
extern u8 D_800A37B0;
extern u8 D_800A37B4;
extern u8 D_800A37B5;
extern u8 D_800A37B6;
extern s32 D_800A37B8;
extern u8 D_800A37BC;
extern s32 D_800A37C0;
extern u8 D_800A37C6;
extern u8 D_800A37D2;
extern u8 D_800A37D3;
extern u8 D_800A37E0;
extern u8 D_800A37E1;
extern s16 D_800A37E8;
extern s16 D_800A37EA;
extern s16 D_800A37EC;
extern u8 D_800A37F8;
extern u8 D_800A3804;
extern s32 D_800A380C;
extern u8 D_800A3816;
extern u8 D_800A3817;
extern s16 D_800A381C;
extern u8 D_800A381E;
extern s32 D_800A3820;
extern s16 D_800A3824;
extern u8 D_800A382D;
extern s16 D_800A382E;
extern s32 D_800A3830;
extern s16 D_800A3834;
extern u8 D_800A3836;
extern s32 D_800A3844;
extern s32 D_800A3858;
extern u8 *D_800A385C;
extern s32 D_800A3860;
extern s32 D_800A3864;
extern u8 D_800A3874;
extern s16 D_800A3876;
extern s32 D_800A3878;
extern s32 D_800A387C;
extern u8 D_800A3880;
extern s32 D_800A3888;
extern s32 D_800A388C;
extern u8 D_800A3898;
extern u8 D_800A3899;
extern u8 D_800A389A;
extern u8 D_800A389B;
extern u16 D_800A389C;
extern s32 D_800A38A0;
extern u8 D_800A38A4;
extern s16 D_800A38A8;
extern u8 D_800A38AA;
extern u8 D_800A38AB;
extern s16 D_800A38AE;
extern u8 D_800A38B0;
extern u8 D_800A38B8;
extern s16 D_800A38BA;
extern u8 D_800A38C0;
extern u8 D_800A38C1;
extern u16 D_800A38C6;
extern u8 D_800A38D4;
extern s16 D_800A38DC;
extern u8 D_800A38DE;
extern u8 D_800A38DF;
extern u8 D_800A38E0;
extern u8 D_800A38E1;
extern u8 D_800A38E2;
extern s32 D_800A38E4;
extern u8 D_800A38E8;
extern u8 D_800A38E9;
extern u8 D_800A38EC;
extern u8 D_800A38ED;
extern u8 D_800A38EE;
extern s32 D_800A38F0;
extern s32 D_800A38F4;
extern u8 D_800A38F8;
extern u8 D_800A3906;
extern u8 D_800A3907;
extern u8 D_800A390C;
extern u8 D_800A390D;
extern s8 D_800A390E;
extern u8 D_800A390F;
extern s16 D_800A3910;
extern u8 D_800A3912;
extern u8 D_800A3913;
extern u8 D_800A3914;
extern u8 D_800A3915;
extern u8 D_800A3918;
extern u8 D_800A391E;
extern u8 D_800A391F;
extern u8 D_800A3920;
extern u8 D_800A3928;
extern u8 D_800A3929;
extern s32 D_800A3D40;






typedef struct Rec44 {
    s32 w0; s32 w4; s32 w8; s32 wC;
    s16 h10; s16 h12; s16 h14; s16 h16;
    s32 w18;
    s16 h1C; u8 b1E; u8 b1F;
    s32 w20; s32 w24; s32 w28; s32 w2C;
    s16 h30; s16 h32; s16 h34; s16 h36;
    s16 h38; s16 h3A; s16 h3C; s16 h3E;
    u8 b40; u8 b41; u8 b42; u8 b43;
} Rec44;



typedef struct Rec1C {
    s16 h0; s16 h2; s16 h4; s16 h6; s16 h8; s16 hA; s16 hC; s16 hE;
    s32 w10; s32 w14; s32 w18;
} Rec1C;
extern Rec44 D_800F5328;
extern Rec44 D_800F6608;
extern u8 D_800F65F9;
extern s16 D_800F68E0[];
extern s32 D_800FF584;
extern s32 D_800FF5A4;
extern s32 D_800FF5A8;
extern s32 D_800FF5C8;
extern s32 D_800FF5CC;
extern s32 D_800FF5D0;
extern s16 D_800FF5D8;
extern s16 D_800FF5DA;
extern s16 D_800FF5DC;
extern s32 D_800FF5E0;
extern u8 D_80101BF0;
extern s16 D_80101E00;
extern u8 D_80101E59;
extern s32 D_80101E5C;
typedef struct {
    s32 a;
    s32 b;
} CamPair;
# 320 "include/code6cac.h"
typedef struct {
    s16 unk00;
    s16 unk02;
    s16 unk04;
    s16 unk06;
    s16 unk08;
    s16 unk0A;
    CamPair pair;
    s32 unk14;
} ReplayCamRec;

extern ReplayCamRec D_80101E60;
extern s32 D_80101E78;
extern s32 D_80101E7C;
extern s32 D_80101E80;
extern s32 D_80101E84;
extern s32 D_80101E88;
extern s32 D_80101E8C;
extern u8 D_80101E90;
extern s32 D_80101E94;
extern s16 D_80101E98;
extern s16 D_80101E9A;
extern s16 D_80101E9C;
extern u16 D_80101E9E;
extern s32 D_80101EA0;
extern s32 D_80101EA4;
extern u8 D_80101EC8;
extern s16 D_80101ECE;
extern s16 D_80101ED2;
extern s16 D_80101EDC;
extern s16 D_80101EE8;
extern s32 D_80101F04;
extern s16 D_80101F08;
extern s16 D_80101F10;
extern s16 D_80101F12;
extern s16 D_80101F14;
extern s16 D_80101F26;
extern s16 D_80101F42;
extern s16 D_80101F4C;
extern s16 D_80101F4E;
extern s16 D_80101F5E;
extern u8 D_80101F75;
extern u8 D_80101F79;
extern u8 D_80101F7A;
extern u8 D_80101F7B;
extern s32 D_80101F80;
extern s32 D_80101F84;
extern s32 D_80101F88;
extern s32 D_80101FA0;
extern s32 D_80101FA4;
extern s32 D_80101FA8;
extern s32 D_80101FB0;
extern s32 D_80101FB4;
extern s32 D_80101FB8;
extern s32 D_80101FBC;
extern s32 D_80101FC0;
extern s32 D_80101FC4;
extern s32 D_80101FCC;
extern s32 D_80101FD0;
extern s32 D_80101FD4;
extern s32 D_80101FDC;
extern s32 D_80101FE0;
extern s32 D_80101FE4;
extern s32 D_80101FEC;
extern s32 D_80101FF0;
extern s32 D_80101FF4;
extern s32 D_80101FFC;
extern s32 D_80102000;
extern s32 D_80102004;
extern s32 D_8010200C;
extern s32 D_80102010;
extern s16 D_80102014;
extern s16 D_80102016;
extern s16 D_80102018;
extern s16 D_8010201A;
extern s32 D_8010203C;
extern s32 D_80102040;
extern s32 D_80102044;
extern s32 D_80102054;
extern s32 D_80102058;
extern s32 D_8010205C;
extern s32 D_801020D8;
extern s32 D_801020DC;
extern s32 D_801020E0;
extern s32 D_801020E4;
extern s32 D_801020E8;
extern s32 D_801020EC;
extern s32 D_801020FC;
extern s32 D_80102100;
extern s32 D_80102104;
extern s32 D_80102108;
extern s32 D_8010210C;
extern s32 D_80102110;
extern s16 D_8010214E;
extern s32 D_80102154;
extern s16 D_801021E2;
extern u8 D_80102216;
extern s16 D_8010231A;
extern u16 D_80102322;
extern s16 D_80102334;
extern s32 D_80102350;
extern s16 D_8010235C;
extern s16 D_80102372;
extern u16 D_8010237E;
extern s16 D_8010238E;
extern s16 D_801023AA;
extern u8 D_801023C1;
extern u8 D_801023C5;
extern s32 D_801023EC;
extern s32 D_801023F4;
extern s32 D_80102408;
extern s32 D_80102410;
extern s32 D_80102448;
extern s32 D_80102450;
extern s16 D_80102462;
extern s16 D_801024DE;
extern s16 D_8010259A;
extern s32 D_801025A0;
extern s16 D_8010262E;
extern s32 D_80102760;
extern s32 D_80102764;
extern s32 D_80102768;
extern s32 D_80102770;
extern s16 D_80102778;
extern s16 D_8010277A;
extern u8 D_8010277C;
extern u8 D_8010277E;
extern u8 D_80102780;
extern u8 D_80102782;
extern u8 D_80102783;
extern u8 D_80102784;
extern u8 D_80102785;
extern u8 D_80102786;
extern u8 D_80102787;
extern s16 D_80102788;
extern s16 D_8010278A;
extern s16 D_8010278C;
extern s16 D_8010278E;
extern s32 D_80102790;
extern u8 D_80102795;
extern s32 D_80102798;
extern s32 D_8010279C;
extern s32 D_801027B0;
extern s32 D_801027B4;
extern s32 D_801027B8;
extern s32 D_801027BC;
extern s32 D_801027C0;
extern s32 D_801027D4;
extern u8 D_80104E88;
extern s32 MotDataBaseAddress;
extern u8 D_80106A70;
extern u8 D_80106A71;
extern u8 D_80106A72;
extern s16 D_80106A7A;
extern u8 D_80106A80;
extern u8 D_80106A82;
extern u8 D_801077AF;
extern u8 D_801077B0;
extern u8 D_801077BA;
extern s32 D_80107850;
extern s32 D_80107854;
extern s32 D_80107858;


extern void func_8001B748(Rec44 *, Rec1C *, Rec1C *, s32, s32, s32);
extern void func_8003D52C(s32, s32, s32, s32);
extern void func_80021A98(s32, u8 *, s32);
extern void func_80022580(s32, s32, s32, s32, s32);
extern s32 func_80036EA8(s32, s32);
extern void func_8003A728(s32);
extern void func_8003AE5C(s32);
extern void func_8003DE14(s32 *, s32);
extern void game_SetControllerPorts(s32);
extern void func_80041688(s32, s32);
extern void func_80048BA4(s32, s32, s32);
extern void func_800493E4(s32);
extern void func_800494D4(s32, s32);
extern void func_80049584(s32);
extern s32 func_8005B8B8(s32);
extern void func_8005C6D0(void);
extern void Exec(s32 *, s32, s32 *);
extern s32 format(s32 *);
extern void sprintf(s32 *, s32, s32, s32);
extern void ResetGraph(s32);
extern void SetDispMask(s32);
extern void DrawSync(s32);
extern void CdInit(void);
extern void CdFlush(void);
extern void CdSetDebug(s32);
extern void CdReadyCallback(s32);
extern void CdControlF(s32, s32);
extern void CdRead(s32);
extern s32 CdReadSync(s32, s32);
extern void SsSetSerialVol(s32, s32, s32);
extern s32 _comb_control(s32, s32, s32);
extern s32 func_80038C70(void);
extern void func_8003E2D8(s32, s32, s32, s32);
extern void func_80036940(void);
# 9 "src/code6cac.c" 2
# 1 "include/bb2_const.h" 1
# 10 "src/code6cac.c" 2






typedef struct MATRIX { s16 m[3][3]; u16 pad; s32 t[3]; } MATRIX;


extern u8 D_8008D118;
extern s32 D_800F33D8;
extern u32 D_800A378C;
extern u32 D_80101E3C;
extern u32 D_80101E44;
extern s32 D_800FF580;


extern s32 func_80037110(s32);
extern void game_FrameInit(void);
extern void game_FrameLoop(void);
extern void seq_Reset(void);
extern void func_8003A39C(void);
extern void VSync(s32);
extern void LoadImage(s32, s32);
extern s32 func_80036FD4(void);
extern void func_80035FA8(void);
extern void game_Cleanup(void);
extern s32 func_800371E8(s16);
extern void seq_Start(s32, s32);
extern u16 g_game_p1_ctrl;
extern s32 D_80102794;
extern s32 D_800A3894;
extern u16 D_800A38C4;
extern s16 D_80101F32;
extern void func_80035F30(s32, s32, s32, s32);
extern void obj_InitChars(void);
extern void obj_Reset(void);
extern void obj_InitTask(void);
extern void obj_InitPair(void);
extern void player_SetCharId(s32, s32);
extern void player_Destroy(s32);
extern void file_ResetDmaFlag(void);
extern void obj_InitAll(void);
extern void func_80077820(s32);
extern s32 D_80101E70;
extern s32 D_800A3894;
extern s8 D_80102781;
extern u16 D_800A3310;


extern s8 D_8010277D;
extern s8 D_8010277F;
extern s16 D_800A391D;
extern s32 file_GetFlag2(void);
extern s16 *snd_GetSeId(void);
extern void func_800324D0(u8 *);
extern void func_8003553C(void);
extern void func_8003AF40(s32);
extern void func_8003AFFC(void);

extern void sys_Panic(void);
extern s32 obj_InitTaskCamera(s32);
extern s32 D_800A38B4;
extern s32 memcpy(s32 *, s32, s32);
extern void obj_ExecTask(s32);
extern s32 func_8005344C(s32 *, s32 *, s32 *, s32 *, s32);
extern s32 func_80054434(void);
extern void func_8002EBDC(s16 *, s16 *, s32 *, s32, s32);

extern void func_8005B98C(s32);
extern void func_8003AA78(void);
extern s32 func_80036D88(void);
extern void func_8003AA48(void);
extern void func_800174F4(void);
extern void func_8003AAB0(void);
extern u8 D_800A384C;
extern s32 ratan2(s32, s32);
extern s16 D_80101E74;

extern void file_LoadOverlay(void);
extern void func_80040510(s32, s32, s32);
extern s32 stage_GetDataPtr(void);

extern void func_8005B50C(void);
extern void func_80037774(void);
extern void special_camera_get_rot_dir(s32 *);
extern void StopPAD(void);
extern void StopCallback(void);
extern s32 EnterCriticalSection(void);
extern void sys_Init(void);
extern void file_LoadSoundData(void);
extern s32 func_8004939C(void);
extern s32 func_800392B8(void);
extern s16 Judge;
extern s16 D_800A3678;
extern s32 D_800A3708;
extern s32 D_800A374C;
extern u8 D_800A377C;
extern u8 D_800A37A8;
extern u16 D_800A3904;
extern u8 D_800F65F8;
extern s32 g_anim_func_table;
extern s32 g_pad_data;
extern u16 D_80101E02;
extern u16 D_80101E04;
extern s16 D_80101ED6;
extern u8 D_800F1B18[];
extern s32 g_file_disc_size;
extern s32 replay_camera_Init(s32, s32);
extern s32 rand();
extern void func_800325E0(s32, s32);
extern void func_80046BF4(s32 *, s32 *, s32);
extern s32 game_GetPlayerData(s32);
extern s32 func_80032854(s32, s32, u8 *, s16 *);
extern void func_8002EECC(s32, s32 *);
extern void func_80061064(s32 *, s32 *);
extern s32 SquareRoot0(s32);
extern void *RotMatrixX(s32, s32);
extern void *RotMatrixY(s32, s32);
extern void *RotMatrixZ(s32, s32);
extern s32 func_80053614(s32 *, s32 *, s32 *, s32 *, s32);
extern u16 D_8008D59C;
extern s16 D_8008EB40;
extern u8 D_800F5F68;
extern s16 Judge;
extern void func_80033BC0(void);
extern void func_8001DA2C(void);
extern void game_SetPlayerCount(s32);
extern s32 disp_CalcFov(s32);
extern void SetGeomScreen(s32);
extern void func_8003F3D4(s16 *);
extern void func_80055138(s32, s32, s32);
extern void func_8003FFE0(s32);
extern s32 D_80101F90;
extern s32 D_801020C0;
extern s32 D_80102114;
extern s32 camera_GetBoneData(void);
extern void func_80039320(void);
extern void func_8002C61C(void);
extern void func_80030D7C(void);
extern void func_800321E8(void);
extern void func_800397A0(void);
extern void func_8003E6A0(s32, s32);
extern void game_StageInit(s32);
extern void func_800335D8(void);
extern s32 D_80102030;
extern s8 D_800A3768;
extern void func_800321E8(void);
extern void func_800335D8(void);
extern void func_80033BC0(void);
extern void func_8005C650(s32, s32, s32);
extern s32 func_8005C8A8(s32, s32, s32, s32);
extern s32 func_8005FA98(s32, s32, s32);
extern s32 func_8005D814(s16 *, s32, s32, s32);
extern void func_800550E8(s32);
typedef struct { s32 f0, f1, f2, f3; } Copy16;
extern void func_80017FA0(s32 *);
extern void func_80018300(s32 *);
extern void func_800372C0(void);
extern void func_80023F08(s32, s32);
# 209 "src/code6cac.c"
void func_80017FA0(s32 *a0) {
    s32 *scr = (s32 *)0x1F800000;
    s32 temp;
    s32 *ptr;

    temp = a0[3];
    if (temp == 0) {
        goto end;
    }
    ptr = (s32 *)temp;

    scr[0x2E] = ptr[0] << 7;

    {
        s32 i = 0;
        if (i < ptr[1]) {
            s32 *p68 = ptr;
            s32 *ac_base = (s32 *)0x1F800000;
            s32 sp_off = 0;
            do {
                s32 j = 0;
                s32 data_off = i << 5;
                s32 sp_inner = sp_off;
                do {
                    s32 *dp = (s32 *)((u8 *)ptr + data_off);
                    *(s32 *)(0x1F800064 + sp_inner) = dp[2] << 2;
                    data_off += 0x10;
                    *(s32 *)(0x1F800068 + sp_inner) = dp[3] << 2;
                    j++;
                    *(s32 *)(0x1F80006C + sp_inner) = dp[4] << 2;
                    sp_inner += 0xC;
                } while (j < 2);
                ac_base[0x2B] = *(s32 *)((u8 *)p68 + 0x68) << 2;
                p68 = (s32 *)((u8 *)p68 + 4);
                sp_off += 0x18;
                i++;
                ac_base++;
            } while (i < ptr[1]);
        }
    }

    scr[0x18] = ((s32 *)a0[3])[1];
end:
    ;
}
void func_80018094(s32 *arg0, s32 *arg1) {
    register s32 *p0 asm("s0") = arg0;
    register s32 *p1 asm("s1") = arg1;
    s32 sp_area[4];

    {
        register s32 mat_ptr asm("a2") = p0[1];


        __asm__ volatile (".word 0x00000000" :: "r"(mat_ptr));
        __asm__ volatile (".word 0x00C06021" :: "r"(mat_ptr));
        __asm__ volatile (".word 0x8D8D0000" :: "r"(mat_ptr));
        __asm__ volatile (".word 0x8D8E0004" :: "r"(mat_ptr));
        __asm__ volatile (".word 0x48CD0000" :: "r"(mat_ptr));
        __asm__ volatile (".word 0x48CE0800" :: "r"(mat_ptr));
        __asm__ volatile (".word 0x8D8D0008" :: "r"(mat_ptr));
        __asm__ volatile (".word 0x8D8E000C" :: "r"(mat_ptr));
        __asm__ volatile (".word 0x8D8F0010" :: "r"(mat_ptr));
        __asm__ volatile (".word 0x48CD1000" :: "r"(mat_ptr));
        __asm__ volatile (".word 0x48CE1800" :: "r"(mat_ptr));
        __asm__ volatile (".word 0x48CF2000" :: "r"(mat_ptr));
    }



    __asm__ volatile (".word 0x8E060004");
    __asm__ volatile (".word 0x00000000");
    __asm__ volatile (".word 0x00C06021");
    __asm__ volatile (".word 0x8D8D0014");
    __asm__ volatile (".word 0x8D8E0018");
    __asm__ volatile (".word 0x48CD2800");
    __asm__ volatile (".word 0x8D8F001C");
    __asm__ volatile (".word 0x48CE3000");
    __asm__ volatile (".word 0x48CF3800");

    func_80017FA0(p0);

    {
        s32 *mat;
        s32 dx, dy, dz;
        s32 sum_sq;
        s32 scale;

        mat = (s32 *)p0[1];
        dx = mat[5] - p1[10];
        *(volatile s32 *)0x1F800024 = dx;

        mat = (s32 *)p0[1];
        dy = mat[6] - p1[11];
        *(volatile s32 *)0x1F800028 = dy;

        mat = (s32 *)p0[1];
        dz = mat[7] - p1[12];
        *(volatile s32 *)0x1F80002C = dz;

        sum_sq = (dx * dx) + (dy * dy) + (dz * dz);

        scale = 0x100;
        if (sum_sq <= 250000) {
            if (sum_sq < 0) {
                scale = 0;
            } else {
                s32 log2_val;
                if (sum_sq < 0x400) {
                    log2_val = (u32)(*(&D_8008D118 + sum_sq)) >> 3;
                } else {
                    s32 shift_a, shift_b;
                    register s32 t4_v asm("t4");
                    asm volatile("" : "=r"(t4_v));
                    t4_v = sum_sq;
                    {
                        s32 *new_var = &sp_area[0];
                        asm volatile(".word 0x488CF000" : : "r"(t4_v));
                        asm volatile("nop");
                        asm volatile("nop");
                        {
                            s32 addr_v0 = (s32)new_var;
                            t4_v = addr_v0;
                            asm volatile(".word 0xE99F0000" : : "r"(t4_v));
                        }
                    }
                    {
                        s32 lw_v1 = sp_area[0];
                        s32 li_v0 = -2;
                        li_v0 = lw_v1 & li_v0;
                        shift_a = 0x16 - li_v0;
                    }
                    shift_b = shift_a >> 1;
                    log2_val = (((u8)(*(&D_8008D118 + (sum_sq >> shift_a)))) << 16) >> (0x13 - shift_b);
                }
                scale = ((log2_val << 6) / 500) + 0xC0;
            }
        }

        {
            s32 v24 = *(volatile s32 *)0x1F800024;
            s32 v28 = *(volatile s32 *)0x1F800028;
            s32 v2c = *(volatile s32 *)0x1F80002C;
            *(volatile s32 *)0x1F800024 = (v24 * scale) >> 1;
            *(volatile s32 *)0x1F800028 = (v28 * scale) >> 1;
            *(volatile s32 *)0x1F80002C = (v2c * scale) >> 1;
        }
    }

    {
        s32 *src = (s32 *)p0[1];
        *(Copy16 *)((u8 *)p1 + 0x14) = *(Copy16 *)src;
        *(Copy16 *)((u8 *)p1 + 0x24) = *(Copy16 *)((u8 *)src + 0x10);
    }

    func_80018300(p1);
}

__asm__( ".section .text\n" "    .set noat\n" "    .set noreorder\n" "    .include \"" "asm/funcs" "/" "func_80018300" ".s\"\n" "    .set reorder\n" "    .set at\n" );

void func_800187F4(s32 arg0, s32 *arg1);
__asm__( ".section .text\n" "    .set noat\n" "    .set noreorder\n" "    .include \"" "asm/funcs" "/" "func_800187F4" ".s\"\n" "    .set reorder\n" "    .set at\n" );

extern s32 g_file_data_buf;
void func_8001924C(s16 *arg0, s32 arg1) {
    s32 i = 0;
    s16 *s0;
    s32 new_var;

    if (i < arg1) {
        new_var = (s32)&g_file_data_buf;
        s0 = arg0;
        do {
            if (*(u8 *)((u8 *)s0 + 2) & 1) {
                s16 val = s0[0];
                func_80019310(s0, (s32 *)(val * 52 + new_var));
            } else {
                s16 val = s0[0];
                func_800187F4(s0, (s32 *)(val * 52 + new_var));
            }
            i++;
            s0 = (s16 *)((u8 *)s0 + 16);
        } while (i < arg1);
    }
}
void func_80019310(volatile s32 *arg0, s32 *arg1) {
    s32 sp_buf[6];
    register s32 *t0 asm("t0") = arg1;
    register s32 t1 asm("t1");
    register s32 *t4 asm("t4");
    register s32 t5 asm("t5");
    register s32 t6 asm("t6");
    register s32 t7 asm("t7");


    t1 = arg0[1];
    t4 = (s32 *)t1;
    t5 = t4[0];
    t6 = t4[1];
    __asm__ volatile (".word 0x48CD0000" :: "r"(t5));
    __asm__ volatile (".word 0x48CE0800" :: "r"(t6));
    t5 = t4[2];
    t6 = t4[3];
    t7 = t4[4];
    __asm__ volatile (".word 0x48CD1000" :: "r"(t5));
    __asm__ volatile (".word 0x48CE1800" :: "r"(t6));
    __asm__ volatile (".word 0x48CF2000" :: "r"(t7));


    t1 = arg0[1];
    t4 = (s32 *)t1;
    t5 = t4[5];
    t6 = t4[6];
    __asm__ volatile (".word 0x48CD2800" :: "r"(t5));
    t7 = t4[7];
    __asm__ volatile (".word 0x48CE3000" :: "r"(t6));
    __asm__ volatile (".word 0x48CF3800" :: "r"(t7));

    {
        s16 count = *(s16 *)((u8 *)t0 + 4);
        s32 *output = (s32 *)t0[3];
        s32 i = 0;
        if (count > 0) {
            do {
                s32 *base = (s32 *)t0[0];
                s32 *p = (s32 *)((u8 *)base + (i << 3));
                __asm__ volatile ("move %0, %1" : "=r"(t4) : "r"(p));
                __asm__ volatile (".word 0xC9800000" :: "r"(t4));
                __asm__ volatile (".word 0xC9810004" :: "r"(t4));
                __asm__ volatile ("nop");
                __asm__ volatile ("nop");
                __asm__ volatile (".word 0x4A480012");
                t4 = sp_buf;
                __asm__ volatile (".word 0xE9990000" :: "r"(t4));
                __asm__ volatile (".word 0xE99A0004" :: "r"(t4));
                __asm__ volatile (".word 0xE99B0008" :: "r"(t4));

                output[0] = sp_buf[0] << 7;
                output[1] = sp_buf[1] << 7;
                i++;
                output[2] = sp_buf[2] << 7;
                output[3] = 0;
                output[4] = 0;
                output[5] = 0;
                output = (s32 *)((u8 *)output + 0x40);
            } while (i < *(s16 *)((u8 *)t0 + 4));
        }
    }

    {
        typedef struct { s32 a[8]; } Copy8;
        s32 *src = (s32 *)arg0[1];
        *(Copy8 *)((u8 *)t0 + 0x14) = *(Copy8 *)src;
    }
}
void func_8001945C(void) {
    D_80106A70 = 0x11;
    D_80106A71 = 0x44;
    D_80106A72 = 0x88;
}
s32 func_80019488(void) {
    return (D_80106A70 & 0xF) | ((D_80106A71 & 0xF) << 4) | ((D_80106A72 & 0xF) << 8);
}
void func_800194C0(s32 arg0) {
    D_800A3912 = arg0 & 0xF;
    D_800A3913 = (arg0 >> 4) & 0xF;
    D_800A3914 = (arg0 >> 8) & 0xF;
}
void func_800194F4(void) {
    D_80102788 = 4;
    D_8010278A = 4;
    D_80102790 = 0;
    D_80102794 = 0;
    D_80102798 = 0;
    D_8010279C = -1;
}
void func_80019534(void) {
    func_800194F4();
    D_8010278C = 1;
    D_8010278E = 1;
}
void func_80019568(s32 arg0) {
    typedef struct {
        u8 b0;
        u8 b1;
        u8 b2;
        u8 b3;
        u8 _pad[4];
    } VoicePacket;
    struct {
        s16 output[4];
        s32 voice_mask;
        s32 unk_1C;
        s32 unk_20;
        s32 unk_24;
        s32 packets[4];
    } sp;
    register s32 arg0_reg asm("s0") = arg0;
    register s16 *output asm("a2");
    register VoicePacket *packets asm("a3");
    register s32 i asm("t0");
    register s32 voice_mask asm("t1");
    s32 old_mask;
    s32 *D_80102790_p;
    s16 *base_addr;
    s16 *dst1;
    s16 *dst0;
    s16 *src;

    voice_mask = 0;
    i = 0;
    output = &sp.output[0];
    sp.packets[0] = D_800FF580;
    sp.packets[1] = D_800FF584;
    sp.packets[2] = D_800FF5A4;
    sp.packets[3] = D_800FF5A8;
    packets = (VoicePacket *)&sp.packets[0];
    do {
        register s32 bits asm("v1");

        if (packets->b0 == 0) {
            register s32 voice asm("v0");
            s32 voice2;

            voice = packets->b1 >> 4;
            output[0] = voice;
            __asm__ volatile ("addiu %0, $zero, 1" : "=r"(voice));
            output[2] = voice;
            voice2 = (s16)((u16)output[0] - 1);

            if ((u32)voice2 < 8) {
                switch (voice2) {
                case 4:
                case 6:
                    output[0] = 4;
                case 1:
                case 2:
                case 3:
                    bits = ~((packets->b2 << 8) | packets->b3);
                    break;
                case 0:
                case 5:
                case 7:
                default:
                    bits = 0;
                    break;
                }
            } else {
                bits = 0;
            }
        } else {
            output[0] = 4;
            output[2] = 0;
            bits = 0;
        }

        {
            register s32 vm_shifted asm("v0");
            __asm__ volatile ("srl %0, %1, 16" : "=r"(vm_shifted) : "r"(voice_mask));
            voice_mask = vm_shifted | (bits << 16);
        }
        output++;
        i++;
        packets = (VoicePacket *)((u8 *)packets + 8);
    } while (i < 2);

    sp.voice_mask = voice_mask;
    func_8001B138(&sp.voice_mask);

    if (D_800A3834 == 1 && arg0_reg == 0) {
        s32 voice_state = D_800A38DC;

        if ((u32)voice_state < 7) {
            switch (voice_state) {
            case 4:
            case 5:
                if (D_8010278E == 0) {
                    sp.voice_mask |= 0x08000800;
                }
            case 0:
            case 1:
            case 2:
            case 3:
            case 6:
                if (D_8010278C == 0) {
                    sp.voice_mask |= 0x08000800;
                }
                break;
            }
        }
    }

    func_8003A728((s32)&sp.output[0]);

    __asm__ volatile ("addu %0, $zero, $zero" : "=r"(i));
    base_addr = &D_80102788;
    dst1 = base_addr + 2;
    dst0 = base_addr;
    src = &sp.output[0];

    do {
        dst0[0] = src[0];
        dst0++;
        dst1[0] = src[2];
        src++;
        i++;
        dst1++;
    } while (i < 2);

    D_80102790_p = &D_80102790;
    old_mask = *D_80102790_p;
    *D_80102790_p = sp.voice_mask;
    arg0_reg = (D_80102794 = sp.voice_mask & ~old_mask);
    D_8010279C = ~sp.voice_mask;
    D_80102798 = ~sp.voice_mask & old_mask;
}
__asm__( ".section .rodata\n" "    .include \"" "asm/rodata" "/" "D_800100A4" ".s\"\n" ".section .text" );
void func_8001979C(s32 arg0, u32 *arg1) {
    s32 bits_left;
    u32 base;
    s32 i;
    u32 cur;
    u32 hi;
    s32 needed;
    u32 dst;
    u32 dst2;
    u32 out;
    s32 val;
    s32 nd;
    s32 neg2;
    u32 lo;
    u32 lo2;

    bits_left = 0x20;
    base = (u32)&D_800F1B18[arg0 * 0x570];

    *(u32 **)base = arg1;
    cur = *arg1;
    arg1++;

    i = 0;
    do {
        dst = base + i * 2;
        if (bits_left < 0xC) {

            nd = 0xC - bits_left;

            hi = 0x20 - bits_left;
            hi = cur >> hi;
            cur = *arg1;
            arg1++;
            needed = nd;

            val = 0x20 - needed;
            bits_left = val;
            hi = hi << needed;
            lo = cur >> bits_left;
            cur <<= needed;
            hi = hi | lo;
            *(s16 *)(dst + 0xA) = (s16)hi;
        } else {
            *(s16 *)(dst + 0xA) = (s16)(cur >> 20);
            cur <<= 0xC;
            bits_left -= 0xC;
        }
        i++;
    } while (i < 0x3F);

    i = 0;
    do {
        dst2 = base + i * 2;
        if (bits_left < 2) {

            nd = 2 - bits_left;
            hi = 0x20 - bits_left;
            hi = cur >> hi;
            cur = *arg1;
            arg1++;
            needed = nd;
            val = 0x20 - needed;
            bits_left = val;
            hi = hi << needed;
            lo2 = cur >> bits_left;
            cur <<= needed;
            hi = hi | lo2;
            *(s16 *)(dst2 + 0x8E) = (s16)hi;
        } else {
            *(s16 *)(dst2 + 0x8E) = (s16)(cur >> 30);
            cur <<= 2;
            bits_left -= 2;
        }
        i++;
    } while (i < 0x3F);


    neg2 = -2;
    i = 3;
    out = base + 0x348;
    do {
        *(s32 *)(out + 0x110) = neg2;
        i--;
        out -= 0x118;
    } while (i >= 0);

    val = 0;
    *(s32 *)(base + 0x10C) = val;
}
__asm__( ".section .text\n" "    .set noat\n" "    .set noreorder\n" "    .include \"" "asm/funcs" "/" "func_800198D0" ".s\"\n" "    .set reorder\n" "    .set at\n" );
void func_8001A484(u16 *arg0) {
    s32 i;
    u16 *p;
    i = 0;
    p = arg0 + 2;
    do {
        i++;
        func_8003D52C((s32)&D_800100A4, arg0[0], p[-1], p[0]);
        p += 3;
        arg0 += 3;
    } while (i < 0x16);
}
s32 func_8001A4F0(s32 arg0, s32 arg1) {
    s32 v = arg0 & 0xFFF;
    if (v >= 0x800) {
        v -= 0x1000;
    }
    return v / arg1;
}
void func_8001A538(s32 *arg0, s32 *arg1) {
    MATRIX m;
    m.m[0][0] = 0x1000;
    m.m[0][1] = 0;
    m.m[0][2] = 0;
    m.m[1][0] = 0;
    m.m[1][1] = 0x1000;
    m.m[1][2] = 0;
    m.m[2][0] = 0;
    m.m[2][1] = 0;
    m.m[2][2] = 0x1000;
    RotMatrixX(-*(s16 *)((u8 *)arg0 + 0x10), (s32)&m);
    RotMatrixY(-*(s16 *)((u8 *)arg0 + 0x12), (s32)&m);
    RotMatrixZ(-*(s16 *)((u8 *)arg0 + 0x14), (s32)&m);
    arg1[0] = arg0[0] - ((s32)(m.m[0][2] * arg0[6]) >> 12);
    arg1[1] = arg0[1] - ((s32)(m.m[1][2] * arg0[6]) >> 12);
    arg1[2] = arg0[2] - ((s32)(m.m[2][2] * arg0[6]) >> 12);
}
s32 func_8001A62C(s32 arg0) {
    if (arg0 < 0) {
        return -((0x7CF - arg0) / 2000);
    }
    return arg0 / 2000;
}
void func_8001A67C(s16 *arg0, s32 *arg1, s32 *arg2) {
    s32 dx;
    s32 dz;
    u32 dist_sq;
    u32 log2_val;
    s32 sp_tmp;
    dx = arg1[0] - arg2[0];
    dz = arg1[2] - arg2[2];
    while ((((u32)(dx + 0x4000)) > 0x8000U) || (((u32)(dz + 0x4000)) > 0x8000U)) {
        dx = dx / 2;
        dz = dz / 2;
    }
    dist_sq = (dx * dx) + (dz * dz);
    if (dist_sq < 0x400U) {
        log2_val = ((u32)((u8)(*((&D_8008D118) + dist_sq)))) >> 3;
    } else {
        u32 shift_a;
        u32 shift_b;





        __asm__ volatile(
            "addu   $t4, %1, $zero\n"
            "mtc2   $t4, $30\n"
            "nop\n"
            "nop\n"
            "addiu  $v0, $sp, 0x10\n"
            "addu   $t4, $v0, $zero\n"
            "swc2   $31, 0($t4)\n"
            : "=m"(sp_tmp)
            : "r"(dist_sq)
            : "$2", "$12");
        {
            s32 lw_v1 = sp_tmp;
            s32 li_v0 = -2;
            li_v0 = lw_v1 & li_v0;
            shift_a = 0x16 - li_v0;
        }
        shift_b = shift_a >> 1;
        log2_val = (((u32)((u8)(*((&D_8008D118) + (dist_sq >> shift_a))))) << 16) >> (0x13 - shift_b);
    }
    arg0[0] = (s16)func_8001A62C(arg2[0] + ((dx << 10) / ((s32)log2_val)));
    arg0[2] = (s16)func_8001A62C(arg2[2] + ((dz << 10) / ((s32)log2_val)));
}
void func_8001A820(s32 arg0, GameObj *arg1, s32 arg2, s32 arg3);
__asm__( ".section .text\n" "    .set noat\n" "    .set noreorder\n" "    .include \"" "asm/funcs" "/" "func_8001A820" ".s\"\n" "    .set reorder\n" "    .set at\n" );
void func_8001B138(s32 *arg0) {
    D_800FF5C8 = 0;
    D_800FF5CC = 0;
    D_800FF5D0 = 0;
    D_800FF5D8 = 0;
    D_800FF5DA = 0;
    D_800FF5DC = 0;
    D_800FF5E0 = 0;
    if (D_800A38BA != 0 && D_800A3834 == 1) {
        if (*arg0 & 1) {
            D_800A37E0 = 1;
            if (*arg0 & 8) {
                g_file_vram_timer = g_file_vram_timer + 0x4CC;
            }
            if (*arg0 & 2) {
                g_file_vram_timer = g_file_vram_timer - 0x4CC;
            }
            if (g_file_vram_timer < -0x1C00) {
                g_file_vram_timer = -0x1C00;
            }
            if (g_file_vram_timer >= 0x7401) {
                g_file_vram_timer = 0x7400;
            }
            *arg0 = *arg0 & ~0xB;
        }
        {
            s32 v;
            v = g_file_vram_timer;
            if (v < 0) {
                v = v + 0xF;
            }
            D_800FF5E0 = v >> 4;
        }
    }
    *arg0 = *arg0 & (s32)0xFFFEFFFE;
}
void func_8001B294(s32 *a0, s32 *a1) { s32 v0; D_800A36FA = 0; D_800F6608.h30 = 0x64; D_800F6608.h32 = 0; D_800F6608.h34 = 0x64; D_800F6608.h38 = 0x64; D_800F6608.h3A = 0; D_800F6608.h3C = 0x64; game_SetControllerPorts(0); D_800F6608.w0 = (*(s32 *)((u8 *)a0 + 0xF4) + *(s32 *)((u8 *)a1 + 0xF4)) / 2; D_800F6608.w4 = (*(s32 *)((u8 *)a0 + 0xF8) + *(s32 *)((u8 *)a1 + 0xF8)) / 2; { s32 t1 = *(s32 *)((u8 *)a0 + 0xFC); s32 t2 = *(s32 *)((u8 *)a1 + 0xFC); D_800F6608.h10 = 0; D_800F6608.w8 = (t1 + t2) / 2; } { s32 dx = *(s32 *)((u8 *)a1 + 0xF4) - *(s32 *)((u8 *)a0 + 0xF4); s32 dy = *(s32 *)((u8 *)a1 + 0xFC) - *(s32 *)((u8 *)a0 + 0xFC); v0 = ratan2(dx, dy); } D_800F6608.h12 = 0x400 - v0; D_800F6608.h14 = 0; D_800F6608.w18 = 0x1388; D_800F6608.b1E = 0;}
void func_8001B3C0(s32 *a0, s32 *a1) { D_800A36FA = 0; D_800F5328.h30 = 0x64; D_800F5328.h32 = 0; D_800F5328.h34 = 0x64; D_800F5328.h38 = 0x64; D_800F5328.h3A = 0; D_800F5328.h3C = 0x64; game_SetControllerPorts(0); if (D_800A36F6 != 0) { a0 = a1; } D_800F5328.w0 = *(s32 *)((u8 *)a0 + 0x180); D_800F5328.w8 = *(s32 *)((u8 *)a0 + 0x188); { s32 v = *(s32 *)((u8 *)a0 + 0x184); D_800F5328.b40 = 0; D_800F5328.w4 = v; }}
void func_8001B478(s32 arg0) {
    u8 *obj = (u8 *)arg0;
    u8 *s2 = (u8 *)&D_800F5328;
    s32 a2;
    s32 val;
    s32 far;

    game_SetControllerPorts(0);

    val = (*(s32 *)(obj + 0x19C) + *(s32 *)(obj + 0x1A8)) / 2 - *(s32 *)(obj + 0x184);
    far = val >= 0x391;

    if (*(u16 *)(obj + 0x6A) == 0x2A) {
        val = 0x200;
    } else {
        *(s32 *)s2 = *(s32 *)(obj + 0x180);
        D_800F5328.w8 = *(s32 *)(obj + 0x188);
        val = *(s32 *)(obj + 0x184);

        if (!far) {
            s32 v = -(*(s16 *)(obj + 0x1A) * 950);
            if (v < 0) {
                v += 0xFFF;
            }
            val += v >> 12;
        }

        {
            s32 diff = val - *(s32 *)(s2 + 4);
            if (diff < 0) {
                diff += 3;
            }
            a2 = *(s32 *)(s2 + 4) + (diff >> 2);
            *(s32 *)(s2 + 4) = a2;
        }

        if (*(u16 *)(obj + 0x6A) == 0x2A) {
            val = 0x200;
        } else {
            val = (-(*(s16 *)(obj + 0x1D8)) - *(s16 *)(s2 + 0x12)) & 0xFFF;

            if (val >= 0x800) {
                val = 0x1000 - val;
            }
            if (val >= 0x400) {
                val = 0x400;
            }

            {
                s32 base_val = *(s32 *)(*(s32 *)obj + 0xF8);
                s32 result = ratan2(base_val - a2, D_800A387C);
                val = (result * (0x400 - val)) >> 10;
            }
        }
    }

    {
        s16 old = *(s16 *)(s2 + 0x10);
        s32 diff = val - old;
        if (diff < 0) {
            diff += 7;
        }
        *(s16 *)(s2 + 0x10) = old + (diff >> 3);
    }
    *(s16 *)(s2 + 0x14) = 0;

    {
        s16 counter;
        val = -(*(s16 *)(obj + 0x1CA));
        counter = D_800A36FC;

        if (counter != 0) {
            s16 old12 = *(s16 *)(s2 + 0x12);
            s32 diff = val - old12;
            if (diff < 0) {
                diff += 3;
            }
            {
                s16 cnt = counter - 1;
                *(s16 *)(s2 + 0x12) = old12 + (diff >> 2);
                D_800A36FC = cnt;
            }

            {
                s32 decay = *(s16 *)(s2 + 0x1C) * 3;
                if (decay < 0) {
                    decay += 3;
                }
                *(s16 *)(s2 + 0x1C) = decay >> 2;
            }
        } else {
            *(s16 *)(s2 + 0x12) = val;
            *(s16 *)(s2 + 0x1C) = 0;
        }
    }
    *(s32 *)(s2 + 0x18) = 0;
}


void func_8001B690(s32 arg0, s32 arg1) {
    if (D_800A38BA == 0) {
        return;
    }
    if (D_800A36F6 != arg0) {
        return;
    }
    arg1 &= 0xFFF;
    if (arg1 >= 0x800) {
        arg1 = 0x1000 - arg1;
    }
    if (arg1 >= 0x401) {
        D_800A36FC = 0x19;
        D_800F5328.h1C = 0x800;
    }
}
void func_8001B6F4(void) {
    func_80041688(0, 0);
    func_80041688(1, 0);
    D_800A36FA = 1;
    D_800F6608.b1F = 0;
    D_800F5328.b1F = 0;
    game_SetControllerPorts(0);
}
void func_8001B748(Rec44 *dst, Rec1C *a, Rec1C *b, s32 frac_s1, s32 frac, s32 val) {
    s32 inv_frac = 0x1000 - frac;
    s32 inv_s1 = 0x1000 - frac_s1;
    u8 *base = (u8 *)&D_80101EC8 + D_800A3748 * 0x44C;
    s32 zval;
    s32 dx;
    s32 dy;
    s32 dz;
    s32 cur;
    s32 use_high;
    s32 v;
    s32 t;
    s32 dd;
    if (dst->b1F == 0) {
        dst->b1F = 1;
        dst->w0 = ((frac * (a->h4)) + (inv_frac * (b->h4))) >> 12;
        dst->w4 = (((frac * (a->h6)) + (inv_frac * (b->h6))) >> 12) - 0x12C;
        D_800A3310 = 0;
        zval = (frac * (a->h8)) + (inv_frac * (b->h8));
        dst->h12 = val;
        dst->h10 = 0x80;
        dst->h14 = 0;
        dst->w18 = ((frac_s1 * 0x9C4) + (inv_s1 * 0x2710)) >> 12;
        dst->w8 = zval >> 12;
        return;
    }
    {
        s32 sum = (*((s32 *) (base + 0x19C))) + (*((s32 *) (base + 0x1A8)));
        s32 avg = ((s32) (sum + (((u32) sum) >> 31))) >> 1;
        if ((avg - (*((s32 *) (base + 0x184)))) < 0xC8) {
            D_800A3310 += 1;
        }
    }
    use_high = ((s16) D_800A3310) >= 0xB;
    cur = dst->w0;
    t = ((frac * (a->h4)) + (inv_frac * (b->h4))) >> 12;
    dx = t - cur;
    if (dx < 0) {
        dx += 0xF;
    }
    dst->w0 = cur + (dx >> 4);
    cur = dst->w4;
    t = (((frac * (a->h6)) + (inv_frac * (b->h6))) >> 12) - 0x12C;
    dy = t - cur;
    if (dy < 0) {
        dy += 0xF;
    }
    dst->w4 = cur + (dy >> 4);
    cur = dst->w8;
    t = ((frac * (a->h8)) + (inv_frac * (b->h8))) >> 12;
    dz = t - cur;
    if (dz < 0) {
        dz += 0xF;
    }
    dst->w8 = cur + (dz >> 4);
    if (use_high) {
        t = ((frac_s1 * 0x180) >> 12) + 0x80;
    } else {
        t = 0x80 - ((frac_s1 << 8) >> 12);
    }
    dst->h10 = dst->h10 + func_8001A4F0(t - (s16)dst->h10, 0x10);
    v = func_8001A4F0(val - (s16)dst->h12, 0x10);
    dst->h14 = 0;
    dst->h12 = dst->h12 + v;
    if (use_high) {
        t = ((frac_s1 * 0x7D0) + (inv_s1 * 0x2EE0)) >> 12;
    } else {
        t = ((frac_s1 * 0x1F4) + (inv_s1 * 0x2EE0)) >> 12;
    }
    cur = dst->w18;
    dd = t - cur;
    if (dd < 0) {
        dd += 0xF;
    }
    dst->w18 = cur + (dd >> 4);
    dst->h30 = 0x64;
    dst->h32 = 0;
    dst->h34 = 0x64;
    dst->h38 = 0x64;
    dst->h3A = 0;
    dst->h3C = 0x64;
}

void func_8001BAE4(s32 *arg0, s32 *arg1, s32 arg2) {
    s32 temp_a2;
    s32 var_s3;
    s32 var_v1;
    s32 var_v0;

    if (D_800A387C < 0x2711) {
        var_s3 = (arg2 / 2) + 0x800;
    } else {
        var_s3 = 0x1000;
    }
    temp_a2 = ratan2(*(s16 *)((u8 *)arg1 + 4) - *(s16 *)((u8 *)arg0 + 4),
                             *(s16 *)((u8 *)arg1 + 8) - *(s16 *)((u8 *)arg0 + 8));
    var_v1 = arg2;
    if (arg2 < 0) {
        var_v1 = arg2 + 3;
    }
    var_v0 = *(s16 *)((u8 *)&Judge + ((var_v1 >> 1) & 0x1FFE)) * 3;
    if (var_v0 < 0) {
        var_v0 += 3;
    }
    func_8001B748(&D_800F6608, arg0, arg1, (s32 *)arg2, var_s3, (0x500 - temp_a2) - (var_v0 >> 2));
}
void func_8001BBD8(s32 *arg0, s32 *arg1, s32 *arg2) {
    s32 temp_s0;
    temp_s0 = (D_800A387C < 0x2711) << 0xB;
    func_8001B748(&D_800F5328, arg0, arg1, arg2, temp_s0, -0x200 - ratan2(*(s16 *)((u8 *)arg1 + 4) - *(s16 *)((u8 *)arg0 + 4), *(s16 *)((u8 *)arg1 + 8) - *(s16 *)((u8 *)arg0 + 8)));
}
void func_8001BC70(u8 *arg0, s32 arg1) {
    typedef struct { s32 x, y, z; } Vec3;
    Vec3 *dst;
    Vec3 *src;
    game_SetControllerPorts(0);
    dst = (Vec3 *)&D_800F6608;
    src = (Vec3 *)(arg0 + 0x174);
    *dst = *src;
    D_800F6608.h10 = 0x120;
    D_800F6608.h12 = arg1;
    D_800F6608.h14 = 0;
    D_800F6608.w18 = 0x1162;
}
void func_8001BCF0(u8 *arg0, s32 arg1) {
    typedef struct { s32 x, y, z; } Vec3;
    s32 diff = 0x1000 - arg1;

    game_SetControllerPorts(0);

    *(Vec3 *)&D_800F6608 = *(Vec3 *)(arg0 + 0xB8);

    D_800F6608.w4 -= 0x44C;

    D_800F6608.h10 = 0x100 - (arg1 * 288) / 4096;

    {
        s32 div4 = arg1 / 4;
        s32 sum = arg1 * 3000 + diff * 8000;
        u16 lhu_val = *(u16 *)(arg0 + 0x1CA);
        s32 val;
        D_800F6608.w18 = sum >> 12;
        val = 0xB00 - div4;
        D_800F6608.h14 = 0;
        D_800F6608.h12 = val - lhu_val;
    }
}
void func_8001BE08(s32 *arg0) {
    arg0[2] = 0;
    arg0[3] = 0;
    arg0[4] = 0;
    arg0[5] = -1;
}
void func_8001BE20(s32 arg0, GameObj *arg1);
__asm__( ".section .text\n" "    .set noat\n" "    .set noreorder\n" "    .include \"" "asm/funcs" "/" "func_8001BE20" ".s\"\n" "    .set reorder\n" "    .set at\n" );
void func_8001C444(void) {
    D_8010277A = 0x800;
    D_80102778 = 0x800;
    D_8010277C = 1;
    D_8010277D = 0x10;
    D_80102784 = 0xC;
    D_8010277E = 0;
    D_8010277F = 0;
    D_80102781 = 0;
    D_80102780 = 0;
    D_80102785 = 4;
    D_80102786 = 0;
    D_80102787 = 0;
}
void func_8001C4C0(void) {
    u16 v = D_80101F32;
    if (v == 0x32 || v == 0x11) {
        func_800218C8(0);
        {
            s32 v0 = func_80021974(0);
            D_80101F26 = 0;
            func_80021A98(0, v0, 0);
        }
    }
}
void func_8001C51C(void) {
    s16 *s0;
    s32 v0;
    func_8001C4C0();
    if (D_800A38DC == 3 && D_800A3728 != 0) {
        func_80022580(1, D_80102781, D_8010277D, D_8010277F, 0);
    } else {
        func_80022580(1, D_80102781, D_8010277D, D_8010277F, 1);
    }
    func_80022F34();
    func_800218C8(1);
    v0 = func_80021974(1);
    s0 = &D_80102372;
    *s0 = 0;
    func_80021A98(1, v0, 0);
    D_800A382E = 0;
    D_800A3748 = -1;
    func_80030524();
    func_80030D04();
    func_8001B294((s32)((u8 *)s0 - 0x4AA), (s32)((u8 *)s0 - 0x5E));
    func_800392C8();
    func_80021280(1);
}



void func_8001C624(void) {
    typedef struct { s32 a, b, c, d; } Blk16;
    typedef struct { s32 a, b, c; } Blk12;
    u8 *e = (u8 *)&D_80101EC8;
    s32 local[3];
    s32 x, y, z;

    func_80021D10(0, (s32 *)(e + 0xD8), (s32)D_800A38E0);
    func_80021D10(1, local, (s32)D_800A38E0);
    *(s32 *)(e + 0xE8) = 0;
    x = *(s32 *)(e + 0xD8);
    y = *(s32 *)(e + 0xDC);
    z = *(s32 *)(e + 0xE0);
    *(s32 *)(e + 0xEC) = -0x384;
    *(s32 *)(e + 0xF0) = 0;
    *(s32 *)(e + 0xF4) = x;
    *(s32 *)(e + 0xF8) = y - 0x384;
    *(s32 *)(e + 0xFC) = z;
    *(s32 *)(e + 0xB8) = x;
    *(s32 *)(e + 0xBC) = y;
    *(s32 *)(e + 0xC0) = z;
    *(Blk16 *)(e + 0xC8) = *(Blk16 *)(e + 0xB8);
    *(Blk12 *)(e + 0x1F8) = *(Blk12 *)(e + 0xE8);
    *(s32 *)(e + 0x104) = 0;
    *(s32 *)(e + 0x108) = 0;
    *(s32 *)(e + 0x10C) = 0;
    *(Blk16 *)(e + 0x24C) = *(Blk16 *)(e + 0x104);





    local[0] = local[0], local[1] = local[1] - 0x384, local[2] = local[2];
    *(s32 *)(e + 0x114) = 0;
    *(s32 *)(e + 0x118) = 0;
    *(s32 *)(e + 0x11C) = 0;
    *(s32 *)(e + 0x124) = 0;
    *(s32 *)(e + 0x128) = 0;
    *(s32 *)(e + 0x12C) = 0;
    *(s32 *)(e + 0x134) = 0;
    *(s32 *)(e + 0x138) = 0;
    *(s32 *)(e + 0x13C) = 0;
    *(s32 *)(e + 0x144) = 0;
    *(s16 *)(e + 0x14C) = 0;
    *(s16 *)(e + 0x150) = 0;
    *(s16 *)(e + 0x152) = 0;
    *(s16 *)(e + 0x14E) = 0;
    *(s32 *)(e + 0x148) = *(s32 *)(e + 0xBC);
    func_8003FFE0(0);
}
void func_8001C820(void) {
    s16 *s0 = &D_80101ED2;
    s32 a0;
    if ((&D_8008D9EC)[*s0] != 0) {
        if (D_800A37A0 == 1) return;
    }
    if (D_800A38DC != 0) return;
    if (D_800A3712 != 0) return;
    a0 = 0x56;
    if (D_800A3680 != D_800A3671) {
        if (rand(0x56) & 1) {
            a0 = 0x57;
        } else {
            a0 = 0x58;
        }
    }
    func_800325E0(a0, (s32)((u8 *)s0 + 0x536));
}
__asm__( ".section .rodata\n" "    .include \"" "asm/rodata" "/" "jtbl_800100C4" ".s\"\n" ".section .text" );
void func_8001C8DC(void);
__asm__( ".section .text\n" "    .set noat\n" "    .set noreorder\n" "    .include \"" "asm/funcs" "/" "func_8001C8DC" ".s\"\n" "    .set reorder\n" "    .set at\n" );
void func_8001CD68(s16 *arg0) {
    s32 val = D_800A3858;

    if (val > 0x2BF1F) {
        *(s16 *)arg0 = 99;
        *((u8 *)arg0 + 2) = 59;
        *((u8 *)arg0 + 3) = 99;
        return;
    }
    {
        s32 minutes = val / 1800;
        s32 seconds = val / 30 - minutes * 60;
        *((u8 *)arg0 + 2) = seconds;
        {
            s32 centiseconds = (D_800A3858 % 30) * 100 / 30;
            *(s16 *)arg0 = minutes;
            *((u8 *)arg0 + 3) = centiseconds;
        }
    }
}
void func_8001CE60(void);
__asm__( ".section .text\n" "    .set noat\n" "    .set noreorder\n" "    .include \"" "asm/funcs" "/" "func_8001CE60" ".s\"\n" "    .set reorder\n" "    .set at\n" );

extern s8 D_800A30FC;
extern s8 D_800A30FD;
extern s32 D_800FF6A8;
void func_8001D790(void) {
    s32 s2 = (s32)0x80190800;
    s32 s1;
    s32 *s0;

    gpu_EnableDisplay();

    if (D_800A36A4 != D_800A390E
        || *(&D_8008E5A8 + (s8)D_8010277C) != D_800A30FC
        || *(&D_8008E5A8 + D_8010277D) != D_800A30FD) {







        u8 *p = &D_8010277C;

        func_80020D38();
        game_StageCleanup(D_800A36A4, s2);
        func_8002906C();
        func_8005BDF0();

        s1 = func_8005BA8C(s2, D_800A36A4, *(&D_8008E5A8 + (s8)*p), *(&D_8008E5A8 + D_8010277D));

        D_800A390E = D_800A36A4;
        D_800A30FC = *(&D_8008E5A8 + (s8)*p);
        D_800A30FD = *(&D_8008E5A8 + D_8010277D);

        if (s1 >= 0x2519) {
            sys_Panic();
        }

        s0 = &D_800FF6A8;
        memcpy(s0, s2, s1);
        func_8005BD30((s32)s0 - s2);
    }
}

void func_8001D904(void) {
    s32 s2 = (s32)0x80190800;
    s32 s1;
    s32 *s0;
    gpu_EnableDisplay();
    func_80020D38();
    obj_InitTask();
    s1 = obj_InitTaskCamera((s32)0x80190800);
    if (s1 >= 0xE81) {
        sys_Panic();
    }
    s0 = &MotDataBaseAddress;
    memcpy(s0, (s32)0x80190800, s1);
    obj_ExecTask((s32)s0 - s2);
}
void func_8001D998(void) {
    s32 s2 = (s32)0x80190800;
    s32 s1;
    s32 *s0;
    gpu_EnableDisplay();
    func_80020D38();
    obj_InitPair();
    s1 = func_8005B8B8((s32)0x80190800);
    if (s1 >= 0x1B19) {
        sys_Panic();
    }
    s0 = &MotDataBaseAddress;
    memcpy(s0, (s32)0x80190800, s1);
    func_8005B98C((s32)s0 - s2);
}
void func_8001DA2C(void) {
    obj_InitChars();
    obj_Reset();
    if (D_800A38DC == 5) {
        obj_InitTask();
    }
    if (D_800A38DC == 3) {
        obj_InitPair();
    }
}
void func_8001DA8C(void) {
    func_80035FA8();
    if (file_GetFlag2()) {
        return;
    }
    switch (D_800A38DC) {
        case 0:
        case 1:
        default:
            break;
        case 4:
            func_80037110((&D_8008D518)[D_800A36A4]);
            break;
        case 3:
            if ((&D_8008D9EC)[D_80101ED2] != 0) {
                func_80037110(9);
            } else {
                func_80037110(8);
            }
            break;
        case 2:
            if (D_800A389A != 0) {
                func_80037110(0xA);
            } else {
                func_80037110(0xB);
            }
            break;
        case 5:
            break;
    }
    func_800371E8(1);
}
s32 func_8001DB58(void) {
    s32 v = D_800A38DC;
    if (v >= 5) {
        return 1;
    }
    if (v >= 2) {
        return file_GetFlag2();
    }
    return 1;
}
void func_8001DB9C(void) {
    seq_Start((&D_8008D9EC)[D_80101ED2] < 1, (s32)0x80190800);
    D_800A38C6 = (u16)0xFFFF;
}
void func_8001DBE4(void) {
    s32 i;

    if (g_disp_enable != 0x14) {
        return;
    }
    func_8003AA78();
    if (!(D_800A38F8 > D_800A37A0)) {
        do {
            func_8003AA48();
            func_800174F4();
            VSync(2);
        } while (!(D_800A38F8 > D_800A37A0));
        i = 0;
        do {
            func_8003AA48();
            i += 1;
            func_800174F4();
            VSync(2);
        } while (i < 15);
    }
    func_8003AAB0();
    gpu_InitDisplay();
    gpu_DisableDisplay();
}
__asm__( ".section .text\n" "    .set noat\n" "    .set noreorder\n" "    .include \"" "asm/funcs" "/" "func_8001DCB0" ".s\"\n" "    .set reorder\n" "    .set at\n" );

typedef struct {
    s32 vx, vy, vz;
    s32 pad0;
    u16 rx, ry, rz;
    u16 pad1;
    s32 dist;
    s32 tail[10];
} CamBuf;

void func_8001E404(void) {

    volatile u32 pre_pad[2];
    CamBuf local;
    s32 *s2;

    if (D_800A38BA != 0) {
        s32 v3 = D_800A36FA;
        if (v3 == 1) {
            if (D_80101F5E != 0 || D_801023AA != 0) {
                D_800A36FA = 2;
            }
        }
        if (D_800A36FA == 2) goto s2_default;
        if ((u16)D_80101F32 == 0x11 || (u16)D_8010237E == 0x11) {
            s2 = (s32 *)&D_800F6608;
            D_800A36FA = 1;
        } else {
            s2 = (s32 *)&D_800F5328;
            D_800A36FA = 0;
        }
        goto done_s2;
    s2_default:
        s2 = (s32 *)&D_800F6608;
    done_s2:

        game_SetPlayerCount(D_800A36FA < 1);

        {
            s32 fov = 0x2D;
            if (D_800A36FA == 0) {
                fov = 0x50;
            }
            SetGeomScreen(disp_CalcFov(fov));
        }

        if (D_800A36FA == 0) {
            func_80041688(D_800A36F6, 1);
            func_80041688(D_800A36F6 == 0, 0);
        } else {
            func_80041688(0, 0);
            func_80041688(1, 0);
        }
        goto common_tail;
    }
    s2 = (s32 *)&D_800F6608;
common_tail:

    if (D_800A3834 == 1) {
        local.vx = s2[0] + D_800FF5C8;
        local.vy = s2[1] + D_800FF5CC;
        local.vz = s2[2] + D_800FF5D0;
        local.rx = *(u16 *)((u8 *)s2 + 0x10) + (u16)D_800FF5D8;
        local.ry = *(u16 *)((u8 *)s2 + 0x12) + (u16)D_800FF5DA;
        local.rz = *(u16 *)((u8 *)s2 + 0x14) + (u16)D_800FF5DC;
        local.dist = *(s32 *)((u8 *)s2 + 0x18) + D_800FF5E0;
    } else {
        local = *(CamBuf *)s2;
    }

    func_80046BF4((s32 *)&local, (s32 *)&local.rx, local.dist);
    {
        s32 *p20 = (s32 *)((u8 *)s2 + 0x20);
        func_8001A538((s32 *)&local, p20);
        func_80061064((s32 *)&local.rx, p20);
    }
    func_8003F3D4((s16 *)((u8 *)s2 + 0x30));
    func_8003F3D4((s16 *)((u8 *)s2 + 0x38));
    D_800A36B4 = (s32)s2;
}
typedef struct {
    s32 vx, vy, vz;
    s32 pad0;
    s16 rx, ry, rz;
    s16 pad1;
    s32 dist;
    s32 pad2[11];
} CamWork;

void func_8001E6E4(s32 arg0) {

    volatile u32 pre_pad[2];
    CamWork local;
    s32 *s2;

    s2 = (s32 *)&D_800F5328;
    if ((u32)(arg0 - 0x555) >= 0x556U) {
        s2 = (s32 *)&D_800F6608;
    }

    local.vx = s2[0] + D_800FF5C8;
    local.vy = s2[1] + D_800FF5CC;
    local.vz = s2[2] + D_800FF5D0;
    local.rx = *(u16 *)((u8 *)s2 + 0x10) + (u16)D_800FF5D8;
    local.ry = *(u16 *)((u8 *)s2 + 0x12) + (u16)D_800FF5DA;
    local.rz = *(u16 *)((u8 *)s2 + 0x14) + (u16)D_800FF5DC;

    local.dist = *(s32 *)((u8 *)s2 + 0x18) + D_800FF5E0;
    func_80046BF4((s32 *)&local, &local.rx, local.dist);

    {
        s32 *p20 = (s32 *)((u8 *)s2 + 0x20);
        func_8001A538((s32 *)&local, p20);
        func_80061064((s32 *)&local.rx, p20);
    }

    D_800A36B4 = (s32)s2;
}
void func_8001E800(void) {
    s32 v = D_800A36F6;
    u8 *ptr = (u8 *)(&D_80101EC8 + v * 1100);
    s32 a1;
    if (ptr[0x62] & 1) {
        a1 = *(s16 *)(ptr + 0xE);
    } else {
        a1 = -1;
    }
    {
        u32 flags = ptr[0x62] & 4;
        func_80048BA4(D_800F5328.h1C, a1, flags > 0);
    }
}
void func_8001E878(void) {
    s32 buf[6];
    s32 v0;
    s32 *a0 = &D_80102030;
    u8 *s0;
    v0 = camera_GetBoneData();
    s0 = (u8 *)a0 - 0x168;
    D_800A3778 = v0;
    func_8001A820((s32)a0, (s32)((u8 *)a0 + 0x44C), (s32)s0, (s32)((u8 *)a0 + 0x2E4));
    if (D_800A38BA != 0) {
        func_8001B478((s32)(s0 + D_800A36F6 * 1100));
    }
    func_8001E404();
    func_80039320();
    func_8002006C();
    func_8001BE20(0, (s32)buf);
    func_80023F08(0, (s32)buf);
    func_8001BE20(1, (s32)buf);
    func_80023F08(1, (s32)buf);
    func_8002C61C();
    func_80030D7C();
    func_800321E8();
    func_800397A0();
    if (D_800A38BA != 0 && D_800A36FA == 0) {
        func_8001E800();
    } else {
        func_8003E6A0(D_80101FBC, D_80101FC4);
        func_8003E6A0(D_80102408, D_80102410);
    }
    game_StageInit((D_800A3690 ^ 1) != 0);
    func_8001CE60();
    func_800335D8();
    func_8001C8DC();
}
void func_8001EA04(void) {
    u8 v;
    func_80041688(0, 0);
    func_80041688(1, 0);
    game_Cleanup();
    v = D_800A38D4;
    D_8010262E = 0;
    D_801021E2 = 0;
    D_800A37B8 = 0;
    D_800A3929 = 0;
    D_800A3834 = 0xD;
    D_800A3804 = v < 1;
    D_800A3817 = v < 1;
}
void func_8001EA84(void) {
    s32 sp10[6];
    s16 buf[4];
    s32 ret;
    u8 *base;

    D_800A37B8 += 1;
    D_800A3778 = camera_GetBoneData();
    base = (u8 *)&D_80101EC8;
    if (D_800A3748 == 0) {
        base += 0x44C;
    }
    func_8001BC70(base, D_800A37B8 << 3);
    func_8001E404();
    func_80039320();
    func_8002006C();
    func_8001BE08(sp10);
    func_80023F08(0, (s32)sp10);
    func_80023F08(1, (s32)sp10);
    func_8002C61C();
    func_80030D7C();
    func_800321E8();
    func_800397A0();
    game_StageInit(1);
    func_800335D8();
    if (D_800A38DC == 3) {
        func_8001CD68(buf);
        D_800A38B4 = D_800A38B4 + ((func_8005D814(buf, D_800A38E2, D_800A38B4, 1) / 4) * 4);
    }
    if (D_800A3929 == 0) {
        D_800A38B4 = D_800A38B4 + ((func_8005C8A8(1, D_800A3817, D_800A38B4, 0) / 4) * 4);
        if ((D_80102794 & 0x10001000) != 0) {
            func_8005C650(0, 0x7F, 0x7F);
            if (D_800A3817 != D_800A3804) {
                D_800A3817 = D_800A3817 - 1;
            } else {
                D_800A3817 = 2;
            }
        } else if ((D_80102794 & 0x40004000) != 0) {
            func_8005C650(0, 0x7F, 0x7F);
            if (D_800A3817 == 2) {
                D_800A3817 = D_800A3804;
            } else {
                D_800A3817 = D_800A3817 + 1;
            }
        }
        if ((D_80102794 & 0x400040) != 0) {
            func_8005C650(1, 0x7F, 0x7F);
            D_800A3929 = (D_800A3817 == 0) ? 1 : 0x3C;
            if (D_800A3817 != 0) return;
            (&D_80101F7B)[ret = (D_800A3748 == 0) * 0x44C] = 0;
            if (D_800A38DC == 3) {
                D_800A3858 = D_800A3858 + 0x384;
                if (D_800A3858 > 0x2BF20) {
                    D_800A3858 = 0x2BF20;
                }
            }
        }
        return;
    }
    if (D_800A3817 == 0) {
        ret = func_8005FA98(0, D_800A38B4, 1);
        D_800A38B4 = D_800A38B4 + ((ret / 4) * 4);
    }
    D_800A3929 = D_800A3929 + 1;
    if (((u8)D_800A3929) < 0x3C) return;
    if (D_800A3817 == 0) {
        D_800A3670 = 1;
        D_800A380C = D_800A380C + 1;
        D_800A38DF = func_80022408((s32 *)((u8 *)&D_80101FBC + (s32)D_800A3748 * 0x44C));
        if (D_8010231A != 0) {
            func_800550E8(1);
        }
        D_800A3834 = 0;
        return;
    }
    if (D_800A3817 == 1) {
        func_800372C0();
        func_8001DA2C();
        D_800A31DA = 1;
        D_800A3834 = 8;
        return;
    }
    if (D_800A3817 == 2) {
        func_800372C0();
        func_8001DA2C();
        D_800A3834 = 8;
    }
}

void func_8001EEB4(void) {
    s8 idx = D_800A3748;
    u8 *entry = (u8 *)&D_80101EC8 + idx * 0x44C;
    u16 a1 = *(u16 *)(entry + 0x6A);

    if (a1 != 0xA && *(s16 *)(entry + 0x72) == 0 &&
        a1 != 0x17 && a1 != 0x18 && *(s16 *)(entry + 0x96) == 0) {
        func_800218C8(D_800A3748);
        {
            s32 ret = func_80021A3C(D_800A3748, *(s16 *)(entry + 0xA));
            s32 idx2 = D_800A3748;
            *(s16 *)(entry + 0x5E) = 1;
            func_80021A98(idx2, ret, 1);
        }
        *(s16 *)(entry + 0x26C) = 1;
    }

    game_Cleanup();
    D_800A37B8 = 0;
    D_800A3834 = 0x11;
}
void func_8001EFA0(void) {
    s32 sp10[6];
    s16 var_v0;

    D_800A37B8 += 1;
    D_800A3778 = camera_GetBoneData();
    func_8001BCF0((u8 *)&D_80101EC8 + D_800A3748 * 1100, (D_800A37B8 << 12) / 105);
    func_8001E404();
    func_80039320();
    func_8002006C();
    func_8001BE08(sp10);
    func_80023F08(0, (s32)sp10);
    func_80023F08(1, (s32)sp10);
    func_8002C61C();
    func_80030D7C();
    func_800321E8();
    func_800397A0();
    game_StageInit(1);
    func_800335D8();

    if (*(&D_80101F5E + D_800A3748 * 550) != 0 && D_800A38DC == 1) {
        D_800A37B8 = 0x69;
    }

    if (D_800A37B8 >= 0x69 || (D_80102794 & 0x400040)) {
        switch (D_800A38DC) {
        case 4:
            var_v0 = 0xC;
            break;
        case 1:
            if (D_800A3748 == 0) {
                func_8001DA2C();
                D_800A3768 = 2;
                func_80033BC0();
                return;
            }
            var_v0 = 0xC;
            break;
        case 6:
            var_v0 = 0xC;
            break;
        default:
            func_8001DA2C();
            var_v0 = 2;
            break;
        }
        D_800A3834 = var_v0;
    }
}
void func_8001F1C4(u8 *arg0, u8 *arg1, u8 *arg2, u8 *arg3) {
    s16 temp_v1;
    if (!(*(u8 *)(arg1 + 0x18) & 0x80)) {
        func_80027334((s32 *)arg2);
        func_80027334((s32 *)arg3);
    }
    func_8002F770((s32 *)(arg2 + 0x36), *(s8 *)(arg1 + 0x14) * 4, *(s8 *)(arg1 + 0x15) * 4, 0);
    func_8002F770((s32 *)(arg3 + 0x36), *(s8 *)(arg1 + 0x14) * 4, *(s8 *)(arg1 + 0x15) * 4, 0);
    temp_v1 = *(s16 *)(arg0 + 0xC);
    if ((temp_v1 == 0x1D) || (temp_v1 == 0xE)) {
        *(u16 *)(arg2 + 0x7E) = (u16)(*(u16 *)(arg2 + 0x7E) + (*(s8 *)(arg1 + 0x16) * 4));
        *(u16 *)(arg3 + 0x7E) = (u16)(*(u16 *)(arg3 + 0x7E) + (*(s8 *)(arg1 + 0x16) * 4));
    }
    if ((u32)(*(u16 *)(arg0 + 0xE) - 6) < 2U) {
        *(u16 *)(arg2 + 0x72) = (u16)(*(u16 *)(arg2 + 0x72) + (*(s8 *)(arg1 + 0x16) * 4));
        *(u16 *)(arg3 + 0x72) = (u16)(*(u16 *)(arg3 + 0x72) + (*(s8 *)(arg1 + 0x16) * 4));
    }
}
__asm__( ".section .text\n" "    .set noat\n" "    .set noreorder\n" "    .include \"" "asm/funcs" "/" "func_8001F2E4" ".s\"\n" "    .set reorder\n" "    .set at\n" );

void func_8001F860(s16 *arg0, s32 arg1) {
    arg1 = (arg1 - *(s16 *)((u8 *)arg0 + 0x1CA)) & 0xFFF;
    if (arg1 >= 0x800) {
        arg1 -= 0x1000;
    }
    *(s16 *)((u8 *)arg0 + 0x14C) = arg1;
}
s32 func_8001F888(void) {
    s32 dx = D_80102408 - D_80101FBC;
    s32 dy = D_80102410 - D_80101FC4;
    s32 s0 = 0;
    while ((u32)(dx + 0x4000) > 0x8000 || (u32)(dy + 0x4000) > 0x8000) {
        s32 t;
        t = dx + ((u32)dx >> 31);
        dx = (s32)t >> 1;
        t = dy + ((u32)dy >> 31);
        dy = (s32)t >> 1;
        s0 += 1;
    }
    {
        s32 v0 = dx * dx;
        s32 v1 = dy * dy;
        s32 r = SquareRoot0(v0 + v1);
        return r << s0;
    }
}
__asm__( ".section .text\n" "    .set noat\n" "    .set noreorder\n" "    .include \"" "asm/funcs" "/" "func_8001F938" ".s\"\n" "    .set reorder\n" "    .set at\n" );

s32 func_8001FAE4(s32 *arg0) {
    u16 v1;
    s32 *a0;

    a0 = (s32 *)((s32)arg0 + 0xA);
    v1 = *(u16 *)a0;
    while (v1 != 0) {
        if ((v1 & 0x4000) != 0) {
            return (s32)a0;
        }
        if ((v1 & 0xC000) != 0) {
            a0 = (s32 *)((s32)a0 + 8);
        } else {
            a0 = (s32 *)((s32)a0 + 4);
        }
        v1 = *(u16 *)a0;
    }
    return 0;
}
s32 func_8001FB34(s32 *arg0, s32 arg1) {
    s16 v1;
    s32 v0;
    v1 = D_800A38DC;
    if (v1 == 2) return 0;
    if (v1 == 5) return 0;
    if (v1 == 3) return 0;
    if (v1 != 0) goto check2;
    if (D_800A385C != 0) return 0;
check2:
    v0 = *(s32 *)arg0;
    v1 = *(s16 *)(v0 + 0xC);
    if (v1 == 0xD) return 0;
    if (v1 == 0x1C) return 0;
    v1 = *(s16 *)((u8 *)arg0 + 0xA);
    if (v1 != 0xE) goto check3;
    if (*(s16 *)((u8 *)arg0 + 0x330) == 0) return 0;
    v1 = *(s16 *)((u8 *)arg0 + 0x332);
    if (v1 == 0xA) goto check3;
    return 0;
check3:
    v0 = 1;
    if (arg1 != 0) {
        v0 = *(s16 *)((u8 *)arg0 + 0x26C);
        v0 = (v0 != 0);
    }
    return v0;
}
void func_8001FBE8(void);
__asm__( ".section .text\n" "    .set noat\n" "    .set noreorder\n" "    .include \"" "asm/funcs" "/" "func_8001FBE8" ".s\"\n" "    .set reorder\n" "    .set at\n" );

s32 func_8002006C(void) {
    s32 s0 = D_800A387C;
    s32 v0 = func_8001F888();
    s32 v = D_800A38DC;
    D_800A387C = v0;
    D_800A38F0 = v0 - s0;
    if (v != 5 && v != 2) {
        func_8001FBE8();
    }
    D_800A38A8 = 0;
}
void func_800200DC(s32 *arg0, s32 *arg1, s32 arg2, s32 arg3, s32 *arg4) {
    s32 disc;
    s32 dx;
    s32 dz;
    s32 dist;

    disc = arg1[0];
    dx = disc - arg0[0];
    dz = arg1[2] - arg0[2];
    dist = SquareRoot0(dx * dx + dz * dz);

    if (dist == 0) {
        arg4[2] = 0;
        arg4[0] = 0;
        return;
    }

    {
        s32 dy;

        disc = arg1[1];
        dy = disc - arg0[1];

        if (dy == 0) {
            s32 neg = -arg3;
            s32 denom = arg2 * 2;
            arg4[0] = (neg * dx) / denom;
            arg4[2] = (neg * dz) / denom;
        } else {
            s32 dy2 = dy * 2;
            s32 a0;

            disc = arg2 * arg2 + arg3 * dy2;

            if (disc >= 0) {
                s32 a2;
                disc = SquareRoot0(disc << 10);
                a2 = arg2 << 5;
                a0 = ((a2 + disc) * dist) / dy2 / 32;

                if (a0 < 0) {
# 1923 "src/code6cac.c"
                    dy = a2 - disc;
                    a0 = (dy * dist) / dy2 / 32;
                }
            } else {
                a0 = 300;
            }

            if (a0 >= 301) {
                a0 = 300;
            }

            arg4[0] = (a0 * dx) / dist;
            arg4[2] = (a0 * dz) / dist;
        }
    }
}
void func_800203B4(u8 *arg0, s32 arg1, s16 *arg2) {
    s32 mat[8];
    s32 vec[3];
    s32 m0;
    s32 m1;
    s32 m2;
    s32 src;
    *(s16 *)(arg0 + 0x350) = 1;
    *(s16 *)(arg0 + 0x352) = *(u16 *)((u8 *)&D_8008D59E + arg1 * 20);
    {
        s32 new_var;
        new_var = game_GetPlayerData(*(s16 *)(arg0 + 4));
        src = *(s32 *)((((s32)*(s16 *)(arg0 + 0x352)) << 2) + new_var);
    }
    func_8002EECC(src, mat);
    {
        register s32 *mp asm("$12");
        register s32 t5 asm("$13");
        register s32 t6 asm("$14");
        register s32 t7 asm("$15");
        s32 *p = mat;
        __asm__ volatile ("move %0, %1" : "=r"(mp) : "r"(p));
        t5 = *mp;
        t6 = *(mp + 1);
        __asm__ volatile ("ctc2 %0, $0" :: "r"(t5));
        __asm__ volatile ("ctc2 %0, $1" :: "r"(t6));
        t5 = *(mp + 2);
        t6 = *(mp + 3);
        t7 = *(mp + 4);
        __asm__ volatile ("ctc2 %0, $2" :: "r"(t5));
        __asm__ volatile ("ctc2 %0, $3" :: "r"(t6));
        __asm__ volatile ("ctc2 %0, $4" :: "r"(t7));
    }
    vec[0] = arg2[0];
    vec[1] = arg2[1];
    vec[2] = arg2[2];
    {
        register s32 *vp asm("$12");
        register s32 t5 asm("$13");
        register s32 t6 asm("$14");
        s32 *p = vec;
        __asm__ volatile ("move %0, %1" : "=r"(vp) : "r"(p));
        t6 = ((u16 *)vp)[2];
        t5 = ((u16 *)vp)[0];
        t6 = t6 << 16;
        t5 = t5 | t6;
        __asm__ volatile ("mtc2 %0, $0" :: "r"(t5));
        __asm__ volatile ("lwc2 $1, 8(%0)" :: "r"(vp));
        __asm__ volatile ("nop");
        __asm__ volatile ("nop");
        __asm__ volatile (".word 0x4A486012");
    }
    arg0 += 0x354;
    {
        register u8 *outp asm("$12");
        u8 *p = arg0;
        __asm__ volatile ("move %0, %1" : "=r"(outp) : "r"(p));
        __asm__ volatile ("swc2 $25, 0(%0)" :: "r"(outp));
        __asm__ volatile ("swc2 $26, 4(%0)" :: "r"(outp));
        __asm__ volatile ("swc2 $27, 8(%0)" :: "r"(outp));
    }
}
void func_800204C0(u8 *arg0) {
    long temp_s1;
    s32 sp10[3];
    s16 sp20[3];
    s32 tx, ty, tz;
    s32 mul;
    s16 idx;
    s32 pd;

    temp_s1 = *(s16 *)(arg0 + 0x4);
    if (*(s16 *)(arg0 + 0x350) != 0) {
        *(u16 *)(arg0 + 0x350) += 1;
        if ((*(u16 *)(arg0 + 0x350) & 7) == 2) {
            pd = game_GetPlayerData(temp_s1);
            idx = *(s16 *)(arg0 + 0x352);



            {
                register s32 *mp asm("$12");
                register s32 t5 asm("$13");
                register s32 t6 asm("$14");
                register s32 t7 asm("$15");
                register s32 *src asm("$3") = (s32 *)*(s32 *)(pd + idx * 4);
                __asm__ volatile ("move %0, %1" : "=r"(mp) : "r"(src));
                t5 = mp[0];
                t6 = mp[1];
                __asm__ volatile ("ctc2 %0, $0" :: "r"(t5));
                __asm__ volatile ("ctc2 %0, $1" :: "r"(t6));
                t5 = mp[2];
                t6 = mp[3];
                t7 = mp[4];
                __asm__ volatile ("ctc2 %0, $2" :: "r"(t5));
                __asm__ volatile ("ctc2 %0, $3" :: "r"(t6));
                __asm__ volatile ("ctc2 %0, $4" :: "r"(t7));
            }



            {
                register s32 *vp asm("$12");
                register s32 t5 asm("$13");
                register s32 t6 asm("$14");
                s32 *src = (s32 *)(arg0 + 0x354);
                __asm__ volatile ("move %0, %1" : "=r"(vp) : "r"(src));
                t6 = ((u16 *)vp)[2];
                t5 = ((u16 *)vp)[0];
                t6 = t6 << 16;
                t5 = t5 | t6;
                __asm__ volatile ("mtc2 %0, $0" :: "r"(t5));
                __asm__ volatile ("lwc2 $1, 8(%0)" :: "r"(vp));
            }
            __asm__ volatile ("nop");
            __asm__ volatile ("nop");
            __asm__ volatile (".word 0x4A486012");

            { s32 cc = *(s16 *)(arg0 + 0x350); mul = ((0x96 - cc) << 12) / 150; do {} while(0); }


            {
                register s32 *rp asm("$12");
                s32 *dst = sp10;
                __asm__ volatile ("move %0, %1" : "=r"(rp) : "r"(dst));
                __asm__ volatile ("swc2 $25, 0(%0)" :: "r"(rp));
                __asm__ volatile ("swc2 $26, 4(%0)" :: "r"(rp));
                __asm__ volatile ("swc2 $27, 8(%0)" :: "r"(rp));
            }
            tx = (sp10[0] * mul) / 0x1000;
            sp20[0] = tx;
            ty = (sp10[1] * mul) / 0x1000;
            sp20[1] = ty;
            tz = (sp10[2] * mul) / 0x1000;
            sp20[2] = tz;
            if ((s16)ty >= 0x801) {
                sp20[0] = -tx;
                sp20[1] = -ty;
                sp20[2] = -tz;
            }
            func_80032854(temp_s1, 4, (u8 *)0x1F8000A8 + temp_s1 * 0x108 + *(s16 *)(arg0 + 0x352) * 0xC, sp20);
        }
        if (*(s16 *)(arg0 + 0x350) >= 0x96) {
            *(s16 *)(arg0 + 0x350) = 0;
        }
        *(s16 *)(arg0 + 0x350) = 0;
    }
}


void func_800206B0(s32 arg0, s32 arg1) {
    u8 *a3 = (u8 *)&D_8008D59C;
    u8 *a2 = (u8 *)&D_800F5F68 + arg0 * 0x1B8;
    s32 t0 = 0;
    u8 *a0 = a2 + 0x12;
    u8 *v1 = a3 + 0x12;

loop:
    *(u16 *)a2 = *(u16 *)a3;
    *(u16 *)(a0 - 0x10) = *(u16 *)(v1 - 0x10);
    *(s16 *)(a0 - 0xE) = (s32)(*(s16 *)(v1 - 0xE) * arg1) >> 0xC;
    *(s16 *)(a0 - 0xC) = (s32)(*(s16 *)(v1 - 0xC) * arg1) >> 0xC;
    *(s16 *)(a0 - 0xA) = (s32)(*(s16 *)(v1 - 0xA) * arg1) >> 0xC;
    *(s16 *)(a0 - 6) = (s32)(*(u16 *)(v1 - 6) * arg1) >> 0xC;
    *(s16 *)(a0 - 4) = (s32)(*(u16 *)(v1 - 4) * arg1) >> 0xC;
    *(s16 *)(a0 - 2) = (s32)(*(u16 *)(v1 - 2) * arg1) >> 0xC;
    {
        s32 temp_lo = *(u16 *)v1 * arg1;
        t0 += 1;
        a3 += 0x14;
        a2 += 0x14;
        v1 += 0x14;
        *(s16 *)a0 = temp_lo >> 0xC;
        a0 += 0x14;
    }
    if (t0 < 0x16) goto loop;
}
__asm__( ".section .text\n" "    .set noat\n" "    .set noreorder\n" "    .include \"" "asm/funcs" "/" "func_800207C8" ".s\"\n" "    .set reorder\n" "    .set at\n" );
void func_80020CDC(void) {
    if (D_800A38C6 == 0xFFFF) {
        seq_Reset();
    }
    D_800A3880 = 0;
    D_800A38C6 = 0;
    D_800A38C4 = 0;
    D_800A38C1 = 0xFF;
    D_800A38C0 = 0xFF;
}
void func_80020D38(void) {
    if (D_800A38C6 == 0xFFFF) {
        seq_Reset();
    }
    D_800A38C6 = 0;
}

void func_80020D70(void) {
    D_800A3888 = (s32)0x80118800;
    D_800A388C = (s32)0x8011C400;
    D_800A3830 = (s32)0x80120000;
    D_800A3860 = (s32)0x80148800;
    D_800A3864 = (s32)0x80190800;
    func_80020CDC();
}
void func_80020DDC(void) { s32 v0; s32 v1; s32 v2; v0 = func_80036EA8(1, 1); replay_camera_Init(v0, D_800A3830); game_FrameLoop(); v1 = D_800A3830; D_80102760 = v1 + 0x14; D_80102764 = v1 + *(s32 *)(v1 + 4); D_80102768 = v1 + *(s32 *)(v1 + 8); v2 = *(s32 *)(v1 + 0x10); D_800A3880 = 1; D_80102770 = v1 + v2;}
__asm__( ".section .text\n" "    .set noat\n" "    .set noreorder\n" "    .include \"" "asm/funcs" "/" "func_80020E74" ".s\"\n" "    .set reorder\n" "    .set at\n" );

void func_80021210(void) {
    func_8001979C(0, D_80102770);
    if (D_800A38C4) {
        func_8001979C(1, D_801027C0);
    }
    if (D_800A38C6) {
        func_8001979C(2, D_801027D4);
    }
}
# 2185 "src/code6cac.c"
void func_80021280(s32 a0) {
    s32 a1 = 0;
    u8 *a2 = (u8 *)&D_80101EC8 + a0 * 1100;
    s32 a3 = *(u16 *)(a2 + 0x48);
    u16 *v1 = (u16 *)&D_800A38C4;

loop1_21280:
    if (a3 == *v1) goto done1_21280;
    a1++;
    v1++;
    if (a1 < 2) goto loop1_21280;
done1_21280:

    {
        u16 val = *(u16 *)(a2 + 0x48);
        *(s16 *)(a2 + 0x4A) = a1;
        *(s16 *)(a2 + 0x4C) = 0;

        if ((u32)(val >> 12) < 2) {
            u16 t1;
            s32 t4;
            s32 t3;
            s32 t2;
            u8 t0;

            a1 = 0;
            t1 = val;
            t4 = 4;
            t3 = 3;
            t2 = 1;
            a3 = D_800A38DC;
            t0 = D_800A384C;
        loop2_21280:
            {
                u16 nibble = (t1 >> (a1 << 2)) & 0xF;
                if (nibble != t4) goto not4_21280;
                *(s16 *)(a2 + 0x88) = a1;
                if (a3 != t3) goto store4_21280;
                if (a0 != t2) goto store4_21280;
                if (t0 != nibble) goto next_21280;
            store4_21280:
                *(u16 *)(a2 + 0x8A) = *(u16 *)(a2 + 0x26C);
                goto next_21280;
            not4_21280:
                if (nibble != 5) goto next_21280;
                *(s16 *)(a2 + 0x8E) = a1;
                if (a3 != 0) goto store5_21280;
                if (D_800A385C == 0) goto store5_21280;
                if (a0 == 0) {



                    a1++;
                    if (a1 < 3) goto loop2_21280;
                    return;
                }
            store5_21280:
                *(u16 *)(a2 + 0x90) = *(u16 *)(a2 + 0x26C);
            }
        next_21280:
            a1++;
            if (a1 < 3) goto loop2_21280;
        }
    }
}
void func_800213A0(s16 *arg0) {
    s16 a1 = arg0[0x86 / 2];
    if (a1 != arg0[0x88 / 2]) {
        if (a1 != arg0[0x8E / 2]) {
            return;
        }
    }
    {
        s16 *v = (s16 *)(&D_800A3860)[arg0[0x4A / 2]];
        arg0[0x86 / 2] = (s16)((a1 + 1) % v[0x14 / 2]);
    }
}
__asm__( ".section .text\n" "    .set noat\n" "    .set noreorder\n" "    .include \"" "asm/funcs" "/" "func_80021424" ".s\"\n" "    .set reorder\n" "    .set at\n" );
void func_800218C8(s32 a0) {
    s32 offset = a0 * 1100;
    *(u16 *)((u8 *)&D_80101F4E + offset) = *(u16 *)((u8 *)&D_80101F4C + offset);
}
s32 func_80021904(s32 a0) {
    s32 offset = a0 * 1100;
    s16 v1 = *(s16 *)((u8 *)&D_80101F12 + offset);
    s16 v0 = *(s16 *)((u8 *)&D_80101F4E + offset);
    s32 a0_2 = v1 * 4;
    s32 v1_2 = (a0_2 + v1) * 4;
    s32 base = *(s32 *)((u8 *)&D_800A3860 + a0_2);
    u16 idx = *(u16 *)(base + v0 * 2 + 0x4E);
    s32 tbl = *(s32 *)((u8 *)&D_801027B0 + v1_2);
    return tbl + idx * 2;
}
s32 func_80021974(s32 a0) {
    s32 offset = a0 * 1100;
    s16 v1 = *(s16 *)((u8 *)&D_80101F12 + offset);
    s16 v0 = *(s16 *)((u8 *)&D_80101F4C + offset);
    s32 a0_2 = v1 * 4;
    s32 v1_2 = (a0_2 + v1) * 4;
    s32 base = *(s32 *)((u8 *)&D_800A3860 + a0_2);
    u16 idx = *(u16 *)(base + v0 * 2 + 0x4E);
    s32 tbl = *(s32 *)((u8 *)&D_801027B0 + v1_2);
    return tbl + idx * 2;
}
s32 func_800219E4(s32 a0) {
    s32 offset = a0 * 1100;
    s16 v0 = *(s16 *)((u8 *)&D_80101F12 + offset);
    s32 base = *(s32 *)((u8 *)&D_800A3860 + v0 * 4);
    u16 idx = *(u16 *)(base + 0x16);
    return D_80102760 + idx * 2;
}
s32 func_80021A3C(s32 a0, s32 a1) {
    s32 offset = a0 * 1100;
    s16 v0 = *(s16 *)((u8 *)&D_80101F12 + offset);
    s32 base = *(s32 *)((u8 *)&D_800A3860 + v0 * 4);
    u16 idx = *(u16 *)(base + a1 * 2 + 0x18);
    return D_80102760 + idx * 2;
}
void func_80021A98(s32 arg0, u8 *arg1, s32 arg2) {
    u8 *s0 = ((u8 *) (&D_80101EC8)) + (arg0 * 1100);
    s32 a3;
    if ((*((s16 *) (s0 + 0x4C))) != 0) {
        a3 = *((s16 *) ((*((s32 *) s0)) + 0x4A));
    } else {
        a3 = *((s16 *) (s0 + 0x4A));
    }
    *((s16 *) (s0 + 0x4C)) = 0;
    *((s32 *) (s0 + 0x50)) = (s32) arg1;
    {
        u16 v1 = *((u16 *) (arg1 + 4));
        *((s16 *) (s0 + 0x5C)) = v1;
        if (arg2 != 0) {
            s32 v0 = D_80102764 + (v1 * 4);
            *((s32 *) (s0 + 0x54)) = v0;
            v1 = *((u16 *) (v0 + 2));
            *((s32 *) (s0 + 0x58)) = D_80102768 + v1;
        } else {
            s32 idx = a3 * 5;
            s32 v0 = (&D_801027B4)[idx] + (v1 * 4);
            *((s32 *) (s0 + 0x54)) = v0;
            v1 = *((u16 *) (v0 + 2));
            *((s32 *) (s0 + 0x58)) = (&D_801027B8)[idx] + v1;
        }
    }
    {
        s32 v0_50 = *((s32 *) (s0 + 0x50));
        u16 old_kind = *((u16 *) (s0 + 0x6A));
        s32 a0_58 = *((s32 *) (s0 + 0x58));
        *((u8 *) (s0 + 0x60)) = (u8) arg2;





        do { } while (0);
        *((u8 *) (s0 + 0x61)) = (u8) a3;
        {
            u8 a1_val = *((u8 *) (v0_50 + 6));
            *((s16 *) (s0 + 0x6C)) = old_kind;
            {
                s32 v1_58 = *((s32 *) (s0 + 0x58));
                *((s16 *) (s0 + 0x42)) = 0;
                *((s16 *) (s0 + 0x7A)) = 1;
                *((s32 *) (s0 + 0x7C)) = 0;
                *((s16 *) (s0 + 0x46)) = 0;
                *((s16 *) (s0 + 0x40)) = a1_val;



                do { *((s16 *) (s0 + 0x6A)) = *((u8 *) a0_58); } while (0);
                *((s16 *) (s0 + 0x6E)) = *((u8 *) (v1_58 + 2));
            }
        }
        {
            s32 v0_50b = *((s32 *) (s0 + 0x50));
            s32 kind = *((u16 *) (s0 + 0x6A));
            *((s16 *) (s0 + 0x70)) = (*((u8 *) (v0_50b + 9))) & 3;
            {
                s32 a0_flag = 0;
                if ((((kind == 2) || (kind == 0x1B)) || (kind == 0x28)) || (kind == 0x26)) {
                    a0_flag = 1;
                }
                *((u8 *) (s0 + 0xAD)) = a0_flag;
            }
            func_800324D0(s0);
            {
                s32 kind2 = *((u16 *) (s0 + 0x6A));
                s32 v1k = kind2 & 0xFFFF;
                if (v1k == 9) {
                    *((s16 *) (s0 + 0x152)) = 1;
                    *((s16 *) (s0 + 0x154)) = *((u16 *) (s0 + 0x1CA));
                    goto end;
                }
                if (v1k == 2) {
                    if ((*((s16 *) (s0 + 0x152))) != 0) goto clear_152;
                    if ((*((s16 *) (s0 + 0x6C))) == 0x13) goto clear_152;
                    *((s16 *) (s0 + 0x154)) = *((u16 *) (s0 + 0x1D8));
                    goto clear_152;
                }
                if (((u32) (kind2 - 0x19)) >= 2U) goto not_in_range;
                if ((*((s16 *) (s0 + 0x152))) == 0) goto set_154;
                if (v1k != 0x19) goto set_152;
                if ((*((s16 *) (s0 + 0x6C))) != v1k) goto set_152;
                goto set_154;
                set_154:
                *((s16 *) (s0 + 0x154)) = *((u16 *) (s0 + 0x1D8));
                goto set_152;
                not_in_range:
                if (v1k != 0x11) goto clear_152;
                set_152:
                *((s16 *) (s0 + 0x152)) = 1;
                goto end;
                clear_152:
                *((s16 *) (s0 + 0x152)) = 0;
            }
            end:
            {
                u16 v1f = *((u16 *) (s0 + 0x6A));
                if ((((v1f == 2) || (v1f == 0x1B)) || (v1f == 0x28)) || (v1f == 0x26)) {
                    *((u8 *) (s0 + 0xAF)) = ((*((u8 *) (s0 + 0xB0))) & 0xF) != 5;
                }
            }
        }
    }
}
void func_80021D10(s32 arg0, s32 *arg1, s32 arg2) {
    s16 *temp_v0;
    temp_v0 = (s16 *)(stage_GetDataPtr() + (((D_800A36A4 * 0x18) + (arg2 * 6) + (arg0 * 3)) * 2));
    arg1[0] = (s32)temp_v0[0];
    arg1[1] = (s32)temp_v0[1];
    arg1[2] = (s32)temp_v0[2];
}
__asm__( ".section .text\n" "    .set noat\n" "    .set noreorder\n" "    .include \"" "asm/funcs" "/" "func_80021DB0" ".s\"\n" "    .set reorder\n" "    .set at\n" );
void func_80022224(s32 arg0, s32 *arg1, s32 *arg2) {
    s32 dists[6];
    s16 *base;
    s16 *p;
    s32 *d;
    s32 dx;
    s32 dz;
    s32 i;
    s32 best;
    s32 *r;
    s32 *w;

    base = (s16 *)(stage_GetDataPtr() + (D_800A36A4 * 3) * 0x10);
    i = 0;
    p = base;
    d = dists;
    do {
        dx = p[3] - arg2[0];
        dz = p[5] - arg2[2];
        *d = dx * dx + dz * dz;
        i++;
        d++;






        p += 3;
        p += 3;
    } while (i < 4);

    best = 0;
    for (i = 1; i < 4; i++) {
        if (dists[i] < dists[best]) {
            best = i;
        }
    }
    dists[best] = -1;

    best = 0;
    for (i = 1; i < 4; i++) {
        if (dists[i] > dists[best]) {
            best = i;
        }
    }
    dists[best] = -1;

    r = dists;
    i = 0;
    {
        s32 stop = -1;
        w = r;
        for (; i < 4; i++) {
            if (*r != stop) {
                w[4] = i;
                w++;
            }
            r++;
        }
    }

    base += dists[4 + (rand() & 1)] * 6 + 3;
    arg1[0] = base[0];
    arg1[1] = base[1];
    arg1[2] = base[2];
}
s32 func_80022408(s32 *arg0) {
    s16 *p;
    s32 i;
    s32 best_dist;
    s32 best;
    s32 t1;
    s32 t2;
    int new_var;
    s32 dx;
    s32 dz;
    s32 dist;
    p = (s16 *)stage_GetDataPtr();
    best_dist = 0x7FFFFFFF;
    i = 0;
    t1 = arg0[0];
    t2 = arg0[2];
    p = p + ((D_800A36A4 * 3) * 8);
loop:
    dx = ((p[0] + p[3]) / 2) - t1;
    new_var = dx * dx;
    dist = new_var;
    dz = ((p[2] + p[5]) / 2) - t2;
    dist = dist + (dz * dz);
    if (dist < best_dist) {
        best_dist = dist;
        best = i;
    }
    i++;
    if (i < 4) {
        p += 6;
        goto loop;
    }
    return best;
}
s32 func_800224E0(s32 *arg0) {
    u8 *p;
    u8 *end;
    u8 *base;
    s32 *ptr;
    s32 val;
    s32 i;
    u8 *db1c;

    p = (&D_8008EB1C) + (D_800A384C * 2);
    end = p + 2;
    ptr = (s32 *)(*arg0);
    db1c = &D_8008DB1C;
    base = db1c + (*(s16 *)((u8 *)ptr + 0xA) * 16);
    val = *(u16 *)(base + *(s16 *)((u8 *)ptr + 0xE) * 2);
    do {
        for (i = 0; i < 3; i++) {
            if (*p == ((val >> (i * 4)) & 0xF)) {
                return i;
            }
        }
        p++;
    } while ((s32)p < (s32)end);
    return 0;
}
void func_80022568(s16 *arg0) {
    arg0[0x136] = 1;
    arg0[0x137] = 0;
    arg0[0x138] = 0;
    arg0[0x139] = 0;
}
__asm__( ".section .text\n" "    .set noat\n" "    .set noreorder\n" "    .include \"" "asm/funcs" "/" "func_80022580" ".s\"\n" "    .set reorder\n" "    .set at\n" );
__asm__( ".section .text\n" "    .set noat\n" "    .set noreorder\n" "    .include \"" "asm/funcs" "/" "func_80022F34" ".s\"\n" "    .set reorder\n" "    .set at\n" );

typedef struct { s32 a, b, c, d; } Quad_2304C;

void func_8002304C(u8 *obj, s32 *pos1, s32 *pos2, s32 *arg3)
{
  s32 *scratch = (s32 *) 0x1F8001B0;
  register s32 *scratch_c asm("s4") = (s32 *) 0x1F8001C0;
  register s16 *scratch_d asm("s6") = (s16 *) 0x1F8001D0;
  register s32 count asm("s5") = 0;
  loop:
  if (((pos1[0] != pos2[0]) || (pos1[1] != pos2[1])) || (pos1[2] != pos2[2]))
  {
    if (func_8005344C(pos1, pos2, scratch, scratch_c, 0x1F8002B8) == 0)
    {
      *(Quad_2304C *)pos1 = *(Quad_2304C *)pos2;
      goto done;
    }
    *((s8 *) (obj + 0xB1)) = (s8) func_80054434();
    *(Quad_2304C *)pos1 = *(Quad_2304C *)scratch;
    func_8002EBDC((s16 *) arg3, (s16 *) scratch_c, arg3, -0x40, 0xE6);
    {
      s16 vel;
      vel = *((s16 *) (((u8 *) scratch) + 0x10));
      scratch[12] = pos1[0] + (vel / 1024);
      vel = *((s16 *) (((u8 *) scratch) + 0x12));
      scratch[13] = pos1[1] + (vel / 1024);
      vel = *((s16 *) (((u8 *) scratch) + 0x14));
      scratch[14] = pos1[2] + (vel / 1024);
    }
    {
      s16 vel;
      vel = *((s16 *) (((u8 *) scratch) + 0x10));
      pos2[0] += vel / 1024;
      vel = *((s16 *) (((u8 *) scratch) + 0x12));
      pos2[1] += vel / 1024;
      vel = *((s16 *) (((u8 *) scratch) + 0x14));
      pos2[2] += vel / 1024;
    }
    if (func_8005344C(pos1, scratch + 12, scratch, scratch + 6, 0x1F8002B8) == 0)
    {
      *(Quad_2304C *)pos1 = *(Quad_2304C *)(scratch + 12);
      scratch[8] = pos2[0] - pos1[0];
      scratch[9] = pos2[1] - pos1[1];
      scratch[10] = pos2[2] - pos1[2];
      {
        s32 step;
        if ((*((u16 *) (obj + 0x6A))) == 0x15)
        {
          step = 0x80;
        }
        else
        {
          step = 0x100;
        }
        func_8002EBDC(scratch_d, (s16 *) scratch_c, (s32 *) scratch_d, 0, step);
      }
      {
        s16 vel_y = *((s16 *) (((u8 *) scratch) + 0x12));
        if (vel_y >= (-0x7FF))
        {
          u16 mode = *((u16 *) (obj + 0x6A));
          s32 m = mode & 0xFFFF;
          if (((((m != 8) && (m != 0x22)) && (((u32) (mode - 0x17)) >= 2)) && (m != 0xA)) && ((*((s16 *) (obj + 0x72))) == 0))
          {
            scratch[9] = 0;
          }
        }
      }
      pos2[0] = pos1[0] + scratch[8];
      pos2[1] = pos1[1] + scratch[9];
      count++;
      pos2[2] = pos1[2] + scratch[10];
      if (count < 4)
      {
        goto loop;
      }
    }
  }

  done:
  ;

  ;
}
typedef struct { s16 a, b, c, d; } SVec8_233AC;

s32 func_800233AC(u8 *arg0, s32 *arg1) {
    s32 pos[3];
    s32 off[3];
    s16 out1[4];
    s32 out2[4];
    u32 bits;
    s32 a1_idx;
    s32 a0_idx;
    s16 *judge_ptr;

    bits = *(u32 *)(arg0 + 0x2C);
    a1_idx = (bits >> 14) & 1;
    if (!(bits & 0x1000)) {
        a1_idx++;
    }
    a0_idx = (bits >> 15) & 1;
    if (!(bits & 0x2000)) {
        a0_idx++;
    }

    {
        s16 *tbl = &D_8008EB40;
        s32 px;
        s16 *row;
        s32 a1_val;

        px = *(s32 *)(arg0 + 0xB8);
        row = tbl + a0_idx * 3;
        a1_val = row[a1_idx];

        pos[0] = px;
        pos[1] = *(s32 *)(arg0 + 0xBC) - 0x64;
        pos[2] = *(s32 *)(arg0 + 0xC0);

        {
            s32 angle = (*(s16 *)(arg0 + 0x1D8) + a1_val) & 0xFFF;
            s16 jv = (&Judge)[angle];
            judge_ptr = &Judge;

            off[0] = px + jv / 4;
            off[1] = pos[1];
        }

        {
            s32 angle2 = (*(s16 *)(arg0 + 0x1D8) + a1_val + 0x400) & 0xFFF;
            s16 jv2 = judge_ptr[angle2];

            off[2] = pos[2] + jv2 / 4;
        }
    }

    if (func_80053614(pos, off, out2, (s32 *)out1, (s32)0x1F8002B8) == 0) {
        return 0;
    }

    *(SVec8_233AC *)(arg0 + 0x98) = *(SVec8_233AC *)out1;

    {
        s32 fwd_angle = ratan2(out1[0], out1[2]);
        s32 fwd_800;

        pos[0] = *(s32 *)(arg0 + 0xB8);
        pos[1] = *(s32 *)(arg0 + 0xBC) - 0x898;
        pos[2] = *(s32 *)(arg0 + 0xC0);

        fwd_800 = fwd_angle + 0x800;

        {
            s32 angle3 = fwd_800 & 0xFFF;
            s16 jv3 = judge_ptr[angle3];
            off[0] = pos[0] + jv3 / 8;
        }

        off[1] = pos[1];

        {
            s32 angle4 = (fwd_angle + 0xC00) & 0xFFF;
            s16 jv4 = judge_ptr[angle4];
            off[2] = pos[2] + jv4 / 8;
        }

        if (func_80053614(pos, off, out2, (s32 *)out1, (s32)0x1F8002B8) != 0) {
            return 0;
        }

        pos[0] = off[0];
        pos[1] = off[1] + 0x190;
        pos[2] = off[2];

        if (func_80053614(off, pos, out2, (s32 *)out1, (s32)0x1F8002B8) == 0) {
            return 0;
        }

        *arg1 = fwd_800;
        return 1;
    }
}
__asm__( ".section .text\n" "    .set noat\n" "    .set noreorder\n" "    .include \"" "asm/funcs" "/" "func_80023648" ".s\"\n" "    .set reorder\n" "    .set at\n" );
__asm__( ".section .text\n" "    .set noat\n" "    .set noreorder\n" "    .include \"" "asm/funcs" "/" "func_800238C4" ".s\"\n" "    .set reorder\n" "    .set at\n" );

void func_80023C30(s32 arg0, s32 arg1, s32 arg2, s16 *arg3) {
    arg3[0] = 0x1000;
    arg3[1] = 0;
    arg3[2] = 0;
    arg3[3] = 0;
    arg3[4] = 0x1000;
    arg3[5] = 0;
    arg3[6] = 0;
    arg3[7] = 0;
    arg3[8] = 0x1000;
    RotMatrixX(arg0, (s32)arg3);
    RotMatrixY(arg1, (s32)arg3);
    RotMatrixZ(arg2, (s32)arg3);
}
void func_80023CB4(s16 *arg0, s16 arg1) {
    s16 v;
    *(u16 *)((u8 *)arg0 + 0x31A) += 1;
    v = *(s16 *)((u8 *)arg0 + 0x31A);
    if (v == 1) {
        *(s16 *)((u8 *)arg0 + 0x318) = arg1;
        *(s32 *)((u8 *)arg0 + 0x320) = 0;
        *(s32 *)((u8 *)arg0 + 0x328) = 0;
    }
    *(s16 *)((u8 *)arg0 + 0x31C) = arg1;
    if (*(s16 *)((u8 *)arg0 + 0x152) == 0) {
        *(s16 *)((u8 *)arg0 + 0x152) = 1;
        *(s16 *)((u8 *)arg0 + 0x154) = *(u16 *)((u8 *)arg0 + 0x1D8);
    }
}
void func_80023D08(s32 arg0) {
    func_80023CB4(arg0, 0x200);
}
void func_80023D28(u8 *arg0) {
    if (*(s32 *)(arg0 + 0x108) < 0) {
        *(s16 *)(arg0 + 0x1DC) = 0;
        return;
    }
    *(s32 *)0x1F8001E0 = *(s32 *)(arg0 + 0xB8);
    *(s32 *)0x1F8001E4 = *(s32 *)(arg0 + 0xBC) + 0x1F4;
    *(s32 *)0x1F8001E8 = *(s32 *)(arg0 + 0xC0);
    *(s16 *)(arg0 + 0x1DC) = func_8005344C((s32 *)(arg0 + 0xB8), (s32 *)0x1F8001E0, (s32 *)0x1F8001B0, (s32 *)0x1F8001C0, 0x1F8002B8);
}
s32 func_80023DB8(u8 *arg0) {
    s32 result;
    *(s32 *)0x1F8001E0 = *(s32 *)(arg0 + 0xB8);
    *(s32 *)0x1F8001E4 = *(s32 *)(arg0 + 0xBC) + 5;
    *(s32 *)0x1F8001E8 = *(s32 *)(arg0 + 0xC0);
    if (func_8005344C((s32 *)(arg0 + 0xB8), (s32 *)0x1F8001E0, (s32 *)0x1F8001B0, (s32 *)0x1F8001C0, 0x1F8002B8) != 0) {
        result = *(s16 *)0x1F8001C2 < -0x800;
    } else {
        result = 0;
    }
    return result;
}
void func_80023E40(u8 *arg0) {
    s32 *s1 = (s32 *)0x1F8001B0;
    s32 a0;
    s32 v1;
    a0 = *(u16 *)(arg0 + 0x6A);
    v1 = a0 & 0xFFFF;
    if (v1 == 8) goto done;
    if (v1 == 0x22) goto done;
    if ((u32)(a0 - 0x17) < 2 || v1 == 0x28 || v1 == 0xA) {
        s32 v0;
        s32 *v3 = (s32 *)0x1F8002B8;
        s1[0xC] = *(s32 *)(arg0 + 0xB8);
        s1[0xD] = *(s32 *)(arg0 + 0xBC) + 0x1F40;
        s1[0xE] = *(s32 *)(arg0 + 0xC0);
        v0 = func_80053614((s32 *)(arg0 + 0xB8), &s1[0xC], s1, &s1[4], (s32)v3);
        if (v0 == 0) goto done;
        *(s32 *)(arg0 + 0x148) = s1[1];
        goto done;
    }
    *(s32 *)(arg0 + 0x148) = *(s32 *)(arg0 + 0xBC);
done:;
}
__asm__( ".section .text\n" "    .set noat\n" "    .set noreorder\n" "    .include \"" "asm/funcs" "/" "func_80023F08" ".s\"\n" "    .set reorder\n" "    .set at\n" );
# 2832 "src/code6cac.c"
const char D_800100FC[66][12] = {
    "WIN     ",
    "KARAMI_ED",
    "RUN_ED  ",
    "RUN_ST  ",
    "CHAKUTI ",
    "APPEAR  ",
    "KAISHAKU_ST",
    "HAJIKARE",
    "SERIEXIT",
    "SYAGAMI ",
    "HOM_ED  ",
    "HOM_AT  ",
    "HOM_ST  ",
    "ANOBORI ",
    "KAMAE_KA",
    "MOVE    ",
    "NOBORI_E",
    "NOBORI_S",
    "FURI2   ",
    "FURI1   ",
    "YURI2   ",
    "YURI1   ",
    "GOKAKU  ",
    "START   ",
    "ARUN    ",
    "STEP    ",
    "WALK    ",
    "LJUMP   ",
    "MJUMP   ",
    "SJUMP   ",
    "KAMAE   ",
    "DTH     ",
    "RUN     ",
    "SUNA    ",
    "KARAMI  ",
    "RELOAD  ",
    "SERI    ",
    "HAJI    ",
    "UKE     ",
    "SYASTEP ",
    "SUBWEP  ",
    "ORI     ",
    "OKIAGARI",
    "NOBORI  ",
    "KZRE    ",
    "KOROGARI",
    "KAISYAKU",
    "END_GAME",
    "DAM     ",
    "ATTACK  ",
    "NORMAL  ",
    "NULL    ",
    "Y123.BBM",
    "N123.BBM",
    "K123.BBM",
    "T123.BBM",
    "S234.BBM",
    "S125.BBM",
    "S124.BBM",
    "S123.BBM",
    "U235.BBM",
    "U135.BBM",
    "U134.BBM",
    "U125.BBM",
    "U124.BBM",
    "U123.BBM",
};
const u32 jtbl_80010414[6] = {
    0x800214D0, 0x80021520, 0x80021578, 0x80021690, 0x80021578, 0x00000000,
};
