#!/usr/bin/env python3
"""Independent default-refute re-derivation of tmp/naming-wave-2026-09/.../near_manifest.csv.
Read-only w.r.t. the tree; writes only tmp/near_audit/verify_out.md."""
import csv, glob, json, os, re, struct, subprocess, sys
import numpy as np

REPO = "/mnt/c/Users/Trenton/Desktop/Bushido Blade 2 Decompile"
sys.path.insert(0, os.path.join(REPO, "tmp", "closer"))
from psyq_lib import lib_modules, parse_obj  # noqa

OUT = []
def P(s=""): OUT.append(s); print(s)

exeb = open(os.path.join(REPO, "disc", "SLUS_006.63"), "rb").read()
taddr = struct.unpack_from("<I", exeb, 0x18)[0]
body = exeb[2048:]
NW = len(body) // 4
exe = np.frombuffer(body[:NW * 4], dtype="<u4").astype(np.uint32)
def word(va): return int(exe[(va - taddr) // 4])
def vaddr(i): return taddr + i * 4

BUILDS = {"40J": os.path.join(REPO, "tmp/libscan/psyq40"),
          "40U": os.path.join(REPO, "tmp/libsnd_hunt/psyq40u"),
          "41": os.path.join(REPO, "tmp/libsnd_hunt/psyq41"),
          "42": os.path.join(REPO, "tmp/libsnd_hunt/psyq42/LIB"),
          "43": os.path.join(REPO, "tmp/libsnd_hunt/psyq43"),
          "44": os.path.join(REPO, "tmp/libsnd_hunt/psyq44")}
_libcache = {}
def modules(build, lib):
    p = os.path.join(BUILDS[build], lib + ".LIB")
    if p not in _libcache:
        _libcache[p] = dict(lib_modules(open(p, "rb").read())) if os.path.exists(p) else {}
    return _libcache[p]
def load(build, lib, mod):
    d = modules(build, lib)
    return parse_obj(d[mod]) if mod in d else None

def text_of(o):
    for sid, s in o.sections.items():
        if s["name"] == ".text" and len(s["bytes"]) >= 8:
            return sid, bytes(s["bytes"])
    return None, None

def masked(o):
    """words, masks, relocs(list of (wordidx,type,expr-with-names)) for .text"""
    sid, data = text_of(o)
    n = len(data) // 4
    words = np.frombuffer(data[:n * 4], dtype="<u4").astype(np.uint32)
    masks = np.full(n, 0xFFFFFFFF, dtype=np.uint32)
    rl = []
    for rsec, t, roff, e in o.relocs:
        if rsec != sid or roff // 4 >= n:
            continue
        m = {82: 0xFFFF0000, 84: 0xFFFF0000, 74: 0xFC000000, 16: 0}.get(t, 0)
        masks[roff // 4] &= np.uint32(m)
        e = re.sub(r"sym:(\d+)", lambda mm: "sym:" + str(o.xrefs.get(int(mm.group(1)), mm.group(1))), e)
        rl.append((roff // 4, t, e))
    return sid, words, masks, rl

def mism_at(words, masks, base):
    j = (base - taddr) // 4
    n = len(words)
    if j < 0 or j + n > NW:
        return 10**9
    return int((((exe[j:j + n] & masks) != (words & masks)) & (masks != 0)).sum())

def scan(words, masks):
    n = len(words); span = NW - n + 1
    mm = np.zeros(span, dtype=np.int32)
    for i in range(n):
        if masks[i] == 0: continue
        mm += ((exe[i:i + span] & masks[i]) != (words[i] & masks[i]))
    j = int(mm.argmin()); m = int(mm[j])
    m2 = mm.copy(); m2[max(0, j - n):min(span, j + n)] = 10**9
    j2 = int(m2.argmin())
    return vaddr(j), m, vaddr(j2), int(m2[j2])

def disasm(blob, base):
    fn = os.path.join(REPO, "tmp/near_audit/_v.bin")
    open(fn, "wb").write(blob)
    out = subprocess.run(["mipsel-linux-gnu-objdump", "-D", "-b", "binary", "-mmips:3000", "-EL",
                          "--adjust-vma=0x%x" % base, fn], capture_output=True, text=True).stdout
    res = {}
    for ln in out.splitlines():
        m = re.match(r"^\s*([0-9a-f]+):\s+([0-9a-f]{8})\s+(.*)$", ln)
        if m: res[int(m.group(1), 16)] = re.sub(r"\s+", " ", m.group(3).strip())
    return res

# ---- our names
MAPDEF = re.compile(r"^\s+0x0*([0-9a-f]{8})\s+([A-Za-z_]\w*)\s*$")
mapdefs = {}
for ln in open(os.path.join(REPO, "build/bb2.map"), encoding="utf-8", errors="replace"):
    m = MAPDEF.match(ln)
    if m: mapdefs.setdefault(int(m.group(1), 16), []).append(m.group(2))
ALIAS = {}
for f in ("named_syms.txt", "symbol_addrs.txt", "undefined_syms_auto.txt", "undefined_funcs_auto.txt"):
    for ln in open(os.path.join(REPO, f), encoding="utf-8", errors="replace"):
        m = re.match(r"\s*([A-Za-z_]\w*)\s*=\s*(0x[0-9A-Fa-f]+)", ln)
        if m: ALIAS.setdefault(int(m.group(2), 16), []).append(m.group(1))
def names(a): return mapdefs.get(a, []) + [x for x in ALIAS.get(a, []) if x not in mapdefs.get(a, [])]
fstarts = sorted(mapdefs)
def contain(a):
    lo = [f for f in fstarts if f <= a]; return lo[-1] if lo else None

# accepted placements (rename_manifest) + matches.json verbatim
ACCEPT = {"CONFIRM", "FILL", "CONTRADICTED", "CONTRADICTED_ALIAS", "MODULE_LOCAL_STATIC", "IN_SPAN_NO_SYMBOL"}
manifest_place = {}
for r in csv.DictReader(open(os.path.join(REPO, "docs/naming/libscan/rename_manifest.csv"), encoding="utf-8", errors="replace")):
    manifest_place.setdefault((r["lib"], r["module"], int(r["mod_start"], 16)), set()).add(r["classification"])
MJ = json.load(open(os.path.join(REPO, "tmp/libscan/matches.json")))
mj = {(r["lib"], r["mod"]): r for r in MJ["results"]}

rows = list(csv.DictReader(open(os.path.join(REPO, "tmp/naming-wave-2026-09/stage/docs/naming/libscan/near_manifest.csv"), encoding="utf-8")))

# =====================================================================
P("# Verifier re-derivation (independent of audit.py)\n")
P("## (1) libscan-xref rows\n")
XREF = {  # addr -> [(build, lib, module, mod_start)]
    0x80089A48: [("40J", "LIBSPU", "S_SNV", 0x80089A24), ("40J", "LIBSPU", "S_SRV", 0x8008A904)],
    0x800841E0: [("40J", "LIBSND", "SSCALL", 0x80083F6C)],
    0x80084500: [("40J", "LIBSND", "SSCALL", 0x80083F6C)],
    0x800863CC: [("40U", "LIBSND", "SSSTOP", 0x80085270)],
    0x800863DC: [("40J", "LIBSND", "SSCALL", 0x80083F6C)],
    0x80086818: [("40J", "LIBSND", "SSINIT", 0x80083A48)],
    0x80087DA0: [("40J", "LIBSND", "PAUSE", 0x800848AC), ("40U", "LIBSND", "SSSTOP", 0x80085270)],
}
for r in rows:
    if r["evidence_class"] != "libscan-xref": continue
    addr = int(r["addr"], 16); nm = r["proposed_name"]
    P(f"### {r['addr']} {nm}")
    for build, lib, mod, ms in XREF[addr]:
        o = load(build, lib, mod)
        sid, words, masks, rl = masked(o)
        mm = mism_at(words, masks, ms)
        b1, m1, b2, m2 = scan(words, masks)
        cls = manifest_place.get((lib, mod, ms))
        mjr = mj.get((lib, mod)); mjv = (mjr.get("status"), mjr.get("vaddrs")) if mjr else None
        xd = [(n_, off) for n_, s_, off in o.xdefs if s_ == sid]
        P(f"- {lib}/{mod} ({build}) @0x{ms:08X}: {len(words)} words, masked mismatch at placement = {mm}; "
          f"exhaustive best 0x{b1:08X} ({m1}) second 0x{b2:08X} ({m2}); manifest class={cls}; matches.json={mjv}; XDEFs={xd}")
        hits = [(wi, t, e) for wi, t, e in rl if t == 74 and e == "sym:" + nm]
        if not hits:
            P(f"  - **NO REL26 XREF {nm} in this module** (REL26 xrefs: {[e for wi,t,e in rl if t==74]})")
        for wi, t, e in hits:
            a = ms + wi * 4; w = word(a)
            op = w >> 26
            tgt = ((w & 0x3FFFFFF) << 2) | (a & 0xF0000000)
            P(f"  - reloc +0x{wi*4:X} @0x{a:08X}: EXE word {w:08X} op={op} ({'jal' if op==3 else 'j' if op==2 else '??'}) -> 0x{tgt:08X} "
              f"{'== row addr' if tgt == addr else '!= row addr ' + r['addr']}; fn start in map: {tgt in mapdefs} {names(tgt)}")

# =====================================================================
P("\n## (2) libscan-near rows — my own placement\n")
NEAR = [  # (lib, mod, sym, expected_sym_addr, builds to report)
    ("LIBSND", "UT_KEYV", "SsUtKeyOnV", 0x80085A40),
    ("LIBSND", "VM_NOWOF", "_SsVmKeyOffNow", 0x800871D4),
    ("LIBSND", "VM_ALOC2", "_SsVmDoAllocate", 0x800861BC),
    ("LIBSND", "UT_VVOL", "SsUtGetDetVVol", 0x80085FD8),
    ("LIBSND", "UT_VVOL3", "SsUtGetVVol", 0x80086080),
    ("LIBSND", "UT_VVOL2", "SsUtSetDetVVol", 0x80086014),
    ("LIBSND", "VM_SEQ_2", "_SsVmGetSeqLVol", 0x80087D10),
    ("LIBSND", "VM_SEQ_2", "_SsVmGetSeqRVol", 0x80087D58),
    ("LIBSPU", "S_SAV", "_SpuSetAnyVoice", 0x80089A48),
]
for lib, mod, sym, want in NEAR:
    P(f"### {lib}/{mod} {sym} expected @0x{want:08X}")
    best = None
    for build in BUILDS:
        o = load(build, lib, mod)
        if o is None: P(f"- {build}: absent"); continue
        sid, words, masks, rl = masked(o)
        b1, m1, b2, m2 = scan(words, masks)
        scored = int((masks != 0).sum())
        xd = {n_: off for n_, s_, off in o.xdefs if s_ == sid}
        symaddr = b1 + xd.get(sym, -1) if sym in xd else None
        P(f"- {build}: {len(words)}w scored {scored}; best 0x{b1:08X} mism {m1}; 2nd 0x{b2:08X} mism {m2}; "
          f"{sym}+0x{xd.get(sym, -1):X} -> {('0x%08X' % symaddr) if symaddr is not None else 'n/a'} "
          f"{'== fn start' if symaddr == want else '(want 0x%08X; delta %+d)' % (want, (symaddr - want) if symaddr is not None else 0)}; all XDEFs {[(k, hex(v)) for k, v in xd.items()]}")
        if best is None or m1 / max(scored, 1) < best[0]:
            best = (m1 / max(scored, 1), build, words, masks, rl, b1, m1, o, sid)
    _, build, words, masks, rl, base, m1, o, sid = best
    n = len(words)
    ld = disasm(words.astype("<u4").tobytes(), base)
    ed = disasm(body[(base - taddr):(base - taddr) + n * 4], base)
    P(f"- best build {build} @0x{base:08X}, {m1} differing scored words:")
    for i in range(n):
        if masks[i] == 0: continue
        if (int(exe[(base - taddr)//4 + i]) & int(masks[i])) != (int(words[i]) & int(masks[i])):
            a = base + i * 4
            P(f"  - 0x{a:08X}: lib {int(words[i]):08X} `{ld.get(a)}` | EXE {int(exe[(base-taddr)//4+i]):08X} `{ed.get(a)}`")
    for wi, t, e in rl:
        if t != 74 or not e.startswith("sym:"): continue
        a = base + wi * 4; w = word(a); tgt = ((w & 0x3FFFFFF) << 2) | (a & 0xF0000000)
        P(f"  - callee +0x{wi*4:X}: module `{e[4:]}` -> EXE jal 0x{tgt:08X} = {names(tgt)} {'fnstart' if tgt in mapdefs else 'NOT-START'}")
    hi = {}
    seen = set()
    for wi, t, e in rl:
        a = base + wi * 4; w = word(a)
        if t == 82: hi[e] = w & 0xFFFF
        elif t == 84 and e in hi:
            lo = w & 0xFFFF; lo = lo - 0x10000 if lo >= 0x8000 else lo
            da = ((hi[e] << 16) + lo) & 0xFFFFFFFF
            if (e, da) in seen: continue
            seen.add((e, da)); P(f"  - data `{e}` -> 0x{da:08X} = {ALIAS.get(da, ['?'])}")

# ---- alternative-module sweep: at each near-row function start, which Sony LIBSND/LIBSPU
# module (any build) fits best when its XDEF'd function start is aligned to that address?
P("\n## (2b) alternative-module sweep at each near-row function start (all LIBSND+LIBSPU, all builds)\n")
P("For every XDEF in every module of every build, align that XDEF to the row address and count masked mismatches over the module's full .text (also for the window function-length). Lower = better fit.")
def fn_len(a):
    i = fstarts.index(a); return (fstarts[i + 1] - a) // 4 if i + 1 < len(fstarts) else 64
for r in rows:
    if r["evidence_class"] != "libscan-near": continue
    addr = int(r["addr"], 16); L = fn_len(addr)
    cands = []
    for build in BUILDS:
        for lib in ("LIBSND", "LIBSPU"):
            for mod, od in modules(build, lib).items():
                try: o = parse_obj(od)
                except Exception: continue
                sid, data = text_of(o)
                if sid is None: continue
                _, words, masks, rl = masked(o)
                for n_, s_, off in o.xdefs:
                    if s_ != sid or off % 4: continue
                    base = addr - off
                    # score only the window [off, off + L words) of the module, clipped
                    j0 = off // 4; j1 = min(len(words), j0 + L)
                    if j1 - j0 < 4: continue
                    sub_w = words[j0:j1]; sub_m = masks[j0:j1]
                    jj = (addr - taddr) // 4
                    mm = int((((exe[jj:jj + (j1 - j0)] & sub_m) != (sub_w & sub_m)) & (sub_m != 0)).sum())
                    sc = int((sub_m != 0).sum())
                    cands.append((mm / max(sc, 1), mm, sc, build, lib, mod, n_))
    cands.sort()
    P(f"- {r['addr']} (fn len {L}w) proposed {r['proposed_name']}: top fits = " +
      "; ".join(f"{b}/{lib}/{mod}:{n_} {mm}/{sc}" for _, mm, sc, b, lib, mod, n_ in cands[:6]))

# =====================================================================
P("\n## (3) libscan-desync rows\n")
srcfiles = glob.glob(os.path.join(REPO, "src/*.c"))
for r in rows:
    if r["evidence_class"] != "libscan-desync": continue
    addr = int(r["addr"], 16); old = r["current_name"]; new = r["proposed_name"]
    md = mapdefs.get(addr, []); al = ALIAS.get(addr, [])
    defs = []
    for f in srcfiles:
        for i, ln in enumerate(open(f, encoding="utf-8", errors="replace"), 1):
            if re.search(r"^\w[\w\s\*]*\b" + re.escape(old) + r"\s*\(", ln) and not ln.strip().endswith(";"):
                defs.append(f"{os.path.basename(f)}:{i}")
    sfile = os.path.join(REPO, "asm/funcs", new + ".s")
    sglabel = None
    if os.path.exists(sfile):
        t = open(sfile, encoding="utf-8", errors="replace").read()
        g = re.search(r"glabel\s+(\w+)", t); a2 = re.search(r"/\*\s*[0-9A-F]+\s+(8[0-9A-F]{7})", t)
        sglabel = (g.group(1) if g else None, a2.group(1) if a2 else None)
    oldsfile = os.path.exists(os.path.join(REPO, "asm/funcs", old + ".s"))
    P(f"- {r['addr']} map={md} aliases={al}; C def of `{old}` at {defs or 'NONE'}; asm/funcs/{new}.s: {sglabel}; asm/funcs/{old}.s exists={oldsfile}")

# =====================================================================
P("\n## (4) whole-word collisions for every proposed name (src include *.txt engine/queue.json)\n")
files = glob.glob(os.path.join(REPO, "src/*.c")) + glob.glob(os.path.join(REPO, "include/*.h")) + \
        glob.glob(os.path.join(REPO, "*.txt")) + [os.path.join(REPO, "engine/queue.json")]
for r in rows:
    new = r["proposed_name"]; addr = r["addr"].lower()
    hits = []
    for f in files:
        for i, ln in enumerate(open(f, encoding="utf-8", errors="replace"), 1):
            if re.search(r"\b" + re.escape(new) + r"\b", ln):
                hits.append(f"{os.path.relpath(f, REPO)}:{i}: {ln.strip()[:110]}")
    other = [h for h in hits if not re.search(re.escape(new) + r"\s*=\s*0x" + addr[2:], h, re.I)]
    P(f"- {new} ({r['addr']}): {len(hits)} hits; non-same-addr-alias hits:")
    for h in other[:12]: P(f"    {h}")

open(os.path.join(REPO, "tmp/near_audit/verify_out.md"), "w").write("\n".join(OUT) + "\n")
