/* Minimal reproducers for the combine.c PLUS->IOR transform (combine.c:3618-3626).
   Each function's operands to the final `+` have provably disjoint nonzero_bits,
   so stock GCC 2.7.2 rewrites the PLUS into an IOR. */

/* R1 -- ings/gnd_disp_loop_ctrl shape: (x & 3) + 4  ->  x | 4 */
int r1(int x) { return (x & 3) + 4; }

/* R2 -- code6cac_b/func_80033DF4 shape: b in {0,1}; (b<<2) + b -> (b<<2) | b */
int r2(int a, int b) { int t = (unsigned)a < (unsigned)b; return (t << 2) + t; }

/* R3 -- the comment's own example: ((a & 1) + (a & 2)) -> a & 3 */
int r3(int a) { return (a & 1) + (a & 2); }

/* R4 -- ings/cpu_set_... shape: ((v - 1) << 8) + 128 */
int r4(unsigned char v) { return ((int)(v - 1) << 8) + 128; }

/* R5 -- byte-pack: (hi << 8) + lo with lo known 8-bit */
int r5(int hi, unsigned char lo) { return (hi << 8) + lo; }
