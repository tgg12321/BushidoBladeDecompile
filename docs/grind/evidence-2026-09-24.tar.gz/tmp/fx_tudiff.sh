#!/bin/bash
set -uo pipefail
cd "/mnt/c/Users/Trenton/Desktop/Bushido Blade 2 Decompile"
T=tmp/fx
F="-O2 -G0 -funsigned-char -quiet -mcpu=3000 -mips1 -mno-abicalls -fno-builtin -w -mel"
CPP="mipsel-linux-gnu-cpp -Iinclude -undef -Wall -lang-c -fno-builtin -Dmips -D__GNUC__=2 -D__OPTIMIZE__ -D__mips__ -D__mips -Dpsx -D__psx__ -D__psx -D_PSYQ -D__EXTENSIONS__ -D_MIPSEL -D_LANGUAGE_C -DLANGUAGE_C"
for stem in ings code6cac_b; do
  $CPP src/$stem.c > $T/$stem.i 2>/dev/null
  tools/gcc-2.7.2/build/cc1 $F $T/$stem.i -o $T/$stem.shipped.s 2>/dev/null
  tmp/ab/cc1.mixed          $F $T/$stem.i -o $T/$stem.mixed.s 2>/dev/null
  echo "##### $stem"
  diff -u $T/$stem.shipped.s $T/$stem.mixed.s | sed -n '1,200p'
  echo "----- containing functions:"
  diff --unchanged-group-format='' --old-group-format='%<' --new-group-format='' \
       $T/$stem.shipped.s $T/$stem.mixed.s >/dev/null 2>&1
  python3 - "$T/$stem.shipped.s" "$T/$stem.mixed.s" <<'PY'
import sys, difflib, re
a=open(sys.argv[1]).read().splitlines(); b=open(sys.argv[2]).read().splitlines()
def fnat(lines, idx):
    for k in range(idx, -1, -1):
        m=re.match(r'^\s*(?:\.globl\s+|)([A-Za-z_$][\w$]*):', lines[k])
        if m and not m.group(1).startswith('$'): return m.group(1)
    return '?'
sm=difflib.SequenceMatcher(None,a,b,autojunk=False)
for tag,i1,i2,j1,j2 in sm.get_opcodes():
    if tag=='equal': continue
    print(f"  [{tag}] in {fnat(a,i1)}  shipped:{a[i1:i2]}  mixed:{b[j1:j2]}")
PY
done
