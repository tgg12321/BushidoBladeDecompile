#!/bin/bash
# Phase 1: disassemble simplify_rtx from shipped vs recipe-rebuilt cc1.
set -uo pipefail
R="/mnt/c/Users/Trenton/Desktop/Bushido Blade 2 Decompile"
cd "$R"
T=tmp/fx; mkdir -p $T
A=tools/gcc-2.7.2/build/cc1
B=tmp/ab/cc1.mixed
echo "shipped sha1: $(sha1sum $A | cut -d' ' -f1)"
echo "shipped size: $(stat -c%s $A)   mixed size: $(stat -c%s $B)"
for tag in shipped mixed; do
  case $tag in shipped) BIN=$A;; mixed) BIN=$B;; esac
  nm --defined-only -S $BIN 2>/dev/null | awk '$4=="simplify_rtx"{print $1, $2}' > $T/sym.$tag
  read ADDR SIZE < $T/sym.$tag
  echo "$tag simplify_rtx addr=0x$ADDR size=0x$SIZE ($((16#$SIZE)) bytes)"
  objdump -d --start-address=0x$ADDR --stop-address=$((0x$ADDR + 16#$SIZE)) $BIN \
    | sed -e 's/^[0-9a-f]*//' -e 's/^\s*//' > $T/dis.$tag.raw
  # normalise: drop addresses and raw bytes, keep mnemonic+operands
  objdump -d --start-address=0x$ADDR --stop-address=$((0x$ADDR + 16#$SIZE)) $BIN \
    | grep -E '^\s+[0-9a-f]+:' \
    | sed -e 's/^\s*\([0-9a-f]*\):\s*//' -e 's/^\(\([0-9a-f][0-9a-f] \)*\)\s*//' \
    > $T/dis.$tag.txt
  wc -l $T/dis.$tag.txt
done
echo "=== also dump size of every combine.c-resident symbol for context ==="
