import os,re,glob,json
root=r"C:/Users/Trenton/Desktop/Bushido Blade 2 Decompile"
rows=[]
for base in ("memory/grind","memory/wip"):
    for f in glob.glob(os.path.join(root,base,"*","hypotheses.md"))+glob.glob(os.path.join(root,base,"*","notes.md")):
        fn=f.replace("\\","/").split("/")[-2]
        lines=open(f,encoding='utf-8',errors='replace').read().split("\n")
        inkill=False
        for i,l in enumerate(lines):
            s=l.strip()
            if re.match(r"^#{1,4}\s",s):
                inkill = bool(re.search(r"\bKILL(ED)?\b|\bDEAD\b|GRAVEYARD|REFUTED|NEGATIVE", s, re.I))
                continue
            if inkill and s.startswith("- "):
                rows.append((fn,base.split("/")[-1],os.path.basename(f),i+1,s[2:]))
            # also catch inline 'verdict: KILLED' bullets
            elif re.search(r"verdict:\s*KILLED", s, re.I):
                # back up to the nearest bullet start
                j=i
                while j>0 and not lines[j].strip().startswith("- "): j-=1
                rows.append((fn,base.split("/")[-1],os.path.basename(f),j+1,lines[j].strip()[2:]))
json.dump(rows,open(os.path.join(root,"tmp/killed_rows.json"),"w",encoding='utf-8'),indent=0)
print("rows:",len(rows),"funcs:",len(set(r[0] for r in rows)))
