#!/usr/bin/env python3
"""Adjudicate the 154 active ASM-SUSPECT / ASM-PARTIAL queue items.

Rubric (base-rate corrected -- see docs/grind/asm-suspect-census-2026-08-06.md):
  DECISIVE  = GCC-2.7.2-impossible construct, zero counter-examples in the
              already-COMPLETED-C population: trapping arithmetic, non-standard
              `break` code, S1/S2/S6/S7/S8, duplicated cop2 read, near-clone of
              an already-authorized canonical function.
  WEAK      = enriched in the authorized population but with COMPLETED-C
              counter-examples (G1 ghost callee-save) or purely structural.
  NOISE     = fires on >30% of the >=40-insn corpus (S4 front-loads,
              D1 unfilled jr-$ra delay) -- recorded, never scored.
"""
import json
from pathlib import Path
from collections import Counter

ROOT = Path(__file__).resolve().parent.parent
scan = {s["func"]: s for s in json.load(open(ROOT / "tmp" / "scan_full.json"))}
supp = json.load(open(ROOT / "tmp" / "supp_signals.json"))
gate = json.load(open(ROOT / "tmp" / "gate_reasons.json"))

COP2 = ("mtc2", "mfc2", "ctc2", "cfc2", "lwc2", "swc2", "gpf", "gpl", "rtps",
        "rtpt", "nclip", "avsz", "mvmva", "ncd", "ncc", "cdp", "dpc", "intpl",
        "sqr", "op", "ncs", "nct", "cc")

rows = []
for name, sp in supp.items():
    if "error" in sp:
        continue
    sc, g, q = scan.get(name), gate.get(name, {}), sp["queue"]
    decisive, weak, noise = [], [], []

    reasons = g.get("reasons", [])
    gte_reasons = [r for r in reasons if "GTE/cop2" in r]
    trap_reasons = [r for r in reasons if "trapping-overflow" in r]
    other_reasons = [r for r in reasons if r not in gte_reasons and r not in trap_reasons]
    gte_frac = (g.get("asm_insns", 0) / g["total"]) if g.get("total") else 0.0
    if trap_reasons:
        decisive.append("T1:trapping-arith(" + ",".join(
            r.split("(")[1].split(")")[0] for r in trap_reasons) + ")")
    if other_reasons:
        decisive.append("GATE:" + ";".join(other_reasons))
    if gte_reasons:
        weak.append(f"GTE-region:{g.get('asm_insns')}/{g.get('total')} "
                    f"({gte_frac:.0%}) in {len(g.get('regions', []))} region(s)")

    if sc:
        for k, lbl in (("s1_uniform_multu", "S1:uniform-multu-pacing"),
                       ("s2_empty_branch", "S2:empty-body-branch"),
                       ("s6_bios_jumptable", "S6:BIOS-jumptable-delay-slot"),
                       ("s7_no_save_callee_use", "S7:unsaved-callee-save-use"),
                       ("s8_redundant_mask_shift", "S8:redundant-mask-before-shift")):
            if sc[k]:
                decisive.append(lbl)
        if sc["s3_no_spills"]:
            weak.append("S3:no-spills")
        if sc["s5_cluster"]:
            weak.append("S5:cluster-sibling")
        if sc["s4_front_loads"]:
            noise.append("S4:front-loaded-loads(base-rate 39%)")
        scan_tier, insns = sc["tier"], sc["insn_count"]
    else:
        scan_tier, insns = "NOT-SCANNED", sp["insns"]

    if sp["B1_nonstd_break"]:
        decisive.append("B1:nonstd-break(" + ",".join(sp["B1_nonstd_break"]) + ")")
    dup_cop2 = [d for d in sp["X1_dup_adjacent_insn"] if d.split()[0].startswith(COP2)]
    if dup_cop2:
        decisive.append("X1:duplicated-cop2-read(" + dup_cop2[0].split("/")[0].strip() + ")")
    if sp["K1_jaccard"] >= 0.85 and insns >= 12:
        decisive.append(f"K1:canon-clone {sp['K1_canon_sibling']} j={sp['K1_jaccard']}")
    elif sp["K1_jaccard"] >= 0.70 and insns >= 12:
        weak.append(f"K1:canon-similar {sp['K1_canon_sibling']} j={sp['K1_jaccard']}")
    if sp["G1_ghost_callee_save"]:
        weak.append("G1:ghost-callee-save($" + ",$".join(sp["G1_ghost_callee_save"]) + ")")
    if sp["R1_leaf_ra_save"]:
        decisive.append("R1:leaf-saves-ra")
    if sp["N1_noframe_uses_s"]:
        decisive.append("N1:no-frame-uses-callee-save")
    if sp["D1_unfilled_jr_ra"]:
        noise.append(f"D1:unfilled-jr-ra-delay x{sp['D1_unfilled_jr_ra']}(base-rate high)")

    has_ghost = bool(sp["G1_ghost_callee_save"])
    if decisive:
        tier, bucket = "STRONG", "canonical-eligible"
        ev = ("GCC-2.7.2-impossible construct present: " + "; ".join(decisive) +
              ". No counter-example exists in the COMPLETED-C population.")
    elif gte_reasons and gte_frac >= 0.35:
        tier, bucket = "WEAK", "canonical-eligible"
        ev = (f"cop2/GTE ops are {gte_frac:.0%} of the body "
              f"({g.get('asm_insns')}/{g.get('total')} insns across "
              f"{len(g.get('regions', []))} regions) -- the GTE spans ARE the function. "
              f"Region-granular canonical authorization is the right form; the "
              f"non-cop2 remainder is ordinary C scaffolding.")
    elif has_ghost or scan_tier in ("STRONG", "POSSIBLE"):
        tier, bucket = "WEAK", "uncertain"
        ev = (f"Ghost callee-save / scanner tier={scan_tier}: enriched in the "
              f"authorized-canonical population (11 of ~130) but NOT impossible -- "
              f"COMPLETED-C witnesses func_80037540 and "
              f"replay_camera_rob_back_loose3 both carry one. Pure-C distance "
              f"{q['distance']}. Needs a manual .s read before routing.")
    elif len(weak) >= 2:
        tier, bucket = "WEAK", "uncertain"
        ev = (f"No GCC-impossible construct; corroborating-only signals "
              f"({'; '.join(weak)}) at pure-C distance {q['distance']}. "
              f"Manual review recommended, but the prior is compiler-emitted.")
    elif gte_reasons:
        tier, bucket = "NONE", "compiler-emitted"
        ev = (f"Ordinary C body with a small authorized GTE region "
              f"({g.get('asm_insns')}/{g.get('total')} insns, {gte_frac:.0%}); zero "
              f"hand-coded signal outside it. Real decomp target -- grind the C, "
              f"inline-asm only the cop2 span.")
    else:
        tier, bucket = "NONE", "compiler-emitted"
        ev = (f"Zero definitive gate signals, zero S1/S2/S6/S7/S8, scanner "
              f"tier={scan_tier}. The ASM-SUSPECT verdict here is distance-only "
              f"(pure-C distance {q['distance']} > 50), which engine/canonical.py "
              f"itself documents as NOT hand-asm evidence. Real decomp target.")

    rows.append({
        "name": name, "verdict": q["verdict"], "distance": q["distance"],
        "rules": q["rules"], "file": q["file"], "insns": insns,
        "scan_tier": scan_tier, "gate_reasons": reasons,
        "signals": decisive + weak, "noise_signals": noise,
        "tier": tier, "recommendation": bucket, "evidence": ev,
    })

rows.sort(key=lambda r: ({"STRONG": 0, "WEAK": 1, "NONE": 2}[r["tier"]], -r["distance"]))
json.dump(rows, open(ROOT / "tmp" / "census_2026-08-06.json", "w"), indent=1)
print(Counter(r["recommendation"] for r in rows))
print(Counter((r["verdict"], r["recommendation"]) for r in rows))
print()
for r in rows:
    if r["recommendation"] != "compiler-emitted":
        print(f'{r["tier"]:6} {r["recommendation"]:19} {r["name"]:32} d={r["distance"]:5} '
              f'n={r["insns"]:4} rules={r["rules"]:2} {r["verdict"]:12} {r["signals"]}')
