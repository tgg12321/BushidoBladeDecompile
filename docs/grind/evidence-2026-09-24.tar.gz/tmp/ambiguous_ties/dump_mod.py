import sys, os, struct
REPO=os.path.abspath(os.path.join(os.path.dirname(__file__),'..','..'))
sys.path.insert(0, os.path.join(REPO,'tmp','closer'))
from psyq_lib import lib_modules, parse_obj
libdir=os.path.join(REPO,'tmp','libscan','psyq40')
for spec in sys.argv[1:]:
    lib,mod=spec.split('/')
    for mn,od in lib_modules(open(os.path.join(libdir,lib+'.LIB'),'rb').read()):
        if mn!=mod: continue
        o=parse_obj(od)
        print(f"=== {lib}/{mod} ===")
        print("  xdefs:", o.xdefs)
        secs={sid:s['name'] for sid,s in o.sections.items()}
        print("  sections:", {k:(v,len(o.sections[k]['bytes'])) for k,v in secs.items()})
        tsid=[k for k,v in secs.items() if v=='.text'][0]
        for rsec,t,roff,e in o.relocs:
            if rsec==tsid: print(f"   reloc @0x{roff:04x} type={t} expr={e}")
        print("  all xrefs:", o.xrefs)
