#!/usr/bin/env python3
"""Do the hardcoded labels in the two exposed rules actually EXIST in the stream,
and where? Definition vs reference, and in whose function block."""
import re
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "tools"))
from probe_func_labels import stream_before_asmfix

CASES = {"main": [".L761", ".L762", ".L764"], "code6cac_b": [".L631"]}
FUNC_START = re.compile(r'(?m)^([A-Za-z_]\w*):\s*$')


def owner_at(text, pos):
    last = None
    for m in FUNC_START.finditer(text):
        if m.start() > pos:
            break
        last = m.group(1)
    return last


for stem, labels in CASES.items():
    print(f"########## src/{stem}.c ##########")
    text = stream_before_asmfix(stem)
    for lab in labels:
        defs = [m.start() for m in
                re.finditer(rf'(?m)^\s*{re.escape(lab)}:\s*$', text)]
        refs = [m.start() for m in
                re.finditer(rf'{re.escape(lab)}(?![0-9A-Za-z_])', text)
                if m.start() not in defs]
        print(f"  {lab}: {len(defs)} definition(s), {len(refs)} total occurrence(s)")
        for d in defs:
            print(f"      DEFINED in function block: {owner_at(text, d)}")
        seen = set()
        for r in refs:
            o = owner_at(text, r)
            if o not in seen:
                seen.add(o)
                print(f"      referenced in: {o}")
        if not defs and not refs:
            print(f"      *** ABSENT from the stream entirely ***")
    print()

# Does the SetPacketData rule PATTERN match anything?
print("########## do the SetPacketData replace_first patterns match? ##########")
text = stream_before_asmfix("main")
for pat in (r'^beq\t\$2,\$0,\.L761$', r'^beq\t\$20,\$0,\.L764$'):
    n = len(re.findall(pat, text, re.MULTILINE))
    print(f"  {pat!r}: {n} match(es){'   <-- DEAD RULE (no-op)' if n == 0 else ''}")
