#!/usr/bin/env python3
import re, glob, os, subprocess
os.chdir("/mnt/c/Users/Trenton/Desktop/Bushido Blade 2 Decompile")

files = glob.glob('asm/**/*.s', recursive=True)
print("### files matching cpu_set_move_command_and_dir_for_no_action*:")
for f in files:
    if 'cpu_set_move_command_and_dir_for_no_action' in f:
        print("  ", f)

print("\n### SITE C target window (function cpu_set_move_command_and_dir_for_no_action_2)")
for f in files:
    txt = open(f, errors='replace').read().splitlines()
    for i, l in enumerate(txt):
        if re.search(r'glabel\s+cpu_set_move_command_and_dir_for_no_action_2\b', l):
            print(f"  found in {f}:{i+1}")
            for j in range(i, min(len(txt), i+400)):
                if re.search(r'\bsll\b.*\b8\s*$', txt[j]):
                    print("  --- window:")
                    for k in range(max(0,j-6), min(len(txt), j+5)):
                        print("   ", txt[k])
                    break

print("\n### SITE B: (sll d,s,2 ; addu/or d,d,s) pairs anywhere in asm/")
sll = re.compile(r'\bsll\s+\$(\w+), \$(\w+), (?:0x2|2)\s*$')
hits = 0
for f in files:
    lines = open(f, errors='replace').read().splitlines()
    for i in range(len(lines)-1):
        m = sll.search(lines[i])
        if not m: continue
        d, s = m.groups()
        if re.search(rf'\b(addu|or)\s+\${d}, \${d}, \${s}\s*$', lines[i+1]):
            print(f"  {f}:{i+1}\n     {lines[i].strip()}\n     {lines[i+1].strip()}")
            hits += 1
print(f"  total: {hits}")
