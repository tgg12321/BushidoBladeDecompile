#!/usr/bin/env python3
"""Deliverables 2 + 3 — Wave 5 substantial stubs and non-.text emitters.

For each: the mechanical classification, the body verbatim for hand-reading, and
(for the non-.text emitters) what the DISCARDED body actually contributes to the
object today, measured from a real per-TU build rather than assumed.
"""
import json
import re
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "tools"))
from engine import inlineasm

MAP = json.load(open("tmp/resplit_map.json"))
WAVE = int(sys.argv[1]) if len(sys.argv) > 1 else 5

subs, nontext = [], []
for stem, t in MAP["tus"].items():
    if t.get("wave") != WAVE:
        continue
    for f in t["funcs"]:
        if f["stub_class"] != "empty":
            subs.append((stem, f))
        if f["emits_non_text"]:
            nontext.append((stem, f))


def body_of(stem, func):
    text = Path(f"src/{stem}.c").read_text(encoding="utf-8")
    sp = inlineasm._func_body_span(text, func)
    return text[sp[0]:sp[1]] if sp else None


def classify(body):
    code = inlineasm._code_without_comments_and_strings(body)
    lines = [l.strip() for l in code.split("{", 1)[-1].splitlines() if l.strip()]
    meat = []
    for l in lines:
        for part in (p.strip() for p in l.split(";")):
            if part and not re.fullmatch(r'\(void\)\s*\w+|return\s+[-\w]*|\}', part):
                meat.append(part)
    return ("GENUINE DRAFT" if meat else "PLACEHOLDER"), meat


print(f"########## DELIVERABLE 2 — wave {WAVE} substantial stubs "
      f"({len(subs)}) ##########\n")
for stem, f in subs:
    body = body_of(stem, f["func"])
    verdict, meat = classify(body)
    print(f"--- {f['func']:28s} (src/{stem}.c, {f['stub_body_lines']:>3}L)  ->  {verdict}"
          f"   [{len(meat)} surviving statement(s)]")
    if meat:
        print(f"    first: {meat[:5]}")
    Path("tmp/w5_bodies").mkdir(exist_ok=True)
    Path(f"tmp/w5_bodies/{f['func']}.c").write_text(body, encoding="utf-8")

print(f"\n########## DELIVERABLE 3 — wave {WAVE} non-.text emitters "
      f"({len(nontext)}) ##########\n")
for stem, f in nontext:
    func = f["func"]
    body = body_of(stem, func)
    verdict, _ = classify(body)
    print(f"--- {func}  (src/{stem}.c)  stub={verdict}, {len(body.splitlines())} lines")
    Path("tmp/w5_bodies").mkdir(exist_ok=True)
    Path(f"tmp/w5_bodies/{func}.c").write_text(body, encoding="utf-8")
    # what NON-.text does the CURRENT (discarded) body actually emit?
    lits = re.findall(r'"(?:[^"\\]|\\.)*"', body)
    sw = re.findall(r'\bswitch\s*\(', body)
    print(f"    discarded body emits: {len(lits)} string literal(s), "
          f"{len(sw)} switch statement(s)")
    for s in lits[:6]:
        print(f"        {s[:70]}")
    # what does the asm file itself carry beyond .text?
    p = Path(f"asm/funcs/{func}.s")
    if p.exists():
        directives = sorted(set(re.findall(r'(?m)^\s*(\.[a-z0-9_]+)', p.read_text(encoding="utf-8"))))
        print(f"    asm/funcs/{func}.s directives: {directives}")
    print()
