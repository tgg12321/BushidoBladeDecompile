$ErrorActionPreference = 'Continue'
Set-Location "C:\Users\Trenton\Desktop\Bushido Blade 2 Decompile"

function Restore { git checkout -- src/code6cac_b.c maspsx_label_nop_funcs.txt | Out-Null }

"##### func_80027640: gate-list entry + final body #####"
Add-Content -Path maspsx_label_nop_funcs.txt -Value "func_80027640" -NoNewline
# ensure LF + trailing newline
$raw = [IO.File]::ReadAllText("maspsx_label_nop_funcs.txt").Replace("`r`n","`n")
if (-not $raw.EndsWith("`n")) { $raw += "`n" }
[IO.File]::WriteAllText("maspsx_label_nop_funcs.txt", $raw, (New-Object Text.UTF8Encoding $false))
python tmp/foreclosed/apply.py func_80027640 tmp/foreclosed/func_80027640_body.c
& tools/wteng.ps1 main build 2>&1 | Select-Object -Last 6
Restore
git status --short

"##### func_80030580: pad body, NO engine row #####"
python tmp/foreclosed/apply.py func_80030580 tmp/foreclosed/func_80030580_body.c
& tools/wteng.ps1 main build 2>&1 | Select-Object -Last 6
Restore
git status --short
