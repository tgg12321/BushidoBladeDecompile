#!/bin/bash
# PROOF: does deleting combine.c's PLUS->IOR transform reproduce the shipped cc1?
# Operates ONLY on the scratch copy tmp/cc1recipe. tools/gcc-2.7.2 is NEVER touched.
set -uo pipefail
R="/mnt/c/Users/Trenton/Desktop/Bushido Blade 2 Decompile"
cd "$R"
S=tmp/cc1recipe
[ -d "$S" ] || { echo "scratch tree missing"; exit 1; }
[ "$(readlink -f $S)" != "$(readlink -f tools/gcc-2.7.2)" ] || { echo "REFUSING: scratch == live tree"; exit 1; }

cp $S/combine.c tmp/fx/combine.c.orig
python3 - <<'PY'
p = "tmp/cc1recipe/combine.c"
s = open(p).read()
block = """      /* If we are adding two things that have no bits in common, convert
	 the addition into an IOR.  This will often be further simplified,
	 for example in cases like ((a & 1) + (a & 2)), which can
	 become a & 3.  */

      if (GET_MODE_BITSIZE (mode) <= HOST_BITS_PER_WIDE_INT
	  && (nonzero_bits (XEXP (x, 0), mode)
	      & nonzero_bits (XEXP (x, 1), mode)) == 0)
	return gen_binary (IOR, mode, XEXP (x, 0), XEXP (x, 1));
      break;
"""
assert block in s, "anchor not found"
s = s.replace(block, "      break;\n", 1)
open(p, "w").write(s)
print("patched: PLUS->IOR conversion removed from the scratch combine.c")
PY

( cd $S
  rm -f combine.o cc1
  TMPDIR=/dev/shm make combine.o CFLAGS="-O -g -fgnu89-inline" >/dev/null 2>&1
  TMPDIR=/dev/shm make cc1 CFLAGS="-g -fgnu89-inline" >/dev/null 2>&1 )
cp tmp/fx/combine.c.orig $S/combine.c   # restore scratch source immediately
[ -f $S/cc1 ] || { echo "BUILD FAILED"; exit 1; }
cp $S/cc1 tmp/fx/cc1.noplusior

echo "simplify_rtx size:"
for t in "tools/gcc-2.7.2/build/cc1 SHIPPED" "tmp/fx/cc1.noplusior PATCHED" "tmp/ab/cc1.mixed STOCK"; do
  set -- $t
  printf "  %-8s %s\n" "$2" "$(nm --defined-only -S $1 2>/dev/null | awk '$4=="simplify_rtx"{print $2}')"
done

F="-O2 -G0 -funsigned-char -quiet -mcpu=3000 -mips1 -mno-abicalls -fno-builtin -w -mel"
FG8="-O2 -G8 -funsigned-char -quiet -mcpu=3000 -mips1 -mno-abicalls -fno-builtin -w -mel"
CPP="mipsel-linux-gnu-cpp -Iinclude -undef -Wall -lang-c -fno-builtin -Dmips -D__GNUC__=2 -D__OPTIMIZE__ -D__mips__ -D__mips -Dpsx -D__psx__ -D__psx -D_PSYQ -D__EXTENSIONS__ -D_MIPSEL -D_LANGUAGE_C -DLANGUAGE_C"
n=0; bad=""
for stem in $(ls src/*.c | sed 's|src/||; s|\.c$||'); do
  $CPP src/$stem.c > tmp/fx/p.i 2>/dev/null
  case "$stem" in text1a_pre|text1a_post) FL="$FG8";; *) FL="$F";; esac
  tmp/fx/cc1.noplusior      $FL tmp/fx/p.i -o tmp/fx/p1.s 2>/dev/null
  tools/gcc-2.7.2/build/cc1 $FL tmp/fx/p.i -o tmp/fx/p2.s 2>/dev/null
  n=$((n+1))
  cmp -s tmp/fx/p1.s tmp/fx/p2.s || bad="$bad $stem"
done
echo
echo "patched-cc1 vs SHIPPED over $n TUs:${bad:+ DIFFER:$bad}"
[ -z "$bad" ] && echo "*** CONFIRMED: removing combine.c's PLUS->IOR conversion reproduces the shipped compiler's behaviour on all $n TUs. ***"
