#!/usr/bin/env python3
"""Batch-2: address-ordered neighbourhood map around the candidate functions.

If a candidate sits inside a contiguous run of already-authorized canonical
functions, that is cluster evidence the original build had a hand-written .s
object there.
"""
import json
import os
import re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FUNCS = os.path.join(ROOT, "asm", "funcs")
ADDR = re.compile(r"^\s*/\*\s*[0-9A-Fa-f]+\s+([0-9A-Fa-f]{8})\s", re.M)


def load_names(path):
    names = set()
    for line in open(path, encoding="utf-8", errors="replace"):
        line = line.split("#")[0].strip()
        if line:
            names.add(line.split()[0])
    return names


canon = load_names(os.path.join(ROOT, "inline_asm_canonical.txt"))
q = json.load(open(os.path.join(ROOT, "engine", "queue.json"), encoding="utf-8"))
items = q if isinstance(q, list) else q.get("items", q.get("queue", []))
queued = {it["func"] for it in items}

rows = []
for fn in sorted(os.listdir(FUNCS)):
    if not fn.endswith(".s"):
        continue
    name = fn[:-2]
    txt = open(os.path.join(FUNCS, fn), encoding="utf-8", errors="replace").read()
    m = ADDR.search(txt)
    if not m:
        continue
    rows.append((int(m.group(1), 16), name, len(ADDR.findall(txt))))
rows.sort()

targets = {"func_8004C388", "func_80052788", "func_80052930",
           "game_2d_CheckLifeGaugeNoDisp", "func_80052A88", "func_80052B7C",
           "ang_hosei"}

idx = {n: i for i, (_, n, _) in enumerate(rows)}
for t in sorted(targets, key=lambda n: idx.get(n, 1 << 30)):
    i = idx.get(t)
    if i is None:
        continue
    print(f"--- neighbourhood of {t} ---")
    for j in range(max(0, i - 4), min(len(rows), i + 5)):
        a, n, k = rows[j]
        tag = "CANON " if n in canon else ("QUEUE " if n in queued else "DONE-C")
        mark = " <<<" if j == i else ""
        print(f"   0x{a:08X} {tag} {n:44s} {k:5d}i{mark}")
    print()

# contiguous canonical run containing each target's address band
print("=== canonical-density in 0x8004A000-0x80053000 ===")
band = [r for r in rows if 0x8004A000 <= r[0] < 0x80053000]
nc = sum(1 for a, n, k in band if n in canon)
print(f"   {nc} of {len(band)} functions in the band are authorized canonical")
for a, n, k in band:
    tag = "CANON " if n in canon else ("QUEUE " if n in queued else "DONE-C")
    if tag != "CANON ":
        print(f"   NON-CANON: 0x{a:08X} {tag} {n} ({k}i)")
