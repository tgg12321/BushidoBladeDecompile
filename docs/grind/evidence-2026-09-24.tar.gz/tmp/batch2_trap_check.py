#!/usr/bin/env python3
"""Batch-2 verification: is trapping add/addi/sub GCC-2.7.2-impossible in this corpus?

Partitions asm/funcs/*.s into (a) authorized canonical, (b) still-queued,
(c) everything else == COMPLETED-C, and counts trapping-arith occurrences in each.
A single hit in (c) would kill the 'GCC-impossible' claim for func_8004C388 /
func_80052788 / ang_hosei.
"""
import json
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FUNCS = os.path.join(ROOT, "asm", "funcs")

TRAP = re.compile(r"^\s*/\*.*?\*/\s+(add|addi|sub|neg)\s+", re.M)
COP2 = re.compile(r"^\s*/\*.*?\*/\s+(ctc2|cfc2|mtc2|mfc2|lwc2|swc2|mvmva|rtps|rtpt|nclip|avsz3|avsz4|gpf|gpl|op|dpcs|intpl|sqr|ncds|nccs|ncs|nct|dcpl|dpct|cc|cdp)\b", re.M)
BREAK = re.compile(r"^\s*/\*.*?\*/\s+break\s+0,\s*(\d+)", re.M)


def load_names(path):
    names = set()
    if not os.path.exists(path):
        return names
    for line in open(path, encoding="utf-8", errors="replace"):
        line = line.split("#")[0].strip()
        if line:
            names.add(line.split()[0])
    return names


canon = load_names(os.path.join(ROOT, "inline_asm_canonical.txt"))
q = json.load(open(os.path.join(ROOT, "engine", "queue.json"), encoding="utf-8"))
items = q if isinstance(q, list) else q.get("items", q.get("queue", []))
queued = {it["func"] for it in items}

buckets = {"canonical": [], "queued": [], "completed": []}
for fn in sorted(os.listdir(FUNCS)):
    if not fn.endswith(".s"):
        continue
    name = fn[:-2]
    txt = open(os.path.join(FUNCS, fn), encoding="utf-8", errors="replace").read()
    hits = TRAP.findall(txt)
    if not hits:
        continue
    b = "canonical" if name in canon else ("queued" if name in queued else "completed")
    buckets[b].append((name, len(hits), sorted(set(hits))))

for b in ("canonical", "queued", "completed"):
    print(f"=== {b}: {len(buckets[b])} function(s) with trapping arith ===")
    for name, n, kinds in buckets[b]:
        print(f"   {name:44s} {n:3d}  {','.join(kinds)}")
    print()

# break-code census: which codes appear, and where
print("=== non-div-guard break codes (code != 6 and != 7) ===")
for fn in sorted(os.listdir(FUNCS)):
    if not fn.endswith(".s"):
        continue
    name = fn[:-2]
    txt = open(os.path.join(FUNCS, fn), encoding="utf-8", errors="replace").read()
    codes = [c for c in BREAK.findall(txt) if c not in ("6", "7")]
    if codes:
        b = "CANON" if name in canon else ("QUEUED" if name in queued else "COMPLETED-C")
        print(f"   {name:44s} {b:12s} codes={sorted(set(codes))}")
