#!/usr/bin/env python3
"""Campaign 4 scoping: map asmfix replace_with_asmfile funcs -> TU -> split topology.

Method: every emitted function has asm/funcs/<name>.s (1437 files) carrying its
VRAM address in the first instruction comment. TU membership is derived by
locating each name's DEFINITION site in src/*.c (a `name(` occurrence whose line
is not a call/decl). Within a TU, cc1 emits functions in source order, and
bb2.ld pins object order, so address order == source order (asserted per TU).
"""
import json, re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

# ---- asmfix ---------------------------------------------------------------
asmfix_lines = (ROOT / "asmfix.txt").read_text(encoding="utf-8").splitlines()
asmfile_funcs, other_rules = {}, {}
for ln, raw in enumerate(asmfix_lines, 1):
    s = raw.strip()
    if not s or s.startswith("#"):
        continue
    m = re.match(r'(\w+)\s*:\s*replace_with_asmfile\s+"([^"]+)"$', s)
    if m:
        asmfile_funcs[m.group(1)] = m.group(2)
        continue
    m = re.match(r'(\w+)\s*:\s*(\w+)', s)
    if m:
        other_rules.setdefault(m.group(1), []).append({"line": ln, "op": m.group(2), "text": s[:160]})

# ---- addresses ------------------------------------------------------------
ADDR_RE = re.compile(r'^\s*/\*\s*[0-9A-Fa-f]+\s+([0-9A-Fa-f]{8})\s')
addr, size = {}, {}
for p in sorted((ROOT / "asm" / "funcs").glob("*.s")):
    n = 0; a = None
    for line in p.read_text(encoding="utf-8", errors="replace").splitlines():
        m = ADDR_RE.match(line)
        if m:
            n += 1
            if a is None:
                a = int(m.group(1), 16)
    if a is not None:
        addr[p.stem] = a
        size[p.stem] = n * 4

# ---- TU membership --------------------------------------------------------
ld = (ROOT / "bb2.ld").read_text(encoding="utf-8")
ld_text_order = re.findall(r'build/src/(\w+)\.o\(\.text\)',
                           ld.split("main_TEXT_START")[1].split("main_TEXT_END")[0])
ld_rodata_order = re.findall(r'build/src/(\w+)\.o\(\.rodata\)',
                             ld.split("main_RODATA_START")[1].split("main_RODATA_END")[0])

srcs = {stem: (ROOT / "src" / f"{stem}.c").read_text(encoding="utf-8", errors="replace")
        for stem in ld_text_order if (ROOT / "src" / f"{stem}.c").exists()}

# A definition site: `NAME (` preceded on the same line only by type tokens
# starting at column 0, and the logical statement ends with `{` not `;`.
def def_sites(text, name):
    out = []
    for m in re.finditer(r'(?m)^([A-Za-z_][\w \t\*]*?)\b' + re.escape(name) + r'\s*\(', text):
        head = m.group(1)
        if re.match(r'\s', head) or 'return' in head or 'extern' in head:
            continue
        # find matching close paren then require '{'
        i = text.index('(', m.end() - 1)
        depth, j = 0, i
        while j < len(text):
            if text[j] == '(':
                depth += 1
            elif text[j] == ')':
                depth -= 1
                if depth == 0:
                    break
            j += 1
        tail = text[j + 1:j + 200].lstrip()
        if tail.startswith('{'):
            out.append(m.start())
    return out

# 3 asm/funcs/*.s are HAND-AUTHORED canonical bodies (no splat address comments):
# func_80052BE4 / func_80052CD4 (text1b) and save_vc_ctrl (text1a). Recover their
# addresses from the func_ name where possible; save_vc_ctrl is interpolated from
# source position below.
for name in set(asmfile_funcs) - set(addr):
    m = re.fullmatch(r'func_(80[0-9A-Fa-f]{6})', name)
    if m:
        addr[name] = int(m.group(1), 16)
        size[name] = 4 * sum(1 for l in (ROOT / "asm" / "funcs" / f"{name}.s")
                             .read_text(encoding="utf-8").splitlines()
                             if l.strip() and not l.strip().startswith(('.', 'glabel', '/*')))
    else:
        addr[name] = None          # interpolated after TU mapping
        size[name] = None

func_tu, tu_members = {}, {s: [] for s in srcs}
ambiguous = []
for name in addr:
    hits = [(stem, off) for stem, txt in srcs.items() for off in def_sites(txt, name)]
    if len(hits) == 1:
        stem, off = hits[0]
        func_tu[name] = stem
        tu_members[stem].append({"name": name, "addr": addr[name], "size": size[name],
                                 "off": off, "asm": name in asmfile_funcs})
    elif len(hits) > 1:
        ambiguous.append({"func": name, "files": sorted({h[0] for h in hits})})

missing_asm = sorted(set(asmfile_funcs) - set(func_tu))

# interpolate addresses for any address-less member from its source neighbours
for stem, members in tu_members.items():
    members.sort(key=lambda d: d["off"])
    for i, d in enumerate(members):
        if d["addr"] is None:
            prev = next((m["addr"] for m in reversed(members[:i]) if m["addr"]), None)
            nxt = next((m["addr"] for m in members[i + 1:] if m["addr"]), None)
            d["addr"] = (prev + 4) if prev else (nxt - 4)
            d["addr_interpolated"] = True

# ---- canonical-asm authorization cross-check ------------------------------
canon = set()
for line in (ROOT / "inline_asm_canonical.txt").read_text(encoding="utf-8").splitlines():
    s = line.strip()
    if s and not s.startswith("#"):
        canon.add(s.split()[0].split("#")[0].strip())

# ---- rule scans -----------------------------------------------------------
regfix_lines = (ROOT / "regfix.txt").read_text(encoding="utf-8").splitlines()
# Trailing boundary is load-bearing (erratum 1f8346c2, 2026-08-06). Without it
# this matched the DIGIT PREFIX of address-form labels — `.L80070D7C` matched as
# `.L80070`, `.L8003EBA0` as `.L8003` — so every self-defined address label in an
# asmfix payload was counted as a hardcoded cc1-label reference. That produced
# the false R1 "4 drift-exposed rules" table; all four were already drift-robust.
HARD_L = re.compile(r'(?<!\{lbl)\.L\d+(?![0-9A-Za-z_])')

def scan(lines):
    counts, hard = {}, {}
    for raw in lines:
        s = raw.strip()
        if not s or s.startswith('#'):
            continue
        m = re.match(r'(\w+)\s*:', s)
        if not m:
            continue
        f = m.group(1)
        counts[f] = counts.get(f, 0) + 1
        if HARD_L.search(s):
            hard[f] = hard.get(f, 0) + 1
    return counts, hard

regfix_counts, regfix_hard = scan(regfix_lines)
asmfix_counts, asmfix_hard = scan(asmfix_lines)

GP_FILES = {"text1a"}
EXPAND_LB = {"code6cac_b"}
RODATA_ALIGN2 = set("code6cac code6cac_b code6cac_c code6cac_c0 code6cac_c_ab "
                    "code6cac_c2 text1a text1a_b text1a_c text1a_c2 text1b_b main".split())

result = {"generated_by": "tmp/resplit_scope.py", "tus": {},
          "ld_text_order": ld_text_order, "ld_rodata_order": ld_rodata_order,
          "ambiguous_defs": ambiguous, "asm_funcs_without_tu": missing_asm,
          "non_resplit_asmfix_funcs": {k: v for k, v in other_rules.items()
                                       if k not in asmfile_funcs}}

for stem, members in tu_members.items():
    if not members:
        continue
    by_addr = sorted(members, key=lambda d: d["addr"])
    by_src = sorted(members, key=lambda d: d["off"])
    order_ok = [d["name"] for d in by_addr] == [d["name"] for d in by_src]
    runs, cur = [], None
    for d in by_addr:
        kind = "asm" if d["asm"] else "c"
        if cur is None or cur["kind"] != kind:
            cur = {"kind": kind, "funcs": [], "start": d["addr"]}
            runs.append(cur)
        cur["funcs"].append(d["name"])
    asm_runs = [r for r in runs if r["kind"] == "asm"]
    c_runs = [r for r in runs if r["kind"] == "c"]
    n_asm = sum(1 for d in members if d["asm"])
    txt = srcs[stem]
    asm_names = [d["name"] for d in by_addr if d["asm"]]
    sib_names = [d["name"] for d in by_addr if not d["asm"]]
    result["tus"][stem] = {
        "src": f"src/{stem}.c",
        "src_lines": txt.count("\n") + 1,
        "total_funcs": len(members),
        "asm_funcs": n_asm,
        "c_funcs": len(members) - n_asm,
        "src_order_matches_addr_order": order_ok,
        "asm_runs": len(asm_runs),
        "c_fragments_needed": len(c_runs),
        "new_objects": len(asm_runs) + len(c_runs),
        "runs": [{"kind": r["kind"], "n": len(r["funcs"]), "start": f"0x{r['start']:08X}",
                  "funcs": r["funcs"] if (r["kind"] == "asm" or len(r["funcs"]) <= 8)
                           else r["funcs"][:4] + [f"...{len(r['funcs'])-6} more..."] + r["funcs"][-2:]}
                 for r in runs],
        "gp_file_G8": stem in GP_FILES,
        "expand_lb_file": stem in EXPAND_LB,
        "rodata_align2_file": stem in RODATA_ALIGN2,
        "has_rodata_slot": stem in ld_rodata_order,
        "n_static_decls": len(re.findall(r'(?m)^\s*static\b', txt)),
        "n_file_scope_defs": len(re.findall(r'(?m)^(?!extern|static|typedef)[A-Za-z_][\w \t\*]*\w\s*(\[[^\]]*\])*\s*=', txt)),
        "asm_funcs_canonical_authorized": sorted(n for n in asm_names if n in canon),
        "asm_funcs_NOT_authorized": sorted(n for n in asm_names if n not in canon),
        "asm_funcs_with_extra_asmfix_rules": sorted(n for n in asm_names if asmfix_counts.get(n, 0) > 1),
        "asm_funcs_with_regfix_rules": {n: regfix_counts[n] for n in asm_names if n in regfix_counts},
        "sibling_c_hardcoded_L_rules": {n: regfix_hard.get(n, 0) + asmfix_hard.get(n, 0)
                                        for n in sib_names
                                        if regfix_hard.get(n) or asmfix_hard.get(n)},
        "sibling_c_regfix_total": sum(regfix_counts.get(n, 0) for n in sib_names),
        "asm_run_details": [{"start": f"0x{r['start']:08X}", "funcs": r["funcs"]} for r in asm_runs],
    }

active = {k: v for k, v in result["tus"].items() if v["asm_funcs"]}
result["summary"] = {
    "replace_with_asmfile_rules": len(asmfile_funcs),
    "other_asmfix_rules_funcs": len(result["non_resplit_asmfix_funcs"]),
    "other_asmfix_rule_lines": sum(len(v) for v in result["non_resplit_asmfix_funcs"].values()),
    "tus_in_scope": len(active),
    "total_asm_runs_split_points": sum(v["asm_runs"] for v in active.values()),
    "total_c_fragments": sum(v["c_fragments_needed"] for v in active.values()),
    "total_new_objects": sum(v["new_objects"] for v in active.values()),
    "asm_funcs_mapped": sum(v["asm_funcs"] for v in active.values()),
    "asm_funcs_unmapped": len(missing_asm),
    "canonical_authorized": sum(len(v["asm_funcs_canonical_authorized"]) for v in active.values()),
    "not_canonical_authorized": sum(len(v["asm_funcs_NOT_authorized"]) for v in active.values()),
}

(ROOT / "tmp" / "resplit_map.json").write_text(json.dumps(result, indent=2) + "\n",
                                               encoding="utf-8", newline="\n")
print(json.dumps(result["summary"], indent=2))
print("unmapped:", missing_asm)
print("ambiguous:", [a["func"] for a in ambiguous][:20], len(ambiguous))
print()
hdr = f'{"TU":26s}{"asm":>4}{"C":>5}{"runs":>6}{"frag":>6}{"objs":>6}{"auth":>6}{"unauth":>7}{"sibHardL":>9}{"sibRegfix":>10}  flags'
print(hdr)
for stem, v in sorted(active.items(), key=lambda kv: (kv[1]["asm_runs"], kv[1]["asm_funcs"])):
    flags = ",".join(f for f, c in (("G8", v["gp_file_G8"]), ("lb", v["expand_lb_file"]),
                                    ("al2", v["rodata_align2_file"]),
                                    ("ORDER!", not v["src_order_matches_addr_order"])) if c)
    print(f'{stem:26s}{v["asm_funcs"]:>4}{v["c_funcs"]:>5}{v["asm_runs"]:>6}{v["c_fragments_needed"]:>6}'
          f'{v["new_objects"]:>6}{len(v["asm_funcs_canonical_authorized"]):>6}'
          f'{len(v["asm_funcs_NOT_authorized"]):>7}{len(v["sibling_c_hardcoded_L_rules"]):>9}'
          f'{v["sibling_c_regfix_total"]:>10}  {flags}')
