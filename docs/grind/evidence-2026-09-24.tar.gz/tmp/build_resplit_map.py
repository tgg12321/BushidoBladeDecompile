#!/usr/bin/env python3
"""Merge the TU topology scan + stub-body risk scan into the final
tmp/resplit_map.json execution map for the Campaign-4 asmfix-to-zero project."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
topo = json.loads((ROOT / "tmp" / "resplit_map.json").read_text(encoding="utf-8"))
risk = json.loads((ROOT / "tmp" / "stub_risk.json").read_text(encoding="utf-8"))
byfunc = {r["func"]: r for r in risk["per_func"]}

GP_FILES = {"text1a"}

WAVES = {
    "ings2": 1, "ings": 2, "config": 2, "code6cac_c_mid": 2,
    "code6cac_b2_post": 3, "text1b_b": 3, "system": 3, "code6cac_c2": 3,
    "text1a_c": 4, "display": 4,
    "main": 5, "code6cac": 5, "code6cac_b": 5,
    "text1b": 6,
    "text1a": 7,
}

out = {
    "campaign": "2026-08-06 asmfix-to-zero (Campaign 4)",
    "owner_ruling": "docs/grind/decisions.md, 2026-08-06 entry",
    "measured_facts": {
        "file_scope_asm_G0_stays_in_source_position": True,
        "file_scope_asm_G8_floats_to_text_offset_0": True,
        "probe": "tmp/probe/run.sh (cc1 -G0 vs -G8 emission order), tmp/probe/run2.sh (full pipeline + as)",
        "in_tree_precedent_G0": "src/ings2.c:577 and :595 — file-scope __asm__ glabel blocks for "
                               "func_80083698 / md_gview_init sit mid-file between C functions in the "
                               "shipped byte-matching build",
        "asm_funcs_files": 1437,
        "asm_funcs_files_missing_endlabel": 4,
        "regfix_rules_on_replace_with_asmfile_funcs": 0,
    },
    "routes": {
        "include-asm-in-place": "Delete the discarded C stub, put INCLUDE_ASM(\"asm/funcs\", <fn>) at "
                                "that exact source position, add an extern prototype for in-file "
                                "callers, delete the asmfix line. No bb2.ld change, no new object, "
                                "no TU split. Valid for every -G0 TU.",
        "tu-resplit": "Only for -G8 TUs (text1a): split the .c into _pre/_post around the function, "
                      "assemble asm/funcs/<fn>.s as its own object, insert it between the fragments "
                      "in all four bb2.ld sections.",
    },
    "summary": dict(topo["summary"]),
    "tus": {},
    "tier1_not_in_scope": topo["non_resplit_asmfix_funcs"],
    "ld_text_order": topo["ld_text_order"],
    "ld_rodata_order": topo["ld_rodata_order"],
}

def _order(v):
    o = []
    for r in v["runs"]:
        o += [f for f in r["funcs"] if not f.startswith("...")]
    return o


for stem, v in topo["tus"].items():
    if not v["asm_funcs"]:
        continue
    g8 = stem in GP_FILES
    funcs = []
    for run in v["asm_run_details"]:
        for fn in run["funcs"]:
            r = byfunc.get(fn, {})
            funcs.append({
                "func": fn,
                "asm_file": f"asm/funcs/{fn}.s",
                "addr": run["start"] if len(run["funcs"]) == 1 else None,
                "canonical_authorized": fn in v["asm_funcs_canonical_authorized"],
                "stub_body_lines": r.get("body_lines"),
                "stub_class": "empty" if (r.get("body_lines") or 0) <= 3 else "substantial",
                "emits_non_text": bool(r.get("switch") or r.get("string_literal")
                                       or r.get("fp_literal") or r.get("static_local")),
                "extra_asmfix_rules": fn in v["asm_funcs_with_extra_asmfix_rules"],
            })
    out["tus"][stem] = {
        "src": v["src"],
        "route": "tu-resplit" if g8 else "include-asm-in-place",
        "wave": WAVES.get(stem),
        "G8": g8,
        "expand_lb_file": v["expand_lb_file"],
        "rodata_align2_file": v["rodata_align2_file"],
        "has_rodata_slot_in_ld": v["has_rodata_slot"],
        "asm_funcs": v["asm_funcs"],
        "c_funcs": v["c_funcs"],
        "canonical_authorized": len(v["asm_funcs_canonical_authorized"]),
        "not_authorized": len(v["asm_funcs_NOT_authorized"]),
        "substantial_stubs": [f["func"] for f in funcs if f["stub_class"] == "substantial"],
        "non_text_emitting_stubs": [f["func"] for f in funcs if f["emits_non_text"]],
        "sibling_hardcoded_L_rules": v["sibling_c_hardcoded_L_rules"],
        # Order-aware: a substantial stub only drifts a hardcoded-.L rule that sits
        # AFTER it in the TU (cc1's .L counter is file-global and monotonic).
        "label_drift_exposure": sorted({
            h for h in v["sibling_c_hardcoded_L_rules"]
            if h in _order(v) and any(
                f["stub_class"] == "substantial" and f["func"] in _order(v)
                and _order(v).index(f["func"]) < _order(v).index(h) for f in funcs)}),
        # topology retained for the tu-resplit route (and as an audit of address adjacency)
        "asm_runs_if_resplit": v["asm_runs"],
        "c_fragments_if_resplit": v["c_fragments_needed"],
        "new_objects_if_resplit": v["new_objects"],
        "runs": v["runs"],
        "funcs": funcs,
    }

active = out["tus"]
out["summary"]["route_include_asm_in_place_funcs"] = sum(
    v["asm_funcs"] for v in active.values() if v["route"] == "include-asm-in-place")
out["summary"]["route_tu_resplit_funcs"] = sum(
    v["asm_funcs"] for v in active.values() if v["route"] == "tu-resplit")
out["summary"]["bb2_ld_lines_changed"] = 4 * 1  # only the text1a split touches the linker script
out["summary"]["substantial_stubs"] = sum(len(v["substantial_stubs"]) for v in active.values())
out["summary"]["non_text_emitting_stubs"] = sum(len(v["non_text_emitting_stubs"]) for v in active.values())
out["summary"]["label_drift_exposure"] = {k: v["label_drift_exposure"] for k, v in active.items() if v["label_drift_exposure"]}

(ROOT / "tmp" / "resplit_map.json").write_text(json.dumps(out, indent=2) + "\n",
                                               encoding="utf-8", newline="\n")
print(json.dumps(out["summary"], indent=2))
