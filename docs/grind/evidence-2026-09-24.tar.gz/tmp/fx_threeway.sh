#!/bin/bash
# THE WORLD A/B DISCRIMINATOR: rebuilt (stock GCC 2.7.2) vs shipped (oracle) vs cc1psx (PsyQ original)
set -uo pipefail
cd "/mnt/c/Users/Trenton/Desktop/Bushido Blade 2 Decompile"
T=tmp/fx
F="-O2 -G0 -funsigned-char -quiet -mcpu=3000 -mips1 -mno-abicalls -fno-builtin -w -mel"
FPSX="-O2 -G0 -funsigned-char -quiet -mcpu=3000 -mips1 -w"
mipsel-linux-gnu-cpp -undef -lang-c -fno-builtin -Dmips -D__GNUC__=2 -D__OPTIMIZE__ \
  -D__mips__ -D__mips -Dpsx -D__psx__ -D__psx -D_PSYQ -D_MIPSEL -D_LANGUAGE_C -DLANGUAGE_C \
  tmp/fx_repro.c > $T/repro.i 2>/dev/null

tmp/ab/cc1.mixed          $F $T/repro.i -o $T/repro.rebuilt.s 2>/dev/null
tools/gcc-2.7.2/build/cc1 $F $T/repro.i -o $T/repro.shipped.s 2>/dev/null
tools/cc1psx_wrapper.sh   $FPSX < $T/repro.i > $T/repro.cc1psx.s 2>$T/psx.err
echo "cc1psx rc=$? size=$(stat -c%s $T/repro.cc1psx.s 2>/dev/null)"
head -3 $T/psx.err

python3 - <<'PY'
import re, sys
T="tmp/fx"
def funcs(path):
    out={}; cur=None
    try: lines=open(path,errors='replace').read().splitlines()
    except OSError: return out
    for l in lines:
        m=re.match(r'^\s*(r[1-5]):\s*$', l)
        if m: cur=m.group(1); out[cur]=[]; continue
        if cur is None: continue
        if re.match(r'^\s*\.(end|size)\b', l): cur=None; continue
        s=l.strip()
        if not s or s.startswith('.') or s.startswith('#') or s.endswith(':'): continue
        out[cur].append(s)
    return out
A=funcs(f"{T}/repro.rebuilt.s"); B=funcs(f"{T}/repro.shipped.s"); C=funcs(f"{T}/repro.cc1psx.s")
keys=[k for k in ("r1","r2","r3","r4","r5")]
for k in keys:
    print(f"\n===== {k}")
    for tag,d in (("rebuilt(stock)",A),("shipped(oracle)",B),("cc1psx(PsyQ)",C)):
        body=d.get(k)
        print(f"  {tag:16}: " + (" | ".join(body) if body else "<absent>"))
    def has_or(b): return b is not None and any(re.match(r'^(or|ori)\b', i) for i in b)
    print(f"  IOR present? rebuilt={has_or(A.get(k))} shipped={has_or(B.get(k))} cc1psx={has_or(C.get(k))}")
PY
