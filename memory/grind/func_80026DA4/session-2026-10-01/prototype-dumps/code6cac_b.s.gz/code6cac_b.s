	.file	1 "tmp/grind/func_80026DA4/dumps/code6cac_b.c"

 # GNU C 2.7.2 [AL 1.1, MM 40] GNU MIPS/ELF compiled by GNU C

 # Cc1 defaults:
 # -mgas

 # Cc1 arguments (-G value = 0, Cpu = 3000, ISA = 1):
 # -O2 -G0 -funsigned-char -quiet -mcpu=3000 -mips1 -mno-abicalls -fno-builtin
 # -w -mel -msoft-float -da -dumpbase -o

	.version	"01.01"
gcc2_compiled.:
 #APP
	.include "include/macro.inc"

	.section .rodata
    .include "asm/rodata/jtbl_8001042C.s"
.section .text
 #NO_APP
	.text
	.align	2
	.globl	func_80026DA4
	.type	 func_80026DA4,@function
	.ent	func_80026DA4
func_80026DA4:
	.frame	$sp,72,$31		# vars= 32, regs= 5/0, args= 16, extra= 0
	.mask	0x800f0000,-8
	.fmask	0x00000000,0
	subu	$sp,$sp,72
	sw	$16,48($sp)
	la	$16,g_practice_menu_table
	sw	$31,64($sp)
	sw	$19,60($sp)
	sw	$18,56($sp)
	.set	noreorder
	.set	nomacro
	jal	func_8002BEA0
	sw	$17,52($sp)
	.set	macro
	.set	reorder

	li	$3,-1			# 0xffffffff
	move	$19,$2
	sh	$3,D_800A3824
	lhu	$3,g_practice_menu_table+106
	li	$2,0x0000001c		# 28
	.set	noreorder
	.set	nomacro
	bne	$3,$2,.L2
	li	$2,0x0000000f		# 15
	.set	macro
	.set	reorder

	lh	$3,g_practice_menu_table+64
	li	$2,0x00000004		# 4
	.set	noreorder
	.set	nomacro
	bne	$3,$2,.L4
	li	$2,-1			# 0xffffffff
	.set	macro
	.set	reorder

	lh	$4,D_800A3876
	#nop
	.set	noreorder
	.set	nomacro
	beq	$4,$2,.L4
	sll	$2,$4,4
	.set	macro
	.set	reorder

	addu	$2,$2,$4
	sll	$2,$2,2
	addu	$2,$2,$4
	sll	$2,$2,2
	subu	$2,$2,$4
	sll	$2,$2,2
	move	$3,$16
	addu	$16,$2,$16
	.set	noreorder
	.set	nomacro
	bne	$4,$0,.L6
	move	$17,$3
	.set	macro
	.set	reorder

	addu	$17,$17,1100
.L6:
	li	$2,0x00000003		# 3
	sh	$2,646($16)
	.set	noreorder
	.set	nomacro
	j	.L53
	li	$2,0x00000004		# 4
	.set	macro
	.set	reorder

.L2:
	.set	noreorder
	.set	nomacro
	beq	$3,$2,.L7
	move	$7,$0
	.set	macro
	.set	reorder

	la	$8,Judge
	move	$6,$16
.L12:
	lw	$2,48($6)
	#nop
	andi	$2,$2,0x0020
	beq	$2,$0,.L13
	lh	$3,32($6)
	lw	$2,652($6)
	#nop
	addu	$2,$2,$3
	sw	$2,652($6)
.L13:
	lw	$2,48($6)
	#nop
	andi	$2,$2,0x0040
	beq	$2,$0,.L14
	lh	$3,32($6)
	lw	$2,652($6)
	#nop
	addu	$2,$2,$3
	sw	$2,652($6)
.L14:
	lhu	$3,106($6)
	#nop
	addu	$2,$3,-29
	sltu	$2,$2,2
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L16
	andi	$3,$3,0xffff
	.set	macro
	.set	reorder

	li	$2,0x00000020		# 32
	bne	$3,$2,.L11
.L16:
	lw	$3,44($6)
	#nop
	andi	$2,$3,0x1000
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L18
	li	$5,0x00000001		# 1
	.set	macro
	.set	reorder

	andi	$2,$3,0x4000
	sltu	$2,$0,$2
	subu	$5,$0,$2
.L18:
	lh	$2,458($6)
	#nop
	addu	$2,$2,1024
	andi	$2,$2,0x0fff
	sll	$2,$2,1
	addu	$2,$2,$8
	lh	$2,0($2)
	#nop
	mult	$2,$5
	mflo	$2
	#nop
	#nop
	.set	noreorder
	.set	nomacro
	bgez	$2,.L56
	sra	$4,$2,8
	.set	macro
	.set	reorder

	addu	$2,$2,255
	sra	$4,$2,8
.L56:
	lw	$3,308($6)
	lhu	$2,458($6)
	subu	$3,$3,$4
	andi	$2,$2,0x0fff
	sll	$2,$2,1
	addu	$2,$2,$8
	sw	$3,308($6)
	lh	$2,0($2)
	#nop
	mult	$2,$5
	mflo	$3
	#nop
	#nop
	bgez	$3,.L22
	addu	$3,$3,255
.L22:
	lw	$2,316($6)
	sra	$3,$3,8
	addu	$2,$2,$3
	sw	$2,316($6)
.L11:
	addu	$7,$7,1
	slt	$2,$7,2
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L12
	addu	$6,$6,1100
	.set	macro
	.set	reorder

	la	$16,g_practice_menu_table
	lhu	$2,D_800A389C
	#nop
	addu	$2,$2,1
	sh	$2,D_800A389C
	sll	$2,$2,16
	sra	$2,$2,16
	slt	$2,$2,43
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L24
	addu	$17,$16,1100
	.set	macro
	.set	reorder

	lw	$4,g_practice_menu_table+652
	lw	$3,g_practice_menu_table+1752
	#nop
	slt	$2,$3,$4
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L25
	li	$2,0x00000003		# 3
	.set	macro
	.set	reorder

	lhu	$3,g_practice_menu_table+1206
	sh	$2,g_practice_menu_table+646
	li	$2,0x00000004		# 4
	sh	$2,g_practice_menu_table+1746
	li	$2,0x00000021		# 33
	.set	noreorder
	.set	nomacro
	bne	$3,$2,.L57
	li	$4,0x00000001		# 1
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_80027A58
	move	$4,$17
	.set	macro
	.set	reorder

	li	$4,0x00000001		# 1
.L57:
	li	$5,0x0000002d		# 45
	.set	noreorder
	.set	nomacro
	j	.L54
	addu	$6,$16,1344
	.set	macro
	.set	reorder

.L25:
	slt	$2,$4,$3
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L27
	li	$2,0x00000003		# 3
	.set	macro
	.set	reorder

	lhu	$3,g_practice_menu_table+106
	sh	$2,g_practice_menu_table+1746
	li	$2,0x00000004		# 4
	sh	$2,g_practice_menu_table+646
	li	$2,0x00000021		# 33
	.set	noreorder
	.set	nomacro
	bne	$3,$2,.L58
	move	$4,$0
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	jal	func_80027A58
	move	$4,$16
	.set	macro
	.set	reorder

	move	$4,$0
.L58:
	li	$5,0x0000002d		# 45
	addu	$6,$16,244
.L54:
	.set	noreorder
	.set	nomacro
	jal	func_80032854
	move	$7,$0
	.set	macro
	.set	reorder

.L27:
	sw	$0,652($17)
	sw	$0,652($16)
	sh	$0,D_800A389C
.L24:
	slt	$2,$19,201
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L59
	li	$2,0x00000002		# 2
	.set	macro
	.set	reorder

	lw	$3,248($16)
	lw	$2,248($17)
	#nop
	subu	$2,$3,$2
	bgez	$2,.L32
	subu	$2,$0,$2
.L32:
	slt	$2,$2,1000
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L31
	li	$2,0x00000002		# 2
	.set	macro
	.set	reorder

.L59:
	sh	$2,646($16)
	sh	$2,646($17)
.L31:
	lhu	$3,106($16)
	li	$2,0x0000001d		# 29
	bne	$3,$2,.L7
	lw	$2,44($16)
	#nop
	andi	$2,$2,0x8000
	beq	$2,$0,.L35
	lw	$2,44($17)
	#nop
	andi	$2,$2,0x8000
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L36
	li	$2,0x00000002		# 2
	.set	macro
	.set	reorder

	.set	noreorder
	.set	nomacro
	j	.L53
	sh	$2,646($16)
	.set	macro
	.set	reorder

.L36:
	sh	$2,646($16)
	.set	noreorder
	.set	nomacro
	j	.L53
	li	$2,0x00000005		# 5
	.set	macro
	.set	reorder

.L35:
	lw	$2,44($17)
	#nop
	andi	$2,$2,0x8000
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L7
	li	$2,0x00000005		# 5
	.set	macro
	.set	reorder

	sh	$2,646($16)
	li	$2,0x00000002		# 2
.L53:
	sh	$2,646($17)
.L7:
	la	$16,g_practice_menu_table
.L4:
	lh	$2,D_800A3910
	addu	$17,$16,1100
	.set	noreorder
	.set	nomacro
	bne	$2,$0,.L40
	move	$3,$2
	.set	macro
	.set	reorder

	lhu	$2,g_practice_menu_table+106
	#nop
	addu	$3,$2,-15
	sltu	$2,$3,19
	.set	noreorder
	.set	nomacro
	beq	$2,$0,.L41
	sll	$2,$3,2
	.set	macro
	.set	reorder

	lw	$2,.L49($2)
	#nop
	j	$2
.section	.rodata
	.align	3
	.align	2
.L49:
	.word	.L42
	.word	.L41
	.word	.L41
	.word	.L41
	.word	.L41
	.word	.L41
	.word	.L41
	.word	.L41
	.word	.L41
	.word	.L41
	.word	.L41
	.word	.L41
	.word	.L41
	.word	.L43
	.word	.L46
	.word	.L47
	.word	.L48
	.word	.L45
	.word	.L44
	.text
.L42:
	.set	noreorder
	.set	nomacro
	j	.L41
	li	$18,-1			# 0xffffffff
	.set	macro
	.set	reorder

.L43:
	.set	noreorder
	.set	nomacro
	j	.L41
	move	$18,$0
	.set	macro
	.set	reorder

.L44:
	.set	noreorder
	.set	nomacro
	j	.L41
	li	$18,0x00000001		# 1
	.set	macro
	.set	reorder

.L45:
	.set	noreorder
	.set	nomacro
	j	.L41
	li	$18,0x00000002		# 2
	.set	macro
	.set	reorder

.L46:
	.set	noreorder
	.set	nomacro
	j	.L41
	li	$18,0x00000003		# 3
	.set	macro
	.set	reorder

.L47:
	.set	noreorder
	.set	nomacro
	j	.L41
	li	$18,0x00000004		# 4
	.set	macro
	.set	reorder

.L48:
	li	$18,0x00000005		# 5
.L41:
	.set	noreorder
	.set	nomacro
	bltz	$18,.L52
	sll	$7,$18,2
	.set	macro
	.set	reorder

	lw	$4,244($16)
	lw	$2,244($17)
	#nop
	addu	$4,$4,$2
	srl	$2,$4,31
	addu	$4,$4,$2
	sra	$4,$4,1
	sw	$4,16($sp)
	lw	$3,220($16)
	lw	$2,220($17)
	#nop
	addu	$3,$3,$2
	srl	$2,$3,31
	addu	$3,$3,$2
	sra	$3,$3,1
	sw	$3,20($sp)
	lw	$5,252($16)
	lw	$2,252($17)
	#nop
	addu	$5,$5,$2
	srl	$2,$5,31
	addu	$5,$5,$2
	sra	$5,$5,1
	sw	$5,24($sp)
	lhu	$2,472($16)
	#nop
	andi	$2,$2,0x0fff
	sll	$2,$2,1
	lh	$6,Judge($2)
	lh	$2,D_8008EB54($7)
	#nop
	mult	$6,$2
	mflo	$9
	#nop
	#nop
	sra	$2,$9,12
	addu	$4,$4,$2
	sw	$4,16($sp)
	lh	$2,D_8008EB54+2($7)
	#nop
	addu	$3,$3,$2
	sw	$3,20($sp)
	lh	$2,472($16)
	#nop
	addu	$2,$2,1024
	andi	$2,$2,0x0fff
	sll	$2,$2,1
	lh	$3,Judge($2)
	lh	$2,D_8008EB54($7)
	#nop
	mult	$3,$2
	addu	$6,$sp,16
	move	$4,$0
	mflo	$9
	#nop
	#nop
	sra	$2,$9,12
	addu	$5,$5,$2
	sw	$5,24($sp)
	lbu	$5,D_8008EB6C($18)
	.set	noreorder
	.set	nomacro
	jal	func_80032854
	move	$7,$0
	.set	macro
	.set	reorder

	j	.L52
.L40:
	addu	$2,$3,-1
	sh	$2,D_800A3910
.L52:
	lw	$31,64($sp)
	lw	$19,60($sp)
	lw	$18,56($sp)
	lw	$17,52($sp)
	lw	$16,48($sp)
	addu	$sp,$sp,72
	j	$31
	.end	func_80026DA4
.Lfe1:
	.size	 func_80026DA4,.Lfe1-func_80026DA4
 #APP
	.section .rodata
    .include "asm/rodata/D_80010478.s"
.section .text
	.ident	"GCC: (GNU) 2.7.2"
